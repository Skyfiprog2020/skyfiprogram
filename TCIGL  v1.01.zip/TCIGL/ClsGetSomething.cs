﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;

namespace TCIGL
{
    class ClsGetSomething
    {
        public string plsvarCAdress;
        public string plsvarCustNameAdress, plsSMCode, plsTerm, plsSPCode, plsvarCreditLimit, plsvarCollectCode;
        public string plsdefdate;
        public string plsPA, plsAT;
        public string plsBeginDate;
        public string plsEndDate;
        public string plsUsageCode;
        public string plsVersionGo;
       // public string plvarbalance;
        public string plvarSPPC, plsvarItem, plvarVC, plsvarUM, plsvarStockNo, plsvarSize, plsvarDesign;
        public string plvarUCost;
        public string plsVATRate;
        public string plsUCost, plsUVAT;
        public string plsxstrDate, plsystrDate, plsxstrtxtCustName, plsystrtxtCustName, plsxstrtxtcamount; //
        public string plsystrtxtcamount, plsxstramtinword, plsystramtinword, plsXCompDoc, plsYCompDoc, plssizefont, plsFontName;
        public string plsavailbal, plsReceiveBal, plsCreditStatus;

        SqlConnection myconnection;
        SqlDataReader dr;
        SqlCommand mycommand;
        ClsGetConnection ClsGetConnection1 = new ClsGetConnection(); 

        public void ClsGetBranchAddress(string strCNCode)
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();

                mycommand = new SqlCommand("SELECT CAddress FROM tblCompanyName WHERE CNCode='" + strCNCode + "'", myconnection);
                    dr = mycommand.ExecuteReader();
                    while (dr.Read())
                    {
                        plsvarCAdress = dr["CAddress"].ToString();
                    }
                    myconnection.Close();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                //dr.Close();
                myconnection.Close();
            }
    }

        
        public void ClsGetDefaultDate()
        {
            DateTime VarToday = DateTime.Today;
            plsdefdate = String.Format("{0:MM/dd/yyyy}", VarToday);
        }

        public void ClsGetAT(string strPA)
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();

                mycommand = new SqlCommand("SELECT AT FROM ViewPA WHERE PA='" + strPA + "'", myconnection);
                dr = mycommand.ExecuteReader();
                while (dr.Read())
                {
                    plsAT = dr["AT"].ToString();
                }
                myconnection.Close();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                //dr.Close();
                myconnection.Close();
            }
        }

        public void ClsGetChartData(string strUsageCode)
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();

                mycommand = new SqlCommand("SELECT PA, AT FROM ViewPA WHERE UsageCode='" + strUsageCode + "'", myconnection);
                dr = mycommand.ExecuteReader();
                while (dr.Read())
                {
                    plsPA = dr["PA"].ToString();
                    plsAT = dr["AT"].ToString();
                }
                myconnection.Close();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                //dr.Close();
                myconnection.Close();
            }
        }
        public void ClsGetSecureDate()
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();

                mycommand = new SqlCommand("SELECT * FROM tblSecurityDate", myconnection);
                dr = mycommand.ExecuteReader();
                while (dr.Read())
                {
                    DateTime dtBeginDate = Convert.ToDateTime(dr["BeginDate"].ToString());
                    DateTime dtEndDate = Convert.ToDateTime(dr["EndDate"].ToString());
                    plsBeginDate = String.Format("{0:MM/dd/yyyy}", dtBeginDate);
                    plsEndDate = String.Format("{0:MM/dd/yyyy}", dtEndDate);
                }
                myconnection.Close();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                //dr.Close();
                myconnection.Close();
            }
        }

        public void ClsGetUsageCode(string varPA)
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = new SqlCommand("SELECT * FROM ViewPA WHERE PA ='" + varPA + "'", myconnection);
                dr = mycommand.ExecuteReader();
                while (dr.Read())
                {
                    plsUsageCode = dr["UsageCode"].ToString();
                }
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                //dr.Close();
                myconnection.Close();
            }
        }

        public void ClsConfirmVersionNum()
        {
            try
            {
                string vnumdb;
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = new SqlCommand("Select VersionNum FROM tblCover", myconnection);
                dr = mycommand.ExecuteReader();
                while (dr.Read())
                {
                    vnumdb = dr["VersionNum"].ToString();
                    if (vnumdb == "6")
                    {
                        plsVersionGo = "Yes";
                    }
                    else
                    {
                        plsVersionGo = "No";
                    }
                }
                dr.Close();
                myconnection.Close();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                //dr.Close();
                myconnection.Close();
            }
        }

        public void ClsGetCustData(string strControlNo)
        {
            try
            {

                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = new SqlCommand("Select SMCode, Term, SPCode, Address, Creditlimit, CollectCode FROM tblCustomer WHERE ControlNo = '" + strControlNo + "'", myconnection);
                dr = mycommand.ExecuteReader();
                while (dr.Read())
                {
                    plsSMCode = dr["SMCode"].ToString();
                    plsTerm = dr["Term"].ToString();
                    plsSPCode = dr["SPCode"].ToString();
                    plsvarCustNameAdress = dr["Address"].ToString();
                    plsvarCreditLimit = dr["CreditLimit"].ToString();
                    plsvarCollectCode = dr["CollectCode"].ToString();
                }

                dr.Close();
                myconnection.Close();

            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                //dr.Close();
                myconnection.Close();
            }
        }

        public void ClsGetProductDetails(string strStockNumber)
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = new SqlCommand("Select *  FROM tblStocks WHERE StockNumber ='" + strStockNumber + "'", myconnection);
                dr = mycommand.ExecuteReader();
                while (dr.Read())
                {
                    plsvarItem = dr["StockDesc"].ToString();
                    plvarUCost = dr["UCost"].ToString();
                    plvarVC = dr["VC"].ToString();
                    plvarSPPC = dr["SellingPrice"].ToString();
                    plsvarUM = dr["UM"].ToString();
                    plsvarStockNo = dr["StockNumber"].ToString();
                    plsvarSize = dr["Size"].ToString();
                    plsvarDesign = dr["Design"].ToString();
                }

                dr.Close();
                myconnection.Close();

            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                //dr.Close();
                myconnection.Close();
            }
        }

   
 
        public void ClsGetVATRate()
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = new SqlCommand("Select VAT FROM tblVat", myconnection);
                dr = mycommand.ExecuteReader();
                while (dr.Read())
                {
                    plsVATRate = (Convert.ToDouble(dr["VAT"]) + 1).ToString();
                }
                dr.Close();
                myconnection.Close();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                //dr.Close();
                myconnection.Close();
            }
        }

        public void ClsPDUCost(double dblTotalCost, double dbltotalVAT, double dblPIn)
        {
            double dblUCost = dblTotalCost / dblPIn;
            double dblUVAT = dbltotalVAT / dblPIn;
            plsUCost = dblUCost.ToString("N2");
            plsUVAT = dblUVAT.ToString("N2");
        }

        public void ClsGetCheckWriterCheckUp(string strBankCode)
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL(); myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();

                mycommand = new SqlCommand("SELECT * FROM tblCheckWriterSetup WHERE BankCode='" + strBankCode + "'", myconnection);
                dr = mycommand.ExecuteReader();
                while (dr.Read())
                {
                    plsxstrDate = dr["XDate"].ToString();
                    plsystrDate = dr["YDate"].ToString();
                    plsxstrtxtCustName = dr["XCustName"].ToString();
                    plsystrtxtCustName = dr["YCustName"].ToString();
                    plsxstrtxtcamount = dr["XCAmount"].ToString();
                    plsystrtxtcamount = dr["YCAmount"].ToString();
                    plsxstramtinword = dr["XAmtInWord"].ToString();
                    plsystramtinword = dr["YAmtInWord"].ToString();
                    plsXCompDoc = dr["XCompDoc"].ToString();
                    plsYCompDoc = dr["YCompDoc"].ToString();
                    plssizefont = dr["SizeFont"].ToString();
                    plsFontName = dr["FontName"].ToString();

                }
                dr.Close();
                myconnection.Close();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                //dr.Close();
                myconnection.Close();
            }
        }

        public void ClsGetReceiveBal(string strControlNo, string strCNCode)
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();

                if (new Clsexist().RecordExists(ref myconnection, "SELECT ReceiveBal FROM ViewSOSaveReceiveBal WHERE ControlNo='" + strControlNo + "' AND CNCode='" + strCNCode + "'"))
                {
                    mycommand = new SqlCommand("SELECT ReceiveBal FROM ViewSOSaveReceiveBal WHERE ControlNo='" + strControlNo + "' AND CNCode='" + strCNCode + "'", myconnection);
                    dr = mycommand.ExecuteReader();
                    while (dr.Read())
                    {
                        plsReceiveBal = dr["ReceiveBal"].ToString();
                    }
                }
                else
                {
                    plsReceiveBal = "0";
                }
                if (plsReceiveBal == "0")
                {
                    myconnection.Close();
                }
                else
                {
                    dr.Close();
                    myconnection.Close();
                }
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                myconnection.Close();
            }
        }

        public void ClsGetOverdue(string strControlNo, DateTime DTEnterDate, string strCNCode)
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();

                mycommand = new SqlCommand("usp_Overdue", myconnection);
                mycommand.CommandType = CommandType.StoredProcedure;

                mycommand.Parameters.Add("@Paramenterdate", SqlDbType.DateTime).Value = DTEnterDate;
                mycommand.Parameters.Add("@ParamControlNo", SqlDbType.VarChar).Value = strControlNo;
                mycommand.Parameters.Add("@ParamCNCode", SqlDbType.VarChar).Value = strCNCode;
                mycommand.Parameters.Add("@DecStatus", System.Data.SqlDbType.Int).Direction = System.Data.ParameterDirection.ReturnValue;
                mycommand.ExecuteNonQuery();

                plsCreditStatus = mycommand.Parameters["@DecStatus"].Value.ToString();
                //string CRStatus = mycommand.Parameters["@DecStatus"].Value.ToString();
                //if (CRStatus=="2")
                //{
                //    plsCreditStatus = "S";
                //}

                myconnection.Close();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                myconnection.Close();
            }
        }

        public void ClsGetAvailSaleBal(string strStockNumber, string strWHCode, string strCNCode)
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();

                string CheckNoTransact = string.Format("SELECT Count(*) FROM ViewInvBalServed WHERE StockNumber = '" + strStockNumber + "' AND WHCode='" + strWHCode + "' AND CNCode= '" + strCNCode + "'");
                SqlCommand com = new SqlCommand(CheckNoTransact, myconnection);
                int CountData = int.Parse(com.ExecuteScalar().ToString());
                string strServed;
                if (CountData > 0)
                {
                    strServed = "SELECT SUM(ConvertedQty) FROM ViewInvBalServed WHERE StockNumber = '" + strStockNumber + "' ";
                    strServed += " AND WHCode='" + strWHCode + "' AND CNCode= '" + strCNCode + "'";
                }
                else
                {
                    strServed = string.Format("SELECT Count(*) FROM ViewInvBalServed WHERE StockNumber = '" + strStockNumber + "' AND WHCode='" + strWHCode + "' AND CNCode= '" + strCNCode + "'");
                }
                SqlCommand comServed = new SqlCommand(strServed, myconnection);
                double TotalServed = double.Parse(comServed.ExecuteScalar().ToString());
                myconnection.Close();
                plsavailbal = (TotalServed).ToString();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                myconnection.Close();
            }
        }

 
    }
}
