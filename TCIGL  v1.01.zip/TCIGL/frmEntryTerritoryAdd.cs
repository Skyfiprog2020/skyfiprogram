﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TCIGL
{
    public partial class frmEntryTerritoryAdd : Form
    {
        SqlConnection myconnection;
        SqlCommand mycommand;
        BindingSource dbind = new BindingSource();
        ClsAutoNumber ClsAutoNumber1 = new ClsAutoNumber();
        ClsPermission ClsPermission1 = new ClsPermission();
        ClsGetConnection ClsGetConnection1 = new ClsGetConnection(); 

        public frmEntryTerritoryAdd()
        {
            InitializeComponent();
        }
   
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            Save();
        }

        private void Save()
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                if (new ClsValidation().emptytxt(txtTDesc.Text))
                {
                    myconnection.Close();
                    MessageBox.Show("Please complete your entry", "GL");
                    txtTDesc.Focus();
                }
                else if (new Clsexist().RecordExists(ref myconnection, "SELECT TDesc FROM tblTerritory WHERE TDesc ='" + txtTDesc.Text + "'"))
                {
                    myconnection.Close();
                    MessageBox.Show("Duplicate entry", "GL");
                    txtTDesc.Focus();
                }
                else
                {
                    ClsAutoNumber1.TerritoryAutoNum();
                    txtTCode.Text = (ClsAutoNumber1.plsnumber);
                    string sqlstatement;
                    sqlstatement = "INSERT INTO tblTerritory (TCode, TDesc) Values (@_TCode, @_TDesc)";
                    mycommand = new SqlCommand(sqlstatement, myconnection);
                    mycommand.Parameters.Add("_TCode", SqlDbType.VarChar).Value = txtTCode.Text;
                    mycommand.Parameters.Add("_TDesc", SqlDbType.VarChar).Value = txtTDesc.Text;
                    int n2 = mycommand.ExecuteNonQuery();

                    myconnection.Close();
                    txtTDesc.Text = "";
                    txtTDesc.Focus();

                    ClsAutoNumber1.TerritoryAutoNum();
                    txtTCode.Text = (ClsAutoNumber1.plsnumber);
                }
            }
            catch
            {
                MessageBox.Show("Busy, please click OK", "GL");
                Save();
            }
            finally
            {
                //               dr.Close();
                myconnection.Close();
            }

        }
        private void frmEntryTerritoryAdd_Load(object sender, EventArgs e)
        {
            ClsPermission1.ClsObjects(this.Text);
            if (new ClsValidation().emptytxt(ClsPermission1.plstxtObject))
            {
                MessageBox.Show("You do not have necessary permission to open this file", "GL");
                this.Close();
            }
            else
            {
                ClsAutoNumber1.TerritoryAutoNum();
                txtTCode.Text = (ClsAutoNumber1.plsnumber);
            }
        }

        private void nextfieldenter1(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.Equals(Keys.Enter))
            {
                SendKeys.Send("{TAB}");
            }
            else if ((e.KeyCode.Equals(Keys.Up)) || (e.KeyCode.Equals(Keys.Left)))
            {
                SendKeys.Send("+{TAB}");
            }
            else if ((e.KeyCode.Equals(Keys.Down)) || (e.KeyCode.Equals(Keys.Right)))
            {
                SendKeys.Send("{TAB}");
            }
        }

       
     

    
    }
}
