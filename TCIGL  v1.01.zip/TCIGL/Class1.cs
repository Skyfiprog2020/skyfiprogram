﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BALCORGL
{
    class Class1
    {
    }
}
