﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TCIGL
{
    public partial class frmTransactEntryCI : Form
    {
        ClsBuildComboBox ClsBuildComboBox1 = new ClsBuildComboBox();
        ClsGetSomething ClsGetSomething1 = new ClsGetSomething();
        ClsVariousFormula ClsVariousFormula1 = new ClsVariousFormula();
        ClsDefaultBranch ClsDefaultBranch1 = new ClsDefaultBranch();
        ClsBuildEntryComboBox ClsBuildEntryComboBox1 = new ClsBuildEntryComboBox();
        ClsGetRate ClsGetRate1 = new ClsGetRate();
        public frmTransactEntryCI()
        {
            InitializeComponent();
        }

        private void buildcboStocks()
        {
            cboStockNumber.DataSource = null;
            ClsBuildComboBox1.ARLSN.Clear();
            ClsBuildComboBox1.ClsBuildStocks("3", (Convert.ToBoolean(cbProductCode.CheckState)));
            this.cboStockNumber.DataSource = (ClsBuildComboBox1.ARLSN);
            this.cboStockNumber.DisplayMember = "Display";
            this.cboStockNumber.ValueMember = "Value";
        }

        //private void buildcboStocksCode()
        //{
        //    cboStockNumber.DataSource = null;
        //    ClsBuildComboBox1.ARLSNCode.Clear();
        //    ClsBuildComboBox1.ClsBuildStocksCode("3");
        //    this.cboStockNumber.DataSource = (ClsBuildComboBox1.ARLSNCode);
        //    this.cboStockNumber.DisplayMember = "Display";
        //    this.cboStockNumber.ValueMember = "Value";
        //}
        private void frmSalesEntry_Load(object sender, EventArgs e)
        {
            buildcboStocks();
            cboStockNumber.SelectedValue = "";
        }

        private void cboStockNumber_Validating(object sender, CancelEventArgs e)
        {
                if (new ClsValidation().emptytxt(cboStockNumber.Text))
                {
                }
                else if (cboStockNumber.Text != null && cboStockNumber.SelectedValue == null)
                {
                    MessageBox.Show("Not found", "GL");
                    cboStockNumber.Focus();
                }
                else
                {
                    getproductdetails();
                    getproductBalance();
                }
        }


        private void getproductdetails()
        {
            ClsGetSomething1.ClsGetProductDetails(cboStockNumber.SelectedValue.ToString());
            txtUPCS.Text = Convert.ToDouble(ClsGetSomething1.plvarSPPC).ToString("N2");
            txtCost.Text = Convert.ToDouble(ClsGetSomething1.plvarUCost).ToString("N2");
            //ClsGetRate1.ClsGetAveCost(cboStockNumber.SelectedValue.ToString());
            //txtCost.Text = Convert.ToDouble(ClsGetRate1.plsAveCostCase).ToString("N2");

            //txtCost.Text = Convert.ToDouble(ClsGetSomething1.plvarUCost).ToString("N2");
        }

        private void getproductBalance()
        {
            ClsGetSomething1.ClsGetAvailSaleBal(cboStockNumber.SelectedValue.ToString(), frmVoucherCI.glblcboWHCode.SelectedValue.ToString(), ClsDefaultBranch1.plsvardb);
            txtBalance.Text = double.Parse(ClsGetSomething1.plsavailbal).ToString("N2");
        }

    

        private void txtQty_Validating(object sender, CancelEventArgs e)
        {
            if (new ClsValidation().isDouble(txtQty.Text) == true)
            {
                MessageBox.Show("Invalid Number", "GL");
                txtQty.Focus();
            }
            else
            {
                txtQty.Text = Convert.ToDouble(txtQty.Text).ToString("N2");
            }
      }

     

        private void txtD1_Validating(object sender, CancelEventArgs e)
        {
            string numStringD1 = txtD1.Text.Replace(System.Globalization.CultureInfo.CurrentCulture.NumberFormat.PercentSymbol, "");
            double varfloatD1 = (float)(System.Convert.ToDouble(numStringD1) / 100);

            if (new ClsValidation().isDouble(numStringD1) == true)
            {
                MessageBox.Show("Invalid Number", "GL");
                txtD1.Focus();
            }
            else
            {
                txtD1.Text = Convert.ToDouble(varfloatD1).ToString("0.0%");
            }
        }

        private void txtPDisct_Validating(object sender, CancelEventArgs e)
        {
            if (new ClsValidation().isDouble(txtPDisct.Text) == true)
            {
                MessageBox.Show("Invalid Number", "GL");
                txtPDisct.Focus();
            }
            else
            {
                txtPDisct.Text = Convert.ToDouble(txtPDisct.Text).ToString("N2");
            }
        }

        private void savetodgv()
        {
            if (new ClsValidation().emptytxt(cboStockNumber.Text))
            {
                MessageBox.Show("Product Description is empty", "GL");
                cboStockNumber.Focus();
            }
            else if (double.Parse(txtQty.Text) == 0)
            {
                MessageBox.Show("Quantity  is zero", "GL");
                txtQty.Focus();
            }
            else if (double.Parse(txtBalance.Text) < double.Parse(txtQty.Text))
            {
                MessageBox.Show("Quantity ordered is greater than inventory balance", "GL");
                cboStockNumber.Focus();
            }
            //else if (double.Parse(txtCost.Text) == 0)
            //{
            //    MessageBox.Show("Cost is zero", "GL");
            //    cboStockNumber.Focus();
            //}
            else if (double.Parse(txtUPCS.Text) == 0)
            {
                MessageBox.Show("Please check selling price", "GL");
                cboStockNumber.Focus();
            }
            else 
            {
                string numStringD1 = txtD1.Text.Replace(System.Globalization.CultureInfo.CurrentCulture.NumberFormat.PercentSymbol, "");
                float varfloatD1 = (float)(System.Convert.ToDouble(numStringD1) / 100);
                string numStringD2 = txtD2.Text.Replace(System.Globalization.CultureInfo.CurrentCulture.NumberFormat.PercentSymbol, "");
                float varfloatD2 = (float)(System.Convert.ToDouble(numStringD2) / 100);
                string numStringD3 = txtD3.Text.Replace(System.Globalization.CultureInfo.CurrentCulture.NumberFormat.PercentSymbol, "");
                float varfloatD3 = (float)(System.Convert.ToDouble(numStringD3) / 100);
                double vargrosssales = (Convert.ToDouble(txtQty.Text) * Convert.ToDouble(txtUPCS.Text));
                double varTotalCost = (Convert.ToDouble(txtQty.Text) * Convert.ToDouble(txtCost.Text));
                ClsVariousFormula1.getActDisct(vargrosssales, varfloatD1, varfloatD2, varfloatD3);
                txtActDisct.Text = Convert.ToDouble(ClsVariousFormula1.pldtotalactdisc).ToString("N2");
                ClsGetSomething1.ClsGetVATRate();
                ClsVariousFormula1.getVATAmt(Convert.ToBoolean(cbVAT.CheckState), Convert.ToDouble(ClsGetSomething1.plsVATRate), vargrosssales - (Convert.ToDouble(txtActDisct.Text) + Convert.ToDouble(txtPDisct.Text)));
                string transactVATAmt = Convert.ToDouble(ClsVariousFormula1.pldbVAT).ToString("N2");
                double varNetSales = vargrosssales - (double.Parse(txtActDisct.Text) + double.Parse(txtPDisct.Text)+double.Parse(transactVATAmt));
                frmVoucherCI.glbldgv2.Rows.Add(varfloatD1, cboStockNumber.SelectedValue, cboStockNumber.Text, txtQty.Text, txtUPCS.Text, txtActDisct.Text, txtPDisct.Text, transactVATAmt, varNetSales.ToString("N2"), varTotalCost.ToString("N2"), frmVoucherCI.glblcboWHCode.SelectedValue.ToString());
                
            }
      
            txtQty.Text = "0.00";
            txtD1.Text = "0.0%";
            txtPDisct.Text = "0.00";
            cboStockNumber.SelectedValue = "";
            cboStockNumber.Focus();
            txtUPCS.Text = "0.00";
            txtBalance.Text = "0.00";
            dgv2total();
        }

 
        private void dgv2total()
        {
            double vartxtTotCost = 0.00;
            double vartxtTotNet = 0.00;
            double vartxtTotDisct = 0.00;
            double vartxtTotVAT = 0;
            {
                for (int x = 0; x < frmVoucherCI.glbldgv2.Rows.Count - 1; x++)
                {
                    vartxtTotCost += double.Parse(frmVoucherCI.glbldgv2.Rows[x].Cells[9].FormattedValue.ToString());
                }

                for (int x = 0; x < frmVoucherCI.glbldgv2.Rows.Count - 1; x++)
                {
                    vartxtTotNet += double.Parse(frmVoucherCI.glbldgv2.Rows[x].Cells[8].FormattedValue.ToString());
                }

                for (int x = 0; x < frmVoucherCI.glbldgv2.Rows.Count - 1; x++)
                {
                    string vartxtD1 = frmVoucherCI.glbldgv2.Rows[x].Cells[5].FormattedValue.ToString();
                    string vartxtD2 = frmVoucherCI.glbldgv2.Rows[x].Cells[6].FormattedValue.ToString();
                    vartxtTotDisct += double.Parse(vartxtD1) + double.Parse(vartxtD2);
                }

                for (int x = 0; x < frmVoucherCI.glbldgv2.Rows.Count - 1; x++)
                {
                    vartxtTotVAT += double.Parse(frmVoucherCI.glbldgv2.Rows[x].Cells[7].FormattedValue.ToString());
                }

                frmVoucherCI.glbltxtTotCost.Text = vartxtTotCost.ToString("N2");
                frmVoucherCI.glbltxtTotNet.Text = (vartxtTotNet - double.Parse(frmVoucherCI.glbltxtOverAllDisct.Text)).ToString("N2");
                frmVoucherCI.glbltxtTotDisct.Text = (vartxtTotDisct + double.Parse(frmVoucherCI.glbltxtOTDisct.Text)).ToString("N2");
                //frmVoucherCI.glbltxtTotVAT.Text = vartxtTotVAT.ToString("N2");
                frmVoucherCI.glbltxtTReceivable.Text = (vartxtTotNet - double.Parse(frmVoucherCI.glbltxtOverAllDisct.Text)).ToString("N2");
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            SendtoBackEntry();
        }
        private void SendtoBackEntry()
        {
            this.Hide();
            //this.SendToBack();
            cboStockNumber.Focus();
            frmVoucherCI.glblbtnSave.Focus();
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            savetodgv();
        }

        private void frmSalesEntry_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                SendtoBackEntry();
            }

        }

        private void txtD2_Validating(object sender, CancelEventArgs e)
        {
            string numStringD2 = txtD2.Text.Replace(System.Globalization.CultureInfo.CurrentCulture.NumberFormat.PercentSymbol, "");
            double varfloatD2 = (float)(System.Convert.ToDouble(numStringD2) / 100);

            if (new ClsValidation().isDouble(numStringD2) == true)
            {
                MessageBox.Show("Invalid Number", "GL");
                txtD2.Focus();
            }
            else
            {
                txtD2.Text = Convert.ToDouble(varfloatD2).ToString("0.0%");
            }
        }

        private void txtD3_Validating(object sender, CancelEventArgs e)
        {
            string numStringD3 = txtD3.Text.Replace(System.Globalization.CultureInfo.CurrentCulture.NumberFormat.PercentSymbol, "");
            double varfloatD3 = (float)(System.Convert.ToDouble(numStringD3) / 100);

            if (new ClsValidation().isDouble(numStringD3) == true)
            {
                MessageBox.Show("Invalid Number", "GL");
                txtD3.Focus();
            }
            else
            {
                txtD3.Text = Convert.ToDouble(varfloatD3).ToString("0.0%");
            }
        }

        private void nextfieldenter1(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.Equals(Keys.Enter))
            {
                SendKeys.Send("{TAB}");
            }
            else if ((e.KeyCode.Equals(Keys.Up)) || (e.KeyCode.Equals(Keys.Left)))
            {
                SendKeys.Send("+{TAB}");
            }
            else if ((e.KeyCode.Equals(Keys.Down)) || (e.KeyCode.Equals(Keys.Right)))
            {
                SendKeys.Send("{TAB}");
            }

        }

        private void nextfieldenter2(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.Equals(Keys.Enter))
            {
                SendKeys.Send("{TAB}");
            }

        }

        private void txtUPCS_Validating(object sender, CancelEventArgs e)
        {
            if (new ClsValidation().isDouble(txtUPCS.Text) == true)
            {
                MessageBox.Show("Invalid Number", "GL");
                txtUPCS.Focus();
            }
            else
            {
                txtUPCS.Text = Double.Parse(txtUPCS.Text).ToString("N2");
            }

        }

        private void cbProductCode_CheckedChanged(object sender, EventArgs e)
        {
            buildcboStocks();
        }

    }
}
