﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using CrystalDecisions.CrystalReports.Engine;
using System.Data.SqlClient;

namespace TCIGL
{
    public partial class frmrptPOTransaction : Form
    {
        SqlConnection myconnection;
        BindingSource dbind = new BindingSource();
        ClsCompName ClsCompName1 = new ClsCompName();
        ClsBuildComboBox ClsBuildComboBox1 = new ClsBuildComboBox();
        ClsDefaultBranch ClsDefaultBranch1 = new ClsDefaultBranch();
        ClsGetSomething ClsGetSomething1 = new ClsGetSomething();
        ClsGetConnection ClsGetConnection1 = new ClsGetConnection();
        ClsPermission ClsPermission1 = new ClsPermission(); 
        public frmrptPOTransaction()
        {
            InitializeComponent();
        }
        private void buildcboControlNo()
        {
            cboControlNo.DataSource = null;
            ClsBuildComboBox1.ARPDCN.Clear();
            ClsBuildComboBox1.ClsBuildPDControlNo();
            this.cboControlNo.DataSource = (ClsBuildComboBox1.ARPDCN);
            this.cboControlNo.DisplayMember = "Display";
            this.cboControlNo.ValueMember = "Value";
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtBeginDate_Leave(object sender, EventArgs e)
        {
            if (new ClsValidation().errordate(txtBeginDate.Text) == true)
            {
                MessageBox.Show("Invalid Date", "GL");
                txtBeginDate.Focus();
            }
        }

        private void txtEndDate_Leave(object sender, EventArgs e)
        {
            if (new ClsValidation().errordate(txtEndDate.Text) == true)
            {
                MessageBox.Show("Invalid Date", "GL");
                txtEndDate.Focus();
            }
        }

        private void btnPreview_Click(object sender, EventArgs e)
        {
            if (new ClsValidation().emptytxt(cbortprint.Text))
            {
                MessageBox.Show("Please complete your entry", "GL");
                cbortprint.Focus();
            }
            else if (new ClsValidation().emptytxt(cboCNCode.Text))
            {
                MessageBox.Show("Please complete your entry", "GL");
                cboCNCode.Focus();
            }
            else if (txtBeginDate.Text == "  /  /")
            {
                MessageBox.Show("Please complete your entry", "GL");
                txtBeginDate.Focus();
            }
            else if (txtEndDate.Text == "  /  /")
            {
                MessageBox.Show("Please complete your entry", "GL");
                txtEndDate.Focus();
            }
            else if (Convert.ToDateTime(txtBeginDate.Text) > Convert.ToDateTime(txtEndDate.Text))
            {
                MessageBox.Show("Beginning date is greater than ending date");
                txtBeginDate.Focus();
            }
            else
            {
                if (cbortprint.Text == "Purchase Order Pending - All")
                {
                    BookPOPendingAll();
                }
                else if (cbortprint.Text == "Purchase Order Pending - Supplier")
                {
                    BookPOPendingSupplier();
                }
                else if (cbortprint.Text == "Purchase Order Cancelled - All")
                {
                    BookPOCancelledAll();
                }
                else if (cbortprint.Text == "Purchase Order Cancelled - Supplier")
                {
                    BookPOCancelledSupplier();
                }

            }
        }        
        private void BookPOPendingAll()
        {
            string sqlstatement;

            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();

            sqlstatement = "SELECT * FROM ViewDetailsBookPOUnserved WHERE TDate BETWEEN '" + txtBeginDate.Text + "' And  '" + txtEndDate.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "'";

            SqlDataAdapter dscmd = new SqlDataAdapter(sqlstatement, myconnection);
            DSBooksDetail DSBooksDetail1 = new DSBooksDetail();
            dscmd.Fill(DSBooksDetail1, "ViewDetailsBookPOUnserved");
            myconnection.Close();


            CRBookPO objRpt = new CRBookPO();
            TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            ClsCompName1.ClsCompNameMain();
            vartxtcompany.Text = ClsCompName1.varcn;

            ClsCompName1.ClsCompNamebranchAddress(cboCNCode.SelectedValue.ToString());
            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            vartxtaddress.Text = ClsCompName1.plsCRaddress;

            TextObject varTextDateRange = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["TextDateRange"];
            varTextDateRange.Text = "From " + txtBeginDate.Text + " To " + txtEndDate.Text;

            objRpt.SetDataSource(DSBooksDetail1.Tables[1]);
            crystalReportViewer1.ReportSource = objRpt;
            crystalReportViewer1.Refresh();
        }
        private void BookPOPendingSupplier()
        {
            string sqlstatement;

            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();

            sqlstatement = "SELECT * FROM ViewDetailsBookPOUnserved WHERE TDate BETWEEN '" + txtBeginDate.Text + "' And  '" + txtEndDate.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "' AND ControlNo = '" + cboControlNo.SelectedValue.ToString() + "'";

            SqlDataAdapter dscmd = new SqlDataAdapter(sqlstatement, myconnection);
            DSBooksDetail DSBooksDetail1 = new DSBooksDetail();
            dscmd.Fill(DSBooksDetail1, "ViewDetailsBookPOUnserved");
            myconnection.Close();


            CRBookPO objRpt = new CRBookPO();
            TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            ClsCompName1.ClsCompNameMain();
            vartxtcompany.Text = ClsCompName1.varcn;

            ClsCompName1.ClsCompNamebranchAddress(cboCNCode.SelectedValue.ToString());
            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            vartxtaddress.Text = ClsCompName1.plsCRaddress;

            TextObject varTextDateRange = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["TextDateRange"];
            varTextDateRange.Text = "From " + txtBeginDate.Text + " To " + txtEndDate.Text;

            objRpt.SetDataSource(DSBooksDetail1.Tables[1]);
            crystalReportViewer1.ReportSource = objRpt;
            crystalReportViewer1.Refresh();
        }
        private void BookPOCancelledAll()
        {
            string sqlstatement;

            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();

            sqlstatement = "SELECT * FROM ViewDetailsBookPOCancel WHERE TDate BETWEEN '" + txtBeginDate.Text + "' And  '" + txtEndDate.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "'";

            SqlDataAdapter dscmd = new SqlDataAdapter(sqlstatement, myconnection);
            DSBooksDetail DSBooksDetail1 = new DSBooksDetail();
            dscmd.Fill(DSBooksDetail1, "ViewDetailsBookPOCancel");
            myconnection.Close();


            CRBookPO objRpt = new CRBookPO();
            TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            ClsCompName1.ClsCompNameMain();
            vartxtcompany.Text = ClsCompName1.varcn;

            ClsCompName1.ClsCompNamebranchAddress(cboCNCode.SelectedValue.ToString());
            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            vartxtaddress.Text = ClsCompName1.plsCRaddress;

            TextObject varTextDateRange = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["TextDateRange"];
            varTextDateRange.Text = "From " + txtBeginDate.Text + " To " + txtEndDate.Text;

            objRpt.SetDataSource(DSBooksDetail1.Tables[1]);
            crystalReportViewer1.ReportSource = objRpt;
            crystalReportViewer1.Refresh();
        }
        private void BookPOCancelledSupplier()
        {
            string sqlstatement;

            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();

            sqlstatement = "SELECT * FROM ViewDetailsBookPOCancel WHERE TDate BETWEEN '" + txtBeginDate.Text + "' And  '" + txtEndDate.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "' AND ControlNo = '" + cboControlNo.SelectedValue.ToString() + "'";

            SqlDataAdapter dscmd = new SqlDataAdapter(sqlstatement, myconnection);
            DSBooksDetail DSBooksDetail1 = new DSBooksDetail();
            dscmd.Fill(DSBooksDetail1, "ViewDetailsBookPOCancel");
            myconnection.Close();


            CRBookPO objRpt = new CRBookPO();
            TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            ClsCompName1.ClsCompNameMain();
            vartxtcompany.Text = ClsCompName1.varcn;

            ClsCompName1.ClsCompNamebranchAddress(cboCNCode.SelectedValue.ToString());
            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            vartxtaddress.Text = ClsCompName1.plsCRaddress;

            TextObject varTextDateRange = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["TextDateRange"];
            varTextDateRange.Text = "From " + txtBeginDate.Text + " To " + txtEndDate.Text;

            objRpt.SetDataSource(DSBooksDetail1.Tables[1]);
            crystalReportViewer1.ReportSource = objRpt;
            crystalReportViewer1.Refresh();
        }   
        private void frmrptPOTransaction_Load(object sender, EventArgs e)
        {
            ClsPermission1.ClsObjects(this.Text);
            if (new ClsValidation().emptytxt(ClsPermission1.plstxtObject))
            {
                MessageBox.Show("You do not have necessary permission to open this file", "GL");
                this.Close();
            }
            else
            {
                ClsGetSomething1.ClsGetDefaultDate();
                txtBeginDate.Text = ClsGetSomething1.plsdefdate;
                txtEndDate.Text = ClsGetSomething1.plsdefdate;
                buildcboCName();
                cboCNCode.SelectedValue = (ClsDefaultBranch1.plsvardb);
                this.WindowState = FormWindowState.Maximized;
                buildcboControlNo();
            }
        }

        private void buildcboCName()
        {
            cboCNCode.DataSource = null;
            ClsBuildComboBox1.ARBranch.Clear();
            ClsBuildComboBox1.ClsBuildBranch();
            this.cboCNCode.DataSource = (ClsBuildComboBox1.ARBranch);
            this.cboCNCode.DisplayMember = "Display";
            this.cboCNCode.ValueMember = "Value";
        }

      

        private void cboCNCode_Validating(object sender, CancelEventArgs e)
        {
            if (new ClsValidation().emptytxt(cboCNCode.Text))
            {
            }
            else if (cboCNCode.Text != null && cboCNCode.SelectedValue == null)
            {
                MessageBox.Show("Not found", "GL");
                cboCNCode.Focus();
            }
        }

        private void txtBeginDate_Leave_1(object sender, EventArgs e)
        {
            if (new ClsValidation().errordate(txtBeginDate.Text) == true)
            {
                MessageBox.Show("Invalid Date", "GL");
                txtBeginDate.Focus();
            }
        }

        private void txtEndDate_Leave_1(object sender, EventArgs e)
        {
            if (new ClsValidation().errordate(txtEndDate.Text) == true)
            {
                MessageBox.Show("Invalid Date", "GL");
                txtEndDate.Focus();
            }
        }

        private void nextfieldenter1(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.Equals(Keys.Enter))
            {
                SendKeys.Send("{TAB}");
            }
            else if ((e.KeyCode.Equals(Keys.Up)) || (e.KeyCode.Equals(Keys.Left)))
            {
                SendKeys.Send("+{TAB}");
            }
            else if ((e.KeyCode.Equals(Keys.Down)) || (e.KeyCode.Equals(Keys.Right)))
            {
                SendKeys.Send("{TAB}");
            }

        }

        private void nextfieldenter2(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.Equals(Keys.Enter))
            {
                SendKeys.Send("{TAB}");
            }

        }

        private void cbortprint_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbortprint.Text == "Purchase Order Pending - All" || cbortprint.Text == "Purchase Order Cancelled - All")
            {
                cboControlNo.Enabled = false;
                txtBeginDate.Visible = true;
                txtEndDate.Visible = true;
                cboCNCode.Enabled = true;

            }
            else if (cbortprint.Text == "Purchase Order Pending - Supplier" || cbortprint.Text == "Purchase Order Cancelled - Supplier")
            {
                cboControlNo.Enabled = true;
                txtBeginDate.Visible = true;
                txtEndDate.Visible = true;
                cboCNCode.Enabled = true;
            }
           
        }

    }
}
