﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using CrystalDecisions.CrystalReports.Engine;
using System.Data.SqlClient;
using System.Threading;

namespace TCIGL
{
    public partial class frmVoucherCRV : Form
    {
        public static TextBox glbldocnum;
        
        SqlConnection myconnection;
        SqlCommand mycommand;
        string varoutdate = "No";
        string dgvdata = null;
      //  SqlDataReader dr;
        ClsAutoNumber ClsAutoNumber1 = new ClsAutoNumber();
        ClsDefaultBranch ClsDefaultBranch1 = new ClsDefaultBranch();
        ClsBuildComboBox ClsBuildComboBox1 = new ClsBuildComboBox();
        ClsBuildCOAComboBox ClsBuildCOAComboBox1 = new ClsBuildCOAComboBox(); 
        ClsCompName ClsCompName1 = new ClsCompName();
        ClsGetSomething ClsGetSomething1 = new ClsGetSomething();
        ClsGetConnection ClsGetConnection1 = new ClsGetConnection();
        ClsValidation ClsValidation1 = new ClsValidation();
        ClsPermission ClsPermission1 = new ClsPermission();
        ClsGetSomethingOthers ClsGetSomethingOthers1 = new ClsGetSomethingOthers(); 
        public static DataGridView glbldgv1;
        public static TextBox glbltxtdrtot, glbltxtcrtot, glbltxtDifference;
        int varintTableDoor = 0;
        int number = 0;
        private string privarstrVoidIC = null;

        public frmVoucherCRV()
        {
            InitializeComponent();
            {
                ClsGetSomethingOthers1.ClsGetVoidRef("CRV", "1");
                privarstrVoidIC = ClsGetSomethingOthers1.plsVoidIC;
                if (new ClsValidation().emptytxt(privarstrVoidIC))
                { }
                else
                {
                    ClsGetSomethingOthers1.ClsDeleteErrorTransaction("CRV", "1");
                }
            }

        }

        private void frmVoucherCRV_Load(object sender, EventArgs e)
        {
           ClsPermission1.ClsObjects(this.Text);
           if (new ClsValidation().emptytxt(ClsPermission1.plstxtObject))
           {
               MessageBox.Show("You do not have necessary permission to open this file", "GL");
               this.Close();
           }
           else
           {
               ClsAutoNumber1.VoucherAutoNum("CRV");
               txtDocNum.Text = (ClsAutoNumber1.plsnumber);
               ClsGetSomething1.ClsGetDefaultDate();
               txtTDate.Text = ClsGetSomething1.plsdefdate;
               glbldgv1 = dgv1;
               glbltxtdrtot = txtdrtot;
               glbltxtcrtot = txtcrtot;
               glbltxtDifference = txtDifference;
               buildcboControlNo();
               buildcboSubtitle();
               buildcboPA();
               cboControlNo.SelectedValue = "";
               privarstrVoidIC = null;
               ClsGetSomethingOthers1.ClsGetVoidRef("CRV", "1");
               privarstrVoidIC = ClsGetSomethingOthers1.plsVoidIC;
               if (new ClsValidation().emptytxt(privarstrVoidIC))
               { }
               else
               {
                   ClsGetSomethingOthers1.ClsDeleteErrorTransaction("CRV", "1");
                   privarstrVoidIC = null;
               }
           }
        }

        private void buildcboControlNo()
        {
            cboControlNo.DataSource = null;
            ClsBuildComboBox1.ARLCVCN.Clear();
            ClsBuildComboBox1.ClsBuildCVControlno();
            this.cboControlNo.DataSource = (ClsBuildComboBox1.ARLCVCN);
            this.cboControlNo.DisplayMember = "Display";
            this.cboControlNo.ValueMember = "Value";
        }
        private void buildcboSubtitle()
        {
            ColumncboSTCode.DataSource = null;
            ClsBuildComboBox1.ARLSubtitle.Clear();
            ClsBuildComboBox1.ClsBuildSubTitle();
            this.ColumncboSTCode.DataSource = (ClsBuildComboBox1.ARLSubtitle);
            this.ColumncboSTCode.DisplayMember = "Display";
            this.ColumncboSTCode.ValueMember = "Value";
        }
 

        private void buildcboPA()
        {
            cboPA.DataSource = null;
            ClsBuildCOAComboBox1.ARPA.Clear();
            ClsBuildCOAComboBox1.ClsBuildPA(Convert.ToBoolean(cbAccountNo.CheckState));
            this.cboPA.DataSource = (ClsBuildCOAComboBox1.ARPA);
            this.cboPA.DisplayMember = "Display";
            this.cboPA.ValueMember = "Value";
            this.cboPA.DropDownWidth = 450;
        }

      
 
        private void cboControlNo_Validating(object sender, CancelEventArgs e)
        {
                if (new ClsValidation().emptytxt(cboControlNo.Text))
                {
                }
                else if (cboControlNo.Text != null && cboControlNo.SelectedValue == null)
                {
                    MessageBox.Show("Not found", "GL");
                    cboControlNo.Focus();
                }
        }

        private void dgv1total()
        {
            double vartxtdr = 0.00;
            double vartxtcr = 0.00;
            double vartxtdiff = 0.00;

            for (int x = 0; x < dgv1.Rows.Count - 1; x++)
            {
                vartxtdr += double.Parse(dgv1.Rows[x].Cells[5].FormattedValue.ToString());
            }

            for (int x = 0; x < dgv1.Rows.Count - 1; x++)
            {
                vartxtcr += double.Parse(dgv1.Rows[x].Cells[6].FormattedValue.ToString());
            }
            txtdrtot.Text = vartxtdr.ToString("N2");
            txtcrtot.Text = vartxtcr.ToString("N2");
            vartxtdiff = Convert.ToDouble(txtdrtot.Text) - Convert.ToDouble(txtcrtot.Text);
            txtDifference.Text = vartxtdiff.ToString("N2");

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dgv1_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            // Clear the row error in case the user presses ESC.   
            dgv1.Rows[e.RowIndex].ErrorText = String.Empty;

            DataGridViewRow row1 = dgv1.Rows[e.RowIndex];
            if (new ClsValidation().emptytxt(row1.Cells[0].FormattedValue.ToString()))
            {
            }
            else
            {
                if (e.ColumnIndex == dgv1.Columns["cbopa"].Index)
                {
                    string[] values = new string[1];
                    DataGridViewRow row = dgv1.Rows[e.RowIndex];

                    ClsGetSomething1.ClsGetAT(row.Cells[0].Value.ToString());
                    row.Cells[1].Value = ClsGetSomething1.plsAT;
                    dgv1.CurrentRow.Cells[2].Value = "000";
                    dgv1.CurrentRow.Cells[3].Value = "NA";
                    dgv1.CurrentRow.Cells[4].Value = "NA";
                    dgv1.CurrentRow.Cells[5].Value = "0.00";
                    dgv1.CurrentRow.Cells[6].Value = "0.00";
                    dgv1.CurrentRow.Cells[7].Value = 0;
                    if (new ClsValidation().emptytxt(txtreference.Text))
                    {
                        dgv1.CurrentRow.Cells[4].Value = "NA";
                    }
                    else
                    {
                        dgv1.CurrentRow.Cells[4].Value = txtreference.Text;
                    }
                    dgv1total();
                }
                else if (e.ColumnIndex == dgv1.Columns["txtdr"].Index)
                {
                    this.dgv1.Rows[e.RowIndex].Cells[5].Value = double.Parse(dgv1.Rows[e.RowIndex].Cells[5].FormattedValue.ToString().Trim()).ToString("N2");
                    dgv1total();
                }
                else if (e.ColumnIndex == dgv1.Columns["txtcr"].Index)
                {
                    this.dgv1.Rows[e.RowIndex].Cells[6].Value = double.Parse(dgv1.Rows[e.RowIndex].Cells[6].FormattedValue.ToString().Trim()).ToString("N2");
                    dgv1total();
                }
            }
        }

        private void dgv1_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            //if (e.Control is DataGridViewComboBoxEditingControl)
            //{
            //    ((ComboBox)e.Control).DropDownStyle = ComboBoxStyle.DropDown;
            //    ((ComboBox)e.Control).AutoCompleteSource = AutoCompleteSource.ListItems;
            //    ((ComboBox)e.Control).AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            //}
            if (e.Control is ComboBox)
            {
                //SendKeys.Send("{F4}");
                SendKeys.Send("%{Down}");
            }
            ComboBox cboPA = e.Control as ComboBox;
            if (cboPA != null)
            {
                cboPA.IntegralHeight = false;
                cboPA.MaxDropDownItems = 12;
            }
        }

        private void dgv1_CurrentCellDirtyStateChanged(object sender, EventArgs e)
        {
            if (dgv1.IsCurrentCellDirty)
            {
                dgv1.CommitEdit(DataGridViewDataErrorContexts.Commit);
            }
        }

        private void dgv1_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        {
            DataGridViewRow row = dgv1.Rows[e.RowIndex];
            if (new ClsValidation().emptytxt(row.Cells[0].FormattedValue.ToString()))
            {
            }
            else
            {
                if (e.ColumnIndex == dgv1.Columns["txtrefer"].Index)  //this is our numeric column
                {
                    if (String.IsNullOrEmpty(e.FormattedValue.ToString()))// &&
                    //dgv1[e.ColumnIndex, e.RowIndex].IsInEditMode)
                    {
                        e.Cancel = true;
                        MessageBox.Show("Empty", "GL");
                    }
                }
                else if (e.ColumnIndex == dgv1.Columns["txtDR"].Index)  //this is our numeric column
                {
                    if (String.IsNullOrEmpty(e.FormattedValue.ToString()))// &&
                    //dgv1[e.ColumnIndex, e.RowIndex].IsInEditMode)
                    {
                        e.Cancel = true;
                        MessageBox.Show("Empty", "GL");
                    }
                    else
                    {
                        double i;
                        if (!double.TryParse(Convert.ToString(e.FormattedValue), out i))
                        {
                            e.Cancel = true;
                            MessageBox.Show("Numeric only", "GL");
                        }
                    }
                }

                else if (e.ColumnIndex == dgv1.Columns["txtCR"].Index)  //this is our numeric column
                {
                    if (String.IsNullOrEmpty(e.FormattedValue.ToString()))// &&
                    //dgv1[e.ColumnIndex, e.RowIndex].IsInEditMode)
                    {
                        e.Cancel = true;
                        MessageBox.Show("Empty", "GL");
                    }
                    else
                    {
                        double i;
                        if (!double.TryParse(Convert.ToString(e.FormattedValue), out i))
                        {
                            e.Cancel = true;
                            MessageBox.Show("Numeric only", "GL");
                        }
                    }
                }

                else if (e.ColumnIndex == dgv1.Columns["ColumnActRemarks"].Index)  //this is our numeric column
                {
                    if (String.IsNullOrEmpty(e.FormattedValue.ToString()))// &&
                    //dgv1[e.ColumnIndex, e.RowIndex].IsInEditMode)
                    {
                        e.Cancel = true;
                        MessageBox.Show("Empty", "GL");
                    }
                }
            }
        }
       
     


        

        private void SaveTransact()
        {
            try
            {
                DateTime DT = DateTime.Now;
                ClsAutoNumber1.VoucherAutoNum("CRV");
                txtDocNum.Text = (ClsAutoNumber1.plsnumber);

                string sqlstatement = "INSERT INTO tblmain1 (IC, DocNum, Voucher, UserCode, TDate, Reference, ControlNo, Remarks,  Term, CheckNo, CAmount, DE, CNCode) ";
                sqlstatement += "Values (@_IC, @_DocNum, @_Voucher, @_UserCode, @_TDate, @_Reference, @_ControlNo, @_Remarks,  @_Term, @_CheckNo, @_CAmount, @_DE, @_CNCode)";
                string sqlstatementdgv2 = "INSERT INTO tblmain3 (IC, Refer, ActRemarks, Debit, Credit, PA, SIT, STCode) Values (@_IC, @_Refer, @_ActRemarks, @_Debit, @_Credit, @_PA, @_SIT, @_STCode)";

                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();

                mycommand = new SqlCommand(sqlstatement, myconnection);
                mycommand.Parameters.Add("_IC", SqlDbType.VarChar).Value = "CRV" + Form1.glbluc.Text + (ClsDefaultBranch1.plsvardb);
                mycommand.Parameters.Add("_DocNum", SqlDbType.VarChar).Value = Form1.glbluc.Text;
                mycommand.Parameters.Add("_Voucher", SqlDbType.VarChar).Value = "CRV";
                mycommand.Parameters.Add("_UserCode", SqlDbType.VarChar).Value = Form1.glbluc.Text;
                mycommand.Parameters.Add("_TDate", SqlDbType.DateTime).Value = txtTDate.Text;
                mycommand.Parameters.Add("_Reference", SqlDbType.VarChar).Value = txtreference.Text;
                mycommand.Parameters.Add("_ControlNo", SqlDbType.VarChar).Value = cboControlNo.SelectedValue.ToString();
                mycommand.Parameters.Add("_Remarks", SqlDbType.VarChar).Value = txtRemarks.Text;
                mycommand.Parameters.Add("_Term", SqlDbType.Int).Value = txtTerm.Text;
                mycommand.Parameters.Add("_CheckNo", SqlDbType.VarChar).Value = txtCheckNo.Text;
                mycommand.Parameters.Add("_CAmount", SqlDbType.Decimal).Value = txtCAmount.Text;
                mycommand.Parameters.Add("_DE", SqlDbType.DateTime).Value = DT;
                mycommand.Parameters.Add("_CNCode", SqlDbType.Char).Value = (ClsDefaultBranch1.plsvardb);
                int n1 = mycommand.ExecuteNonQuery();


                DataGridViewRow row = null;
                for (int x = 0; x < dgv1.Rows.Count - 1; x++)
                {
                    row = dgv1.Rows[x];
                    mycommand = new SqlCommand(sqlstatementdgv2, myconnection);
                    mycommand.Parameters.Add("_IC", SqlDbType.VarChar).Value = "CRV" + Form1.glbluc.Text + (ClsDefaultBranch1.plsvardb);
                    mycommand.Parameters.Add("_Refer", SqlDbType.VarChar).Value = row.Cells[4].Value;
                    mycommand.Parameters.Add("_ActRemarks", SqlDbType.VarChar).Value = row.Cells[3].Value;
                    mycommand.Parameters.Add("_Debit", SqlDbType.Decimal).Value = row.Cells[5].Value;
                    mycommand.Parameters.Add("_Credit", SqlDbType.Decimal).Value = row.Cells[6].Value;
                    mycommand.Parameters.Add("_PA", SqlDbType.VarChar).Value = row.Cells[0].Value;
                    mycommand.Parameters.Add("_SIT", SqlDbType.Bit).Value = row.Cells[7].Value;
                    mycommand.Parameters.Add("_STCode", SqlDbType.VarChar).Value = row.Cells[2].Value;
                    int n2 = mycommand.ExecuteNonQuery();
                }
                myconnection.Close();
                ClsGetSomethingOthers1.ClsFinalize("CRV", txtDocNum.Text, "1");
                //dr.Close();

                if (cbSP.Checked)
                {
                    int varnocopy = int.Parse(frmMain.glbltxtNoCopy.Text);
                    for (int i = 1; i <= varnocopy; i++)
                    {
                        printcurvoucher();
                    }
                }

                ClsAutoNumber1.VoucherAutoNum("CRV");
                txtDocNum.Text = (ClsAutoNumber1.plsnumber);

                dgv1.Rows.Clear();
                txtreference.Text = "";
                // txtCheckNo.Text = "NA";
                txtCAmount.Text = "0.00";
                txtTerm.Text = "0";
                cboControlNo.SelectedValue = "";
                txtRemarks.Text = "";
                txtTDate.Focus();
                txtdrtot.Text = "0.00";
                txtcrtot.Text = "0.00";
                txtDifference.Text = "0.00";
                dgvdata = null;
                txtTDate.Text = ClsGetSomething1.plsdefdate;
            }
            catch
            {
                MessageBox.Show("Error, please click OK", "GL");
                this.Close();
            }
            finally
            {
                myconnection.Close();
            }
        }

        private void printcurvoucher()
        {
            string sqlstatement;
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();
            sqlstatement = "SELECT * FROM viewbookCRV WHERE DocNum ='" + txtDocNum.Text + "' AND CNCode = '" + (ClsDefaultBranch1.plsvardb) + "'";

            SqlDataAdapter dscmd = new SqlDataAdapter(sqlstatement, myconnection);
            DSBooks dsplrv = new DSBooks();
            dscmd.Fill(dsplrv, "viewbookapv");
            myconnection.Close();

            CRprevCRV objRpt = new CRprevCRV();
            TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            ClsCompName1.ClsCompNamebranch();
            vartxtcompany.Text = ClsCompName1.plsbn;

            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            vartxtaddress.Text = (ClsCompName1.plsaddress);

            objRpt.SetDataSource(dsplrv.Tables[1]);
            //crystalReportViewer1.ReportSource = objRpt;
            //crystalReportViewer1.Refresh();

            System.Drawing.Printing.PrintDocument doctoprint = new System.Drawing.Printing.PrintDocument();
            //  doctoprint.PrinterSettings.PrinterName = "EPSON LX-300+ /II";
            int rawKind = 0;
            for (int i = 0; i <= doctoprint.PrinterSettings.PaperSizes.Count - 1; i++)
            {
                if (doctoprint.PrinterSettings.PaperSizes[i].PaperName == "C1-HalfShort")
                {
                    rawKind = Convert.ToInt32(doctoprint.PrinterSettings.PaperSizes[i].GetType().GetField("kind",
                    System.Reflection.BindingFlags.Instance |
                    System.Reflection.BindingFlags.NonPublic).GetValue(doctoprint.PrinterSettings.PaperSizes[i]));
                    break; // TODO: might not be correct. Was : Exit For
                }
            }
            objRpt.PrintOptions.PaperSize = (CrystalDecisions.Shared.PaperSize)rawKind;
            //CrystalDecisions.Shared.PageMargins pMargin = new CrystalDecisions.Shared.PageMargins(0, 0, 0, 0);
            //objRpt.PrintOptions.ApplyPageMargins(pMargin);
            
            objRpt.Refresh();
            objRpt.PrintToPrinter(1, false, 0, 0);

        }
        private void dgv1_UserDeletedRow(object sender, DataGridViewRowEventArgs e)
        {
            dgv1total();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
                double vartxtdrtot = double.Parse((txtdrtot.Text).ToString());
                double vartxtcrtot = double.Parse((txtcrtot.Text).ToString());
        
                ClsValidation1.securedate(DateTime.Parse(txtTDate.Text));
                varoutdate = (ClsValidation1.plsoutdate);

                for (int x = 0; x < dgv1.Rows.Count - 1; x++)
                {
                    dgvdata = (dgv1.Rows[x].Cells[0].FormattedValue.ToString());
                }

                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                if (new Clsexist().RecordExists(ref myconnection, "SELECT Reference FROM tblmain1 WHERE Reference ='" + txtreference.Text + "' AND CNCode = '" + (ClsDefaultBranch1.plsvardb) + "'"))
                {
                    myconnection.Close();
                    MessageBox.Show("Duplicate entry", "GL");
                    txtTDate.Focus();
                }
                else if (txtTDate.Text == "  /  /")
                {
                    myconnection.Close();
                    MessageBox.Show("Please complete your entry", "GL");
                    txtTDate.Focus();
                }
                else if (new ClsValidation().emptytxt (txtreference .Text))
                {
                    myconnection.Close();
                    MessageBox.Show("Please complete your entry", "GL");
                    txtreference.Focus();
                }
                else if (new ClsValidation().emptytxt(txtCheckNo.Text))
                {
                    myconnection.Close();
                    MessageBox.Show("Please complete your entry", "GL");
                    txtCheckNo.Focus();
                }
                else if (new ClsValidation().emptytxt(txtCAmount.Text))
                {
                    myconnection.Close();
                    MessageBox.Show("Please complete your entry", "GL");
                    txtCAmount.Focus();
                }
                else if (new ClsValidation().emptytxt(cboControlNo.Text))
                {
                    myconnection.Close();
                    MessageBox.Show("Please complete your entry", "GL");
                    cboControlNo.Focus();
                }
                else if (new ClsValidation().emptytxt(txtRemarks.Text))
                {
                    myconnection.Close();
                    MessageBox.Show("Please complete your entry", "GL");
                    txtRemarks.Focus();
                }
                else if (varoutdate == "Yes")
                {
                    myconnection.Close();
                    MessageBox.Show("Date is out of range", "GL");
                    txtTDate.Focus();
                }

                else if (vartxtdrtot != vartxtcrtot)
                {
                    myconnection.Close();
                    MessageBox.Show("Not balance", "GL");
                    txtRemarks.Focus();
                }
                else if (new ClsValidation().emptytxt(dgvdata))
                {
                    myconnection.Close();
                    MessageBox.Show("Incomplete Record", "GL");
                    txtTDate.Focus();
                }
                else
                {
                    myconnection.Close();
                    privarstrVoidIC = null;
                    ClsGetSomethingOthers1.ClsGetTDoor("CRV");
                    varintTableDoor = int.Parse(ClsGetSomethingOthers1.plsTableDoor);
                    number = 0;
                    while (varintTableDoor == 1 && number <= 20)
                    {
                        number = number + 1;
                        Thread.Sleep(200);
                        varintTableDoor = int.Parse(ClsGetSomethingOthers1.plsTableDoor);
                    }

                    if (varintTableDoor == 0 && number <= 20)
                    {

                        ClsGetSomethingOthers1.ClsGetVoidRef("CRV", "1");
                        privarstrVoidIC = ClsGetSomethingOthers1.plsVoidIC;
                        if (new ClsValidation().emptytxt(privarstrVoidIC))
                        {
                            ClsGetSomethingOthers1.ClsOneTheDoor("CRV");
                            SaveTransact();
                            ClsGetSomethingOthers1.ClsZeroTheDoor("CRV");
                        }
                        else
                        {
                            ClsGetSomethingOthers1.ClsDeleteErrorTransaction("CRV", "1");
                            MessageBox.Show("Transaction not saved", "GL");
                        }
                    }
                    else if (varintTableDoor == 1 && number == 21)
                    {
                        MessageBox.Show("Contact your adminnistrator", "GL");
                    }
                }
        }

        private void txtCAmount_Validating(object sender, CancelEventArgs e)
        {
            if (new ClsValidation().isDouble(txtCAmount.Text) == true)
            {
                MessageBox.Show("Invalid Number", "GL");
                txtCAmount.Focus();
            }
            else
            {
                txtCAmount.Text = Convert.ToDouble(txtCAmount.Text).ToString("N2");
            }

        }

        private void txtTDate_Leave(object sender, EventArgs e)
        {
            if (new ClsValidation().errordate(txtTDate.Text) == true)
            {
                MessageBox.Show("Invalid Date", "GL");
                txtTDate.Focus();
            }
        }

        private void txtTerm_Validating(object sender, CancelEventArgs e)
        {
            if (new ClsValidation().isInt (txtTerm.Text)==true )
            {
                MessageBox.Show("Invalid Number", "GL");
                txtTerm.Focus();
            }
        }
    

        private void nextfieldenter1(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.Equals(Keys.Enter))
            {
                SendKeys.Send("{TAB}");
            }
            else if ((e.KeyCode.Equals(Keys.Up)) || (e.KeyCode.Equals(Keys.Left)))
            {
                SendKeys.Send("+{TAB}");
            }
            else if ((e.KeyCode.Equals(Keys.Down)) || (e.KeyCode.Equals(Keys.Right)))
            {
                SendKeys.Send("{TAB}");
            }
        }

        private void nextfieldenter2(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.Equals(Keys.Enter))
            {
                SendKeys.Send("{TAB}");
            }

        }

        private void cbAccountNo_CheckedChanged(object sender, EventArgs e)
        {
            buildcboPA();
        }

        private void btnVAT_Click(object sender, EventArgs e)
        {
            if (new ClsValidation().emptytxt(txtreference.Text))
            {
                MessageBox.Show("Please enter reference", "GL");
                txtreference.Focus();
            }
            else
            {
                frmVATEntry frmVATEntry1 = new frmVATEntry();
                frmVATEntry1.Show();
                frmVATEntry.glbltxtVoucher.Text = "CRV";
                frmVATEntry.glbltxtrefer.Text = txtreference.Text;
            }
        }

        private void dgv1_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            DataGridViewRow row = dgv1.Rows[e.RowIndex];
            if ((e.ColumnIndex == dgv1.Columns["ColumnAT"].Index) || (e.ColumnIndex == dgv1.Columns["ColumnActRemarks"].Index) || (e.ColumnIndex == dgv1.Columns["txtRefer"].Index) || (e.ColumnIndex == dgv1.Columns["txtDR"].Index) || (e.ColumnIndex == dgv1.Columns["txtCR"].Index) || (e.ColumnIndex == dgv1.Columns["ColumncbdgvSIT"].Index) || (e.ColumnIndex == dgv1.Columns["ColumncboSTCode"].Index))
            {
                if (new ClsValidation().emptytxt(row.Cells[0].FormattedValue.ToString()))
                {
                    e.Cancel = true;
                    MessageBox.Show("Not Allowed", "GL");
                }
            }
        }
    }
}
