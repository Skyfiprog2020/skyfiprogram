﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Threading;
using CrystalDecisions.CrystalReports.Engine;

namespace TCIGL
{
    public partial class frmVoucherCS : Form
    {
        string varoutdate = "No";
        public static DataGridView glbldgv2;
        SqlConnection myconnection;
        SqlCommand mycommand;
        SqlCommand mycommanddgv2;
        SqlDataReader SqlDataReader1;
        ClsAutoNumber ClsAutoNumber1 = new ClsAutoNumber();
        ClsBuildComboBox ClsBuildComboBox1 = new ClsBuildComboBox();
        ClsValidation ClsValidation1 = new ClsValidation();
        ClsGetSomething ClsGetSomething1 = new ClsGetSomething();
        ClsPermission ClsPermission1 = new ClsPermission(); 
        ClsBuildEntryComboBox ClsBuildEntryComboBox1 = new ClsBuildEntryComboBox();
        ClsGetConnection ClsGetConnection1 = new ClsGetConnection();
        ClsDefaultBranch ClsDefaultBranch1 = new ClsDefaultBranch(); 
        string dgvdata = null;
        public static TextBox glblSPO;
        public static TextBox glbltxtTotDisct, glbltxtOverAllDisct, glbltxtActDisct;
        public static TextBox glbltxtTotNet, glbltxtVat;
        public static TextBox glbltxtTotCost, glbltxtTotVAT, glbltxtTReceivable, glbltxtOTDisct;
        public static ComboBox glblcboWHCode;
        public static Button glblbtnSave;
        public static CheckBox glblcbVAT;
        ClsGetSomethingOthers ClsGetSomethingOthers1 = new ClsGetSomethingOthers();
        ClsCompName ClsCompName1 = new ClsCompName(); 
        int varintTableDoor = 0;
        int number = 0;
        private string privarstrVoidIC = null;
        double doubToNet;
        ClsVariousFormula ClsVariousFormula1 = new ClsVariousFormula();

        public frmVoucherCS()
        {
            InitializeComponent();
            {
                ClsGetSomethingOthers1.ClsGetVoidRef("CS", "1");
                privarstrVoidIC = ClsGetSomethingOthers1.plsVoidIC;
                if (new ClsValidation().emptytxt(privarstrVoidIC))
                { }
                else
                {
                    ClsGetSomethingOthers1.ClsDeleteErrorTransaction("CS", "1");
                }
            }
        }


        private void buildcboCustCode()
        {
            cboControlNo.DataSource = null;
            ClsBuildComboBox1.ARPCN.Clear();
            ClsBuildComboBox1.ClsBuildCustControlno();
            this.cboControlNo.DataSource = (ClsBuildComboBox1.ARPCN);
            this.cboControlNo.DisplayMember = "Display";
            this.cboControlNo.ValueMember = "Value";
        }
   
       
        private void buildcboASMCode()
        {
            cboASMCode.DataSource = null;
            ClsBuildEntryComboBox1.ARSMCode.Clear();
            ClsBuildEntryComboBox1.ClsBuildSalesman();
            this.cboASMCode.DataSource = (ClsBuildEntryComboBox1.ARSMCode);
            this.cboASMCode.DisplayMember = "Display";
            this.cboASMCode.ValueMember = "Value";
        }

        private void buildcboWHCode()
        {
            cboWHCode.DataSource = null;
            ClsBuildEntryComboBox1.ARWHCode.Clear();
            ClsBuildEntryComboBox1.ClsBuildWHCode();
            this.cboWHCode.DataSource = (ClsBuildEntryComboBox1.ARWHCode);
            this.cboWHCode.DisplayMember = "Display";
            this.cboWHCode.ValueMember = "Value";
            //this.cboWHCode.DropDownWidth = 450;
        }
        private void getAcctEntry()
        {
            string vartotalGrossSales = (double.Parse(txtTotDisct.Text) + double.Parse(txtTotNet.Text)).ToString("N2");
            string vartotalDisct = double.Parse(txtTotDisct.Text).ToString("N2");
            string vartotalVAT = double.Parse(txtTotVAT.Text).ToString("N2");
            string vartotalcost = double.Parse(txtTotCost.Text).ToString("N2");
            string varTotalReceivable = ((double.Parse(vartotalGrossSales) + double.Parse(vartotalVAT)) - double.Parse(vartotalDisct)).ToString("N2");

            //Salesman Collection
            dgv1.Rows.Add("11500000000", txtreference.Text, varTotalReceivable, "0.00", 0);

            //Sales
            dgv1.Rows.Add("50000000000", txtreference.Text, "0.00", vartotalGrossSales, 0);

            //Discount
            if (double.Parse(vartotalDisct) != 0)
            { dgv1.Rows.Add("51000000000", txtreference.Text, vartotalDisct, "0.00", 0); }

            //Vat Output
            if (double.Parse(vartotalVAT) != 0)
            { dgv1.Rows.Add("32500000000", txtreference.Text, "0.00", vartotalVAT, 0); }

            if (double.Parse(vartotalcost) != 0)
            {
                //Cost of Goods Sold
                dgv1.Rows.Add("60000000000", txtreference.Text, vartotalcost, "0.00", 0);

                //Finished Goods Inventory
                dgv1.Rows.Add("15500000000", txtreference.Text, "0.00", vartotalcost, 0);
            }
            dgv1total();
        }
        private void SaveTransact()
        {
            try
            {

                DateTime DT = DateTime.Now;
                string sqlstatement;
                string sqlstatementdgv2;
                sqlstatement = "INSERT INTO tblmain1 (IC, DocNum, Voucher, UserCode, ControlNo, TDate, Reference, Term, Remarks, CheckNo, CAmount, ASMCode, DE, CNCode, OverAllDisct, VatAmount)";
                sqlstatement += " Values (@_IC, @_DocNum, @_Voucher, @_UserCode, @_ControlNo, @_TDate, @_Reference, @_Term, @_Remarks, @_CheckNo, @_CAmount, @_ASMCode, @_DE, @_CNCode, @_OverAllDisct, @_VatAmount)";
                sqlstatementdgv2 = "INSERT INTO tblmain2 (IC, StockNumber,  PIn, POut, UP, Cost, ActDisct, PDisct, VAT, RowNum, D1, D2, D3, WHCode)";
                sqlstatementdgv2 += "Values (@_IC, @_StockNumber, @_PIn, @_POut, @_UP, @_Cost, @_ActDisct, @_PDisct, @_VAT, @_RowNum, @_D1, @_D2, @_D3, @_WHCode)";
                string sqlstatementdgv3 = "INSERT INTO tblmain3 (IC, Refer, Debit, Credit, PA, SIT) Values (@_IC, @_Refer, @_Debit, @_Credit, @_PA, @_SIT)";

                ClsAutoNumber1.VoucherAutoNum("CS");
                txtDocNum.Text = (ClsAutoNumber1.plsnumber);

                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();

                mycommand = new SqlCommand(sqlstatement, myconnection);
                mycommand.Parameters.Add("_IC", SqlDbType.VarChar).Value = "CS" + Form1.glbluc.Text + (ClsDefaultBranch1.plsvardb);
                mycommand.Parameters.Add("_DocNum", SqlDbType.VarChar).Value = Form1.glbluc.Text;
                mycommand.Parameters.Add("_Voucher", SqlDbType.VarChar).Value = "CS";
                mycommand.Parameters.Add("_UserCode", SqlDbType.VarChar).Value = Form1.glbluc.Text;
                mycommand.Parameters.Add("_ControlNo", SqlDbType.VarChar).Value = cboControlNo.SelectedValue.ToString();
                mycommand.Parameters.Add("_TDate", SqlDbType.Date).Value = txtTDate.Text;
                mycommand.Parameters.Add("_Reference", SqlDbType.VarChar).Value = txtreference.Text;
                mycommand.Parameters.Add("_Term", SqlDbType.Int).Value = "0";
                mycommand.Parameters.Add("_Remarks", SqlDbType.VarChar).Value = txtRemarks.Text;
                mycommand.Parameters.Add("_CheckNo", SqlDbType.VarChar).Value = txtCheckNo.Text;
                mycommand.Parameters.Add("_CAmount", SqlDbType.Money).Value = txtCAmount.Text;
                mycommand.Parameters.Add("_ASMCode", SqlDbType.VarChar).Value = cboASMCode.SelectedValue.ToString();
                mycommand.Parameters.Add("_DE", SqlDbType.Date).Value = DT;
                mycommand.Parameters.Add("_CNCode", SqlDbType.Char).Value = (ClsDefaultBranch1.plsvardb);
                mycommand.Parameters.Add("_OverAllDisct", SqlDbType.Char).Value = txtOverAllDisct.Text;
                mycommand.Parameters.Add("_VatAmount", SqlDbType.Char).Value = txtTotVAT.Text;
                int n1 = mycommand.ExecuteNonQuery();

                DataGridViewRow row1 = null;
                for (int x = 0; x < dgv2.Rows.Count - 1; x++)
                {
                    row1 = dgv2.Rows[x];
                    mycommanddgv2 = new SqlCommand(sqlstatementdgv2, myconnection);
                    mycommanddgv2.Parameters.Add("_IC", SqlDbType.VarChar).Value = "CS" + Form1.glbluc.Text + (ClsDefaultBranch1.plsvardb);
                    mycommanddgv2.Parameters.Add("_StockNumber", SqlDbType.VarChar).Value = row1.Cells[1].Value;
                    mycommanddgv2.Parameters.Add("_PIn", SqlDbType.Decimal).Value = "0";
                    mycommanddgv2.Parameters.Add("_POut", SqlDbType.Decimal).Value = row1.Cells[3].Value;
                    mycommanddgv2.Parameters.Add("_UP", SqlDbType.Decimal).Value = row1.Cells[4].Value;
                    mycommanddgv2.Parameters.Add("_Cost", SqlDbType.Decimal).Value = row1.Cells[9].Value;
                    mycommanddgv2.Parameters.Add("_ActDisct", SqlDbType.Decimal).Value = row1.Cells[5].Value;
                    mycommanddgv2.Parameters.Add("_PDisct", SqlDbType.Decimal).Value = row1.Cells[6].Value;
                    mycommanddgv2.Parameters.Add("_VAT", SqlDbType.Decimal).Value = row1.Cells[7].Value;
                    mycommanddgv2.Parameters.Add("_RowNum", SqlDbType.Int).Value = (Convert.ToInt32(x) + 1).ToString();
                    mycommanddgv2.Parameters.Add("_D1", SqlDbType.Decimal).Value = row1.Cells[0].Value;
                    mycommanddgv2.Parameters.Add("_D2", SqlDbType.Decimal).Value = "0";
                    mycommanddgv2.Parameters.Add("_D3", SqlDbType.Decimal).Value = "0";
                    mycommanddgv2.Parameters.Add("_WHCode", SqlDbType.VarChar).Value = row1.Cells[10].Value;
                    int n3 = mycommanddgv2.ExecuteNonQuery();
                }

                DataGridViewRow row = null;
                for (int x = 0; x < dgv1.Rows.Count - 1; x++)
                {
                    row = dgv1.Rows[x];
                    mycommand = new SqlCommand(sqlstatementdgv3, myconnection);
                    mycommand.Parameters.Add("_IC", SqlDbType.VarChar).Value = "CS" + Form1.glbluc.Text + (ClsDefaultBranch1.plsvardb);
                    mycommand.Parameters.Add("_PA", SqlDbType.VarChar).Value = row.Cells[0].Value;
                    mycommand.Parameters.Add("_Refer", SqlDbType.VarChar).Value = row.Cells[1].Value;
                    mycommand.Parameters.Add("_Debit", SqlDbType.Decimal).Value = row.Cells[2].Value;
                    mycommand.Parameters.Add("_Credit", SqlDbType.Decimal).Value = row.Cells[3].Value;
                    mycommand.Parameters.Add("_SIT", SqlDbType.VarChar).Value = row.Cells[4].Value;
                    int n3 = mycommand.ExecuteNonQuery();
                }
                myconnection.Close();
                ClsGetSomethingOthers1.ClsFinalize("CS", txtDocNum.Text, "1");

                if (cbSP.Checked)
                {
                    int varnocopy = int.Parse(frmMain.glbltxtNoCopy.Text);
                    for (int i = 1; i <= varnocopy; i++)
                    {
                        printcurvoucher();
                    }
                }

                ClsAutoNumber1.VoucherAutoNum("CS");
                txtDocNum.Text = (ClsAutoNumber1.plsnumber);
                clearscreen();
            }
            catch
            {
                MessageBox.Show("Error, please click OK", "GL");
                this.Close();
            }
            finally
            {
                myconnection.Close();
            }
        }

        private void clearscreen()
        {
            dgv2.Rows.Clear();
            txtreference.Text = "";
            cboControlNo.SelectedValue = "";
            cboASMCode.SelectedValue = "";
            txtCheckNo.Text = "NA";
            txtCAmount.Text = "0.00";
            txtRemarks.Text = "Cash Sales";
            txtTDate.Focus();
            txtTotNet.Text = "0.00";
            txtTotCost.Text = "0.00";
            txtTotDisct.Text = "0.00";
            txtTotVAT.Text = "0.00";
            dgvdata = null;
            txtOverAllDisct.Text = "0.00";
        }


        private void printcurvoucher()
        {
            string sqlstatement = "SELECT * FROM ViewDetailsBookCS WHERE DocNum ='" + txtDocNum.Text + "' AND CNCode = '" + ClsDefaultBranch1.plsvardb + "' ORDER BY RowNum";

            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();
            mycommand = myconnection.CreateCommand();
            mycommand.CommandText = sqlstatement;
            mycommand.CommandTimeout = 900;
            SqlDataReader1 = mycommand.ExecuteReader();
            DataTable DataTable1 = new DataTable();
            DataTable1.Load(SqlDataReader1);
            myconnection.Close();

            if (DataTable1.Rows.Count == 0)
            {
                MessageBox.Show("No data found", "GL");
                return;
            }


            CRprevCS objRpt = new CRprevCS();
            TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            ClsCompName1.ClsCompNameMain();
            vartxtcompany.Text = ClsCompName1.varcn;

            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            ClsCompName1.ClsCompNamebranchAddress(ClsDefaultBranch1.plsvardb); vartxtaddress.Text = (ClsCompName1.plsCRaddress);

            objRpt.SetDataSource(DataTable1);
            
            System.Drawing.Printing.PrintDocument doctoprint = new System.Drawing.Printing.PrintDocument();
            //  doctoprint.PrinterSettings.PrinterName = "EPSON LX-300+ /II";
            int rawKind = 0;
            for (int i = 0; i <= doctoprint.PrinterSettings.PaperSizes.Count - 1; i++)
            {
                if (doctoprint.PrinterSettings.PaperSizes[i].PaperName == "C1-HalfShort")
                {
                    rawKind = Convert.ToInt32(doctoprint.PrinterSettings.PaperSizes[i].GetType().GetField("kind",
                    System.Reflection.BindingFlags.Instance |
                    System.Reflection.BindingFlags.NonPublic).GetValue(doctoprint.PrinterSettings.PaperSizes[i]));
                    break; // TODO: might not be correct. Was : Exit For
                }
            }
            objRpt.PrintOptions.PaperSize = (CrystalDecisions.Shared.PaperSize)rawKind;

            objRpt.Refresh();
            objRpt.PrintToPrinter(1, false, 0, 0);
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
                ClsValidation1.securedate(DateTime.Parse(txtTDate.Text));
                varoutdate = (ClsValidation1.plsoutdate);
                for (int x = 0; x < dgv2.Rows.Count - 1; x++)
                {
                    dgvdata = (dgv2.Rows[x].Cells[0].FormattedValue.ToString());
                }

                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();

                dgv1.Rows.Clear();
                getAcctEntry();
                if (new Clsexist().RecordExists(ref myconnection, "SELECT Reference FROM tblmain1 WHERE Reference ='" + txtreference.Text + "'"))
                {
                    myconnection.Close();
                    MessageBox.Show("Duplicate entry", "GL");
                    txtreference.Focus();
                }

                else if ((txtTDate.Text == "  /  /"))
                {
                    myconnection.Close();
                    MessageBox.Show("Please complete your entry", "GL");
                    txtTDate.Focus();
                }
                else if ((new ClsValidation().emptytxt(cboControlNo.Text)) || (new ClsValidation().emptytxt(txtreference.Text)) ||
                    (new ClsValidation().emptytxt(txtCheckNo.Text)) || (new ClsValidation().emptytxt(txtRemarks.Text)) || (new ClsValidation().emptytxt(cboWHCode.Text)))
                {
                    myconnection.Close();
                    MessageBox.Show("Please complete your entry", "GL");
                    txtTDate.Focus();
                }
                else if (varoutdate == "Yes")
                {
                    myconnection.Close();
                    MessageBox.Show("Date is out of range", "GL");
                    txtTDate.Focus();
                }
                else if (new ClsValidation().emptytxt(dgvdata))
                {
                    myconnection.Close();
                    MessageBox.Show("Incomplete Record", "IS");
                    txtTDate.Focus();
                }
                else if (Convert.ToDouble(txtDifference.Text) != 0)
                {
                    myconnection.Close();
                    dgv1.Rows.Clear();
                    MessageBox.Show("Not balance", "GL");
                    txtRemarks.Focus();
                }

                else
                {
                    myconnection.Close();
                    privarstrVoidIC = null;
                    ClsGetSomethingOthers1.ClsGetTDoor("CS");
                    varintTableDoor = int.Parse(ClsGetSomethingOthers1.plsTableDoor);
                    number = 0;
                    while (varintTableDoor == 1 && number <= 20)
                    {
                        number = number + 1;
                        Thread.Sleep(200);
                        varintTableDoor = int.Parse(ClsGetSomethingOthers1.plsTableDoor);
                    }

                    if (varintTableDoor == 0 && number <= 20)
                    {

                        ClsGetSomethingOthers1.ClsGetVoidRef("CS", "1");
                        privarstrVoidIC = ClsGetSomethingOthers1.plsVoidIC;
                        if (new ClsValidation().emptytxt(privarstrVoidIC))
                        {
                            ClsGetSomethingOthers1.ClsOneTheDoor("CS");
                            SaveTransact();
                            ClsGetSomethingOthers1.ClsZeroTheDoor("CS");
                        }
                        else
                        {
                            ClsGetSomethingOthers1.ClsDeleteErrorTransaction("CS", "1");
                            MessageBox.Show("Transaction not saved", "GL");
                        }
                    }
                    else if (varintTableDoor == 1 && number == 21)
                    {
                        MessageBox.Show("Contact your adminnistrator", "GL");
                    }
                }
        }
 


        private void cboCustCode_Validating(object sender, CancelEventArgs e)
        {
            try
            {
                if (new ClsValidation().emptytxt(cboControlNo.Text))
                {
                }
                else if (cboControlNo.Text != null && cboControlNo.SelectedValue == null)
                {
                    MessageBox.Show("Not found", "GL");
                    cboControlNo.Focus();
                }
                else
                {
                    ClsGetSomething1.ClsGetCustData(cboControlNo.SelectedValue.ToString());
                    txtSPO.Text = ClsGetSomething1.plsSPCode;
                    //txtAddress.Text = ClsGetSomething1.plsvarCustNameAdress;
                    cboASMCode.SelectedValue = ClsGetSomething1.plsSMCode;
                }
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
            }

        }

        private void frmVoucherSales_Load(object sender, EventArgs e)
        {
            ClsPermission1.ClsObjects(this.Text);
            if (new ClsValidation().emptytxt(ClsPermission1.plstxtObject))
            {
                MessageBox.Show("You do not have necessary permission to open this file", "GL");
                this.Close();
            }
            else
            {
                ClsAutoNumber1.VoucherAutoNum("CS");
                txtDocNum.Text = (ClsAutoNumber1.plsnumber);
                ClsGetSomething1.ClsGetDefaultDate();
                txtTDate.Text = ClsGetSomething1.plsdefdate;
                buildcboWHCode();
                buildcboASMCode();
                buildcboCustCode();
                cboControlNo.SelectedValue = "";
                cboASMCode.SelectedValue = "";
                glblSPO = txtSPO;
                glbldgv2 = dgv2;
                glbltxtTotCost = txtTotCost;
                glbltxtTotDisct = txtTotDisct;
                glbltxtTotNet = txtTotNet;
                glbltxtTotVAT = txtTotVAT;
                glblbtnSave = btnSave;
                glbltxtOTDisct = txtOverAllDisct;
                glbltxtTReceivable = txtTReceivable;
                glbltxtOverAllDisct = txtOverAllDisct;
                glbltxtActDisct = txtActDisct;
                glblcbVAT = cbVAT;
                glblcboWHCode = cboWHCode;
                privarstrVoidIC = null;
                ClsGetSomethingOthers1.ClsGetVoidRef("CS", "1");
                privarstrVoidIC = ClsGetSomethingOthers1.plsVoidIC;
                    if (new ClsValidation().emptytxt(privarstrVoidIC))
                    { }
                    else
                    {
                        ClsGetSomethingOthers1.ClsDeleteErrorTransaction("CS", "1");
                        privarstrVoidIC = null;
                    }
            }
        }

        private void txtCAmount_Validating(object sender, CancelEventArgs e)
        {
            if (new ClsValidation().isDouble(txtCAmount.Text) == true)
            {
                MessageBox.Show("Invalid Number", "GL");
                txtCAmount.Focus();
            }
            else
            {
                txtCAmount.Text = Convert.ToDouble(txtCAmount.Text).ToString("N2");
            }

        }

      

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
            frmTransactEntryCS frmTransactEntryCS1 = new frmTransactEntryCS();
            frmTransactEntryCS1.Close();
        }

        private void btnPE_Click(object sender, EventArgs e)
        {
            frmTransactEntryCS frmEntryCS1 = new frmTransactEntryCS();
            frmEntryCS1.Show();
            btnPE.Visible = false;
            label22.Visible = true;
        }

       
        private void frmVoucherSales_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F5)
            {
                if ((txtTDate.Text == "  /  /"))
                {
                    MessageBox.Show("Please complete your entry", "GL");
                    txtTDate.Focus();
                }
                else if ((new ClsValidation().emptytxt(cboControlNo.Text)) || (new ClsValidation().emptytxt(txtreference.Text)) ||
                    (new ClsValidation().emptytxt(txtRemarks.Text)))
                {
                    MessageBox.Show("Please complete your entry", "GL");
                    txtTDate.Focus();
                }
                else
                {
                    //frmTransactEntryCI.glbltxtD1.Enabled = false;
                    //frmTransactEntryCI.glbltxtD2.Enabled = false;
                    //frmTransactEntryCI.glbltxtD3.Enabled = false;
                    Form NonPoultry = Application.OpenForms["frmTransactEntryCS"];
                    if (NonPoultry != null)
                    {
                        //Application.OpenForms["frmTransactEntryCI"].BringToFront();
                        Application.OpenForms["frmTransactEntryCS"].Show();
                    }
                    else
                    {
                        MessageBox.Show("Not applicable at this moment", "GL");
                    }
                }
            }
        }

        private void txtTDate_Validating(object sender, CancelEventArgs e)
        {
            if (new ClsValidation().errordate(txtTDate.Text) == true)
            {
                MessageBox.Show("Invalid Date", "GL");
                txtTDate.Focus();
            }
        
        }

        private void dgv2_UserDeletedRow(object sender, DataGridViewRowEventArgs e)
        {
            dgv2total();
        }

       private void dgv1total()
        {
            double vartxtdr = 0.00;
            double vartxtcr = 0.00;
            double vartxtdiff = 0.00;

            for (int x = 0; x < dgv1.Rows.Count - 1; x++)
            {
                vartxtdr += double.Parse(dgv1.Rows[x].Cells[2].FormattedValue.ToString());
            }

            for (int x = 0; x < dgv1.Rows.Count - 1; x++)
            {
                vartxtcr += double.Parse(dgv1.Rows[x].Cells[3].FormattedValue.ToString());
            }
            txtdrtot.Text = vartxtdr.ToString("N2");
            txtcrtot.Text = vartxtcr.ToString("N2");
            vartxtdiff = Convert.ToDouble(txtdrtot.Text) - Convert.ToDouble(txtcrtot.Text);
            txtDifference.Text = vartxtdiff.ToString("N2");
        }
        private void dgv2total()
        {
            double vartxtTotCost = 0.00;
            double vartxtTotNet = 0.00;
            double vartxtTotDisct = 0.00;
          //  double vartxtTotVAT = 0;
         
            {
                for (int x = 0; x < frmVoucherCS.glbldgv2.Rows.Count - 1; x++)
                {
                    vartxtTotCost += double.Parse(frmVoucherCS.glbldgv2.Rows[x].Cells[9].FormattedValue.ToString());
                }

                for (int x = 0; x < frmVoucherCS.glbldgv2.Rows.Count - 1; x++)
                {
                    vartxtTotNet += double.Parse(frmVoucherCS.glbldgv2.Rows[x].Cells[8].FormattedValue.ToString());
                }

                for (int x = 0; x < frmVoucherCS.glbldgv2.Rows.Count - 1; x++)
                {
                    string vartxtD1 = frmVoucherCS.glbldgv2.Rows[x].Cells[5].FormattedValue.ToString();
                    string vartxtD2 = frmVoucherCS.glbldgv2.Rows[x].Cells[6].FormattedValue.ToString();
                    vartxtTotDisct += double.Parse(vartxtD1) + double.Parse(vartxtD2);
                }

                //for (int x = 0; x < frmVoucherCS.glbldgv2.Rows.Count - 1; x++)
                //{
                //   double varQty = double.Parse(frmVoucherCS.glbldgv2.Rows[x].Cells[3].FormattedValue.ToString());
                //   double varUP = double.Parse(frmVoucherCS.glbldgv2.Rows[x].Cells[4].FormattedValue.ToString());

                //    //vartxtTotVAT += double.Parse(frmVoucherCS.glbldgv2.Rows[x].Cells[7].FormattedValue.ToString());
                //}

                frmVoucherCS.glbltxtTotCost.Text = vartxtTotCost.ToString("N2");
                //frmVoucherCS.glbltxtTotNet.Text = vartxtTotNet.ToString("N2");
                doubToNet = (vartxtTotNet) - double.Parse(txtOverAllDisct.Text);
                frmVoucherCS.glbltxtTotDisct.Text = (vartxtTotDisct + double.Parse(txtOverAllDisct.Text)).ToString("N2");
                //frmVoucherCS.glbltxtTotVAT.Text = vartxtTotVAT.ToString("N2");
                //ClsVariousFormula1.getVATAmt(Convert.ToBoolean(cbVAT.CheckState), Convert.ToDouble(ClsGetSomething1.plsVATRate), Convert.ToDouble(vartxtTotNet));
                ClsGetSomething1.ClsGetVATRate();
                ClsVariousFormula1.getVATAmt(Convert.ToBoolean(cbVAT.CheckState), Convert.ToDouble(ClsGetSomething1.plsVATRate), Convert.ToDouble(txtTotNet.Text));
                txtActDisct.Text = ClsGetSomething1.plsVATRate;
                string transactVATAmt = Convert.ToDouble(ClsVariousFormula1.pldbVAT).ToString("N2");
                frmVoucherCS.glbltxtTotVAT.Text = transactVATAmt;
                frmVoucherCS.glbltxtTotNet.Text = ((vartxtTotNet - double.Parse(txtOverAllDisct.Text) - double.Parse(transactVATAmt)).ToString("N2"));
               // frmVoucherCS.glbltxtTReceivable.Text = (vartxtTotNet + vartxtTotVAT).ToString("N2");
                //frmVoucherCS.glbltxtTReceivable.Text = (vartxtTotNet + double.Parse(transactVATAmt)).ToString("N2");

                frmVoucherCS.glbltxtTReceivable.Text = (vartxtTotNet - double.Parse(txtOverAllDisct.Text)).ToString("N2");
            }
        }
        private void txtreference_Validating(object sender, CancelEventArgs e)
        {
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();

            if (new Clsexist().RecordExists(ref myconnection, "SELECT Reference FROM tblmain1 WHERE Reference ='" + txtreference.Text + "'"))
            {
                myconnection.Close();
                MessageBox.Show("Duplicate entry", "GL");
                txtreference.Focus();
            }
            myconnection.Close();
        }

        private void nextfieldenter1(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.Equals(Keys.Enter))
            {
                SendKeys.Send("{TAB}");
            }
            else if ((e.KeyCode.Equals(Keys.Up)) || (e.KeyCode.Equals(Keys.Left)))
            {
                SendKeys.Send("+{TAB}");
            }
            else if ((e.KeyCode.Equals(Keys.Down)) || (e.KeyCode.Equals(Keys.Right)))
            {
                SendKeys.Send("{TAB}");
            }
        }

        private void nextfieldenter2(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.Equals(Keys.Enter))
            {
                SendKeys.Send("{TAB}");
            }

        }

        private void cboSMCode_Validating(object sender, CancelEventArgs e)
        {
            if (new ClsValidation().emptytxt(cboASMCode.Text))
            {
            }
            else if (cboASMCode.Text != null && cboASMCode.SelectedValue == null)
            {
                MessageBox.Show("Not found", "GL");
                cboASMCode.Focus();
            }

        }

        private void frmVoucherCS_FormClosing(object sender, FormClosingEventArgs e)
        {
            Form NonPoultry = Application.OpenForms["frmTransactEntryCS"];
            if (NonPoultry != null)
            {
                frmTransactEntryCS CloseNonPoultry = (frmTransactEntryCS)Application.OpenForms["frmTransactEntryCS"];
                CloseNonPoultry.Close();
            }
        }

        private void txtOverAllDisct_Validating(object sender, CancelEventArgs e)
        {
            if (new ClsValidation().isDouble(txtOverAllDisct.Text) == true)
            {
                MessageBox.Show("Invalid Number", "GL");
                txtOverAllDisct.Focus();
            }
            else
            {
                txtOverAllDisct.Text = Convert.ToDouble(txtOverAllDisct.Text).ToString("N2");
                dgv2total();
            }
        }

        private void cbVAT_CheckedChanged(object sender, EventArgs e)
        {
            dgv2total();
        }

        private void cbVAT_Validating(object sender, CancelEventArgs e)
        {

        }

        private void txtTotNet_TextChanged(object sender, EventArgs e)
        {
        }

    }
}
