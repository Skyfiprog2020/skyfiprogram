﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using CrystalDecisions.CrystalReports.Engine;
using System.Data.SqlClient;

namespace TCIGL
{
    public partial class frmrptSubsidiaryLedger : Form
    {
        SqlConnection myconnection;
       // SqlDataReader dr;
        SqlDataReader SqlDataReader1;
        SqlCommand mycommand;
        BindingSource dbind = new BindingSource();
        ClsBuildComboBox ClsBuildComboBox1 = new ClsBuildComboBox();
        ClsDefaultBranch ClsDefaultBranch1 = new ClsDefaultBranch();
        ClsCompName ClsCompName1 = new ClsCompName();
        ClsGetSomething ClsGetSomething1 = new ClsGetSomething();
        ClsGetConnection ClsGetConnection1 = new ClsGetConnection();
        ClsBuildCOAComboBox ClsBuildCOAComboBox1 = new ClsBuildCOAComboBox();
        ClsPermission ClsPermission1 = new ClsPermission(); 
        public frmrptSubsidiaryLedger()
        {
            InitializeComponent();
            cbortprint.DisplayMember = "Text";
            cbortprint.ValueMember = "Value";
            var items = new[]
            { 
             new { Text = "Subsidiary Ledger - 1", Value = "01" }, 
             new { Text = "Subsidiary Ledger - 2", Value = "02" }, 
             new { Text = "Subsidiary Ledger - 3", Value = "03" }, 
             new { Text = "Subsidiary Ledger - 4", Value = "04" }, 
             new { Text = "General Ledger", Value = "05" }, 
             };
            cbortprint.DataSource = items;
            cbortprint.SelectedValue = "05";
        }

      

        private void txtBeginDate_Leave(object sender, EventArgs e)
        {
            if (new ClsValidation().errordate(txtBeginDate.Text) == true)
            {
                MessageBox.Show("Invalid Date", "GL");
                txtBeginDate.Focus();
            }

        }

        private void txtEndDate_Leave(object sender, EventArgs e)
        {
            if (new ClsValidation().errordate(txtEndDate.Text) == true)
            {
                MessageBox.Show("Invalid Date", "GL");
                txtEndDate.Focus();
            }
        }

        private void btnPreview_Click(object sender, EventArgs e)
        {
            if (new ClsValidation().emptytxt(cbortprint.Text))
            {
                MessageBox.Show("Please complete your entry", "GL");
                cbortprint.Focus();
            }
            else if (new ClsValidation().emptytxt(cboActTitle.Text))
            {
                MessageBox.Show("Please complete your entry", "GL");
                cboActTitle.Focus();
            }
            else if (new ClsValidation().emptytxt(cboCNCode.Text))
            {
                MessageBox.Show("Please complete your entry", "GL");
                cboCNCode.Focus();
            }
            else if (txtBeginDate.Text == "  /  /")
            {
                MessageBox.Show("Please complete your entry", "GL");
                txtBeginDate.Focus();
            }
            else if (txtEndDate.Text == "  /  /")
            {
                MessageBox.Show("Please complete your entry", "GL");
                txtEndDate.Focus();
            }
            else if (Convert.ToDateTime(txtBeginDate.Text) > Convert.ToDateTime(txtEndDate.Text))
            {
                MessageBox.Show("Beginning date is greater than ending date");
                txtBeginDate.Focus();
            }
            else
            {
                if (cbortprint.SelectedValue.ToString() == "01")//Subsidiary Ledger - 1
                {
                    SL1();
                }

                else if (cbortprint.SelectedValue.ToString() == "02")//Subsidiary Ledger - 2
                {
                    SL2();
                }

                else if (cbortprint.SelectedValue.ToString() == "03")//Subsidiary Ledger - 3
                {
                    SL3();
                }
                else if (cbortprint.SelectedValue.ToString() == "04")//Subsidiary Ledger - 4
                {
                    SL4();
                }
                else if (cbortprint.SelectedValue.ToString() == "05")//General Ledger
                {
                    GL();
                }
            }
        }

        private void SL1()
        {

            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();
            mycommand = new SqlCommand("usp_subsidiaryledgerMain2", myconnection);
            mycommand.CommandType = CommandType.StoredProcedure;

            mycommand.Parameters.Add("@ParamAcctNo2", SqlDbType.VarChar).Value = cboActTitle.SelectedValue;
            mycommand.Parameters.Add("@ParamCNCode2", SqlDbType.VarChar).Value = cboCNCode.SelectedValue.ToString();
            mycommand.Parameters.Add("@Parambegindate2", SqlDbType.DateTime).Value = txtBeginDate.Text;
            mycommand.Parameters.Add("@Paramenddate2", SqlDbType.DateTime).Value = txtEndDate.Text;
            mycommand.CommandTimeout = 900;
            SqlDataReader1 = mycommand.ExecuteReader();
            DataTable DataTable1 = new DataTable();
            DataTable1.Load(SqlDataReader1);
            myconnection.Close();

            if (DataTable1.Rows.Count == 0)
            {
                MessageBox.Show("No data found", "GL");
                return;
            }

            CRSubsidiaryLedgerMain objRpt = new CRSubsidiaryLedgerMain();
            TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            ClsCompName1.ClsCompNameMain();
            vartxtcompany.Text = ClsCompName1.varcn;

            ClsCompName1.ClsCompNamebranchAddress(cboCNCode.SelectedValue.ToString());
            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            vartxtaddress.Text = ClsCompName1.plsCRaddress;

            TextObject varrptAcctTitle = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rptAcctTitle"];
            varrptAcctTitle.Text = cboActTitle.Text;

            TextObject varrpttoenterdate = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rptrangedate"];
            varrpttoenterdate.Text = "From " + txtBeginDate.Text + " To " + txtEndDate.Text;

            objRpt.SetDataSource(DataTable1);
            crystalReportViewer1.ReportSource = objRpt;
            crystalReportViewer1.Refresh();
        }

        private void SL2()
        {
            string sqlstatement = "SELECT TDate As TDate1, DocRef As DocRef1, CustName As CustName1, ";
            sqlstatement += "Debit As DRAmt, Credit As CRAmt, Remarks As Remarks1, NormalBal, AT FROM ViewSubsidiaryLedger1 WHERE TDate BETWEEN '" + txtBeginDate.Text + "' And  '" + txtEndDate.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "' AND AcctNo='" + cboActTitle.SelectedValue.ToString() + "'";
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();
            mycommand = myconnection.CreateCommand();
            mycommand.CommandText = sqlstatement;
            mycommand.CommandTimeout = 900;
            SqlDataReader1 = mycommand.ExecuteReader();
            DataTable DataTable1 = new DataTable();
            DataTable1.Load(SqlDataReader1);
            myconnection.Close();

            if (DataTable1.Rows.Count == 0)
            {
                MessageBox.Show("No data found", "GL");
                return;
            }

            CRSubsidiaryLedgerMain objRpt = new CRSubsidiaryLedgerMain();
            ClsCompName1.ClsCompNamebranchAddress(cboCNCode.SelectedValue.ToString());
            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            vartxtaddress.Text = ClsCompName1.plsCRaddress;

            TextObject varrptAcctTitle = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rptAcctTitle"];
            varrptAcctTitle.Text = cboActTitle.Text;

            TextObject varrpttoenterdate = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rptrangedate"];
            varrpttoenterdate.Text = "From " + txtBeginDate.Text + " To " + txtEndDate.Text;

            objRpt.SetDataSource(DataTable1);
            crystalReportViewer1.ReportSource = objRpt;
            crystalReportViewer1.Refresh();
        }

        private void SL3()
        {

            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();
            mycommand = new SqlCommand("usp_subsidiaryledger2", myconnection);
            mycommand.CommandType = CommandType.StoredProcedure;
            mycommand.Parameters.Add("@ParamPA2", SqlDbType.VarChar).Value = cboActTitle.SelectedValue;
            mycommand.Parameters.Add("@ParamCNCode2", SqlDbType.VarChar).Value = cboCNCode.SelectedValue.ToString();
            mycommand.Parameters.Add("@Parambegindate2", SqlDbType.DateTime).Value = txtBeginDate.Text;
            mycommand.Parameters.Add("@Paramenddate2", SqlDbType.DateTime).Value = txtEndDate.Text;

            mycommand.CommandTimeout = 900;
            SqlDataReader1 = mycommand.ExecuteReader();
            DataTable DataTable1 = new DataTable();
            DataTable1.Load(SqlDataReader1);
            myconnection.Close();

            if (DataTable1.Rows.Count == 0)
            {
                MessageBox.Show("No data found", "GL");
                return;
            }

            CRSubsidiaryLedger objRpt = new CRSubsidiaryLedger();
            TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            ClsCompName1.ClsCompNameMain();
            vartxtcompany.Text = ClsCompName1.varcn;

            ClsCompName1.ClsCompNamebranchAddress(cboCNCode.SelectedValue.ToString());
            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            vartxtaddress.Text = ClsCompName1.plsCRaddress;

            TextObject varrptAcctTitle = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rptAcctTitle"];
            varrptAcctTitle.Text = cboActTitle.Text;

            TextObject varrpttoenterdate = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rptrangedate"];
            varrpttoenterdate.Text = "From " + txtBeginDate.Text + " To " + txtEndDate.Text;

            objRpt.SetDataSource(DataTable1);
            crystalReportViewer1.ReportSource = objRpt;
            crystalReportViewer1.Refresh();
        }

        private void SL4()
        {
            string sqlstatement;
            sqlstatement = "SELECT TDate As TDate1, DocRef As DocRef1, CustName As CustName1, ";
            sqlstatement += "Debit As DRAmt, Credit As CRAmt, Remarks As Remarks1, NormalBal FROM ViewSubsidiaryLedger1 WHERE TDate BETWEEN '" + txtBeginDate.Text + "' And  '" + txtEndDate.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "' AND PA='" + cboActTitle.SelectedValue.ToString() + "'";
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();
            mycommand = myconnection.CreateCommand();
            mycommand.CommandText = sqlstatement;
            mycommand.CommandTimeout = 900;
            SqlDataReader1 = mycommand.ExecuteReader();
            DataTable DataTable1 = new DataTable();
            DataTable1.Load(SqlDataReader1);
            myconnection.Close();

            if (DataTable1.Rows.Count == 0)
            {
                MessageBox.Show("No data found", "GL");
                return;
            }

            CRSubsidiaryLedger objRpt = new CRSubsidiaryLedger();

            ClsCompName1.ClsCompNamebranchAddress(cboCNCode.SelectedValue.ToString());
            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            vartxtaddress.Text = ClsCompName1.plsCRaddress;

            TextObject varrptAcctTitle = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rptAcctTitle"];
            varrptAcctTitle.Text = cboActTitle.Text;

            TextObject varrpttoenterdate = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rptrangedate"];
            varrpttoenterdate.Text = "From " + txtBeginDate.Text + " To " + txtEndDate.Text;

            objRpt.SetDataSource(DataTable1);
            crystalReportViewer1.ReportSource = objRpt;
            crystalReportViewer1.Refresh();
        }

        private void GL()
        {

            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();
            mycommand = new SqlCommand("usp_GeneralLedger2", myconnection);
            mycommand.CommandType = CommandType.StoredProcedure;
            mycommand.Parameters.Add("@ParamCNCode2", SqlDbType.VarChar).Value = cboCNCode.SelectedValue.ToString();
            mycommand.Parameters.Add("@Parambegindate2", SqlDbType.DateTime).Value = txtBeginDate.Text;
            mycommand.Parameters.Add("@Paramenddate2", SqlDbType.DateTime).Value = txtEndDate.Text;
            mycommand.CommandTimeout = 900;
            SqlDataReader1 = mycommand.ExecuteReader();
            DataTable DataTable1 = new DataTable();
            DataTable1.Load(SqlDataReader1);
            myconnection.Close();

            if (DataTable1.Rows.Count == 0)
            {
                MessageBox.Show("No data found", "GL");
                return;
            }

            CRGeneralLedger objRpt = new CRGeneralLedger();
            TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            ClsCompName1.ClsCompNameMain();
            vartxtcompany.Text = ClsCompName1.varcn;

            ClsCompName1.ClsCompNamebranchAddress(cboCNCode.SelectedValue.ToString());
            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            vartxtaddress.Text = ClsCompName1.plsCRaddress;

            TextObject varrpttoenterdate = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rptrangedate"];
            varrpttoenterdate.Text = "From " + txtBeginDate.Text + " To " + txtEndDate.Text;

            objRpt.SetDataSource(DataTable1);
            crystalReportViewer1.ReportSource = objRpt;
            crystalReportViewer1.Refresh();
        }
        private void frmrptSubsidiaryLedger_Load(object sender, EventArgs e)
        {
            ClsPermission1.ClsObjects(this.Text);
            if (new ClsValidation().emptytxt(ClsPermission1.plstxtObject))
            {
                MessageBox.Show("You do not have necessary permission to open this file", "GL");
                this.Close();
            }
            else
            {
                buildcboMainActTitle();
                buildcboCNCode();
                cboCNCode.SelectedValue = (ClsDefaultBranch1.plsvardb);
                ClsGetSomething1.ClsGetDefaultDate();
                txtBeginDate.Text = ClsGetSomething1.plsdefdate;
                txtEndDate.Text = ClsGetSomething1.plsdefdate;
                this.WindowState = FormWindowState.Maximized;
            }
        }

        private void buildcboCNCode()
        {
            cboCNCode.DataSource = null;
            ClsBuildComboBox1.ARBranch.Clear();
            ClsBuildComboBox1.ClsBuildBranch();
            this.cboCNCode.DataSource = (ClsBuildComboBox1.ARBranch);
            this.cboCNCode.DisplayMember = "Display";
            this.cboCNCode.ValueMember = "Value";
        }
        private void buildcboActTitle()
        {
            cboActTitle.DataSource = null;
            ClsBuildCOAComboBox1.ARPA.Clear();
            ClsBuildCOAComboBox1.ClsBuildPA(Convert.ToBoolean (cbAccountNo.CheckState));
            this.cboActTitle.DataSource = ClsBuildCOAComboBox1.ARPA;
            this.cboActTitle.DisplayMember = "Display";
            this.cboActTitle.ValueMember = "Value";
        }

        private void buildcboMainActTitle()
        {
            cboActTitle.DataSource = null;
            ClsBuildCOAComboBox1.ARcboactcode.Clear();
            ClsBuildCOAComboBox1.ClsbuildCboActCode();
            this.cboActTitle.DataSource = ClsBuildCOAComboBox1.ARcboactcode;
            this.cboActTitle.DisplayMember = "Display";
            this.cboActTitle.ValueMember = "Value";
        }
      

        private void cboActTitle_Validating(object sender, CancelEventArgs e)
        {
            if (new ClsValidation().emptytxt(cboActTitle.Text))
            {
            }
            else if (cboActTitle.Text != null && cboActTitle.SelectedValue == null)
            {
                MessageBox.Show("Not found", "GL");
                cboActTitle.Focus();
            }
        }

        private void cboCNCode_Validating(object sender, CancelEventArgs e)
        {
            if (new ClsValidation().emptytxt(cboCNCode.Text))
            {
            }
            else if (cboCNCode.Text != null && cboCNCode.SelectedValue == null)
            {
                MessageBox.Show("Not found", "GL");
                cboCNCode.Focus();
            }
        }


        private void nextfieldenter1(object sender, KeyEventArgs e)
        {

        }

        private void nextfieldenter2(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.Equals(Keys.Enter))
            {
                SendKeys.Send("{TAB}");
            }

        }

        private void cbAccountNo_CheckedChanged(object sender, EventArgs e)
        {
            buildcboActTitle();
        }

        private void cbortprint_Validating(object sender, CancelEventArgs e)
        {
            if (cbortprint.SelectedValue.ToString() == "01" || cbortprint.SelectedValue.ToString() == "02")
            {
                buildcboMainActTitle();
            }
            else if (cbortprint.SelectedValue.ToString() == "03" || cbortprint.SelectedValue.ToString() == "04")
            {
                buildcboActTitle();
            }
        }

        private void cbortprint_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbortprint.SelectedValue.ToString()=="05")
            {cboActTitle.Enabled = false; }
            else
            { cboActTitle.Enabled = true; }
        }

    
   }
}
