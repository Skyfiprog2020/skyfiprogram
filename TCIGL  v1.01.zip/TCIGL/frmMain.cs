﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TCIGL
{
    public partial class frmMain : Form
    {
        public static TextBox glbltxtNoCopy;

        public frmMain()
        {
            InitializeComponent();
        }

      
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void nameAddToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmEntryCustomerNameAdd fna = new frmEntryCustomerNameAdd();
            fna.Show();
        }

        private void nameEditToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmEntryCustomerNameEdit fne = new frmEntryCustomerNameEdit();
            fne.Show();
        }

        private void userAddToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmUserAdd fua = new frmUserAdd();
            fua.Show();
        }

        private void gRToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmusergroup fug = new frmusergroup();
            fug.Show();
        }

        private void membershipToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmusermembership fum = new frmusermembership();
            fum.Show();
        }

        private void permissionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmuserpermission fup = new frmuserpermission();
            fup.Show();
        }

        private void checkVoucherToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmVoucherCV fvc = new frmVoucherCV();
            fvc.Show();
        }

        private void journalVoucherToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmVoucherJV fvjv = new frmVoucherJV();
            fvjv.Show();
        }

        private void accountsPayableVoucherToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmVoucherAPV fvapv = new frmVoucherAPV();
            fvapv.Show();
        }

     
        private void officialReceiptsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmVoucherOR frmVoucherOR1 = new frmVoucherOR();
            frmVoucherOR1.Show();
        }

        private void loanBalancesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmrptAging frmrptAging1 = new frmrptAging();
            frmrptAging1.Show();
        }

        private void trialBalanceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmrptFS frmrptFS1 = new frmrptFS();
            frmrptFS1.Show();
        }

        private void othersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmrptCollection frmrptCollection1 = new frmrptCollection();
            frmrptCollection1.Show();
        }


      

        private void othersAddToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmEntrySupplierAdd frmEntrySupplierAdd1 = new frmEntrySupplierAdd();
            frmEntrySupplierAdd1.Show();
        }

        private void othersEditToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmEntrySupplierEdit frmEntrySupplierEdit1 = new frmEntrySupplierEdit();
            frmEntrySupplierEdit1.Show();
        }

        private void postingAccountToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmCAPAAdd frmCAPAAdd1 = new frmCAPAAdd();
            frmCAPAAdd1.Show();
        }

        private void department2AddToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmCADept2 frmCADept21 = new frmCADept2();
            frmCADept21.Show();
        }

        private void accountTitleAddToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmCAMainAcctAdd frmCAMainAcctAdd1 = new frmCAMainAcctAdd();
            frmCAMainAcctAdd1.Show();
        }

        private void accountTitleEditToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmCAMainAcctEdit frmCAMainAcctEdit1 = new frmCAMainAcctEdit();
            frmCAMainAcctEdit1.Show();
        }

        private void department1AddToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmCADept1Add frmCADept1Add1 = new frmCADept1Add();
            frmCADept1Add1.Show();
        }

        private void department2EditToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmCADept1Edit frmCADept1Edit1 = new frmCADept1Edit();
            frmCADept1Edit1.Show();
        }

        private void departToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmCADept2Edit frmCADept2Edit1 = new frmCADept2Edit();
            frmCADept2Edit1.Show();
        }

        private void postingAccountEditToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmCAPAEdit frmCAPAEdit1 = new frmCAPAEdit();
            frmCAPAEdit1.Show();
        }

        private void viewMainAccountToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmCAViewMainAccount frmCAViewMainAccount1 = new frmCAViewMainAccount();
            frmCAViewMainAccount1.Show();
        }

        private void viewSubAccountToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmCAViewSubAccount frmCAViewSubAccount1 = new frmCAViewSubAccount();
            frmCAViewSubAccount1.Show();
        }

       

        private void checkWriterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmCheckWriter frmCheckWriter1 = new frmCheckWriter();
            frmCheckWriter1.Show();
        }

       

        private void bankReconciliationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmBankRecon frmBankRecon1 = new frmBankRecon();
            frmBankRecon1.Show();
        }

        private void clientAddToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmEntryCustomerNameAdd frmCustomerNameAdd1 = new frmEntryCustomerNameAdd();
            frmCustomerNameAdd1.Show();
        }

        private void clientEditToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmEntryCustomerNameEdit frmCustomerNameEdit1 = new frmEntryCustomerNameEdit();
            frmCustomerNameEdit1.Show();
        }

    

        private void variousDocumentsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmVoucherARV frmVoucherARV1 = new frmVoucherARV();
            frmVoucherARV1.Show();
        }
        private void statementOfAccountsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmrptAgingStatement frmrptAgingStatement1 = new frmrptAgingStatement();
            frmrptAgingStatement1.Show();
        }

        private void vouchersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmEditVouchers frmEditVouchers1 = new frmEditVouchers();
            frmEditVouchers1.Show();
        }

        private void companyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmCompany frmCompany1 = new frmCompany();
            frmCompany1.Show();
        }

        private void securityDateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmSecurityDate frmSecurityDate1 = new frmSecurityDate();
            frmSecurityDate1.Show();
        }

        private void noOfCopiesToPrintToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmSetNoCopiesToPrint frmSetNoCopiesToPrint1 = new frmSetNoCopiesToPrint();
            frmSetNoCopiesToPrint1.Show();
            
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            glbltxtNoCopy = txtNoCopy;
        }

     

        private void categoryAddToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void categoryEditToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void warehouseAddToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmEntryWarehouseAdd frmWarehouseAdd1 = new frmEntryWarehouseAdd();
            frmWarehouseAdd1.Show();
        }

        private void warehouseEditToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmEntryWarehouseEdit frmWarehouseEdit1 = new frmEntryWarehouseEdit();
            frmWarehouseEdit1.Show();
        }

        
        private void purchaseDeliveryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void productAddToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void chargeInvoiceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void cashSalesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmVoucherCS frmVoucherCS1 = new frmVoucherCS();
            frmVoucherCS1.Show();
        }

        private void adjustmentSlipToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmVoucherAS frmVoucherAS1 = new frmVoucherAS();
            frmVoucherAS1.Show();
        }

        private void returnSlipToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void transferSlipToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmVoucherTS frmVoucherTS1 = new frmVoucherTS();
            frmVoucherTS1.Show();
        }

        private void inventoryToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

 

        private void productEditToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void remittanceVoucherToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmVoucherRV frmVoucherRV1 = new frmVoucherRV();
            frmVoucherRV1.Show();
        }

       
        private void purchaseOrderToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

       

        private void cashReceiptsVoucherToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmVoucherCRV frmVoucherCRV1 = new frmVoucherCRV();
            frmVoucherCRV1.Show();
        }

        private void salesmanAddToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmEntrySalesmanAdd frmEntrySalesmanAdd1 = new frmEntrySalesmanAdd();
            frmEntrySalesmanAdd1.Show();
        }

        private void salesmanEditToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmEntrySalesmanEdit frmEntrySalesmanEdit1 = new frmEntrySalesmanEdit();
            frmEntrySalesmanEdit1.Show();
        }

        private void collectorAddToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmEntryCollectorAdd frmEntryCollectorAdd1 = new frmEntryCollectorAdd();
            frmEntryCollectorAdd1.Show();
        }

        private void collectorEditToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmEntryCollectorEdit frmEntryCollectorEdit1 = new frmEntryCollectorEdit();
            frmEntryCollectorEdit1.Show();
        }

       

        private void geographicalAreaAddToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmEntryGeogAreaAdd frmEntryGeogAreaAdd1 = new frmEntryGeogAreaAdd();
            frmEntryGeogAreaAdd1.Show();
        }

        private void geographicalAreaEditToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmEntryGeogAreaEdit frmEntryGeogAreaEdit1 = new frmEntryGeogAreaEdit();
            frmEntryGeogAreaEdit1.Show();
        }

        private void channelAddToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmEntryChannelAdd frmEntryChannelAdd1 = new frmEntryChannelAdd();
            frmEntryChannelAdd1.Show();
        }

        private void channelEditToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmEntryChannelEdit frmEntryChannelEdit1 = new frmEntryChannelEdit();
            frmEntryChannelEdit1.Show();
        }

        private void territoryAddToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmEntryTerritoryAdd frmEntryTerritoryAdd1 = new frmEntryTerritoryAdd();
            frmEntryTerritoryAdd1.Show();
        }

        private void territoryEditToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmEntryTerritoryEdit frmEntryTerritoryEdit1 = new frmEntryTerritoryEdit();
            frmEntryTerritoryEdit1.Show();
        }

    

        private void returnToSupplierToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmVoucherRTS frmVoucherRTS1 = new frmVoucherRTS();
            frmVoucherRTS1.Show();
        }

        private void withdrawalSlipToolStripMenuItem_Click(object sender, EventArgs e)
        {
 
        }

        private void productionSlipToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void resetToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmReset frmReset1 = new frmReset();
            frmReset1.Show();
        }

        private void actualInventoryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmVoucherAI frmVoucherAI1 = new frmVoucherAI();
            frmVoucherAI1.Show();
        }

        private void salesPerCustomerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmrptSalesStore frmrptSalesStore1 = new frmrptSalesStore();
            frmrptSalesStore1.Show();
        }

        private void vouchersToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmrptVoucher frptv = new frmrptVoucher();
            frptv.Show();

        }

        private void booksAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmrptBooks frmrptBooks1 = new frmrptBooks();
            frmrptBooks1.Show();
            
        }

        private void booksWarehouseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmrptBooksWarehouse frmrptBooksWarehouse1 = new frmrptBooksWarehouse();
            frmrptBooksWarehouse1.Show();
        }

        private void pOTransactionToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmrptPOTransaction frmrptPOTransaction1 = new frmrptPOTransaction();
            frmrptPOTransaction1.Show();

        }

        private void inventoryToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            frmrptInventory frmrptInventory1 = new frmrptInventory();
            frmrptInventory1.Show();

        }

        private void inventoryProcessToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmrptInvProcess frmInvCountSheet1 = new frmrptInvProcess();
            frmInvCountSheet1.Show();

        }

        private void transactionSummaryToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmrptTransactSum frmrptTransactSum1 = new frmrptTransactSum();
            frmrptTransactSum1.Show();

        }

        private void ledgerSummaryToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmrptLedgerSummary frmrptLedgerSummary1 = new frmrptLedgerSummary();
            frmrptLedgerSummary1.Show();
        }

        private void individualLedgerToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmrptIndLedger frmrptIndLedger1 = new frmrptIndLedger();
            frmrptIndLedger1.Show();

        }

        private void subsidiaryLedgerToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmrptSubsidiaryLedger frptsl = new frmrptSubsidiaryLedger();
            frptsl.Show();

        }

        private void withdrawalSlipToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            
        }

        private void productionSlipToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            
        }

        private void purchaseDeliveryToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            
        }

        private void salesPerProductToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void chargeInvoiceToolStripMenuItem1_Click(object sender, EventArgs e)
        {
       
        }

        private void transferSlipToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            
        }

        private void purchaseOrderToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmVoucherPO frmVoucherPO1 = new frmVoucherPO();
            frmVoucherPO1.Show();

        }

        private void purchaseDeliveryToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            frmVoucherPD frmVoucherPD1 = new frmVoucherPD();
            frmVoucherPD1.Show();
        }

        private void withdrawalSlipToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            frmVoucherWS frmVoucherWS1 = new frmVoucherWS();
            frmVoucherWS1.Show();
        }

        private void productionSlipToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            frmVoucherPS frmVoucherPS1 = new frmVoucherPS();
            frmVoucherPS1.Show();
        }

        private void proformaInvoiceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmVoucherPI frmVoucherPI1 = new frmVoucherPI();
            frmVoucherPI1.Show();
        }

        private void chargeInvoiceToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            frmVoucherCI frmVoucherCI1 = new frmVoucherCI();
            frmVoucherCI1.Show();
        }

        private void cashSalesToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmVoucherCS frmVoucherCS1 = new frmVoucherCS();
            frmVoucherCS1.Show();
        }

        private void returnSlipToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmVoucherRS frmVoucherRS1 = new frmVoucherRS();
            frmVoucherRS1.Show();
        }

        private void categoryAddToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmEntryCategoryAdd frmEntryCategoryAdd1 = new frmEntryCategoryAdd();
            frmEntryCategoryAdd1.Show();
        }

        private void categoryEditToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmEntryCategoryEdit frmEntryCategoryEdit1 = new frmEntryCategoryEdit();
            frmEntryCategoryEdit1.Show();
        }

        private void bankDetailsAddToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmEntryBankDetailAdd frmEntryBankDetailAdd1 = new frmEntryBankDetailAdd();
            frmEntryBankDetailAdd1.Show();
        }

        private void bankDetailsEditToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmEntryBankDetailEdit frmEntryBankDetailEdit1 = new frmEntryBankDetailEdit();
            frmEntryBankDetailEdit1.Show();
        }

        private void productAddToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmEntryProductAdd frmEntryProductAdd1 = new frmEntryProductAdd();
            frmEntryProductAdd1.Show();
        }

        private void productEditRawMaterialToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmEntryProductEditRawMaterial frmEntryProductEditRawMaterial1 = new frmEntryProductEditRawMaterial();
            frmEntryProductEditRawMaterial1.Show();
        }

        private void productEditFinishedProductToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmEntryProductEditFinishedProduct frmEntryProductEditFinishedProduct1 = new frmEntryProductEditFinishedProduct();
            frmEntryProductEditFinishedProduct1.Show();
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmEntryCustomerNameAddOthers frmEntryCustomerNameAddOthers1 = new frmEntryCustomerNameAddOthers();
            frmEntryCustomerNameAddOthers1.Show();
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            frmEntryCustomerEditOthers frmEntryCustomerEditOthers1 = new frmEntryCustomerEditOthers();
            frmEntryCustomerEditOthers1.Show();
        }

        private void addToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmEntryInvClassification frmEntryInvClassification1 = new frmEntryInvClassification();
            frmEntryInvClassification1.Show();
        }

        private void inventoryClassificationEditToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmEntryInvClassEdit frmEntryInvClassEdit1 = new frmEntryInvClassEdit();
            frmEntryInvClassEdit1.Show();
        }

        private void productEditOfficeSuppliesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmEntryProductEntryOfficeSupplies frmEntryProductEntryOfficeSupplies1 = new frmEntryProductEntryOfficeSupplies();
            frmEntryProductEntryOfficeSupplies1.Show();
        }

        private void withdrawalSlipOfficeSuppliesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new frmVoucherOS().Show();
        }

        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void inventoryClassificationToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
