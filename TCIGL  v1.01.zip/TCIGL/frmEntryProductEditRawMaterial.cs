﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TCIGL
{
    public partial class frmEntryProductEditRawMaterial : Form
    {
        private SqlDataAdapter da;
        private DataTable dataTable = null;
        private SqlConnection myconnection;
        private BindingSource bindingSource = null;
        BindingSource bsource = new BindingSource();
     //   DataSet ds = null;
        string sql;
        ClsPermission ClsPermission1 = new ClsPermission();
        ClsGetConnection ClsGetConnection1 = new ClsGetConnection();
        ClsBuildComboBox ClsBuildComboBox1 = new ClsBuildComboBox();

        public frmEntryProductEditRawMaterial()
        {
            InitializeComponent();
        }

        private void frmProductEditDatasheet_Load(object sender, EventArgs e)
        {
            ClsPermission1.ClsObjects(this.Text);
            if (new ClsValidation().emptytxt(ClsPermission1.plstxtObject))
            {
                MessageBox.Show("You do not have necessary permission to open this file", "POS");
                this.Close();
            }
            else
            {
                LoadData();
            }
        }
        private void btnclose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
       
        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                da.Update(dataTable);
                MessageBox.Show("Saved", "POS");
            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        private void LoadData()
        {
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);

            sql = "SELECT StockNumber, StockCode, StockDesc, Size, UM, CatCode, SupplierCode, UCost,  SellingPrice, Reorderpoint, MaintainingBal, Active, InvClassCode  FROM tblStocks WHERE InvClassCode=01 OR InvClassCode=02";

            da = new SqlDataAdapter(sql, myconnection);
            SqlCommandBuilder commandBuilder = new SqlCommandBuilder(da);
            dataTable = new DataTable();
            da.Fill(dataTable);
            bindingSource = new BindingSource();
            bindingSource.DataSource = dataTable;

            //Category Data Source
            string selectQueryStringtblCategory = "SELECT CatCode, CatDesc FROM tblCategory ORDER BY CatDesc";
            SqlDataAdapter sqlDataAdaptertblCategory = new SqlDataAdapter(selectQueryStringtblCategory, myconnection);
            SqlCommandBuilder sqlCommandBuildertblCategory = new SqlCommandBuilder(sqlDataAdaptertblCategory);
            DataTable dataTabletblCategory = new DataTable();
            sqlDataAdaptertblCategory.Fill(dataTabletblCategory);
            BindingSource bindingSourcetblCategory = new BindingSource();
            bindingSourcetblCategory.DataSource = dataTabletblCategory;

            //tblCustomer Data Source
            string selectQueryStringtblCustomer = "SELECT ControlNo, CustName FROM tblCustomer WHERE NType='S' ORDER BY CustName";
            SqlDataAdapter sqlDataAdaptertblCustomer = new SqlDataAdapter(selectQueryStringtblCustomer, myconnection);
            SqlCommandBuilder sqlCommandBuildertblCustomer = new SqlCommandBuilder(sqlDataAdaptertblCustomer);
            DataTable dataTabletblCustomer = new DataTable();
            sqlDataAdaptertblCustomer.Fill(dataTabletblCustomer);
            BindingSource bindingSourcetblCustomer = new BindingSource();
            bindingSourcetblCustomer.DataSource = dataTabletblCustomer;


            //tblInvClassCode Data Source
            string selectQueryStringtblInvClassCode = "SELECT InvClassCode, InvClassDesc FROM tblInvClass ORDER BY InvClassDesc";
            SqlDataAdapter sqlDataAdaptertblInvClassCode = new SqlDataAdapter(selectQueryStringtblInvClassCode, myconnection);
            SqlCommandBuilder sqlCommandBuildertblInvClassCode = new SqlCommandBuilder(sqlDataAdaptertblInvClassCode);
            DataTable dataTabletblInviClass = new DataTable();
            sqlDataAdaptertblInvClassCode.Fill(dataTabletblInviClass);
            BindingSource bindingSourcetblInviClass = new BindingSource();
            bindingSourcetblInviClass.DataSource = dataTabletblInviClass;



            //Adding  StockNumber TextBox
            DataGridViewTextBoxColumn ColumnStockNumber = new DataGridViewTextBoxColumn();
            ColumnStockNumber.HeaderText = "Number";
            //ColumnStockNumber.Width = 80;
            ColumnStockNumber.DataPropertyName = "StockNumber";
            ColumnStockNumber.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            ColumnStockNumber.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnStockNumber.Visible = false;
            dgv1.Columns.Add(ColumnStockNumber);

            //Adding  StockCode TextBox
            DataGridViewTextBoxColumn ColumnStockCode = new DataGridViewTextBoxColumn();
            ColumnStockCode.HeaderText = "Code";
            ColumnStockCode.Width = 100;
            ColumnStockCode.DataPropertyName = "StockCode";
            ColumnStockCode.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            ColumnStockCode.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgv1.Columns.Add(ColumnStockCode);

            //Adding  StockDesc TextBox
            DataGridViewTextBoxColumn ColumnStockDesc = new DataGridViewTextBoxColumn();
            ColumnStockDesc.HeaderText = "Description";
            ColumnStockDesc.Width = 100;
            ColumnStockDesc.DataPropertyName = "StockDesc";
            ColumnStockDesc.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            ColumnStockDesc.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            ColumnStockDesc.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgv1.Columns.Add(ColumnStockDesc);

        
            DataGridViewTextBoxColumn ColumnUM = new DataGridViewTextBoxColumn();
            ColumnUM.HeaderText = "Unit Measure";
            //ColumnSPPC1.Width = 80;
            ColumnUM.DataPropertyName = "UM";
            ColumnUM.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            ColumnUM.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgv1.Columns.Add(ColumnUM);


            DataGridViewTextBoxColumn ColumnSize = new DataGridViewTextBoxColumn();
            ColumnSize.HeaderText = "Size";
            //ColumnSPPC1.Width = 80;
            ColumnSize.DataPropertyName = "Size";
            ColumnSize.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            ColumnSize.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgv1.Columns.Add(ColumnSize);
          


            //Adding  Category Combo
            DataGridViewComboBoxColumn ColumnCatCode = new DataGridViewComboBoxColumn();
            ColumnCatCode.DataPropertyName = "CatCode";
            ColumnCatCode.HeaderText = "Category";
            ColumnCatCode.Width = 100;
            ColumnCatCode.DataSource = bindingSourcetblCategory;
            ColumnCatCode.ValueMember = "CatCode";
            ColumnCatCode.DisplayMember = "CatDesc";
            dgv1.Columns.Add(ColumnCatCode);

            //Adding  supplier Combo
            DataGridViewComboBoxColumn ColumnSupplierCode = new DataGridViewComboBoxColumn();
            ColumnSupplierCode.DataPropertyName = "SupplierCode";
            ColumnSupplierCode.HeaderText = "Supplier";
            ColumnSupplierCode.Width = 100;
            ColumnSupplierCode.DataSource = bindingSourcetblCustomer;
            ColumnSupplierCode.ValueMember = "ControlNo";
            ColumnSupplierCode.DisplayMember = "CustName";
            dgv1.Columns.Add(ColumnSupplierCode);

            //Adding  UCost TextBox
            DataGridViewTextBoxColumn ColumnUCost = new DataGridViewTextBoxColumn();
            ColumnUCost.HeaderText = "Cost";
            ColumnUCost.Width = 80;
            ColumnUCost.DataPropertyName = "UCost";
            ColumnUCost.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            ColumnUCost.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgv1.Columns.Add(ColumnUCost);

            //Adding  SPPC1 TextBox
            DataGridViewTextBoxColumn ColumnSPPC1 = new DataGridViewTextBoxColumn();
            ColumnSPPC1.HeaderText = "Selling Price";
            //ColumnSPPC1.Width = 80;
            ColumnSPPC1.DataPropertyName = "SellingPrice";
            ColumnSPPC1.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            ColumnSPPC1.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgv1.Columns.Add(ColumnSPPC1);

            DataGridViewTextBoxColumn ColumnReorderpoint = new DataGridViewTextBoxColumn();
            ColumnReorderpoint.HeaderText = "Re-Order Point";
            ColumnReorderpoint.Width = 80;
            ColumnReorderpoint.DataPropertyName = "Reorderpoint";
            ColumnReorderpoint.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            ColumnReorderpoint.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgv1.Columns.Add(ColumnReorderpoint);

            DataGridViewTextBoxColumn ColumnMaintainingBal = new DataGridViewTextBoxColumn();
            ColumnMaintainingBal.HeaderText = "Maintaining Balance";
            ColumnMaintainingBal.Width = 100;
            ColumnMaintainingBal.DataPropertyName = "MaintainingBal";
            ColumnMaintainingBal.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            ColumnMaintainingBal.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgv1.Columns.Add(ColumnMaintainingBal);

            //Adding  FinishedProduct checkbox
            //DataGridViewCheckBoxColumn ColumnFinishedProduct = new DataGridViewCheckBoxColumn();
            //ColumnFinishedProduct.HeaderText = "Finished Product";
            //ColumnFinishedProduct.Width = 70;
            //ColumnFinishedProduct.DataPropertyName = "FinishedProduct";
            //ColumnFinishedProduct.FalseValue = 0;
            //ColumnFinishedProduct.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            //ColumnFinishedProduct.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            //dgv1.Columns.Add(ColumnFinishedProduct);

            //DataGridViewCheckBoxColumn ColumnTBS = new DataGridViewCheckBoxColumn();
            //ColumnTBS.HeaderText = "To be Sold";
            //ColumnTBS.Width = 70;
            //ColumnTBS.DataPropertyName = "TBS";
            //ColumnTBS.FalseValue = 0;
            //ColumnTBS.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            //ColumnTBS.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            //dgv1.Columns.Add(ColumnTBS);

            //Adding  Active checkbox
            DataGridViewCheckBoxColumn ColumnActive = new DataGridViewCheckBoxColumn();
            ColumnActive.HeaderText = "Active";
            ColumnActive.Width = 70;
            ColumnActive.DataPropertyName = "Active";
            ColumnActive.FalseValue = 0;
            ColumnActive.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            ColumnActive.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgv1.Columns.Add(ColumnActive);


            //Adding Inventory Class
            DataGridViewComboBoxColumn ColumnInvClass = new DataGridViewComboBoxColumn();
            ColumnInvClass.HeaderText = "Inventory Class";
            ColumnInvClass.Width = 150;
            ColumnInvClass.DataPropertyName = "InvClassCode";
            ColumnInvClass.DataSource = bindingSourcetblInviClass;
            ColumnInvClass.ValueMember = "InvClassCode";
            ColumnInvClass.DisplayMember = "InvClassDesc";
            ColumnInvClass.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            ColumnInvClass.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgv1.Columns.Add(ColumnInvClass);
            
            


            //Setting Data Source for DataGridView
            dgv1.DataSource = bindingSource;
            //dgv1.AutoResizeColumns();
            //dgv1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            myconnection.Close();
            this.WindowState = FormWindowState.Maximized;
            dgv1.AllowUserToAddRows = false;
           
            dgv1.Columns[6].DefaultCellStyle.Format = "N2";
            dgv1.Columns[7].DefaultCellStyle.Format = "N4";
            dgv1.Columns[8].DefaultCellStyle.Format = "N2";
            dgv1.Columns[9].DefaultCellStyle.Format = "N0";
        }

        private void cbCode_CheckedChanged(object sender, EventArgs e)
        {
            if (cbCode.Checked==true)
            {
                cbDesc.CheckState = 0;
            }
           
        }

        private void cbDesc_CheckedChanged(object sender, EventArgs e)
        {
            if (cbDesc.Checked == true)
            {
                cbCode.CheckState = 0;
            }
        }

        private void txtStockDesc_Validating(object sender, CancelEventArgs e)
        {
          
        }

        private void txtStockDesc_TextChanged(object sender, EventArgs e)
        {
            if (cbCode.Checked==true)
            { 
            DataView dv = dataTable.DefaultView;
            dv.RowFilter = "StockCode LIKE '%" + txtStockDesc.Text + "%'";
            dgv1.DataSource = dv;
            }
            else
            {
                DataView dv = dataTable.DefaultView;
                dv.RowFilter = "StockDesc LIKE '%" + txtStockDesc.Text + "%'";
                dgv1.DataSource = dv;
            }
        }
    }
}
