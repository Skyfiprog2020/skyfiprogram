﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace TCIGL
{
    public partial class frmCAMainAcctAdd : Form
    {
        SqlConnection myconnection;
        //SqlDataReader dr;
        SqlCommand mycommand;
        BindingSource dbind = new BindingSource();
        ClsBuildCOAComboBox ClsBuildCOAComboBox1 = new ClsBuildCOAComboBox();
        ClsGetConnection ClsGetConnection1 = new ClsGetConnection();
        ClsPermission ClsPermission1 = new ClsPermission(); 

        public frmCAMainAcctAdd()
        {
            InitializeComponent();
        }

        private void btnclose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buildcboFSClass()
        {
            ClsBuildCOAComboBox1.ClsbuildCOAG1();
            this.cboFSClass.DataSource = (ClsBuildCOAComboBox1.ARCOAG1);
            this.cboFSClass.DisplayMember = "Display";
            this.cboFSClass.ValueMember = "Value";
        }

        private void buildcboNormalBal()
        {
            ClsBuildCOAComboBox1.ClsbuildCOAG2();
            this.cboNormalBal.DataSource = (ClsBuildCOAComboBox1.ARCOAG2);
            this.cboNormalBal.DisplayMember = "Display";
            this.cboNormalBal.ValueMember = "Value";
        }

        private void buildcboFCCode()
        {
            ClsBuildCOAComboBox1.ClsbuildFirstCaption();
            this.cboFCCode.DataSource = (ClsBuildCOAComboBox1.ARFCCode);
            this.cboFCCode.DisplayMember = "Display";
            this.cboFCCode.ValueMember = "Value";
        }
        private void buildcboSCCode()
        {
            ClsBuildCOAComboBox1.ClsbuildSecondCaption();
            this.cboSCCode.DataSource = (ClsBuildCOAComboBox1.ARSCCode);
            this.cboSCCode.DisplayMember = "Display";
            this.cboSCCode.ValueMember = "Value";
        }

        private void buildcboUsageCode()
        {
            ClsBuildCOAComboBox1.ClsbuildUsage();
            this.cboUsageCode.DataSource = (ClsBuildCOAComboBox1.ARUsage);
            this.cboUsageCode.DisplayMember = "Display";
            this.cboUsageCode.ValueMember = "Value";
        }
        private void frmCAPAAdd_Load(object sender, EventArgs e)
        {
            ClsPermission1.ClsObjects(this.Text);
            if (new ClsValidation().emptytxt(ClsPermission1.plstxtObject))
            {
                MessageBox.Show("You do not have necessary permission to open this file", "GL");
                this.Close();
            }
            else
            {
                buildcboFSClass();
                buildcboNormalBal();
                buildcboFCCode();
                buildcboSCCode();
                buildcboUsageCode();
                cboFSClass.SelectedValue = "";
                cboFCCode.SelectedValue = "";
                cboSCCode.SelectedValue = "";
                cboNormalBal.SelectedValue = "";
                cboUsageCode.SelectedValue = "";
                
            }

        }

 

        private void btnsave_Click(object sender, EventArgs e)
        {

            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();

            if (new Clsexist().RecordExists(ref myconnection, "SELECT AcctNo FROM tblTitleAcct WHERE AcctNo ='" + txtAcctNo.Text + "'"))
            {
                myconnection.Close();
                MessageBox.Show("Duplicate entry", "POS");
                txtAcctNo.Focus();
            }

            else if (new Clsexist().RecordExists(ref myconnection, "SELECT TitleAcct FROM tblTitleAcct WHERE TitleAcct ='" + txtTitleAcct.Text + "'"))
            {
                myconnection.Close();
                MessageBox.Show("Duplicate entry", "POS");
                txtTitleAcct.Focus();
            }

            else if (new ClsValidation().emptytxt(txtAcctNo.Text))
            {
                myconnection.Close();
                MessageBox.Show("Please complete your entry", "GL");
                txtAcctNo.Focus();
            }
            else if (new ClsValidation().emptytxt(txtTitleAcct.Text))
            {
                myconnection.Close();
                MessageBox.Show("Please complete your entry", "GL");
                txtTitleAcct.Focus();
            }
            else if (new ClsValidation().emptytxt(cboFSClass.Text))
            {
                myconnection.Close();
                MessageBox.Show("Please complete your entry", "GL");
                cboFSClass.Focus();
            }
            else if (new ClsValidation().emptytxt(cboFCCode.Text))
            {
                myconnection.Close();
                MessageBox.Show("Please complete your entry", "GL");
                cboFCCode.Focus();
            }
            else if (new ClsValidation().emptytxt(cboSCCode.Text))
            {
                myconnection.Close();
                MessageBox.Show("Please complete your entry", "GL");
                cboSCCode.Focus();
            }
            else if (new ClsValidation().emptytxt(cboNormalBal.Text))
            {
                myconnection.Close();
                MessageBox.Show("Please complete your entry", "GL");
                cboNormalBal.Focus();
            }
            else if (new ClsValidation().emptytxt(cboUsageCode.Text))
            {
                myconnection.Close();
                MessageBox.Show("Please complete your entry", "GL");
                cboUsageCode.Focus();
            }
            else
            {
                string sqlstatement;
                sqlstatement = "INSERT INTO tblTitleAcct (AcctNo, TitleAcct, FSClass, FCCode, SCCode, NormalBal, UsageCode) Values (@_AcctNo, @_TitleAcct, @_FSClass, @_FCCode, @_SCCode, @_NormalBal, @_UsageCode)";
                mycommand = new SqlCommand(sqlstatement, myconnection);
                mycommand.Parameters.Add("_AcctNo", SqlDbType.VarChar).Value = txtAcctNo.Text;
                mycommand.Parameters.Add("_TitleAcct", SqlDbType.VarChar).Value = txtTitleAcct.Text;
                mycommand.Parameters.Add("_FSClass", SqlDbType.VarChar).Value = cboFSClass.SelectedValue;
                mycommand.Parameters.Add("_FCCode", SqlDbType.VarChar).Value = cboFCCode.SelectedValue;
                mycommand.Parameters.Add("_SCCode", SqlDbType.VarChar).Value = cboSCCode.SelectedValue;
                mycommand.Parameters.Add("_NormalBal", SqlDbType.VarChar).Value = cboNormalBal.SelectedValue;
                mycommand.Parameters.Add("_UsageCode", SqlDbType.VarChar).Value = cboUsageCode.SelectedValue;
                int n1 = mycommand.ExecuteNonQuery();
                myconnection.Close();
                txtAcctNo.Text = "";
                txtTitleAcct.Text = "";
                cboFSClass.SelectedValue = "";
                cboFCCode.SelectedValue = "";
                cboSCCode.SelectedValue = "";
                cboNormalBal.SelectedValue = "";
                cboUsageCode.SelectedValue = "";
                txtAcctNo.Focus();
             }
        }

        private void cboFSClass_Validating(object sender, CancelEventArgs e)
            {
                if (new ClsValidation().emptytxt(cboFSClass.Text))
                {
                }
                else if (cboFSClass.Text != null && cboFSClass.SelectedValue == null)
                {
                    MessageBox.Show("Not found", "GL");
                    cboFSClass.Focus();
                }
            }

        private void cboFCCode_Validating(object sender, CancelEventArgs e)
            {
                if (new ClsValidation().emptytxt(cboFCCode.Text))
                {
                }
                else if (cboFCCode.Text != null && cboFCCode.SelectedValue == null)
                {
                    MessageBox.Show("Not found", "GL");
                    cboFCCode.Focus();
                }
            }

        private void cboSCCode_Validating(object sender, CancelEventArgs e)
            {
                if (new ClsValidation().emptytxt(cboSCCode.Text))
                {
                }
                else if (cboSCCode.Text != null && cboSCCode.SelectedValue == null)
                {
                    MessageBox.Show("Not found", "GL");
                    cboSCCode.Focus();
                }
            }

        private void cboNormalBal_Validating(object sender, CancelEventArgs e)
            {
                if (new ClsValidation().emptytxt(cboNormalBal.Text))
                {
                }
                else if (cboNormalBal.Text != null && cboNormalBal.SelectedValue == null)
                {
                    MessageBox.Show("Not found", "GL");
                    cboNormalBal.Focus();
                }
            }

        private void cboUsageCode_Validating(object sender, CancelEventArgs e)
            {
                if (new ClsValidation().emptytxt(cboUsageCode.Text))
                {
                }
                else if (cboUsageCode.Text != null && cboUsageCode.SelectedValue == null)
                {
                    MessageBox.Show("Not found", "GL");
                    cboUsageCode.Focus();
                }
            }

        private void nextfieldenter1(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.Equals(Keys.Enter))
            {
                SendKeys.Send("{TAB}");
            }
            else if ((e.KeyCode.Equals(Keys.Up)) || (e.KeyCode.Equals(Keys.Left)))
            {
                SendKeys.Send("+{TAB}");
            }
            else if ((e.KeyCode.Equals(Keys.Down)) || (e.KeyCode.Equals(Keys.Right)))
            {
                SendKeys.Send("{TAB}");
            }

        }

        private void nextfieldenter2(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.Equals(Keys.Enter))
            {
                SendKeys.Send("{TAB}");
            }
        }
            
    }
}
