﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TCIGL
{
    class convertcents
    {
        public string getconvertcents(string numbers1)
        {
            switch (numbers1)
            {
                case "0.00":
                    return "0/100 only";
                case "0.01":
                    return "01/100 only";
                case "0.02":
                    return "02/100 only";
                case "0.03":
                    return "03/100 only";
                case "0.04":
                    return "04/100 only";
                case "0.05":
                    return "05/100 only";
                case "0.06":
                    return "06/100 only";
                case "0.07":
                    return "07/100 only";
                case "0.08":
                    return "08/100 only";
                case "0.09":
                    return "09/100 only";
                case "0.10":
                    return "10/100 only";

                case "0.11":
                    return "11/100 only";
                case "0.12":
                    return "12/100 only";
                case "0.13":
                    return "13/100 only";
                case "0.14":
                    return "14/100 only";
                case "0.15":
                    return "15/100 only";
                case "0.16":
                    return "16/100 only";
                case "0.17":
                    return "17/100 only";
                case "0.18":
                    return "18/100 only";
                case "0.19":
                    return "19/100 only";
                case "0.20":
                    return "20/100 only";

                case "0.21":
                    return "21/100 only";
                case "0.22":
                    return "22/100 only";
                case "0.23":
                    return "23/100 only";
                case "0.24":
                    return "24/100 only";
                case "0.25":
                    return "25/100 only";
                case "0.26":
                    return "26/100 only";
                case "0.27":
                    return "27/100 only";
                case "0.28":
                    return "28/100 only";
                case "0.29":
                    return "29/100 only";
                case "0.30":
                    return "30/100 only";

                case "0.31":
                    return "31/100 only";
                case "0.32":
                    return "32/100 only";
                case "0.33":
                    return "33/100 only";
                case "0.34":
                    return "34/100 only";
                case "0.35":
                    return "35/100 only";
                case "0.36":
                    return "36/100 only";
                case "0.37":
                    return "37/100 only";
                case "0.38":
                    return "38/100 only";
                case "0.39":
                    return "39/100 only";
                case "0.40":
                    return "40/100 only";

                case "0.41":
                    return "41/100 only";
                case "0.42":
                    return "42/100 only";
                case "0.43":
                    return "43/100 only";
                case "0.44":
                    return "44/100 only";
                case "0.45":
                    return "45/100 only";
                case "0.46":
                    return "46/100 only";
                case "0.47":
                    return "47/100 only";
                case "0.48":
                    return "48/100 only";
                case "0.49":
                    return "49/100 only";
                case "0.50":
                    return "50/100 only";

                case "0.51":
                    return "51/100 only";
                case "0.52":
                    return "52/100 only";
                case "0.53":
                    return "53/100 only";
                case "0.54":
                    return "54/100 only";
                case "0.55":
                    return "55/100 only";
                case "0.56":
                    return "56/100 only";
                case "0.57":
                    return "57/100 only";
                case "0.58":
                    return "58/100 only";
                case "0.59":
                    return "59/100 only";
                case "0.60":
                    return "60/100 only";

                case "0.61":
                    return "61/100 only";
                case "0.62":
                    return "62/100 only";
                case "0.63":
                    return "63/100 only";
                case "0.64":
                    return "64/100 only";
                case "0.65":
                    return "65/100 only";
                case "0.66":
                    return "66/100 only";
                case "0.67":
                    return "67/100 only";
                case "0.68":
                    return "68/100 only";
                case "0.69":
                    return "69/100 only";
                case "0.70":
                    return "70/100 only";

                case "0.71":
                    return "71/100 only";
                case "0.72":
                    return "72/100 only";
                case "0.73":
                    return "73/100 only";
                case "0.74":
                    return "74/100 only";
                case "0.75":
                    return "75/100 only";
                case "0.76":
                    return "76/100 only";
                case "0.77":
                    return "77/100 only";
                case "0.78":
                    return "78/100 only";
                case "0.79":
                    return "79/100 only";
                case "0.80":
                    return "80/100 only";

                case "0.81":
                    return "81/100 only";
                case "0.82":
                    return "82/100 only";
                case "0.83":
                    return "83/100 only";
                case "0.84":
                    return "84/100 only";
                case "0.85":
                    return "85/100 only";
                case "0.86":
                    return "86/100 only";
                case "0.87":
                    return "87/100 only";
                case "0.88":
                    return "88/100 only";
                case "0.89":
                    return "89/100 only";
                case "0.90":
                    return "90/100 only";

                case "0.91":
                    return "91/100 only";
                case "0.92":
                    return "92/100 only";
                case "0.93":
                    return "93/100 only";
                case "0.94":
                    return "94/100 only";
                case "0.95":
                    return "95/100 only";
                case "0.96":
                    return "96/100 only";
                case "0.97":
                    return "97/100 only";
                case "0.98":
                    return "98/100 only";
                case "0.99":
                    return "99/100 only";

                default:
                    return "0/100 only";

            }
        }
    }  

}
