﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;

namespace TCIGL
{
    class ClsCompName
    {

        public string varcn;
        public string varAddress;
        public string varTIN;
        public string plsbn;
        public string plsaddress;
        public string plsCRaddress;
        public string plsCName;
        SqlConnection myconnection;
        SqlDataReader dr;
        SqlCommand mycommand;
        ClsDefaultBranch ClsDefaultBranch1 = new ClsDefaultBranch();
        ClsGetConnection ClsGetConnection1 = new ClsGetConnection(); 

        public void ClsCompNameMain()
        {
            try
            {

                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = new SqlCommand("Select * from tblCompany", myconnection);
                dr = mycommand.ExecuteReader();
                while (dr.Read())
                {
                    varcn = dr["Company"].ToString();
                    varAddress = dr["Address"].ToString();
                    varTIN = dr["TIN"].ToString();
                }

                dr.Close();
                myconnection.Close();

            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                //dr.Close();
                myconnection.Close();
            }
        }

        public void ClsCompNamebranch()
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = new SqlCommand("Select CNCode, CName, CAddress from tblCompanyName WHERE CNCode = '"+(ClsDefaultBranch1.plsvardb)+"'", myconnection);
                dr = mycommand.ExecuteReader();
                while (dr.Read())
                {
                    plsbn = dr["CName"].ToString();
                    plsaddress = dr["CAddress"].ToString();
                }

                dr.Close();
                myconnection.Close();

            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                //dr.Close();
                myconnection.Close();
            }
        }
    

       public void ClsCompNamebranchAddress(string strCNCode)
        {
            try
            {

                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = new SqlCommand("Select CName, CAddress from tblCompanyName WHERE CNCode = '" + strCNCode + "'", myconnection);
                dr = mycommand.ExecuteReader();
                while (dr.Read())
                {
                    plsCName = dr["CName"].ToString();
                    plsCRaddress = dr["CAddress"].ToString();
                }

                dr.Close();
                myconnection.Close();

            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                //dr.Close();
                myconnection.Close();
            }
        }

    }    
   
}
