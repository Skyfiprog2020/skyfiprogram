﻿namespace TCIGL
{
    partial class frmCheckWriter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btnrefresh = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtEndDate = new System.Windows.Forms.MaskedTextBox();
            this.txtBeginDate = new System.Windows.Forms.MaskedTextBox();
            this.txtCustName = new System.Windows.Forms.TextBox();
            this.txtcamount = new System.Windows.Forms.TextBox();
            this.txtamtinwords = new System.Windows.Forms.TextBox();
            this.cboCNCode = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.dgv1 = new System.Windows.Forms.DataGridView();
            this.cboBankCode = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnPrint = new System.Windows.Forms.Button();
            this.btnSettings = new System.Windows.Forms.Button();
            this.ColumnNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnVoucher = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnCustName = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.ColumnBankActEntry = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnCheckNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnTDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnCredit = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgv1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnrefresh
            // 
            this.btnrefresh.Location = new System.Drawing.Point(810, 12);
            this.btnrefresh.Name = "btnrefresh";
            this.btnrefresh.Size = new System.Drawing.Size(75, 23);
            this.btnrefresh.TabIndex = 4;
            this.btnrefresh.Text = "&Refresh List";
            this.btnrefresh.UseVisualStyleBackColor = true;
            this.btnrefresh.Click += new System.EventHandler(this.btnrefresh_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(8, 73);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 19);
            this.label2.TabIndex = 12;
            this.label2.Text = "Ending Date";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(8, 12);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 19);
            this.label3.TabIndex = 11;
            this.label3.Text = "Beginning Date";
            // 
            // txtEndDate
            // 
            this.txtEndDate.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEndDate.Location = new System.Drawing.Point(12, 95);
            this.txtEndDate.Mask = "00/00/0000";
            this.txtEndDate.Name = "txtEndDate";
            this.txtEndDate.Size = new System.Drawing.Size(116, 26);
            this.txtEndDate.TabIndex = 2;
            this.txtEndDate.ValidatingType = typeof(System.DateTime);
            this.txtEndDate.KeyDown += new System.Windows.Forms.KeyEventHandler(this.nextfieldenter1);
            this.txtEndDate.Leave += new System.EventHandler(this.txtEndDate_Leave);
            // 
            // txtBeginDate
            // 
            this.txtBeginDate.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBeginDate.Location = new System.Drawing.Point(12, 34);
            this.txtBeginDate.Mask = "00/00/0000";
            this.txtBeginDate.Name = "txtBeginDate";
            this.txtBeginDate.Size = new System.Drawing.Size(116, 26);
            this.txtBeginDate.TabIndex = 1;
            this.txtBeginDate.ValidatingType = typeof(System.DateTime);
            this.txtBeginDate.KeyDown += new System.Windows.Forms.KeyEventHandler(this.nextfieldenter1);
            this.txtBeginDate.Leave += new System.EventHandler(this.txtBeginDate_Leave);
            // 
            // txtCustName
            // 
            this.txtCustName.BackColor = System.Drawing.SystemColors.Window;
            this.txtCustName.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCustName.Location = new System.Drawing.Point(12, 482);
            this.txtCustName.Name = "txtCustName";
            this.txtCustName.ReadOnly = true;
            this.txtCustName.Size = new System.Drawing.Size(603, 29);
            this.txtCustName.TabIndex = 16;
            // 
            // txtcamount
            // 
            this.txtcamount.BackColor = System.Drawing.SystemColors.Window;
            this.txtcamount.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcamount.Location = new System.Drawing.Point(709, 482);
            this.txtcamount.Name = "txtcamount";
            this.txtcamount.ReadOnly = true;
            this.txtcamount.Size = new System.Drawing.Size(176, 29);
            this.txtcamount.TabIndex = 17;
            this.txtcamount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtamtinwords
            // 
            this.txtamtinwords.BackColor = System.Drawing.SystemColors.Window;
            this.txtamtinwords.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtamtinwords.ForeColor = System.Drawing.Color.Black;
            this.txtamtinwords.Location = new System.Drawing.Point(12, 517);
            this.txtamtinwords.Name = "txtamtinwords";
            this.txtamtinwords.ReadOnly = true;
            this.txtamtinwords.Size = new System.Drawing.Size(873, 29);
            this.txtamtinwords.TabIndex = 18;
            // 
            // cboCNCode
            // 
            this.cboCNCode.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cboCNCode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cboCNCode.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboCNCode.FormattingEnabled = true;
            this.cboCNCode.Location = new System.Drawing.Point(159, 95);
            this.cboCNCode.Name = "cboCNCode";
            this.cboCNCode.Size = new System.Drawing.Size(726, 27);
            this.cboCNCode.TabIndex = 3;
            this.cboCNCode.Validated += new System.EventHandler(this.cboCName_Validated);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(155, 73);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 19);
            this.label4.TabIndex = 30;
            this.label4.Text = "Branch";
            // 
            // dgv1
            // 
            this.dgv1.AllowUserToAddRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgv1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColumnNumber,
            this.ColumnVoucher,
            this.ColumnCustName,
            this.ColumnBankActEntry,
            this.ColumnCheckNo,
            this.ColumnTDate,
            this.ColumnCredit});
            this.dgv1.Location = new System.Drawing.Point(12, 126);
            this.dgv1.Name = "dgv1";
            this.dgv1.Size = new System.Drawing.Size(873, 349);
            this.dgv1.TabIndex = 31;
            this.dgv1.CellEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv1_CellEnter);
            // 
            // cboBankCode
            // 
            this.cboBankCode.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cboBankCode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cboBankCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboBankCode.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboBankCode.FormattingEnabled = true;
            this.cboBankCode.Location = new System.Drawing.Point(58, 557);
            this.cboBankCode.Name = "cboBankCode";
            this.cboBankCode.Size = new System.Drawing.Size(557, 27);
            this.cboBankCode.TabIndex = 66;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(8, 560);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 19);
            this.label1.TabIndex = 67;
            this.label1.Text = "Bank:";
            // 
            // btnPrint
            // 
            this.btnPrint.Location = new System.Drawing.Point(810, 561);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(75, 23);
            this.btnPrint.TabIndex = 68;
            this.btnPrint.Text = "Print";
            this.btnPrint.UseVisualStyleBackColor = true;
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // btnSettings
            // 
            this.btnSettings.Location = new System.Drawing.Point(810, 38);
            this.btnSettings.Name = "btnSettings";
            this.btnSettings.Size = new System.Drawing.Size(75, 23);
            this.btnSettings.TabIndex = 69;
            this.btnSettings.Text = "Settings...";
            this.btnSettings.UseVisualStyleBackColor = true;
            this.btnSettings.Click += new System.EventHandler(this.btnSettings_Click);
            // 
            // ColumnNumber
            // 
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ColumnNumber.DefaultCellStyle = dataGridViewCellStyle2;
            this.ColumnNumber.HeaderText = "Number";
            this.ColumnNumber.Name = "ColumnNumber";
            this.ColumnNumber.Width = 65;
            // 
            // ColumnVoucher
            // 
            this.ColumnVoucher.HeaderText = "Voucher";
            this.ColumnVoucher.Name = "ColumnVoucher";
            this.ColumnVoucher.Width = 60;
            // 
            // ColumnCustName
            // 
            this.ColumnCustName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ColumnCustName.DefaultCellStyle = dataGridViewCellStyle3;
            this.ColumnCustName.HeaderText = "Name";
            this.ColumnCustName.Name = "ColumnCustName";
            this.ColumnCustName.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.ColumnCustName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // ColumnBankActEntry
            // 
            this.ColumnBankActEntry.HeaderText = "Bank";
            this.ColumnBankActEntry.Name = "ColumnBankActEntry";
            this.ColumnBankActEntry.Width = 150;
            // 
            // ColumnCheckNo
            // 
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ColumnCheckNo.DefaultCellStyle = dataGridViewCellStyle4;
            this.ColumnCheckNo.HeaderText = "Check No.";
            this.ColumnCheckNo.Name = "ColumnCheckNo";
            this.ColumnCheckNo.Width = 126;
            // 
            // ColumnTDate
            // 
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ColumnTDate.DefaultCellStyle = dataGridViewCellStyle5;
            this.ColumnTDate.HeaderText = "Date";
            this.ColumnTDate.Name = "ColumnTDate";
            this.ColumnTDate.Width = 75;
            // 
            // ColumnCredit
            // 
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ColumnCredit.DefaultCellStyle = dataGridViewCellStyle6;
            this.ColumnCredit.HeaderText = "Amount";
            this.ColumnCredit.Name = "ColumnCredit";
            // 
            // frmCheckWriter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(897, 591);
            this.Controls.Add(this.btnSettings);
            this.Controls.Add(this.btnPrint);
            this.Controls.Add(this.cboBankCode);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgv1);
            this.Controls.Add(this.cboCNCode);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtamtinwords);
            this.Controls.Add(this.txtcamount);
            this.Controls.Add(this.txtCustName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtEndDate);
            this.Controls.Add(this.txtBeginDate);
            this.Controls.Add(this.btnrefresh);
            this.Name = "frmCheckWriter";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Check Writer";
            this.Load += new System.EventHandler(this.frmCheckWriter_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnrefresh;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.MaskedTextBox txtEndDate;
        private System.Windows.Forms.MaskedTextBox txtBeginDate;
        private System.Windows.Forms.TextBox txtCustName;
        private System.Windows.Forms.TextBox txtcamount;
        private System.Windows.Forms.TextBox txtamtinwords;
        private System.Windows.Forms.ComboBox cboCNCode;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridView dgv1;
        private System.Windows.Forms.ComboBox cboBankCode;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnPrint;
        private System.Windows.Forms.Button btnSettings;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnVoucher;
        private System.Windows.Forms.DataGridViewComboBoxColumn ColumnCustName;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnBankActEntry;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnCheckNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnTDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnCredit;

    }
}