﻿namespace TCIGL
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.companyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator17 = new System.Windows.Forms.ToolStripSeparator();
            this.noOfCopiesToPrintToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.securityDateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator38 = new System.Windows.Forms.ToolStripSeparator();
            this.resetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator18 = new System.Windows.Forms.ToolStripSeparator();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.entryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clientAddToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clientEditToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator48 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.othersAddToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.othersEditToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator16 = new System.Windows.Forms.ToolStripSeparator();
            this.warehouseAddToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.warehouseEditToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator22 = new System.Windows.Forms.ToolStripSeparator();
            this.customerDataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salesmanAddToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.salesmanEditToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.collectorAddToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.collectorEditToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator19 = new System.Windows.Forms.ToolStripSeparator();
            this.geographicalAreaAddToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.geographicalAreaEditToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator34 = new System.Windows.Forms.ToolStripSeparator();
            this.territoryEditToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.territoryAddToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator33 = new System.Windows.Forms.ToolStripSeparator();
            this.channelAddToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.channelEditToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator45 = new System.Windows.Forms.ToolStripSeparator();
            this.categoryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.categoryAddToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator44 = new System.Windows.Forms.ToolStripSeparator();
            this.categoryEditToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator21 = new System.Windows.Forms.ToolStripSeparator();
            this.bankDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bankDetailsAddToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bankDetailsEditToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator23 = new System.Windows.Forms.ToolStripSeparator();
            this.productToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.productAddToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator46 = new System.Windows.Forms.ToolStripSeparator();
            this.productEditRawMaterialToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator47 = new System.Windows.Forms.ToolStripSeparator();
            this.productEditFinishedProductToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator55 = new System.Windows.Forms.ToolStripSeparator();
            this.productEditOfficeSuppliesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator54 = new System.Windows.Forms.ToolStripSeparator();
            this.chartOfAccountsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.accountTitleAddToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.accountTitleEditToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator12 = new System.Windows.Forms.ToolStripSeparator();
            this.department1AddToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.department2EditToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator13 = new System.Windows.Forms.ToolStripSeparator();
            this.department2AddToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.departToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator14 = new System.Windows.Forms.ToolStripSeparator();
            this.postingAccountToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.postingAccountEditToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator15 = new System.Windows.Forms.ToolStripSeparator();
            this.viewMainAccountToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewSubAccountToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.transactionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.accountsPayableVoucherToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.variousDocumentsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.checkVoucherToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.officialReceiptsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cashReceiptsVoucherToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.remittanceVoucherToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.journalVoucherToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator24 = new System.Windows.Forms.ToolStripSeparator();
            this.purchasesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.purchaseOrderToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator53 = new System.Windows.Forms.ToolStripSeparator();
            this.purchaseDeliveryToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.returnToSupplierToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator25 = new System.Windows.Forms.ToolStripSeparator();
            this.salesToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.chargeInvoiceToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator49 = new System.Windows.Forms.ToolStripSeparator();
            this.cashSalesToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator50 = new System.Windows.Forms.ToolStripSeparator();
            this.returnSlipToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator26 = new System.Windows.Forms.ToolStripSeparator();
            this.transferSlipToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator27 = new System.Windows.Forms.ToolStripSeparator();
            this.adjustmentSlipToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator20 = new System.Windows.Forms.ToolStripSeparator();
            this.productionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.proformaInvoiceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator51 = new System.Windows.Forms.ToolStripSeparator();
            this.withdrawalSlipToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator52 = new System.Windows.Forms.ToolStripSeparator();
            this.productionSlipToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.withdrawalSlipOfficeSuppliesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator32 = new System.Windows.Forms.ToolStripSeparator();
            this.actualInventoryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.searchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vouchersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.securityToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.userAddToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator28 = new System.Windows.Forms.ToolStripSeparator();
            this.gRToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator29 = new System.Windows.Forms.ToolStripSeparator();
            this.membershipToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator30 = new System.Windows.Forms.ToolStripSeparator();
            this.permissionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bookPerWarehouseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vouchersToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator37 = new System.Windows.Forms.ToolStripSeparator();
            this.booksAllToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator36 = new System.Windows.Forms.ToolStripSeparator();
            this.booksWarehouseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator35 = new System.Windows.Forms.ToolStripSeparator();
            this.pOTransactionToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.trialBalanceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator10 = new System.Windows.Forms.ToolStripSeparator();
            this.ledgerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.subsidiaryLedgerToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator40 = new System.Windows.Forms.ToolStripSeparator();
            this.ledgerSummaryToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator41 = new System.Windows.Forms.ToolStripSeparator();
            this.individualLedgerToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.loanBalancesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statementOfAccountsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator9 = new System.Windows.Forms.ToolStripSeparator();
            this.othersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator11 = new System.Windows.Forms.ToolStripSeparator();
            this.checkWriterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bankReconciliationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.inventoryToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.inventoryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator42 = new System.Windows.Forms.ToolStripSeparator();
            this.inventoryProcessToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator43 = new System.Windows.Forms.ToolStripSeparator();
            this.transactionSummaryToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator31 = new System.Windows.Forms.ToolStripSeparator();
            this.salesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salesPerCustomerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator39 = new System.Windows.Forms.ToolStripSeparator();
            this.txtNoCopy = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.entryToolStripMenuItem,
            this.chartOfAccountsToolStripMenuItem,
            this.transactionToolStripMenuItem,
            this.searchToolStripMenuItem,
            this.securityToolStripMenuItem,
            this.reportsToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1064, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.companyToolStripMenuItem,
            this.toolStripSeparator17,
            this.noOfCopiesToPrintToolStripMenuItem,
            this.securityDateToolStripMenuItem,
            this.toolStripSeparator38,
            this.resetToolStripMenuItem,
            this.toolStripSeparator18,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "&File";
            // 
            // companyToolStripMenuItem
            // 
            this.companyToolStripMenuItem.Name = "companyToolStripMenuItem";
            this.companyToolStripMenuItem.Size = new System.Drawing.Size(188, 22);
            this.companyToolStripMenuItem.Text = "Company";
            this.companyToolStripMenuItem.Click += new System.EventHandler(this.companyToolStripMenuItem_Click);
            // 
            // toolStripSeparator17
            // 
            this.toolStripSeparator17.Name = "toolStripSeparator17";
            this.toolStripSeparator17.Size = new System.Drawing.Size(185, 6);
            // 
            // noOfCopiesToPrintToolStripMenuItem
            // 
            this.noOfCopiesToPrintToolStripMenuItem.Name = "noOfCopiesToPrintToolStripMenuItem";
            this.noOfCopiesToPrintToolStripMenuItem.Size = new System.Drawing.Size(188, 22);
            this.noOfCopiesToPrintToolStripMenuItem.Text = "No. of Copies to Print";
            this.noOfCopiesToPrintToolStripMenuItem.Click += new System.EventHandler(this.noOfCopiesToPrintToolStripMenuItem_Click);
            // 
            // securityDateToolStripMenuItem
            // 
            this.securityDateToolStripMenuItem.Name = "securityDateToolStripMenuItem";
            this.securityDateToolStripMenuItem.Size = new System.Drawing.Size(188, 22);
            this.securityDateToolStripMenuItem.Text = "Security Date";
            this.securityDateToolStripMenuItem.Click += new System.EventHandler(this.securityDateToolStripMenuItem_Click);
            // 
            // toolStripSeparator38
            // 
            this.toolStripSeparator38.Name = "toolStripSeparator38";
            this.toolStripSeparator38.Size = new System.Drawing.Size(185, 6);
            // 
            // resetToolStripMenuItem
            // 
            this.resetToolStripMenuItem.Name = "resetToolStripMenuItem";
            this.resetToolStripMenuItem.Size = new System.Drawing.Size(188, 22);
            this.resetToolStripMenuItem.Text = "Reset";
            this.resetToolStripMenuItem.Click += new System.EventHandler(this.resetToolStripMenuItem_Click);
            // 
            // toolStripSeparator18
            // 
            this.toolStripSeparator18.Name = "toolStripSeparator18";
            this.toolStripSeparator18.Size = new System.Drawing.Size(185, 6);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(188, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // entryToolStripMenuItem
            // 
            this.entryToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.clientAddToolStripMenuItem,
            this.clientEditToolStripMenuItem,
            this.toolStripSeparator48,
            this.toolStripMenuItem1,
            this.toolStripMenuItem2,
            this.toolStripSeparator5,
            this.othersAddToolStripMenuItem,
            this.othersEditToolStripMenuItem,
            this.toolStripSeparator16,
            this.toolStripMenuItem4,
            this.toolStripMenuItem3,
            this.warehouseAddToolStripMenuItem,
            this.warehouseEditToolStripMenuItem,
            this.toolStripSeparator22,
            this.customerDataToolStripMenuItem,
            this.toolStripSeparator45,
            this.categoryToolStripMenuItem,
            this.toolStripSeparator21,
            this.bankDetailsToolStripMenuItem,
            this.toolStripSeparator23,
            this.productToolStripMenuItem,
            this.toolStripSeparator54,
            this.toolStripMenuItem5});
            this.entryToolStripMenuItem.Name = "entryToolStripMenuItem";
            this.entryToolStripMenuItem.Size = new System.Drawing.Size(46, 20);
            this.entryToolStripMenuItem.Text = "Entry";
            // 
            // clientAddToolStripMenuItem
            // 
            this.clientAddToolStripMenuItem.Name = "clientAddToolStripMenuItem";
            this.clientAddToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.clientAddToolStripMenuItem.Text = "Customer - Add";
            this.clientAddToolStripMenuItem.Click += new System.EventHandler(this.clientAddToolStripMenuItem_Click);
            // 
            // clientEditToolStripMenuItem
            // 
            this.clientEditToolStripMenuItem.Name = "clientEditToolStripMenuItem";
            this.clientEditToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.clientEditToolStripMenuItem.Text = "Customer - Edit";
            this.clientEditToolStripMenuItem.Click += new System.EventHandler(this.clientEditToolStripMenuItem_Click);
            // 
            // toolStripSeparator48
            // 
            this.toolStripSeparator48.Name = "toolStripSeparator48";
            this.toolStripSeparator48.Size = new System.Drawing.Size(194, 6);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(197, 22);
            this.toolStripMenuItem1.Text = "Others - Add";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(197, 22);
            this.toolStripMenuItem2.Text = "Others - Edit";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(194, 6);
            // 
            // othersAddToolStripMenuItem
            // 
            this.othersAddToolStripMenuItem.Name = "othersAddToolStripMenuItem";
            this.othersAddToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.othersAddToolStripMenuItem.Text = "Supplier - Add";
            this.othersAddToolStripMenuItem.Click += new System.EventHandler(this.othersAddToolStripMenuItem_Click);
            // 
            // othersEditToolStripMenuItem
            // 
            this.othersEditToolStripMenuItem.Name = "othersEditToolStripMenuItem";
            this.othersEditToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.othersEditToolStripMenuItem.Text = "Supplier - Edit";
            this.othersEditToolStripMenuItem.Click += new System.EventHandler(this.othersEditToolStripMenuItem_Click);
            // 
            // toolStripSeparator16
            // 
            this.toolStripSeparator16.Name = "toolStripSeparator16";
            this.toolStripSeparator16.Size = new System.Drawing.Size(194, 6);
            // 
            // warehouseAddToolStripMenuItem
            // 
            this.warehouseAddToolStripMenuItem.Name = "warehouseAddToolStripMenuItem";
            this.warehouseAddToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.warehouseAddToolStripMenuItem.Text = "Warehouse - Add";
            this.warehouseAddToolStripMenuItem.Click += new System.EventHandler(this.warehouseAddToolStripMenuItem_Click);
            // 
            // warehouseEditToolStripMenuItem
            // 
            this.warehouseEditToolStripMenuItem.Name = "warehouseEditToolStripMenuItem";
            this.warehouseEditToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.warehouseEditToolStripMenuItem.Text = "Warehouse - Edit";
            this.warehouseEditToolStripMenuItem.Click += new System.EventHandler(this.warehouseEditToolStripMenuItem_Click);
            // 
            // toolStripSeparator22
            // 
            this.toolStripSeparator22.Name = "toolStripSeparator22";
            this.toolStripSeparator22.Size = new System.Drawing.Size(194, 6);
            // 
            // customerDataToolStripMenuItem
            // 
            this.customerDataToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.salesmanAddToolStripMenuItem1,
            this.salesmanEditToolStripMenuItem1,
            this.toolStripSeparator6,
            this.collectorAddToolStripMenuItem,
            this.collectorEditToolStripMenuItem1,
            this.toolStripSeparator19,
            this.geographicalAreaAddToolStripMenuItem1,
            this.geographicalAreaEditToolStripMenuItem1,
            this.toolStripSeparator34,
            this.territoryEditToolStripMenuItem1,
            this.territoryAddToolStripMenuItem1,
            this.toolStripSeparator33,
            this.channelAddToolStripMenuItem1,
            this.channelEditToolStripMenuItem1});
            this.customerDataToolStripMenuItem.Name = "customerDataToolStripMenuItem";
            this.customerDataToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.customerDataToolStripMenuItem.Text = "Customer Data";
            // 
            // salesmanAddToolStripMenuItem1
            // 
            this.salesmanAddToolStripMenuItem1.Name = "salesmanAddToolStripMenuItem1";
            this.salesmanAddToolStripMenuItem1.Size = new System.Drawing.Size(204, 22);
            this.salesmanAddToolStripMenuItem1.Text = "Salesman - Add";
            this.salesmanAddToolStripMenuItem1.Click += new System.EventHandler(this.salesmanAddToolStripMenuItem1_Click);
            // 
            // salesmanEditToolStripMenuItem1
            // 
            this.salesmanEditToolStripMenuItem1.Name = "salesmanEditToolStripMenuItem1";
            this.salesmanEditToolStripMenuItem1.Size = new System.Drawing.Size(204, 22);
            this.salesmanEditToolStripMenuItem1.Text = "Salesman - Edit";
            this.salesmanEditToolStripMenuItem1.Click += new System.EventHandler(this.salesmanEditToolStripMenuItem1_Click);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(201, 6);
            // 
            // collectorAddToolStripMenuItem
            // 
            this.collectorAddToolStripMenuItem.Name = "collectorAddToolStripMenuItem";
            this.collectorAddToolStripMenuItem.Size = new System.Drawing.Size(204, 22);
            this.collectorAddToolStripMenuItem.Text = "Collector - Add";
            this.collectorAddToolStripMenuItem.Click += new System.EventHandler(this.collectorAddToolStripMenuItem_Click);
            // 
            // collectorEditToolStripMenuItem1
            // 
            this.collectorEditToolStripMenuItem1.Name = "collectorEditToolStripMenuItem1";
            this.collectorEditToolStripMenuItem1.Size = new System.Drawing.Size(204, 22);
            this.collectorEditToolStripMenuItem1.Text = "Collector - Edit";
            this.collectorEditToolStripMenuItem1.Click += new System.EventHandler(this.collectorEditToolStripMenuItem1_Click);
            // 
            // toolStripSeparator19
            // 
            this.toolStripSeparator19.Name = "toolStripSeparator19";
            this.toolStripSeparator19.Size = new System.Drawing.Size(201, 6);
            // 
            // geographicalAreaAddToolStripMenuItem1
            // 
            this.geographicalAreaAddToolStripMenuItem1.Name = "geographicalAreaAddToolStripMenuItem1";
            this.geographicalAreaAddToolStripMenuItem1.Size = new System.Drawing.Size(204, 22);
            this.geographicalAreaAddToolStripMenuItem1.Text = "Geographical Area - Add";
            this.geographicalAreaAddToolStripMenuItem1.Click += new System.EventHandler(this.geographicalAreaAddToolStripMenuItem1_Click);
            // 
            // geographicalAreaEditToolStripMenuItem1
            // 
            this.geographicalAreaEditToolStripMenuItem1.Name = "geographicalAreaEditToolStripMenuItem1";
            this.geographicalAreaEditToolStripMenuItem1.Size = new System.Drawing.Size(204, 22);
            this.geographicalAreaEditToolStripMenuItem1.Text = "Geographical Area - Edit";
            this.geographicalAreaEditToolStripMenuItem1.Click += new System.EventHandler(this.geographicalAreaEditToolStripMenuItem1_Click);
            // 
            // toolStripSeparator34
            // 
            this.toolStripSeparator34.Name = "toolStripSeparator34";
            this.toolStripSeparator34.Size = new System.Drawing.Size(201, 6);
            // 
            // territoryEditToolStripMenuItem1
            // 
            this.territoryEditToolStripMenuItem1.Name = "territoryEditToolStripMenuItem1";
            this.territoryEditToolStripMenuItem1.Size = new System.Drawing.Size(204, 22);
            this.territoryEditToolStripMenuItem1.Text = "Territory - Edit";
            this.territoryEditToolStripMenuItem1.Click += new System.EventHandler(this.territoryEditToolStripMenuItem1_Click);
            // 
            // territoryAddToolStripMenuItem1
            // 
            this.territoryAddToolStripMenuItem1.Name = "territoryAddToolStripMenuItem1";
            this.territoryAddToolStripMenuItem1.Size = new System.Drawing.Size(204, 22);
            this.territoryAddToolStripMenuItem1.Text = "Territory - Add";
            this.territoryAddToolStripMenuItem1.Click += new System.EventHandler(this.territoryAddToolStripMenuItem1_Click);
            // 
            // toolStripSeparator33
            // 
            this.toolStripSeparator33.Name = "toolStripSeparator33";
            this.toolStripSeparator33.Size = new System.Drawing.Size(201, 6);
            // 
            // channelAddToolStripMenuItem1
            // 
            this.channelAddToolStripMenuItem1.Name = "channelAddToolStripMenuItem1";
            this.channelAddToolStripMenuItem1.Size = new System.Drawing.Size(204, 22);
            this.channelAddToolStripMenuItem1.Text = "Channel - Add";
            this.channelAddToolStripMenuItem1.Click += new System.EventHandler(this.channelAddToolStripMenuItem1_Click);
            // 
            // channelEditToolStripMenuItem1
            // 
            this.channelEditToolStripMenuItem1.Name = "channelEditToolStripMenuItem1";
            this.channelEditToolStripMenuItem1.Size = new System.Drawing.Size(204, 22);
            this.channelEditToolStripMenuItem1.Text = "Channel - Edit";
            this.channelEditToolStripMenuItem1.Click += new System.EventHandler(this.channelEditToolStripMenuItem1_Click);
            // 
            // toolStripSeparator45
            // 
            this.toolStripSeparator45.Name = "toolStripSeparator45";
            this.toolStripSeparator45.Size = new System.Drawing.Size(194, 6);
            // 
            // categoryToolStripMenuItem
            // 
            this.categoryToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.categoryAddToolStripMenuItem1,
            this.toolStripSeparator44,
            this.categoryEditToolStripMenuItem1});
            this.categoryToolStripMenuItem.Name = "categoryToolStripMenuItem";
            this.categoryToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.categoryToolStripMenuItem.Text = "Category";
            // 
            // categoryAddToolStripMenuItem1
            // 
            this.categoryAddToolStripMenuItem1.Name = "categoryAddToolStripMenuItem1";
            this.categoryAddToolStripMenuItem1.Size = new System.Drawing.Size(155, 22);
            this.categoryAddToolStripMenuItem1.Text = "Category - Add";
            this.categoryAddToolStripMenuItem1.Click += new System.EventHandler(this.categoryAddToolStripMenuItem1_Click);
            // 
            // toolStripSeparator44
            // 
            this.toolStripSeparator44.Name = "toolStripSeparator44";
            this.toolStripSeparator44.Size = new System.Drawing.Size(152, 6);
            // 
            // categoryEditToolStripMenuItem1
            // 
            this.categoryEditToolStripMenuItem1.Name = "categoryEditToolStripMenuItem1";
            this.categoryEditToolStripMenuItem1.Size = new System.Drawing.Size(155, 22);
            this.categoryEditToolStripMenuItem1.Text = "Category - Edit";
            this.categoryEditToolStripMenuItem1.Click += new System.EventHandler(this.categoryEditToolStripMenuItem1_Click);
            // 
            // toolStripSeparator21
            // 
            this.toolStripSeparator21.Name = "toolStripSeparator21";
            this.toolStripSeparator21.Size = new System.Drawing.Size(194, 6);
            // 
            // bankDetailsToolStripMenuItem
            // 
            this.bankDetailsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bankDetailsAddToolStripMenuItem,
            this.bankDetailsEditToolStripMenuItem});
            this.bankDetailsToolStripMenuItem.Name = "bankDetailsToolStripMenuItem";
            this.bankDetailsToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.bankDetailsToolStripMenuItem.Text = "Bank Details";
            // 
            // bankDetailsAddToolStripMenuItem
            // 
            this.bankDetailsAddToolStripMenuItem.Name = "bankDetailsAddToolStripMenuItem";
            this.bankDetailsAddToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.bankDetailsAddToolStripMenuItem.Text = "Bank Details - Add";
            this.bankDetailsAddToolStripMenuItem.Click += new System.EventHandler(this.bankDetailsAddToolStripMenuItem_Click);
            // 
            // bankDetailsEditToolStripMenuItem
            // 
            this.bankDetailsEditToolStripMenuItem.Name = "bankDetailsEditToolStripMenuItem";
            this.bankDetailsEditToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.bankDetailsEditToolStripMenuItem.Text = "Bank Details - Edit";
            this.bankDetailsEditToolStripMenuItem.Click += new System.EventHandler(this.bankDetailsEditToolStripMenuItem_Click);
            // 
            // toolStripSeparator23
            // 
            this.toolStripSeparator23.Name = "toolStripSeparator23";
            this.toolStripSeparator23.Size = new System.Drawing.Size(194, 6);
            // 
            // productToolStripMenuItem
            // 
            this.productToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.productAddToolStripMenuItem1,
            this.toolStripSeparator46,
            this.productEditRawMaterialToolStripMenuItem,
            this.toolStripSeparator47,
            this.productEditFinishedProductToolStripMenuItem,
            this.toolStripSeparator55,
            this.productEditOfficeSuppliesToolStripMenuItem});
            this.productToolStripMenuItem.Name = "productToolStripMenuItem";
            this.productToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.productToolStripMenuItem.Text = "Product";
            // 
            // productAddToolStripMenuItem1
            // 
            this.productAddToolStripMenuItem1.Name = "productAddToolStripMenuItem1";
            this.productAddToolStripMenuItem1.Size = new System.Drawing.Size(239, 22);
            this.productAddToolStripMenuItem1.Text = "Product - Add";
            this.productAddToolStripMenuItem1.Click += new System.EventHandler(this.productAddToolStripMenuItem1_Click);
            // 
            // toolStripSeparator46
            // 
            this.toolStripSeparator46.Name = "toolStripSeparator46";
            this.toolStripSeparator46.Size = new System.Drawing.Size(236, 6);
            // 
            // productEditRawMaterialToolStripMenuItem
            // 
            this.productEditRawMaterialToolStripMenuItem.Name = "productEditRawMaterialToolStripMenuItem";
            this.productEditRawMaterialToolStripMenuItem.Size = new System.Drawing.Size(239, 22);
            this.productEditRawMaterialToolStripMenuItem.Text = "Product - Edit Raw Material";
            this.productEditRawMaterialToolStripMenuItem.Click += new System.EventHandler(this.productEditRawMaterialToolStripMenuItem_Click);
            // 
            // toolStripSeparator47
            // 
            this.toolStripSeparator47.Name = "toolStripSeparator47";
            this.toolStripSeparator47.Size = new System.Drawing.Size(236, 6);
            // 
            // productEditFinishedProductToolStripMenuItem
            // 
            this.productEditFinishedProductToolStripMenuItem.Name = "productEditFinishedProductToolStripMenuItem";
            this.productEditFinishedProductToolStripMenuItem.Size = new System.Drawing.Size(239, 22);
            this.productEditFinishedProductToolStripMenuItem.Text = "Product - Edit Finished Product";
            this.productEditFinishedProductToolStripMenuItem.Click += new System.EventHandler(this.productEditFinishedProductToolStripMenuItem_Click);
            // 
            // toolStripSeparator55
            // 
            this.toolStripSeparator55.Name = "toolStripSeparator55";
            this.toolStripSeparator55.Size = new System.Drawing.Size(236, 6);
            // 
            // productEditOfficeSuppliesToolStripMenuItem
            // 
            this.productEditOfficeSuppliesToolStripMenuItem.Name = "productEditOfficeSuppliesToolStripMenuItem";
            this.productEditOfficeSuppliesToolStripMenuItem.Size = new System.Drawing.Size(239, 22);
            this.productEditOfficeSuppliesToolStripMenuItem.Text = "Product - Edit Office Supplies";
            this.productEditOfficeSuppliesToolStripMenuItem.Click += new System.EventHandler(this.productEditOfficeSuppliesToolStripMenuItem_Click);
            // 
            // toolStripSeparator54
            // 
            this.toolStripSeparator54.Name = "toolStripSeparator54";
            this.toolStripSeparator54.Size = new System.Drawing.Size(194, 6);
            // 
            // chartOfAccountsToolStripMenuItem
            // 
            this.chartOfAccountsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.accountTitleAddToolStripMenuItem,
            this.accountTitleEditToolStripMenuItem,
            this.toolStripSeparator12,
            this.department1AddToolStripMenuItem,
            this.department2EditToolStripMenuItem,
            this.toolStripSeparator13,
            this.department2AddToolStripMenuItem,
            this.departToolStripMenuItem,
            this.toolStripSeparator14,
            this.postingAccountToolStripMenuItem,
            this.postingAccountEditToolStripMenuItem,
            this.toolStripSeparator15,
            this.viewMainAccountToolStripMenuItem,
            this.viewSubAccountToolStripMenuItem});
            this.chartOfAccountsToolStripMenuItem.Name = "chartOfAccountsToolStripMenuItem";
            this.chartOfAccountsToolStripMenuItem.Size = new System.Drawing.Size(115, 20);
            this.chartOfAccountsToolStripMenuItem.Text = "Chart of Accounts";
            // 
            // accountTitleAddToolStripMenuItem
            // 
            this.accountTitleAddToolStripMenuItem.Name = "accountTitleAddToolStripMenuItem";
            this.accountTitleAddToolStripMenuItem.Size = new System.Drawing.Size(195, 22);
            this.accountTitleAddToolStripMenuItem.Text = "Account Title - Add";
            this.accountTitleAddToolStripMenuItem.Click += new System.EventHandler(this.accountTitleAddToolStripMenuItem_Click);
            // 
            // accountTitleEditToolStripMenuItem
            // 
            this.accountTitleEditToolStripMenuItem.Name = "accountTitleEditToolStripMenuItem";
            this.accountTitleEditToolStripMenuItem.Size = new System.Drawing.Size(195, 22);
            this.accountTitleEditToolStripMenuItem.Text = "Account Title - Edit";
            this.accountTitleEditToolStripMenuItem.Click += new System.EventHandler(this.accountTitleEditToolStripMenuItem_Click);
            // 
            // toolStripSeparator12
            // 
            this.toolStripSeparator12.Name = "toolStripSeparator12";
            this.toolStripSeparator12.Size = new System.Drawing.Size(192, 6);
            // 
            // department1AddToolStripMenuItem
            // 
            this.department1AddToolStripMenuItem.Name = "department1AddToolStripMenuItem";
            this.department1AddToolStripMenuItem.Size = new System.Drawing.Size(195, 22);
            this.department1AddToolStripMenuItem.Text = "Department1 - Add";
            this.department1AddToolStripMenuItem.Click += new System.EventHandler(this.department1AddToolStripMenuItem_Click);
            // 
            // department2EditToolStripMenuItem
            // 
            this.department2EditToolStripMenuItem.Name = "department2EditToolStripMenuItem";
            this.department2EditToolStripMenuItem.Size = new System.Drawing.Size(195, 22);
            this.department2EditToolStripMenuItem.Text = "Department1 - Edit";
            this.department2EditToolStripMenuItem.Click += new System.EventHandler(this.department2EditToolStripMenuItem_Click);
            // 
            // toolStripSeparator13
            // 
            this.toolStripSeparator13.Name = "toolStripSeparator13";
            this.toolStripSeparator13.Size = new System.Drawing.Size(192, 6);
            // 
            // department2AddToolStripMenuItem
            // 
            this.department2AddToolStripMenuItem.Name = "department2AddToolStripMenuItem";
            this.department2AddToolStripMenuItem.Size = new System.Drawing.Size(195, 22);
            this.department2AddToolStripMenuItem.Text = "Department2 - Add";
            this.department2AddToolStripMenuItem.Click += new System.EventHandler(this.department2AddToolStripMenuItem_Click);
            // 
            // departToolStripMenuItem
            // 
            this.departToolStripMenuItem.Name = "departToolStripMenuItem";
            this.departToolStripMenuItem.Size = new System.Drawing.Size(195, 22);
            this.departToolStripMenuItem.Text = "Department2 - Edit";
            this.departToolStripMenuItem.Click += new System.EventHandler(this.departToolStripMenuItem_Click);
            // 
            // toolStripSeparator14
            // 
            this.toolStripSeparator14.Name = "toolStripSeparator14";
            this.toolStripSeparator14.Size = new System.Drawing.Size(192, 6);
            // 
            // postingAccountToolStripMenuItem
            // 
            this.postingAccountToolStripMenuItem.Name = "postingAccountToolStripMenuItem";
            this.postingAccountToolStripMenuItem.Size = new System.Drawing.Size(195, 22);
            this.postingAccountToolStripMenuItem.Text = "Posting Account - Add";
            this.postingAccountToolStripMenuItem.Click += new System.EventHandler(this.postingAccountToolStripMenuItem_Click);
            // 
            // postingAccountEditToolStripMenuItem
            // 
            this.postingAccountEditToolStripMenuItem.Name = "postingAccountEditToolStripMenuItem";
            this.postingAccountEditToolStripMenuItem.Size = new System.Drawing.Size(195, 22);
            this.postingAccountEditToolStripMenuItem.Text = "Posting Account - Edit";
            this.postingAccountEditToolStripMenuItem.Click += new System.EventHandler(this.postingAccountEditToolStripMenuItem_Click);
            // 
            // toolStripSeparator15
            // 
            this.toolStripSeparator15.Name = "toolStripSeparator15";
            this.toolStripSeparator15.Size = new System.Drawing.Size(192, 6);
            // 
            // viewMainAccountToolStripMenuItem
            // 
            this.viewMainAccountToolStripMenuItem.Name = "viewMainAccountToolStripMenuItem";
            this.viewMainAccountToolStripMenuItem.Size = new System.Drawing.Size(195, 22);
            this.viewMainAccountToolStripMenuItem.Text = "View - Main Account";
            this.viewMainAccountToolStripMenuItem.Click += new System.EventHandler(this.viewMainAccountToolStripMenuItem_Click);
            // 
            // viewSubAccountToolStripMenuItem
            // 
            this.viewSubAccountToolStripMenuItem.Name = "viewSubAccountToolStripMenuItem";
            this.viewSubAccountToolStripMenuItem.Size = new System.Drawing.Size(195, 22);
            this.viewSubAccountToolStripMenuItem.Text = "View - Sub Account";
            this.viewSubAccountToolStripMenuItem.Click += new System.EventHandler(this.viewSubAccountToolStripMenuItem_Click);
            // 
            // transactionToolStripMenuItem
            // 
            this.transactionToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.accountsPayableVoucherToolStripMenuItem,
            this.variousDocumentsToolStripMenuItem,
            this.toolStripSeparator1,
            this.checkVoucherToolStripMenuItem,
            this.toolStripSeparator3,
            this.officialReceiptsToolStripMenuItem,
            this.cashReceiptsVoucherToolStripMenuItem,
            this.toolStripSeparator4,
            this.remittanceVoucherToolStripMenuItem,
            this.journalVoucherToolStripMenuItem,
            this.toolStripSeparator24,
            this.purchasesToolStripMenuItem,
            this.returnToSupplierToolStripMenuItem,
            this.toolStripSeparator25,
            this.salesToolStripMenuItem2,
            this.toolStripSeparator26,
            this.transferSlipToolStripMenuItem,
            this.toolStripSeparator27,
            this.adjustmentSlipToolStripMenuItem,
            this.toolStripSeparator20,
            this.productionToolStripMenuItem,
            this.toolStripSeparator32,
            this.actualInventoryToolStripMenuItem});
            this.transactionToolStripMenuItem.Name = "transactionToolStripMenuItem";
            this.transactionToolStripMenuItem.Size = new System.Drawing.Size(62, 20);
            this.transactionToolStripMenuItem.Text = "Voucher";
            // 
            // accountsPayableVoucherToolStripMenuItem
            // 
            this.accountsPayableVoucherToolStripMenuItem.Name = "accountsPayableVoucherToolStripMenuItem";
            this.accountsPayableVoucherToolStripMenuItem.Size = new System.Drawing.Size(229, 22);
            this.accountsPayableVoucherToolStripMenuItem.Text = "Accounts Payable Voucher";
            this.accountsPayableVoucherToolStripMenuItem.Click += new System.EventHandler(this.accountsPayableVoucherToolStripMenuItem_Click);
            // 
            // variousDocumentsToolStripMenuItem
            // 
            this.variousDocumentsToolStripMenuItem.Name = "variousDocumentsToolStripMenuItem";
            this.variousDocumentsToolStripMenuItem.Size = new System.Drawing.Size(229, 22);
            this.variousDocumentsToolStripMenuItem.Text = "Accounts Receivable Voucher";
            this.variousDocumentsToolStripMenuItem.Click += new System.EventHandler(this.variousDocumentsToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(226, 6);
            // 
            // checkVoucherToolStripMenuItem
            // 
            this.checkVoucherToolStripMenuItem.Name = "checkVoucherToolStripMenuItem";
            this.checkVoucherToolStripMenuItem.Size = new System.Drawing.Size(229, 22);
            this.checkVoucherToolStripMenuItem.Text = "Check Voucher";
            this.checkVoucherToolStripMenuItem.Click += new System.EventHandler(this.checkVoucherToolStripMenuItem_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(226, 6);
            // 
            // officialReceiptsToolStripMenuItem
            // 
            this.officialReceiptsToolStripMenuItem.Name = "officialReceiptsToolStripMenuItem";
            this.officialReceiptsToolStripMenuItem.Size = new System.Drawing.Size(229, 22);
            this.officialReceiptsToolStripMenuItem.Text = "Official Receipts";
            this.officialReceiptsToolStripMenuItem.Click += new System.EventHandler(this.officialReceiptsToolStripMenuItem_Click);
            // 
            // cashReceiptsVoucherToolStripMenuItem
            // 
            this.cashReceiptsVoucherToolStripMenuItem.Name = "cashReceiptsVoucherToolStripMenuItem";
            this.cashReceiptsVoucherToolStripMenuItem.Size = new System.Drawing.Size(229, 22);
            this.cashReceiptsVoucherToolStripMenuItem.Text = "Cash Receipts Voucher";
            this.cashReceiptsVoucherToolStripMenuItem.Click += new System.EventHandler(this.cashReceiptsVoucherToolStripMenuItem_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(226, 6);
            // 
            // remittanceVoucherToolStripMenuItem
            // 
            this.remittanceVoucherToolStripMenuItem.Name = "remittanceVoucherToolStripMenuItem";
            this.remittanceVoucherToolStripMenuItem.Size = new System.Drawing.Size(229, 22);
            this.remittanceVoucherToolStripMenuItem.Text = "Remittance Voucher";
            this.remittanceVoucherToolStripMenuItem.Click += new System.EventHandler(this.remittanceVoucherToolStripMenuItem_Click);
            // 
            // journalVoucherToolStripMenuItem
            // 
            this.journalVoucherToolStripMenuItem.Name = "journalVoucherToolStripMenuItem";
            this.journalVoucherToolStripMenuItem.Size = new System.Drawing.Size(229, 22);
            this.journalVoucherToolStripMenuItem.Text = "Journal Voucher";
            this.journalVoucherToolStripMenuItem.Click += new System.EventHandler(this.journalVoucherToolStripMenuItem_Click);
            // 
            // toolStripSeparator24
            // 
            this.toolStripSeparator24.Name = "toolStripSeparator24";
            this.toolStripSeparator24.Size = new System.Drawing.Size(226, 6);
            // 
            // purchasesToolStripMenuItem
            // 
            this.purchasesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.purchaseOrderToolStripMenuItem1,
            this.toolStripSeparator53,
            this.purchaseDeliveryToolStripMenuItem2});
            this.purchasesToolStripMenuItem.Name = "purchasesToolStripMenuItem";
            this.purchasesToolStripMenuItem.Size = new System.Drawing.Size(229, 22);
            this.purchasesToolStripMenuItem.Text = "Purchases";
            // 
            // purchaseOrderToolStripMenuItem1
            // 
            this.purchaseOrderToolStripMenuItem1.Name = "purchaseOrderToolStripMenuItem1";
            this.purchaseOrderToolStripMenuItem1.Size = new System.Drawing.Size(167, 22);
            this.purchaseOrderToolStripMenuItem1.Text = "Purchase Order";
            this.purchaseOrderToolStripMenuItem1.Click += new System.EventHandler(this.purchaseOrderToolStripMenuItem1_Click);
            // 
            // toolStripSeparator53
            // 
            this.toolStripSeparator53.Name = "toolStripSeparator53";
            this.toolStripSeparator53.Size = new System.Drawing.Size(164, 6);
            // 
            // purchaseDeliveryToolStripMenuItem2
            // 
            this.purchaseDeliveryToolStripMenuItem2.Name = "purchaseDeliveryToolStripMenuItem2";
            this.purchaseDeliveryToolStripMenuItem2.Size = new System.Drawing.Size(167, 22);
            this.purchaseDeliveryToolStripMenuItem2.Text = "Purchase Delivery";
            this.purchaseDeliveryToolStripMenuItem2.Click += new System.EventHandler(this.purchaseDeliveryToolStripMenuItem2_Click);
            // 
            // returnToSupplierToolStripMenuItem
            // 
            this.returnToSupplierToolStripMenuItem.Name = "returnToSupplierToolStripMenuItem";
            this.returnToSupplierToolStripMenuItem.Size = new System.Drawing.Size(229, 22);
            this.returnToSupplierToolStripMenuItem.Text = "Return to Supplier";
            this.returnToSupplierToolStripMenuItem.Click += new System.EventHandler(this.returnToSupplierToolStripMenuItem_Click);
            // 
            // toolStripSeparator25
            // 
            this.toolStripSeparator25.Name = "toolStripSeparator25";
            this.toolStripSeparator25.Size = new System.Drawing.Size(226, 6);
            // 
            // salesToolStripMenuItem2
            // 
            this.salesToolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.chargeInvoiceToolStripMenuItem2,
            this.toolStripSeparator49,
            this.cashSalesToolStripMenuItem1,
            this.toolStripSeparator50,
            this.returnSlipToolStripMenuItem1});
            this.salesToolStripMenuItem2.Name = "salesToolStripMenuItem2";
            this.salesToolStripMenuItem2.Size = new System.Drawing.Size(229, 22);
            this.salesToolStripMenuItem2.Text = "Sales";
            // 
            // chargeInvoiceToolStripMenuItem2
            // 
            this.chargeInvoiceToolStripMenuItem2.Name = "chargeInvoiceToolStripMenuItem2";
            this.chargeInvoiceToolStripMenuItem2.Size = new System.Drawing.Size(153, 22);
            this.chargeInvoiceToolStripMenuItem2.Text = "Charge Invoice";
            this.chargeInvoiceToolStripMenuItem2.Click += new System.EventHandler(this.chargeInvoiceToolStripMenuItem2_Click);
            // 
            // toolStripSeparator49
            // 
            this.toolStripSeparator49.Name = "toolStripSeparator49";
            this.toolStripSeparator49.Size = new System.Drawing.Size(150, 6);
            // 
            // cashSalesToolStripMenuItem1
            // 
            this.cashSalesToolStripMenuItem1.Name = "cashSalesToolStripMenuItem1";
            this.cashSalesToolStripMenuItem1.Size = new System.Drawing.Size(153, 22);
            this.cashSalesToolStripMenuItem1.Text = "Cash Sales";
            this.cashSalesToolStripMenuItem1.Click += new System.EventHandler(this.cashSalesToolStripMenuItem1_Click);
            // 
            // toolStripSeparator50
            // 
            this.toolStripSeparator50.Name = "toolStripSeparator50";
            this.toolStripSeparator50.Size = new System.Drawing.Size(150, 6);
            // 
            // returnSlipToolStripMenuItem1
            // 
            this.returnSlipToolStripMenuItem1.Name = "returnSlipToolStripMenuItem1";
            this.returnSlipToolStripMenuItem1.Size = new System.Drawing.Size(153, 22);
            this.returnSlipToolStripMenuItem1.Text = "Return Slip";
            this.returnSlipToolStripMenuItem1.Click += new System.EventHandler(this.returnSlipToolStripMenuItem1_Click);
            // 
            // toolStripSeparator26
            // 
            this.toolStripSeparator26.Name = "toolStripSeparator26";
            this.toolStripSeparator26.Size = new System.Drawing.Size(226, 6);
            // 
            // transferSlipToolStripMenuItem
            // 
            this.transferSlipToolStripMenuItem.Name = "transferSlipToolStripMenuItem";
            this.transferSlipToolStripMenuItem.Size = new System.Drawing.Size(229, 22);
            this.transferSlipToolStripMenuItem.Text = "Transfer Slip";
            this.transferSlipToolStripMenuItem.Click += new System.EventHandler(this.transferSlipToolStripMenuItem_Click);
            // 
            // toolStripSeparator27
            // 
            this.toolStripSeparator27.Name = "toolStripSeparator27";
            this.toolStripSeparator27.Size = new System.Drawing.Size(226, 6);
            // 
            // adjustmentSlipToolStripMenuItem
            // 
            this.adjustmentSlipToolStripMenuItem.Name = "adjustmentSlipToolStripMenuItem";
            this.adjustmentSlipToolStripMenuItem.Size = new System.Drawing.Size(229, 22);
            this.adjustmentSlipToolStripMenuItem.Text = "Adjustment Slip";
            this.adjustmentSlipToolStripMenuItem.Click += new System.EventHandler(this.adjustmentSlipToolStripMenuItem_Click);
            // 
            // toolStripSeparator20
            // 
            this.toolStripSeparator20.Name = "toolStripSeparator20";
            this.toolStripSeparator20.Size = new System.Drawing.Size(226, 6);
            // 
            // productionToolStripMenuItem
            // 
            this.productionToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.proformaInvoiceToolStripMenuItem,
            this.toolStripSeparator51,
            this.withdrawalSlipToolStripMenuItem2,
            this.toolStripSeparator52,
            this.productionSlipToolStripMenuItem2,
            this.withdrawalSlipOfficeSuppliesToolStripMenuItem});
            this.productionToolStripMenuItem.Name = "productionToolStripMenuItem";
            this.productionToolStripMenuItem.Size = new System.Drawing.Size(229, 22);
            this.productionToolStripMenuItem.Text = "Production";
            // 
            // proformaInvoiceToolStripMenuItem
            // 
            this.proformaInvoiceToolStripMenuItem.Name = "proformaInvoiceToolStripMenuItem";
            this.proformaInvoiceToolStripMenuItem.Size = new System.Drawing.Size(246, 22);
            this.proformaInvoiceToolStripMenuItem.Text = "Proforma Invoice";
            this.proformaInvoiceToolStripMenuItem.Click += new System.EventHandler(this.proformaInvoiceToolStripMenuItem_Click);
            // 
            // toolStripSeparator51
            // 
            this.toolStripSeparator51.Name = "toolStripSeparator51";
            this.toolStripSeparator51.Size = new System.Drawing.Size(243, 6);
            // 
            // withdrawalSlipToolStripMenuItem2
            // 
            this.withdrawalSlipToolStripMenuItem2.Name = "withdrawalSlipToolStripMenuItem2";
            this.withdrawalSlipToolStripMenuItem2.Size = new System.Drawing.Size(246, 22);
            this.withdrawalSlipToolStripMenuItem2.Text = "Withdrawal Slip";
            this.withdrawalSlipToolStripMenuItem2.Click += new System.EventHandler(this.withdrawalSlipToolStripMenuItem2_Click);
            // 
            // toolStripSeparator52
            // 
            this.toolStripSeparator52.Name = "toolStripSeparator52";
            this.toolStripSeparator52.Size = new System.Drawing.Size(243, 6);
            // 
            // productionSlipToolStripMenuItem2
            // 
            this.productionSlipToolStripMenuItem2.Name = "productionSlipToolStripMenuItem2";
            this.productionSlipToolStripMenuItem2.Size = new System.Drawing.Size(246, 22);
            this.productionSlipToolStripMenuItem2.Text = "Production Slip";
            this.productionSlipToolStripMenuItem2.Click += new System.EventHandler(this.productionSlipToolStripMenuItem2_Click);
            // 
            // withdrawalSlipOfficeSuppliesToolStripMenuItem
            // 
            this.withdrawalSlipOfficeSuppliesToolStripMenuItem.Name = "withdrawalSlipOfficeSuppliesToolStripMenuItem";
            this.withdrawalSlipOfficeSuppliesToolStripMenuItem.Size = new System.Drawing.Size(246, 22);
            this.withdrawalSlipOfficeSuppliesToolStripMenuItem.Text = "Withdrawal Slip - Office Supplies";
            this.withdrawalSlipOfficeSuppliesToolStripMenuItem.Click += new System.EventHandler(this.withdrawalSlipOfficeSuppliesToolStripMenuItem_Click);
            // 
            // toolStripSeparator32
            // 
            this.toolStripSeparator32.Name = "toolStripSeparator32";
            this.toolStripSeparator32.Size = new System.Drawing.Size(226, 6);
            // 
            // actualInventoryToolStripMenuItem
            // 
            this.actualInventoryToolStripMenuItem.Name = "actualInventoryToolStripMenuItem";
            this.actualInventoryToolStripMenuItem.Size = new System.Drawing.Size(229, 22);
            this.actualInventoryToolStripMenuItem.Text = "Actual Inventory";
            this.actualInventoryToolStripMenuItem.Click += new System.EventHandler(this.actualInventoryToolStripMenuItem_Click);
            // 
            // searchToolStripMenuItem
            // 
            this.searchToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.vouchersToolStripMenuItem});
            this.searchToolStripMenuItem.Name = "searchToolStripMenuItem";
            this.searchToolStripMenuItem.Size = new System.Drawing.Size(54, 20);
            this.searchToolStripMenuItem.Text = "Search";
            // 
            // vouchersToolStripMenuItem
            // 
            this.vouchersToolStripMenuItem.Name = "vouchersToolStripMenuItem";
            this.vouchersToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.vouchersToolStripMenuItem.Text = "Vouchers";
            this.vouchersToolStripMenuItem.Click += new System.EventHandler(this.vouchersToolStripMenuItem_Click);
            // 
            // securityToolStripMenuItem
            // 
            this.securityToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.userAddToolStripMenuItem,
            this.toolStripSeparator28,
            this.gRToolStripMenuItem,
            this.toolStripSeparator29,
            this.membershipToolStripMenuItem,
            this.toolStripSeparator30,
            this.permissionToolStripMenuItem});
            this.securityToolStripMenuItem.Name = "securityToolStripMenuItem";
            this.securityToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.securityToolStripMenuItem.Text = "Security";
            // 
            // userAddToolStripMenuItem
            // 
            this.userAddToolStripMenuItem.Name = "userAddToolStripMenuItem";
            this.userAddToolStripMenuItem.Size = new System.Drawing.Size(141, 22);
            this.userAddToolStripMenuItem.Text = "User Add";
            this.userAddToolStripMenuItem.Click += new System.EventHandler(this.userAddToolStripMenuItem_Click);
            // 
            // toolStripSeparator28
            // 
            this.toolStripSeparator28.Name = "toolStripSeparator28";
            this.toolStripSeparator28.Size = new System.Drawing.Size(138, 6);
            // 
            // gRToolStripMenuItem
            // 
            this.gRToolStripMenuItem.Name = "gRToolStripMenuItem";
            this.gRToolStripMenuItem.Size = new System.Drawing.Size(141, 22);
            this.gRToolStripMenuItem.Text = "Group";
            this.gRToolStripMenuItem.Click += new System.EventHandler(this.gRToolStripMenuItem_Click);
            // 
            // toolStripSeparator29
            // 
            this.toolStripSeparator29.Name = "toolStripSeparator29";
            this.toolStripSeparator29.Size = new System.Drawing.Size(138, 6);
            // 
            // membershipToolStripMenuItem
            // 
            this.membershipToolStripMenuItem.Name = "membershipToolStripMenuItem";
            this.membershipToolStripMenuItem.Size = new System.Drawing.Size(141, 22);
            this.membershipToolStripMenuItem.Text = "Membership";
            this.membershipToolStripMenuItem.Click += new System.EventHandler(this.membershipToolStripMenuItem_Click);
            // 
            // toolStripSeparator30
            // 
            this.toolStripSeparator30.Name = "toolStripSeparator30";
            this.toolStripSeparator30.Size = new System.Drawing.Size(138, 6);
            // 
            // permissionToolStripMenuItem
            // 
            this.permissionToolStripMenuItem.Name = "permissionToolStripMenuItem";
            this.permissionToolStripMenuItem.Size = new System.Drawing.Size(141, 22);
            this.permissionToolStripMenuItem.Text = "Permission";
            this.permissionToolStripMenuItem.Click += new System.EventHandler(this.permissionToolStripMenuItem_Click);
            // 
            // reportsToolStripMenuItem
            // 
            this.reportsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bookPerWarehouseToolStripMenuItem,
            this.toolStripSeparator8,
            this.trialBalanceToolStripMenuItem,
            this.toolStripSeparator10,
            this.ledgerToolStripMenuItem,
            this.toolStripSeparator7,
            this.loanBalancesToolStripMenuItem,
            this.statementOfAccountsToolStripMenuItem,
            this.toolStripSeparator9,
            this.othersToolStripMenuItem,
            this.toolStripSeparator11,
            this.checkWriterToolStripMenuItem,
            this.bankReconciliationToolStripMenuItem,
            this.toolStripSeparator2,
            this.inventoryToolStripMenuItem1,
            this.toolStripSeparator31,
            this.salesToolStripMenuItem,
            this.toolStripSeparator39});
            this.reportsToolStripMenuItem.Name = "reportsToolStripMenuItem";
            this.reportsToolStripMenuItem.Size = new System.Drawing.Size(59, 20);
            this.reportsToolStripMenuItem.Text = "&Reports";
            // 
            // bookPerWarehouseToolStripMenuItem
            // 
            this.bookPerWarehouseToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.vouchersToolStripMenuItem1,
            this.toolStripSeparator37,
            this.booksAllToolStripMenuItem,
            this.toolStripSeparator36,
            this.booksWarehouseToolStripMenuItem,
            this.toolStripSeparator35,
            this.pOTransactionToolStripMenuItem1});
            this.bookPerWarehouseToolStripMenuItem.Name = "bookPerWarehouseToolStripMenuItem";
            this.bookPerWarehouseToolStripMenuItem.Size = new System.Drawing.Size(195, 22);
            this.bookPerWarehouseToolStripMenuItem.Text = "Previous";
            // 
            // vouchersToolStripMenuItem1
            // 
            this.vouchersToolStripMenuItem1.Name = "vouchersToolStripMenuItem1";
            this.vouchersToolStripMenuItem1.Size = new System.Drawing.Size(176, 22);
            this.vouchersToolStripMenuItem1.Text = "Vouchers";
            this.vouchersToolStripMenuItem1.Click += new System.EventHandler(this.vouchersToolStripMenuItem1_Click);
            // 
            // toolStripSeparator37
            // 
            this.toolStripSeparator37.Name = "toolStripSeparator37";
            this.toolStripSeparator37.Size = new System.Drawing.Size(173, 6);
            // 
            // booksAllToolStripMenuItem
            // 
            this.booksAllToolStripMenuItem.Name = "booksAllToolStripMenuItem";
            this.booksAllToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.booksAllToolStripMenuItem.Text = "Books - All";
            this.booksAllToolStripMenuItem.Click += new System.EventHandler(this.booksAllToolStripMenuItem_Click);
            // 
            // toolStripSeparator36
            // 
            this.toolStripSeparator36.Name = "toolStripSeparator36";
            this.toolStripSeparator36.Size = new System.Drawing.Size(173, 6);
            // 
            // booksWarehouseToolStripMenuItem
            // 
            this.booksWarehouseToolStripMenuItem.Name = "booksWarehouseToolStripMenuItem";
            this.booksWarehouseToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.booksWarehouseToolStripMenuItem.Text = "Books - Warehouse";
            this.booksWarehouseToolStripMenuItem.Click += new System.EventHandler(this.booksWarehouseToolStripMenuItem_Click);
            // 
            // toolStripSeparator35
            // 
            this.toolStripSeparator35.Name = "toolStripSeparator35";
            this.toolStripSeparator35.Size = new System.Drawing.Size(173, 6);
            // 
            // pOTransactionToolStripMenuItem1
            // 
            this.pOTransactionToolStripMenuItem1.Name = "pOTransactionToolStripMenuItem1";
            this.pOTransactionToolStripMenuItem1.Size = new System.Drawing.Size(176, 22);
            this.pOTransactionToolStripMenuItem1.Text = "PO Transaction";
            this.pOTransactionToolStripMenuItem1.Click += new System.EventHandler(this.pOTransactionToolStripMenuItem1_Click);
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(192, 6);
            // 
            // trialBalanceToolStripMenuItem
            // 
            this.trialBalanceToolStripMenuItem.Name = "trialBalanceToolStripMenuItem";
            this.trialBalanceToolStripMenuItem.Size = new System.Drawing.Size(195, 22);
            this.trialBalanceToolStripMenuItem.Text = "Financial Statements";
            this.trialBalanceToolStripMenuItem.Click += new System.EventHandler(this.trialBalanceToolStripMenuItem_Click);
            // 
            // toolStripSeparator10
            // 
            this.toolStripSeparator10.Name = "toolStripSeparator10";
            this.toolStripSeparator10.Size = new System.Drawing.Size(192, 6);
            // 
            // ledgerToolStripMenuItem
            // 
            this.ledgerToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.subsidiaryLedgerToolStripMenuItem1,
            this.toolStripSeparator40,
            this.ledgerSummaryToolStripMenuItem1,
            this.toolStripSeparator41,
            this.individualLedgerToolStripMenuItem1});
            this.ledgerToolStripMenuItem.Name = "ledgerToolStripMenuItem";
            this.ledgerToolStripMenuItem.Size = new System.Drawing.Size(195, 22);
            this.ledgerToolStripMenuItem.Text = "Ledger";
            // 
            // subsidiaryLedgerToolStripMenuItem1
            // 
            this.subsidiaryLedgerToolStripMenuItem1.Name = "subsidiaryLedgerToolStripMenuItem1";
            this.subsidiaryLedgerToolStripMenuItem1.Size = new System.Drawing.Size(167, 22);
            this.subsidiaryLedgerToolStripMenuItem1.Text = "Subsidiary Ledger";
            this.subsidiaryLedgerToolStripMenuItem1.Click += new System.EventHandler(this.subsidiaryLedgerToolStripMenuItem1_Click);
            // 
            // toolStripSeparator40
            // 
            this.toolStripSeparator40.Name = "toolStripSeparator40";
            this.toolStripSeparator40.Size = new System.Drawing.Size(164, 6);
            // 
            // ledgerSummaryToolStripMenuItem1
            // 
            this.ledgerSummaryToolStripMenuItem1.Name = "ledgerSummaryToolStripMenuItem1";
            this.ledgerSummaryToolStripMenuItem1.Size = new System.Drawing.Size(167, 22);
            this.ledgerSummaryToolStripMenuItem1.Text = "Ledger Summary";
            this.ledgerSummaryToolStripMenuItem1.Click += new System.EventHandler(this.ledgerSummaryToolStripMenuItem1_Click);
            // 
            // toolStripSeparator41
            // 
            this.toolStripSeparator41.Name = "toolStripSeparator41";
            this.toolStripSeparator41.Size = new System.Drawing.Size(164, 6);
            // 
            // individualLedgerToolStripMenuItem1
            // 
            this.individualLedgerToolStripMenuItem1.Name = "individualLedgerToolStripMenuItem1";
            this.individualLedgerToolStripMenuItem1.Size = new System.Drawing.Size(167, 22);
            this.individualLedgerToolStripMenuItem1.Text = "Individual Ledger";
            this.individualLedgerToolStripMenuItem1.Click += new System.EventHandler(this.individualLedgerToolStripMenuItem1_Click);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(192, 6);
            // 
            // loanBalancesToolStripMenuItem
            // 
            this.loanBalancesToolStripMenuItem.Name = "loanBalancesToolStripMenuItem";
            this.loanBalancesToolStripMenuItem.Size = new System.Drawing.Size(195, 22);
            this.loanBalancesToolStripMenuItem.Text = "Aging";
            this.loanBalancesToolStripMenuItem.Click += new System.EventHandler(this.loanBalancesToolStripMenuItem_Click);
            // 
            // statementOfAccountsToolStripMenuItem
            // 
            this.statementOfAccountsToolStripMenuItem.Name = "statementOfAccountsToolStripMenuItem";
            this.statementOfAccountsToolStripMenuItem.Size = new System.Drawing.Size(195, 22);
            this.statementOfAccountsToolStripMenuItem.Text = "Statement of Accounts";
            this.statementOfAccountsToolStripMenuItem.Click += new System.EventHandler(this.statementOfAccountsToolStripMenuItem_Click);
            // 
            // toolStripSeparator9
            // 
            this.toolStripSeparator9.Name = "toolStripSeparator9";
            this.toolStripSeparator9.Size = new System.Drawing.Size(192, 6);
            // 
            // othersToolStripMenuItem
            // 
            this.othersToolStripMenuItem.Name = "othersToolStripMenuItem";
            this.othersToolStripMenuItem.Size = new System.Drawing.Size(195, 22);
            this.othersToolStripMenuItem.Text = "Collection";
            this.othersToolStripMenuItem.Click += new System.EventHandler(this.othersToolStripMenuItem_Click);
            // 
            // toolStripSeparator11
            // 
            this.toolStripSeparator11.Name = "toolStripSeparator11";
            this.toolStripSeparator11.Size = new System.Drawing.Size(192, 6);
            // 
            // checkWriterToolStripMenuItem
            // 
            this.checkWriterToolStripMenuItem.Name = "checkWriterToolStripMenuItem";
            this.checkWriterToolStripMenuItem.Size = new System.Drawing.Size(195, 22);
            this.checkWriterToolStripMenuItem.Text = "Check Writer";
            this.checkWriterToolStripMenuItem.Click += new System.EventHandler(this.checkWriterToolStripMenuItem_Click);
            // 
            // bankReconciliationToolStripMenuItem
            // 
            this.bankReconciliationToolStripMenuItem.Name = "bankReconciliationToolStripMenuItem";
            this.bankReconciliationToolStripMenuItem.Size = new System.Drawing.Size(195, 22);
            this.bankReconciliationToolStripMenuItem.Text = "Bank Reconciliation";
            this.bankReconciliationToolStripMenuItem.Click += new System.EventHandler(this.bankReconciliationToolStripMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(192, 6);
            // 
            // inventoryToolStripMenuItem1
            // 
            this.inventoryToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.inventoryToolStripMenuItem,
            this.toolStripSeparator42,
            this.inventoryProcessToolStripMenuItem,
            this.toolStripSeparator43,
            this.transactionSummaryToolStripMenuItem1});
            this.inventoryToolStripMenuItem1.Name = "inventoryToolStripMenuItem1";
            this.inventoryToolStripMenuItem1.Size = new System.Drawing.Size(195, 22);
            this.inventoryToolStripMenuItem1.Text = "Inventory";
            // 
            // inventoryToolStripMenuItem
            // 
            this.inventoryToolStripMenuItem.Name = "inventoryToolStripMenuItem";
            this.inventoryToolStripMenuItem.Size = new System.Drawing.Size(189, 22);
            this.inventoryToolStripMenuItem.Text = "Inventory Summary";
            this.inventoryToolStripMenuItem.Click += new System.EventHandler(this.inventoryToolStripMenuItem_Click_1);
            // 
            // toolStripSeparator42
            // 
            this.toolStripSeparator42.Name = "toolStripSeparator42";
            this.toolStripSeparator42.Size = new System.Drawing.Size(186, 6);
            // 
            // inventoryProcessToolStripMenuItem
            // 
            this.inventoryProcessToolStripMenuItem.Name = "inventoryProcessToolStripMenuItem";
            this.inventoryProcessToolStripMenuItem.Size = new System.Drawing.Size(189, 22);
            this.inventoryProcessToolStripMenuItem.Text = "Inventory Process";
            this.inventoryProcessToolStripMenuItem.Click += new System.EventHandler(this.inventoryProcessToolStripMenuItem_Click);
            // 
            // toolStripSeparator43
            // 
            this.toolStripSeparator43.Name = "toolStripSeparator43";
            this.toolStripSeparator43.Size = new System.Drawing.Size(186, 6);
            // 
            // transactionSummaryToolStripMenuItem1
            // 
            this.transactionSummaryToolStripMenuItem1.Name = "transactionSummaryToolStripMenuItem1";
            this.transactionSummaryToolStripMenuItem1.Size = new System.Drawing.Size(189, 22);
            this.transactionSummaryToolStripMenuItem1.Text = "Transaction Summary";
            this.transactionSummaryToolStripMenuItem1.Click += new System.EventHandler(this.transactionSummaryToolStripMenuItem1_Click);
            // 
            // toolStripSeparator31
            // 
            this.toolStripSeparator31.Name = "toolStripSeparator31";
            this.toolStripSeparator31.Size = new System.Drawing.Size(192, 6);
            // 
            // salesToolStripMenuItem
            // 
            this.salesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.salesPerCustomerToolStripMenuItem});
            this.salesToolStripMenuItem.Name = "salesToolStripMenuItem";
            this.salesToolStripMenuItem.Size = new System.Drawing.Size(195, 22);
            this.salesToolStripMenuItem.Text = "Sales";
            // 
            // salesPerCustomerToolStripMenuItem
            // 
            this.salesPerCustomerToolStripMenuItem.Name = "salesPerCustomerToolStripMenuItem";
            this.salesPerCustomerToolStripMenuItem.Size = new System.Drawing.Size(150, 22);
            this.salesPerCustomerToolStripMenuItem.Text = "Sales Per Store";
            this.salesPerCustomerToolStripMenuItem.Click += new System.EventHandler(this.salesPerCustomerToolStripMenuItem_Click);
            // 
            // toolStripSeparator39
            // 
            this.toolStripSeparator39.Name = "toolStripSeparator39";
            this.toolStripSeparator39.Size = new System.Drawing.Size(192, 6);
            // 
            // txtNoCopy
            // 
            this.txtNoCopy.Location = new System.Drawing.Point(12, 42);
            this.txtNoCopy.Name = "txtNoCopy";
            this.txtNoCopy.Size = new System.Drawing.Size(100, 20);
            this.txtNoCopy.TabIndex = 2;
            this.txtNoCopy.Text = "1";
            this.txtNoCopy.Visible = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.ErrorImage = null;
            this.pictureBox1.Image = global::TCIGL.Properties.Resources.GB_wp5;
            this.pictureBox1.Location = new System.Drawing.Point(0, 24);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1064, 527);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(197, 22);
            this.toolStripMenuItem3.Text = "Warehouse - Edit";
            this.toolStripMenuItem3.Click += new System.EventHandler(this.warehouseEditToolStripMenuItem_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(197, 22);
            this.toolStripMenuItem4.Text = "Warehouse - Add";
            this.toolStripMenuItem4.Click += new System.EventHandler(this.warehouseAddToolStripMenuItem_Click);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem6,
            this.toolStripMenuItem7});
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(197, 22);
            this.toolStripMenuItem5.Text = "Inventory Classification";
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(230, 22);
            this.toolStripMenuItem6.Text = "Inventory Classification - Add";
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new System.Drawing.Size(230, 22);
            this.toolStripMenuItem7.Text = "Inventory Classification - Edit";
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1064, 551);
            this.Controls.Add(this.txtNoCopy);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Main";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMain_FormClosing);
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem entryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem transactionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem securityToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem userAddToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gRToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem membershipToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem permissionToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ToolStripMenuItem clientAddToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem clientEditToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem variousDocumentsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reportsToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem officialReceiptsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem checkVoucherToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem accountsPayableVoucherToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem journalVoucherToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loanBalancesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem trialBalanceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem othersToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator10;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator9;
        private System.Windows.Forms.ToolStripMenuItem othersAddToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem chartOfAccountsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem postingAccountToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem department2AddToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem accountTitleAddToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem accountTitleEditToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator12;
        private System.Windows.Forms.ToolStripMenuItem department1AddToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem department2EditToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator13;
        private System.Windows.Forms.ToolStripMenuItem departToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator14;
        private System.Windows.Forms.ToolStripMenuItem postingAccountEditToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator15;
        private System.Windows.Forms.ToolStripMenuItem viewMainAccountToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewSubAccountToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem checkWriterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bankReconciliationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem searchToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem othersEditToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripMenuItem statementOfAccountsToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator11;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator16;
        private System.Windows.Forms.ToolStripMenuItem vouchersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem companyToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator17;
        private System.Windows.Forms.ToolStripMenuItem securityDateToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator18;
        private System.Windows.Forms.ToolStripMenuItem noOfCopiesToPrintToolStripMenuItem;
        private System.Windows.Forms.TextBox txtNoCopy;
        private System.Windows.Forms.ToolStripMenuItem warehouseAddToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem warehouseEditToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem adjustmentSlipToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem transferSlipToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator24;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator25;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator26;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator27;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator28;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator29;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator30;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem remittanceVoucherToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator31;
        private System.Windows.Forms.ToolStripMenuItem salesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cashReceiptsVoucherToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem customerDataToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem salesmanAddToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem salesmanEditToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem collectorAddToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem collectorEditToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem geographicalAreaAddToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem geographicalAreaEditToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator19;
        private System.Windows.Forms.ToolStripMenuItem channelAddToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem channelEditToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem territoryAddToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem territoryEditToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator22;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator34;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator33;
        private System.Windows.Forms.ToolStripMenuItem returnToSupplierToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator20;
        private System.Windows.Forms.ToolStripMenuItem resetToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator32;
        private System.Windows.Forms.ToolStripMenuItem actualInventoryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem salesPerCustomerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bookPerWarehouseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vouchersToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem booksAllToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem booksWarehouseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pOTransactionToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator37;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator36;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator35;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator38;
        private System.Windows.Forms.ToolStripMenuItem inventoryToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem inventoryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem inventoryProcessToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem transactionSummaryToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem ledgerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ledgerSummaryToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem individualLedgerToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator39;
        private System.Windows.Forms.ToolStripMenuItem subsidiaryLedgerToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator40;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator41;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator42;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator43;
        private System.Windows.Forms.ToolStripMenuItem purchasesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem purchaseOrderToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem purchaseDeliveryToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem productionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem withdrawalSlipToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem productionSlipToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem proformaInvoiceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem salesToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem chargeInvoiceToolStripMenuItem2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator49;
        private System.Windows.Forms.ToolStripMenuItem cashSalesToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator50;
        private System.Windows.Forms.ToolStripMenuItem returnSlipToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator53;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator51;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator52;
        private System.Windows.Forms.ToolStripMenuItem categoryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem categoryAddToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem categoryEditToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator44;
        private System.Windows.Forms.ToolStripMenuItem bankDetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bankDetailsAddToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bankDetailsEditToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem productToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem productAddToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem productEditRawMaterialToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem productEditFinishedProductToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator45;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator21;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator23;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator46;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator47;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator48;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator54;
        private System.Windows.Forms.ToolStripMenuItem productEditOfficeSuppliesToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator55;
        private System.Windows.Forms.ToolStripMenuItem withdrawalSlipOfficeSuppliesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem7;
    }
}