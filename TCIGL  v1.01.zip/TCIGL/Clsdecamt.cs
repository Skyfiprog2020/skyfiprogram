﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TCIGL
{
    public static class decamout
    {
        public static double Calculateamount(double wamt, int ramt)
        {
            return wamt - ramt;
        }
    }
}
