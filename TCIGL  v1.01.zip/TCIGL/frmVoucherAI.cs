﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using CrystalDecisions.CrystalReports.Engine;
using System.Data.SqlClient;
using System.Threading;

namespace TCIGL
{
    public partial class frmVoucherAI : Form
    {
        public static TextBox glbldocnum;
        
        SqlConnection myconnection;
        SqlCommand mycommand;
        string varoutdate = "No";
        string dgvdata = null;
        SqlDataReader SqlDataReader1;
        ClsAutoNumber ClsAutoNumber1 = new ClsAutoNumber();
        ClsDefaultBranch ClsDefaultBranch1 = new ClsDefaultBranch();
        ClsBuildComboBox ClsBuildComboBox1 = new ClsBuildComboBox();
        ClsBuildCOAComboBox ClsBuildCOAComboBox1 = new ClsBuildCOAComboBox(); 
        ClsCompName ClsCompName1 = new ClsCompName();
        ClsGetSomething ClsGetSomething1 = new ClsGetSomething();
        ClsGetConnection ClsGetConnection1 = new ClsGetConnection();
        ClsValidation ClsValidation1 = new ClsValidation();
        ClsPermission ClsPermission1 = new ClsPermission();
        ClsGetSomethingOthers ClsGetSomethingOthers1 = new ClsGetSomethingOthers();
        ClsBuildEntryComboBox ClsBuildEntryComboBox1 = new ClsBuildEntryComboBox();
        int varintTableDoor = 0;
        int number = 0;
        private string privarstrVoidIC = null;

        public frmVoucherAI()
        {
            InitializeComponent();
            {
                ClsGetSomethingOthers1.ClsGetVoidRef("AI", "4");
                privarstrVoidIC = ClsGetSomethingOthers1.plsVoidIC;
                if (new ClsValidation().emptytxt(privarstrVoidIC))
                { }
                else
                {
                    ClsGetSomethingOthers1.ClsDeleteErrorTransaction("AI", "4");
                }
            }

        }

        private void frmVoucherAI_Load(object sender, EventArgs e)
        {
           ClsPermission1.ClsObjects(this.Text);
           if (new ClsValidation().emptytxt(ClsPermission1.plstxtObject))
           {
               MessageBox.Show("You do not have necessary permission to open this file", "GL");
               this.Close();
           }
           else
           {
               ClsAutoNumber1.VoucherAutoNumAI("AI");
               txtDocNum.Text = (ClsAutoNumber1.plsnumber);
               ClsGetSomething1.ClsGetDefaultDate();
               txtTDate.Text = ClsGetSomething1.plsdefdate;
               buildcboWHCode();
               buildcboStocks();
               privarstrVoidIC = null;
               ClsGetSomethingOthers1.ClsGetVoidRef("AI", "4");
               privarstrVoidIC = ClsGetSomethingOthers1.plsVoidIC;
               if (new ClsValidation().emptytxt(privarstrVoidIC))
               { }
               else
               {
                   ClsGetSomethingOthers1.ClsDeleteErrorTransaction("AI", "4");
                   privarstrVoidIC = null;
               }
           }
        }

   
       

        private void buildcboWHCode()
        {
            cboWHCode.DataSource = null;
            ClsBuildEntryComboBox1.ARWHCode.Clear();
            ClsBuildEntryComboBox1.ClsBuildWHCode();
            this.cboWHCode.DataSource = (ClsBuildEntryComboBox1.ARWHCode);
            this.cboWHCode.DisplayMember = "Display";
            this.cboWHCode.ValueMember = "Value";
            //this.cboWHCode.DropDownWidth = 450;
        }

        private void buildcboStocks()
        {
            ColumncboStockNumber.DataSource = null;
            ClsBuildComboBox1.ARLSNCode.Clear();
            ClsBuildComboBox1.ClsBuildStocksCode("1");
            this.ColumncboStockNumber.DataSource = (ClsBuildComboBox1.ARLSNCode);
            this.ColumncboStockNumber.DisplayMember = "Display";
            this.ColumncboStockNumber.ValueMember = "Value";
        }
 
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dgv1_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            // Clear the row error in case the user presses ESC.   
            dgv1.Rows[e.RowIndex].ErrorText = String.Empty;

            DataGridViewRow row1 = dgv1.Rows[e.RowIndex];
            if (new ClsValidation().emptytxt(row1.Cells[0].FormattedValue.ToString()))
            {
            }
            else
            {
                if (e.ColumnIndex == dgv1.Columns["ColumncboStockNumber"].Index)
                {
                    string[] values = new string[1];
                    DataGridViewRow row = dgv1.Rows[e.RowIndex];

                    ClsGetSomething1.ClsGetProductDetails(row.Cells[0].Value.ToString());
                    row.Cells[1].Value = ClsGetSomething1.plsvarItem;
                    dgv1.CurrentRow.Cells[2].Value = "0.00";
                    dgv1.CurrentRow.Cells[3].Value = double.Parse(ClsGetSomething1.plvarSPPC).ToString("N2");
                }
                else if (e.ColumnIndex == dgv1.Columns["ColumnAqty"].Index)
                {
                    this.dgv1.Rows[e.RowIndex].Cells[2].Value = double.Parse(dgv1.Rows[e.RowIndex].Cells[2].FormattedValue.ToString().Trim()).ToString("N2");
                }
                else if (e.ColumnIndex == dgv1.Columns["ColumnUPrice"].Index)
                {
                    this.dgv1.Rows[e.RowIndex].Cells[3].Value = double.Parse(dgv1.Rows[e.RowIndex].Cells[3].FormattedValue.ToString().Trim()).ToString("N2");
                }
            }
        }

        private void dgv1_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            //if (e.Control is DataGridViewComboBoxEditingControl)
            //{
            //    ((ComboBox)e.Control).DropDownStyle = ComboBoxStyle.DropDown;
            //    ((ComboBox)e.Control).AutoCompleteSource = AutoCompleteSource.ListItems;
            //    ((ComboBox)e.Control).AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            //}
            if (e.Control is ComboBox)
            {
                //SendKeys.Send("{F4}");
                SendKeys.Send("%{Down}");
            }
            ComboBox cboPA = e.Control as ComboBox;
            if (cboPA != null)
            {
                cboPA.IntegralHeight = false;
                cboPA.MaxDropDownItems = 12;
            }
  
        }

        private void dgv1_CurrentCellDirtyStateChanged(object sender, EventArgs e)
        {
            if (dgv1.IsCurrentCellDirty)
            {
                dgv1.CommitEdit(DataGridViewDataErrorContexts.Commit);
            }
        }

        private void dgv1_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        {
            DataGridViewRow row = dgv1.Rows[e.RowIndex];
            if (new ClsValidation().emptytxt(row.Cells[0].FormattedValue.ToString()))
            {
            }
            else
            {
                if (e.ColumnIndex == dgv1.Columns["ColumnAQty"].Index)  //this is our numeric column
                {
                    if (String.IsNullOrEmpty(e.FormattedValue.ToString()))// &&
                    //dgv1[e.ColumnIndex, e.RowIndex].IsInEditMode)
                    {
                        e.Cancel = true;
                        MessageBox.Show("Empty", "GL");
                    }
                    else
                    {
                        double i;
                        if (!double.TryParse(Convert.ToString(e.FormattedValue), out i))
                        {
                            e.Cancel = true;
                            MessageBox.Show("Numeric only", "GL");
                        }
                    }
                }
                else if (e.ColumnIndex == dgv1.Columns["ColumnUPrice"].Index)  //this is our numeric column
                {
                    if (String.IsNullOrEmpty(e.FormattedValue.ToString()))// &&
                    //dgv1[e.ColumnIndex, e.RowIndex].IsInEditMode)
                    {
                        e.Cancel = true;
                        MessageBox.Show("Empty", "GL");
                    }
                    else
                    {
                        double i;
                        if (!double.TryParse(Convert.ToString(e.FormattedValue), out i))
                        {
                            e.Cancel = true;
                            MessageBox.Show("Numeric only", "GL");
                        }
                    }
                }
            }
        }
       
     


        

        private void SaveTransact()
        {
            try
            {
                DateTime DT = DateTime.Now;
                ClsAutoNumber1.VoucherAutoNumAI("AI");
                txtDocNum.Text = (ClsAutoNumber1.plsnumber);

                string sqlstatement = "INSERT INTO tblmain4 (IC, DocNum, Voucher, UserCode, TDate, Reference, WHCode, Remarks, CNCode, DE) ";
                sqlstatement += "Values (@_IC, @_DocNum, @_Voucher, @_UserCode, @_TDate, @_Reference, @_WHCode, @_Remarks, @_CNCode, @_DE)";
                string sqlstatementdgv2 = "INSERT INTO tblmain5 (IC, StockNumber, AQty, UPrice, RowNum) Values (@_IC, @_StockNumber, @_AQty, @_UPrice, @_RowNum)";

                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();

                mycommand = new SqlCommand(sqlstatement, myconnection);
                mycommand.Parameters.Add("_IC", SqlDbType.VarChar).Value = "AI" + Form1.glbluc.Text + (ClsDefaultBranch1.plsvardb);
                mycommand.Parameters.Add("_DocNum", SqlDbType.VarChar).Value = Form1.glbluc.Text;
                mycommand.Parameters.Add("_Voucher", SqlDbType.VarChar).Value = "AI";
                mycommand.Parameters.Add("_UserCode", SqlDbType.VarChar).Value = Form1.glbluc.Text;
                mycommand.Parameters.Add("_TDate", SqlDbType.DateTime).Value = txtTDate.Text;
                mycommand.Parameters.Add("_Reference", SqlDbType.VarChar).Value = txtreference.Text;
                mycommand.Parameters.Add("_WHCode", SqlDbType.VarChar).Value = cboWHCode.SelectedValue.ToString();
                mycommand.Parameters.Add("_Remarks", SqlDbType.VarChar).Value = txtRemarks.Text;
                mycommand.Parameters.Add("_CNCode", SqlDbType.Char).Value = (ClsDefaultBranch1.plsvardb);
                mycommand.Parameters.Add("_DE", SqlDbType.DateTime).Value = DT;
                int n1 = mycommand.ExecuteNonQuery();


                DataGridViewRow row = null;
                for (int x = 0; x < dgv1.Rows.Count - 1; x++)
                {
                    row = dgv1.Rows[x];
                    mycommand = new SqlCommand(sqlstatementdgv2, myconnection);
                    mycommand.Parameters.Add("_IC", SqlDbType.VarChar).Value = "AI" + Form1.glbluc.Text + (ClsDefaultBranch1.plsvardb);
                    mycommand.Parameters.Add("_StockNumber", SqlDbType.VarChar).Value = row.Cells[0].Value;
                    mycommand.Parameters.Add("_AQty", SqlDbType.VarChar).Value = row.Cells[2].Value;
                    mycommand.Parameters.Add("_UPrice", SqlDbType.Decimal).Value = row.Cells[3].Value;
                    mycommand.Parameters.Add("_RowNum", SqlDbType.Decimal).Value = (Convert.ToInt32(x) + 1).ToString();
                    int n2 = mycommand.ExecuteNonQuery();
                }
                myconnection.Close();
                ClsGetSomethingOthers1.ClsFinalize("AI", txtDocNum.Text, "4");
                //dr.Close();

                if (cbSP.Checked)
                {
                    int varnocopy = int.Parse(frmMain.glbltxtNoCopy.Text);
                    for (int i = 1; i <= varnocopy; i++)
                    {
                        printcurvoucher();
                    }
                }

                ClsAutoNumber1.VoucherAutoNumAI("AI");
                txtDocNum.Text = (ClsAutoNumber1.plsnumber);

                dgv1.Rows.Clear();
                txtreference.Text = "";
                // txtCheckNo.Text = "NA";
                txtRemarks.Text = "";
                txtTDate.Focus();
                dgvdata = null;
                txtTDate.Text = ClsGetSomething1.plsdefdate;
            }
            catch
            {
                MessageBox.Show("Error, please click OK", "GL");
                this.Close();
            }
            finally
            {
                //               dr.Close();
                myconnection.Close();
            }
        }

        private void printcurvoucher()
        {
            string sqlstatement = "SELECT * FROM ViewDetailsBookAI WHERE DocNum ='" + txtDocNum.Text + "' AND CNCode = '" + (ClsDefaultBranch1.plsvardb) + "'";

            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();
            mycommand = myconnection.CreateCommand();
            mycommand.CommandText = sqlstatement;
            mycommand.CommandTimeout = 900;
            SqlDataReader1 = mycommand.ExecuteReader();
            DataTable DataTable1 = new DataTable();
            DataTable1.Load(SqlDataReader1);
            myconnection.Close();

            if (DataTable1.Rows.Count == 0)
            {
                MessageBox.Show("No data found", "GL");
                return;
            }
            CRprevAI objRpt = new CRprevAI();
            TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            ClsCompName1.ClsCompNamebranch();
            vartxtcompany.Text = ClsCompName1.plsbn;

            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            vartxtaddress.Text = (ClsCompName1.plsaddress);

            objRpt.SetDataSource(DataTable1);
       
            objRpt.Refresh();
            objRpt.PrintToPrinter(1, false, 0, 0);
        }
    

        private void btnSave_Click(object sender, EventArgs e)
        {
                ClsValidation1.securedate(DateTime.Parse(txtTDate.Text));
                varoutdate = (ClsValidation1.plsoutdate);

                for (int x = 0; x < dgv1.Rows.Count - 1; x++)
                {
                    dgvdata = (dgv1.Rows[x].Cells[0].FormattedValue.ToString());
                }

                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                if (new Clsexist().RecordExists(ref myconnection, "SELECT Reference FROM tblmain1 WHERE Reference ='" + txtreference.Text + "' AND CNCode = '" + (ClsDefaultBranch1.plsvardb) + "'"))
                {
                    myconnection.Close();
                    MessageBox.Show("Duplicate entry", "GL");
                    txtTDate.Focus();
                }
                else if (txtTDate.Text == "  /  /")
                {
                    myconnection.Close();
                    MessageBox.Show("Please complete your entry", "GL");
                    txtTDate.Focus();
                }
                else if (new ClsValidation().emptytxt(cboWHCode.Text))
                {
                    myconnection.Close();
                    MessageBox.Show("Please complete your entry", "GL");
                    cboWHCode.Focus();
                }

                else if (new ClsValidation().emptytxt (txtreference .Text))
                {
                    myconnection.Close();
                    MessageBox.Show("Please complete your entry", "GL");
                    txtreference.Focus();
                }
                 else if (new ClsValidation().emptytxt(txtRemarks.Text))
                {
                    myconnection.Close();
                    MessageBox.Show("Please complete your entry", "GL");
                    txtRemarks.Focus();
                }
                else if (varoutdate == "Yes")
                {
                    myconnection.Close();
                    MessageBox.Show("Date is out of range", "GL");
                    txtTDate.Focus();
                }

               else if (new ClsValidation().emptytxt(dgvdata))
                {
                    myconnection.Close();
                    MessageBox.Show("Incomplete Record", "GL");
                    txtTDate.Focus();
                }
                else
                {
                    myconnection.Close();
                    privarstrVoidIC = null;
                    ClsGetSomethingOthers1.ClsGetTDoor("AI");
                    varintTableDoor = int.Parse(ClsGetSomethingOthers1.plsTableDoor);
                    number = 0;
                    while (varintTableDoor == 1 && number <= 20)
                    {
                        number = number + 1;
                        Thread.Sleep(200);
                        varintTableDoor = int.Parse(ClsGetSomethingOthers1.plsTableDoor);
                    }

                    if (varintTableDoor == 0 && number <= 20)
                    {

                        ClsGetSomethingOthers1.ClsGetVoidRef("AI", "4");
                        privarstrVoidIC = ClsGetSomethingOthers1.plsVoidIC;
                        if (new ClsValidation().emptytxt(privarstrVoidIC))
                        {
                            ClsGetSomethingOthers1.ClsOneTheDoor("AI");
                            SaveTransact();
                            ClsGetSomethingOthers1.ClsZeroTheDoor("AI");
                        }
                        else
                        {
                            ClsGetSomethingOthers1.ClsDeleteErrorTransaction("AI", "4");
                            MessageBox.Show("Transaction not saved", "GL");
                        }
                    }
                    else if (varintTableDoor == 1 && number == 21)
                    {
                        MessageBox.Show("Contact your adminnistrator", "GL");
                    }
                }
        }


        private void txtTDate_Leave(object sender, EventArgs e)
        {
            if (new ClsValidation().errordate(txtTDate.Text) == true)
            {
                MessageBox.Show("Invalid Date", "GL");
                txtTDate.Focus();
            }
        }


        private void nextfieldenter1(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.Equals(Keys.Enter))
            {
                SendKeys.Send("{TAB}");
            }
            else if ((e.KeyCode.Equals(Keys.Up)) || (e.KeyCode.Equals(Keys.Left)))
            {
                SendKeys.Send("+{TAB}");
            }
            else if ((e.KeyCode.Equals(Keys.Down)) || (e.KeyCode.Equals(Keys.Right)))
            {
                SendKeys.Send("{TAB}");
            }
        }

        private void nextfieldenter2(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.Equals(Keys.Enter))
            {
                SendKeys.Send("{TAB}");
            }

        }

   

        

        private void dgv1_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            DataGridViewRow row = dgv1.Rows[e.RowIndex];
            if ((e.ColumnIndex == dgv1.Columns["ColumnAQty"].Index)  || (e.ColumnIndex == dgv1.Columns["ColumnUPrice"].Index))
            {
                if (new ClsValidation().emptytxt(row.Cells[0].FormattedValue.ToString()))
                {
                    e.Cancel = true;
                    MessageBox.Show("Not Allowed", "GL");
                }
            }
        }
    }
}
