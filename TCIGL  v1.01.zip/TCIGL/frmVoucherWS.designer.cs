﻿namespace TCIGL
{
    partial class frmVoucherWS
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            this.label2 = new System.Windows.Forms.Label();
            this.txtTDate = new System.Windows.Forms.MaskedTextBox();
            this.txtreference = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.cboControlNo = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtRemarks = new System.Windows.Forms.TextBox();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.txtDocNum = new System.Windows.Forms.TextBox();
            this.txtTotCost = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.btnPE = new System.Windows.Forms.Button();
            this.cboWHCode = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.cboSMCode = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cboPA = new System.Windows.Forms.ComboBox();
            this.cbAccountNo = new System.Windows.Forms.CheckBox();
            this.txtdrtot = new System.Windows.Forms.TextBox();
            this.txtcrtot = new System.Windows.Forms.TextBox();
            this.txtDifference = new System.Windows.Forms.TextBox();
            this.cbSP = new System.Windows.Forms.CheckBox();
            this.btnListPendingPO = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.cboJONumber = new System.Windows.Forms.ComboBox();
            this.label22 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.txtNum = new System.Windows.Forms.TextBox();
            this.txtWS = new System.Windows.Forms.TextBox();
            this.dgv1 = new TCIGL.moveNextCellDataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtrefer = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtDR = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtCR = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumncbdgvSIT = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dgv2 = new TCIGL.moveNextCellDataGridView();
            this.ColumnStockNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnItem = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnQtyIn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnQtyOut = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnUC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnTotal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnInvClassCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgv1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv2)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(22, 103);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 19);
            this.label2.TabIndex = 31;
            this.label2.Text = "Date:";
            // 
            // txtTDate
            // 
            this.txtTDate.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTDate.Location = new System.Drawing.Point(26, 124);
            this.txtTDate.Mask = "00/00/0000";
            this.txtTDate.Name = "txtTDate";
            this.txtTDate.Size = new System.Drawing.Size(99, 26);
            this.txtTDate.TabIndex = 1;
            this.txtTDate.ValidatingType = typeof(System.DateTime);
            this.txtTDate.KeyDown += new System.Windows.Forms.KeyEventHandler(this.nextfieldenter1);
            this.txtTDate.Validating += new System.ComponentModel.CancelEventHandler(this.txtTDate_Validating);
            // 
            // txtreference
            // 
            this.txtreference.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtreference.Location = new System.Drawing.Point(149, 124);
            this.txtreference.Name = "txtreference";
            this.txtreference.Size = new System.Drawing.Size(159, 26);
            this.txtreference.TabIndex = 2;
            this.txtreference.KeyDown += new System.Windows.Forms.KeyEventHandler(this.nextfieldenter1);
            this.txtreference.Validating += new System.ComponentModel.CancelEventHandler(this.txtreference_Validating);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(145, 103);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 19);
            this.label1.TabIndex = 33;
            this.label1.Text = "Reference:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(396, 41);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 19);
            this.label3.TabIndex = 35;
            this.label3.Text = "Name:";
            // 
            // cboControlNo
            // 
            this.cboControlNo.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cboControlNo.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cboControlNo.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboControlNo.FormattingEnabled = true;
            this.cboControlNo.Location = new System.Drawing.Point(400, 62);
            this.cboControlNo.Name = "cboControlNo";
            this.cboControlNo.Size = new System.Drawing.Size(319, 27);
            this.cboControlNo.TabIndex = 3;
            this.cboControlNo.KeyDown += new System.Windows.Forms.KeyEventHandler(this.nextfieldenter2);
            this.cboControlNo.Validating += new System.ComponentModel.CancelEventHandler(this.cboCustCode_Validating);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(751, 103);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(66, 19);
            this.label11.TabIndex = 40;
            this.label11.Text = "Remarks:";
            // 
            // txtRemarks
            // 
            this.txtRemarks.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRemarks.Location = new System.Drawing.Point(755, 124);
            this.txtRemarks.Name = "txtRemarks";
            this.txtRemarks.Size = new System.Drawing.Size(319, 26);
            this.txtRemarks.TabIndex = 6;
            this.txtRemarks.Text = "Withdraw raw material";
            this.txtRemarks.KeyDown += new System.Windows.Forms.KeyEventHandler(this.nextfieldenter1);
            // 
            // btnClose
            // 
            this.btnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnClose.Location = new System.Drawing.Point(962, 541);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(112, 61);
            this.btnClose.TabIndex = 11;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(844, 541);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(112, 61);
            this.btnSave.TabIndex = 10;
            this.btnSave.Text = "Save - F6";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // txtDocNum
            // 
            this.txtDocNum.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDocNum.Location = new System.Drawing.Point(984, 12);
            this.txtDocNum.Name = "txtDocNum";
            this.txtDocNum.ReadOnly = true;
            this.txtDocNum.Size = new System.Drawing.Size(85, 26);
            this.txtDocNum.TabIndex = 52;
            this.txtDocNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtTotCost
            // 
            this.txtTotCost.Location = new System.Drawing.Point(149, 578);
            this.txtTotCost.Name = "txtTotCost";
            this.txtTotCost.ReadOnly = true;
            this.txtTotCost.Size = new System.Drawing.Size(77, 20);
            this.txtTotCost.TabIndex = 105;
            this.txtTotCost.Text = "0.00";
            this.txtTotCost.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(23, 583);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(85, 15);
            this.label9.TabIndex = 178;
            this.label9.Text = "TOTAL COST:";
            // 
            // btnPE
            // 
            this.btnPE.Location = new System.Drawing.Point(726, 541);
            this.btnPE.Name = "btnPE";
            this.btnPE.Size = new System.Drawing.Size(112, 61);
            this.btnPE.TabIndex = 9;
            this.btnPE.Text = "Product Entry - F5";
            this.btnPE.UseVisualStyleBackColor = true;
            this.btnPE.Click += new System.EventHandler(this.btnPE_Click);
            // 
            // cboWHCode
            // 
            this.cboWHCode.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cboWHCode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cboWHCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboWHCode.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboWHCode.FormattingEnabled = true;
            this.cboWHCode.Location = new System.Drawing.Point(26, 63);
            this.cboWHCode.Name = "cboWHCode";
            this.cboWHCode.Size = new System.Drawing.Size(282, 27);
            this.cboWHCode.TabIndex = 0;
            this.cboWHCode.KeyDown += new System.Windows.Forms.KeyEventHandler(this.nextfieldenter2);
            this.cboWHCode.Validating += new System.ComponentModel.CancelEventHandler(this.cboWHCode_Validating);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(25, 41);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 19);
            this.label5.TabIndex = 182;
            this.label5.Text = "Warehouse:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(396, 103);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(69, 19);
            this.label12.TabIndex = 196;
            this.label12.Text = "Salesman:";
            // 
            // cboSMCode
            // 
            this.cboSMCode.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cboSMCode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cboSMCode.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboSMCode.FormattingEnabled = true;
            this.cboSMCode.Location = new System.Drawing.Point(400, 124);
            this.cboSMCode.Name = "cboSMCode";
            this.cboSMCode.Size = new System.Drawing.Size(319, 27);
            this.cboSMCode.TabIndex = 4;
            this.cboSMCode.KeyDown += new System.Windows.Forms.KeyEventHandler(this.nextfieldenter2);
            this.cboSMCode.Validating += new System.ComponentModel.CancelEventHandler(this.cboSMCode_Validating);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(751, 41);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(92, 19);
            this.label4.TabIndex = 198;
            this.label4.Text = "Account Title:";
            // 
            // cboPA
            // 
            this.cboPA.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cboPA.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cboPA.Enabled = false;
            this.cboPA.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboPA.FormattingEnabled = true;
            this.cboPA.Location = new System.Drawing.Point(755, 63);
            this.cboPA.Name = "cboPA";
            this.cboPA.Size = new System.Drawing.Size(319, 27);
            this.cboPA.TabIndex = 5;
            this.cboPA.KeyDown += new System.Windows.Forms.KeyEventHandler(this.nextfieldenter2);
            // 
            // cbAccountNo
            // 
            this.cbAccountNo.AutoSize = true;
            this.cbAccountNo.Checked = true;
            this.cbAccountNo.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbAccountNo.Location = new System.Drawing.Point(26, 536);
            this.cbAccountNo.Name = "cbAccountNo";
            this.cbAccountNo.Size = new System.Drawing.Size(106, 17);
            this.cbAccountNo.TabIndex = 199;
            this.cbAccountNo.Text = "Account Number";
            this.cbAccountNo.UseVisualStyleBackColor = true;
            this.cbAccountNo.CheckedChanged += new System.EventHandler(this.cbAccountNo_CheckedChanged);
            // 
            // txtdrtot
            // 
            this.txtdrtot.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdrtot.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.txtdrtot.Location = new System.Drawing.Point(670, 33);
            this.txtdrtot.Name = "txtdrtot";
            this.txtdrtot.ReadOnly = true;
            this.txtdrtot.Size = new System.Drawing.Size(77, 20);
            this.txtdrtot.TabIndex = 203;
            this.txtdrtot.Text = "0.00";
            this.txtdrtot.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtdrtot.Visible = false;
            // 
            // txtcrtot
            // 
            this.txtcrtot.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcrtot.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.txtcrtot.Location = new System.Drawing.Point(755, 7);
            this.txtcrtot.Name = "txtcrtot";
            this.txtcrtot.ReadOnly = true;
            this.txtcrtot.Size = new System.Drawing.Size(64, 20);
            this.txtcrtot.TabIndex = 202;
            this.txtcrtot.Text = "0.00";
            this.txtcrtot.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtcrtot.Visible = false;
            // 
            // txtDifference
            // 
            this.txtDifference.Location = new System.Drawing.Point(670, 7);
            this.txtDifference.Name = "txtDifference";
            this.txtDifference.Size = new System.Drawing.Size(77, 20);
            this.txtDifference.TabIndex = 201;
            this.txtDifference.Text = "0.00";
            this.txtDifference.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtDifference.Visible = false;
            // 
            // cbSP
            // 
            this.cbSP.AutoSize = true;
            this.cbSP.Location = new System.Drawing.Point(26, 559);
            this.cbSP.Name = "cbSP";
            this.cbSP.Size = new System.Drawing.Size(102, 17);
            this.cbSP.TabIndex = 204;
            this.cbSP.Text = "Save and Print?";
            this.cbSP.UseVisualStyleBackColor = true;
            // 
            // btnListPendingPO
            // 
            this.btnListPendingPO.Enabled = false;
            this.btnListPendingPO.Location = new System.Drawing.Point(607, 541);
            this.btnListPendingPO.Name = "btnListPendingPO";
            this.btnListPendingPO.Size = new System.Drawing.Size(112, 61);
            this.btnListPendingPO.TabIndex = 8;
            this.btnListPendingPO.Text = "Pending JO...";
            this.btnListPendingPO.UseVisualStyleBackColor = true;
            this.btnListPendingPO.Visible = false;
            this.btnListPendingPO.Click += new System.EventHandler(this.btnListPendingPO_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(700, 164);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(55, 19);
            this.label6.TabIndex = 207;
            this.label6.Text = "JO No.";
            // 
            // cboJONumber
            // 
            this.cboJONumber.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cboJONumber.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cboJONumber.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboJONumber.FormattingEnabled = true;
            this.cboJONumber.Location = new System.Drawing.Point(755, 160);
            this.cboJONumber.Name = "cboJONumber";
            this.cboJONumber.Size = new System.Drawing.Size(319, 27);
            this.cboJONumber.TabIndex = 7;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.Red;
            this.label22.Location = new System.Drawing.Point(25, 9);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(262, 22);
            this.label22.TabIndex = 241;
            this.label22.Text = "Press F5 to open entry window";
            this.label22.Visible = false;
            // 
            // button1
            // 
            this.button1.Enabled = false;
            this.button1.Location = new System.Drawing.Point(304, 553);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 242;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtNum
            // 
            this.txtNum.Location = new System.Drawing.Point(516, 9);
            this.txtNum.Name = "txtNum";
            this.txtNum.Size = new System.Drawing.Size(77, 20);
            this.txtNum.TabIndex = 243;
            this.txtNum.Text = "2";
            this.txtNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtNum.Visible = false;
            // 
            // txtWS
            // 
            this.txtWS.Location = new System.Drawing.Point(433, 9);
            this.txtWS.Name = "txtWS";
            this.txtWS.Size = new System.Drawing.Size(77, 20);
            this.txtWS.TabIndex = 245;
            this.txtWS.Text = "WS";
            this.txtWS.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtWS.Visible = false;
            // 
            // dgv1
            // 
            this.dgv1.AllowUserToAddRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgv1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.txtrefer,
            this.txtDR,
            this.txtCR,
            this.ColumncbdgvSIT});
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv1.DefaultCellStyle = dataGridViewCellStyle6;
            this.dgv1.Location = new System.Drawing.Point(73, 335);
            this.dgv1.Name = "dgv1";
            this.dgv1.Size = new System.Drawing.Size(612, 107);
            this.dgv1.TabIndex = 200;
            this.dgv1.Visible = false;
            // 
            // dataGridViewTextBoxColumn1
            // 
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dataGridViewTextBoxColumn1.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewTextBoxColumn1.HeaderText = "Account Number";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn1.Width = 120;
            // 
            // txtrefer
            // 
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.txtrefer.DefaultCellStyle = dataGridViewCellStyle3;
            this.txtrefer.HeaderText = "Reference";
            this.txtrefer.Name = "txtrefer";
            this.txtrefer.Width = 120;
            // 
            // txtDR
            // 
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.txtDR.DefaultCellStyle = dataGridViewCellStyle4;
            this.txtDR.HeaderText = "Debit";
            this.txtDR.Name = "txtDR";
            // 
            // txtCR
            // 
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.txtCR.DefaultCellStyle = dataGridViewCellStyle5;
            this.txtCR.HeaderText = "Credit";
            this.txtCR.Name = "txtCR";
            // 
            // ColumncbdgvSIT
            // 
            this.ColumncbdgvSIT.HeaderText = "SIT";
            this.ColumncbdgvSIT.Name = "ColumncbdgvSIT";
            this.ColumncbdgvSIT.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.ColumncbdgvSIT.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.ColumncbdgvSIT.Width = 50;
            // 
            // dgv2
            // 
            this.dgv2.AllowUserToAddRows = false;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dgv2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColumnStockNumber,
            this.ColumnItem,
            this.ColumnQtyIn,
            this.ColumnQtyOut,
            this.ColumnUC,
            this.ColumnTotal,
            this.ColumnInvClassCode});
            this.dgv2.Location = new System.Drawing.Point(26, 195);
            this.dgv2.Name = "dgv2";
            this.dgv2.ReadOnly = true;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgv2.RowsDefaultCellStyle = dataGridViewCellStyle12;
            this.dgv2.Size = new System.Drawing.Size(1048, 335);
            this.dgv2.TabIndex = 6;
            this.dgv2.UserDeletedRow += new System.Windows.Forms.DataGridViewRowEventHandler(this.dgv2_UserDeletedRow);
            // 
            // ColumnStockNumber
            // 
            this.ColumnStockNumber.HeaderText = "Stock Number";
            this.ColumnStockNumber.Name = "ColumnStockNumber";
            this.ColumnStockNumber.ReadOnly = true;
            this.ColumnStockNumber.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.ColumnStockNumber.Width = 150;
            // 
            // ColumnItem
            // 
            this.ColumnItem.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ColumnItem.HeaderText = "Description";
            this.ColumnItem.Name = "ColumnItem";
            this.ColumnItem.ReadOnly = true;
            // 
            // ColumnQtyIn
            // 
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle8.Format = "N2";
            dataGridViewCellStyle8.NullValue = null;
            this.ColumnQtyIn.DefaultCellStyle = dataGridViewCellStyle8;
            this.ColumnQtyIn.HeaderText = "Qty-In";
            this.ColumnQtyIn.Name = "ColumnQtyIn";
            this.ColumnQtyIn.ReadOnly = true;
            this.ColumnQtyIn.Width = 75;
            // 
            // ColumnQtyOut
            // 
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle9.Format = "N2";
            dataGridViewCellStyle9.NullValue = null;
            this.ColumnQtyOut.DefaultCellStyle = dataGridViewCellStyle9;
            this.ColumnQtyOut.HeaderText = "Qty-Out";
            this.ColumnQtyOut.Name = "ColumnQtyOut";
            this.ColumnQtyOut.ReadOnly = true;
            this.ColumnQtyOut.Width = 75;
            // 
            // ColumnUC
            // 
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle10.Format = "N2";
            dataGridViewCellStyle10.NullValue = null;
            this.ColumnUC.DefaultCellStyle = dataGridViewCellStyle10;
            this.ColumnUC.HeaderText = "Unit Cost";
            this.ColumnUC.Name = "ColumnUC";
            this.ColumnUC.ReadOnly = true;
            this.ColumnUC.Width = 120;
            // 
            // ColumnTotal
            // 
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle11.Format = "N2";
            dataGridViewCellStyle11.NullValue = null;
            this.ColumnTotal.DefaultCellStyle = dataGridViewCellStyle11;
            this.ColumnTotal.HeaderText = "Total";
            this.ColumnTotal.Name = "ColumnTotal";
            this.ColumnTotal.ReadOnly = true;
            this.ColumnTotal.Width = 120;
            // 
            // ColumnInvClassCode
            // 
            this.ColumnInvClassCode.HeaderText = "InvClassCode";
            this.ColumnInvClassCode.Name = "ColumnInvClassCode";
            this.ColumnInvClassCode.ReadOnly = true;
            this.ColumnInvClassCode.Visible = false;
            // 
            // frmVoucherWS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnClose;
            this.ClientSize = new System.Drawing.Size(1100, 611);
            this.Controls.Add(this.txtWS);
            this.Controls.Add(this.txtNum);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.cboJONumber);
            this.Controls.Add(this.btnListPendingPO);
            this.Controls.Add(this.cbSP);
            this.Controls.Add(this.txtdrtot);
            this.Controls.Add(this.txtcrtot);
            this.Controls.Add(this.txtDifference);
            this.Controls.Add(this.dgv1);
            this.Controls.Add(this.cbAccountNo);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cboPA);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.cboSMCode);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.cboWHCode);
            this.Controls.Add(this.btnPE);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txtTotCost);
            this.Controls.Add(this.dgv2);
            this.Controls.Add(this.txtDocNum);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.txtRemarks);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cboControlNo);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtreference);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtTDate);
            this.KeyPreview = true;
            this.Name = "frmVoucherWS";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Withdrawal Slip";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmVoucherWS_FormClosing);
            this.Load += new System.EventHandler(this.frmVoucherWS_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frmVoucherWS_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.dgv1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.MaskedTextBox txtTDate;
        private System.Windows.Forms.TextBox txtreference;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cboControlNo;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtRemarks;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.TextBox txtDocNum;
        private moveNextCellDataGridView dgv2;
        private System.Windows.Forms.TextBox txtTotCost;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnPE;
        private System.Windows.Forms.ComboBox cboWHCode;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox cboSMCode;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cboPA;
        private System.Windows.Forms.CheckBox cbAccountNo;
        private moveNextCellDataGridView dgv1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn txtrefer;
        private System.Windows.Forms.DataGridViewTextBoxColumn txtDR;
        private System.Windows.Forms.DataGridViewTextBoxColumn txtCR;
        private System.Windows.Forms.DataGridViewCheckBoxColumn ColumncbdgvSIT;
        private System.Windows.Forms.TextBox txtdrtot;
        private System.Windows.Forms.TextBox txtcrtot;
        private System.Windows.Forms.TextBox txtDifference;
        private System.Windows.Forms.CheckBox cbSP;
        private System.Windows.Forms.Button btnListPendingPO;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cboJONumber;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnStockNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnItem;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnQtyIn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnQtyOut;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnUC;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnTotal;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnInvClassCode;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtNum;
        private System.Windows.Forms.TextBox txtWS;
    }
}