﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TCIGL
{
    public partial class frmEntryBankDetailEdit : Form
    {
        SqlConnection myconnection;
        SqlCommand mycommand;
        BindingSource dbind = new BindingSource();
        //SqlDataReader dr;
     //   SqlDataAdapter da;
     //   DataSet dset;
        ClsPermission ClsPermission1 = new ClsPermission();
        ClsGetConnection ClsGetConnection1 = new ClsGetConnection();
        ClsBuildEntryComboBox ClsBuildEntryComboBox1 = new ClsBuildEntryComboBox();
        ClsGetSomethingEntry ClsGetSomethingEntry1 = new ClsGetSomethingEntry(); 
        public frmEntryBankDetailEdit()
        {
            InitializeComponent();
        }

 
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buildBDCode()
        {
            cboBDCode.DataSource = null;
            ClsBuildEntryComboBox1.ARBDCode.Clear();
            ClsBuildEntryComboBox1.ClsBuildBDCode();
            this.cboBDCode.DataSource = (ClsBuildEntryComboBox1.ARBDCode);
            this.cboBDCode.DisplayMember = "Display";
            this.cboBDCode.ValueMember = "Value";
            //this.cboWHCode.DropDownWidth = 450;
        }

  
        private void frmBankDetailEdit_Load(object sender, EventArgs e)
        {
           ClsPermission1.ClsObjects(this.Text);
           if (new ClsValidation().emptytxt(ClsPermission1.plstxtObject))
               {
                  MessageBox.Show("You do not have necessary permission to open this file", "GL");
                  this.Close();
               }
           else
               {
                  buildBDCode();

                  cboBDCode.Text = "";
                  txtBDDesc.Text = "";
               }
        }

  
        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {

                if (new ClsValidation().emptytxt (txtBDDesc.Text))
                {
                    MessageBox.Show("Please complete your entry", "POS");
                    txtBDDesc.Focus();
                }
                else
                {
                    ClsGetConnection1.ClsGetConMSSQL();
                    myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                    myconnection.Open();

                    string sqlstatement;
                    sqlstatement = "UPDATE tblBankDetail SET BankName=@_BankName, AcctNo=@_AcctNo, TelNum=@_TelNum, Address=@_Address WHERE BankCode ='" + cboBDCode.SelectedValue.ToString() + "'";

                    mycommand = new SqlCommand(sqlstatement, myconnection);
                    mycommand.Parameters.Add("_BankName", SqlDbType.VarChar).Value = txtBDDesc.Text;
                    mycommand.Parameters.Add("_AcctNo", SqlDbType.VarChar).Value = txtAccountNo.Text;
                    mycommand.Parameters.Add("_TelNum", SqlDbType.VarChar).Value = txtContactNo.Text;
                    mycommand.Parameters.Add("_Address", SqlDbType.VarChar).Value = txtAddress.Text;
                    int n1 = mycommand.ExecuteNonQuery();
                    myconnection.Close();
                    buildBDCode();
                    cboBDCode.Text = "";
                    txtBDDesc.Text = "";
                    txtAccountNo.Text = "";
                    txtContactNo.Text = "";
                    txtAddress.Text = "";
                    cboBDCode.Focus();
                }
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                //dr.Close();
                myconnection.Close();
            }
        }

        private void cboWHCode_Validating(object sender, CancelEventArgs e)
        {
            if (new ClsValidation().emptytxt(cboBDCode.Text))
            {
            }
            else if (cboBDCode.Text != null && cboBDCode.SelectedValue == null)
            {
                MessageBox.Show("Not found", "GL");
                cboBDCode.Focus();
            }
            else
            {
                GetWHDesc();
            }
        }

      private void GetWHDesc()
        {
            ClsGetSomethingEntry1.ClsGetBDDesc(cboBDCode.SelectedValue.ToString());
            txtBDDesc.Text = ClsGetSomethingEntry1.plsvarBDDesc;
            txtAccountNo.Text = ClsGetSomethingEntry1.plsvarBDAccount;
            txtContactNo.Text = ClsGetSomethingEntry1.plsvarBDContact;
            txtAddress.Text = ClsGetSomethingEntry1.plsvarAddress;
        }

      private void nextfieldenter1(object sender, KeyEventArgs e)
      {
          if (e.KeyCode.Equals(Keys.Enter))
          {
              SendKeys.Send("{TAB}");
          }
          else if ((e.KeyCode.Equals(Keys.Up)) || (e.KeyCode.Equals(Keys.Left)))
          {
              SendKeys.Send("+{TAB}");
          }
          else if ((e.KeyCode.Equals(Keys.Down)) || (e.KeyCode.Equals(Keys.Right)))
          {
              SendKeys.Send("{TAB}");
          }
      }

      private void nextfieldenter2(object sender, KeyEventArgs e)
      {
          if (e.KeyCode.Equals(Keys.Enter))
          {
              SendKeys.Send("{TAB}");
          }

      }
    }
}
