﻿namespace TCIGL
{
    partial class frmBankRecon
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dgv1 = new System.Windows.Forms.DataGridView();
            this.txtTDate1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtCNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtReference = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtCheckNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtDR = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtCR = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cbReconciled = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.txtNum = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnReconReport = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.cboBank = new System.Windows.Forms.ComboBox();
            this.txtTDate = new System.Windows.Forms.MaskedTextBox();
            this.txtBookBalance = new System.Windows.Forms.TextBox();
            this.txtBankBalance = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btnTransaction = new System.Windows.Forms.Button();
            this.cbHideReconTransact = new System.Windows.Forms.CheckBox();
            this.btnDetailedRep = new System.Windows.Forms.Button();
            this.txtReport = new System.Windows.Forms.TextBox();
            this.txtSumDR = new System.Windows.Forms.TextBox();
            this.txtSumCR = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgv1)).BeginInit();
            this.SuspendLayout();
            // 
            // dgv1
            // 
            this.dgv1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dgv1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.txtTDate1,
            this.txtCNumber,
            this.txtReference,
            this.txtCheckNo,
            this.txtDR,
            this.txtCR,
            this.cbReconciled,
            this.txtNum});
            this.dgv1.Location = new System.Drawing.Point(12, 122);
            this.dgv1.Name = "dgv1";
            this.dgv1.Size = new System.Drawing.Size(800, 327);
            this.dgv1.TabIndex = 0;
            this.dgv1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv1_CellContentClick);
            this.dgv1.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv1_CellEndEdit);
            // 
            // txtTDate1
            // 
            this.txtTDate1.HeaderText = "Date";
            this.txtTDate1.Name = "txtTDate1";
            // 
            // txtCNumber
            // 
            this.txtCNumber.HeaderText = "Series";
            this.txtCNumber.Name = "txtCNumber";
            this.txtCNumber.Width = 120;
            // 
            // txtReference
            // 
            this.txtReference.HeaderText = "Reference";
            this.txtReference.Name = "txtReference";
            this.txtReference.Width = 120;
            // 
            // txtCheckNo
            // 
            this.txtCheckNo.HeaderText = "Check #";
            this.txtCheckNo.Name = "txtCheckNo";
            this.txtCheckNo.Width = 120;
            // 
            // txtDR
            // 
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.txtDR.DefaultCellStyle = dataGridViewCellStyle5;
            this.txtDR.HeaderText = "Debit";
            this.txtDR.Name = "txtDR";
            // 
            // txtCR
            // 
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.txtCR.DefaultCellStyle = dataGridViewCellStyle6;
            this.txtCR.HeaderText = "Credit";
            this.txtCR.Name = "txtCR";
            // 
            // cbReconciled
            // 
            this.cbReconciled.HeaderText = "Reconciled";
            this.cbReconciled.Name = "cbReconciled";
            this.cbReconciled.Width = 80;
            // 
            // txtNum
            // 
            this.txtNum.HeaderText = "Num";
            this.txtNum.Name = "txtNum";
            this.txtNum.Visible = false;
            // 
            // btnReconReport
            // 
            this.btnReconReport.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnReconReport.Location = new System.Drawing.Point(594, 464);
            this.btnReconReport.Name = "btnReconReport";
            this.btnReconReport.Size = new System.Drawing.Size(130, 23);
            this.btnReconReport.TabIndex = 3;
            this.btnReconReport.Text = "Reconciliation Report";
            this.btnReconReport.UseVisualStyleBackColor = true;
            this.btnReconReport.Click += new System.EventHandler(this.btnReconReport_Click);
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.Location = new System.Drawing.Point(736, 464);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 4;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // cboBank
            // 
            this.cboBank.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboBank.FormattingEnabled = true;
            this.cboBank.Location = new System.Drawing.Point(99, 48);
            this.cboBank.Name = "cboBank";
            this.cboBank.Size = new System.Drawing.Size(258, 27);
            this.cboBank.TabIndex = 5;
            this.cboBank.KeyDown += new System.Windows.Forms.KeyEventHandler(this.nextfieldenter2);
            // 
            // txtTDate
            // 
            this.txtTDate.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTDate.Location = new System.Drawing.Point(99, 81);
            this.txtTDate.Mask = "00/00/0000";
            this.txtTDate.Name = "txtTDate";
            this.txtTDate.Size = new System.Drawing.Size(258, 26);
            this.txtTDate.TabIndex = 6;
            this.txtTDate.ValidatingType = typeof(System.DateTime);
            this.txtTDate.KeyDown += new System.Windows.Forms.KeyEventHandler(this.nextfieldenter1);
            this.txtTDate.Validating += new System.ComponentModel.CancelEventHandler(this.txtTDate_Validating);
            // 
            // txtBookBalance
            // 
            this.txtBookBalance.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtBookBalance.Enabled = false;
            this.txtBookBalance.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBookBalance.Location = new System.Drawing.Point(656, 49);
            this.txtBookBalance.Name = "txtBookBalance";
            this.txtBookBalance.Size = new System.Drawing.Size(156, 26);
            this.txtBookBalance.TabIndex = 7;
            this.txtBookBalance.Text = "0.00";
            this.txtBookBalance.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtBookBalance.Validating += new System.ComponentModel.CancelEventHandler(this.txtBookBalance_Validating);
            // 
            // txtBankBalance
            // 
            this.txtBankBalance.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtBankBalance.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBankBalance.Location = new System.Drawing.Point(656, 81);
            this.txtBankBalance.Name = "txtBankBalance";
            this.txtBankBalance.Size = new System.Drawing.Size(156, 26);
            this.txtBankBalance.TabIndex = 8;
            this.txtBankBalance.Text = "0.00";
            this.txtBankBalance.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtBankBalance.KeyDown += new System.Windows.Forms.KeyEventHandler(this.nextfieldenter1);
            this.txtBankBalance.Validating += new System.ComponentModel.CancelEventHandler(this.txtBankBalance_Validating);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(8, 56);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(85, 19);
            this.label16.TabIndex = 114;
            this.label16.Text = "Bank Name:";
            this.label16.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(48, 84);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 19);
            this.label1.TabIndex = 115;
            this.label1.Text = "As of:";
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(544, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(98, 19);
            this.label2.TabIndex = 116;
            this.label2.Text = "Book Balance:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(544, 84);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(96, 19);
            this.label3.TabIndex = 117;
            this.label3.Text = "Bank Balance:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(664, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(141, 19);
            this.label4.TabIndex = 118;
            this.label4.Text = "Unreconciled Balance";
            this.label4.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // btnTransaction
            // 
            this.btnTransaction.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnTransaction.Location = new System.Drawing.Point(12, 464);
            this.btnTransaction.Name = "btnTransaction";
            this.btnTransaction.Size = new System.Drawing.Size(129, 23);
            this.btnTransaction.TabIndex = 119;
            this.btnTransaction.Text = "Show Transaction";
            this.btnTransaction.UseVisualStyleBackColor = true;
            this.btnTransaction.Click += new System.EventHandler(this.btnTransaction_Click);
            // 
            // cbHideReconTransact
            // 
            this.cbHideReconTransact.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cbHideReconTransact.AutoSize = true;
            this.cbHideReconTransact.Checked = true;
            this.cbHideReconTransact.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbHideReconTransact.Location = new System.Drawing.Point(13, 493);
            this.cbHideReconTransact.Name = "cbHideReconTransact";
            this.cbHideReconTransact.Size = new System.Drawing.Size(164, 17);
            this.cbHideReconTransact.TabIndex = 120;
            this.cbHideReconTransact.Text = "Hide Reconciled Transaction";
            this.cbHideReconTransact.UseVisualStyleBackColor = true;
            this.cbHideReconTransact.CheckedChanged += new System.EventHandler(this.cbHideReconTransact_CheckedChanged);
            // 
            // btnDetailedRep
            // 
            this.btnDetailedRep.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDetailedRep.Location = new System.Drawing.Point(452, 464);
            this.btnDetailedRep.Name = "btnDetailedRep";
            this.btnDetailedRep.Size = new System.Drawing.Size(130, 23);
            this.btnDetailedRep.TabIndex = 121;
            this.btnDetailedRep.Text = "Detailed Report";
            this.btnDetailedRep.UseVisualStyleBackColor = true;
            this.btnDetailedRep.Click += new System.EventHandler(this.btnDetailedRep_Click);
            // 
            // txtReport
            // 
            this.txtReport.Location = new System.Drawing.Point(187, 467);
            this.txtReport.Name = "txtReport";
            this.txtReport.Size = new System.Drawing.Size(64, 20);
            this.txtReport.TabIndex = 122;
            this.txtReport.Visible = false;
            // 
            // txtSumDR
            // 
            this.txtSumDR.Location = new System.Drawing.Point(267, 464);
            this.txtSumDR.Name = "txtSumDR";
            this.txtSumDR.Size = new System.Drawing.Size(64, 20);
            this.txtSumDR.TabIndex = 123;
            this.txtSumDR.Visible = false;
            // 
            // txtSumCR
            // 
            this.txtSumCR.Location = new System.Drawing.Point(337, 464);
            this.txtSumCR.Name = "txtSumCR";
            this.txtSumCR.Size = new System.Drawing.Size(64, 20);
            this.txtSumCR.TabIndex = 124;
            this.txtSumCR.Visible = false;
            // 
            // frmBankRecon
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(824, 522);
            this.Controls.Add(this.txtSumCR);
            this.Controls.Add(this.txtSumDR);
            this.Controls.Add(this.txtReport);
            this.Controls.Add(this.btnDetailedRep);
            this.Controls.Add(this.cbHideReconTransact);
            this.Controls.Add(this.btnTransaction);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.txtBankBalance);
            this.Controls.Add(this.txtBookBalance);
            this.Controls.Add(this.txtTDate);
            this.Controls.Add(this.cboBank);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnReconReport);
            this.Controls.Add(this.dgv1);
            this.Name = "frmBankRecon";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Bank Reconciliation";
            this.Load += new System.EventHandler(this.frmBankRecon_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgv1;
        private System.Windows.Forms.Button btnReconReport;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.ComboBox cboBank;
        private System.Windows.Forms.MaskedTextBox txtTDate;
        private System.Windows.Forms.TextBox txtBookBalance;
        private System.Windows.Forms.TextBox txtBankBalance;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnTransaction;
        private System.Windows.Forms.CheckBox cbHideReconTransact;
        private System.Windows.Forms.DataGridViewTextBoxColumn txtTDate1;
        private System.Windows.Forms.DataGridViewTextBoxColumn txtCNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn txtReference;
        private System.Windows.Forms.DataGridViewTextBoxColumn txtCheckNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn txtDR;
        private System.Windows.Forms.DataGridViewTextBoxColumn txtCR;
        private System.Windows.Forms.DataGridViewCheckBoxColumn cbReconciled;
        private System.Windows.Forms.DataGridViewTextBoxColumn txtNum;
        private System.Windows.Forms.Button btnDetailedRep;
        private System.Windows.Forms.TextBox txtReport;
        private System.Windows.Forms.TextBox txtSumDR;
        private System.Windows.Forms.TextBox txtSumCR;
    }
}