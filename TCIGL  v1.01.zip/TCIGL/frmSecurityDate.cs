﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TCIGL
{
    public partial class frmSecurityDate : Form
    {
        SqlConnection myconnection;
        SqlCommand mycommand;
        BindingSource dbind = new BindingSource();
        ClsPermission ClsPermission1 = new ClsPermission();
        ClsGetConnection ClsGetConnection1 = new ClsGetConnection();
        ClsCompName ClsCompName1 = new ClsCompName();
        ClsGetSomething ClsGetSomething1 = new ClsGetSomething();
 
        public frmSecurityDate()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        private void frmSecurityDate_Load(object sender, EventArgs e)
        {
            ClsPermission1.ClsObjects(this.Text);
            if (new ClsValidation().emptytxt(ClsPermission1.plstxtObject))
            {
                MessageBox.Show("You do not have necessary permission to open this file", "GL");
                this.Close();
            }
            else
            {
                ClsGetSomething1.ClsGetSecureDate();
                txtBeginDate.Text = ClsGetSomething1.plsBeginDate;
                txtEndDate.Text = ClsGetSomething1.plsEndDate;
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtBeginDate.Text == "  /  /")
                {
                    MessageBox.Show("Please complete your entry", "GL");
                    txtBeginDate.Focus();
                }
                else if (txtEndDate.Text == "  /  /")
                {
                    MessageBox.Show("Please complete your entry", "GL");
                    txtEndDate.Focus();

                }
                else if (Convert.ToDateTime(txtBeginDate.Text) > Convert.ToDateTime(txtEndDate.Text))
                {
                    MessageBox.Show("Beginning date is greater than ending date");
                    txtBeginDate.Focus();
                }
                
                else
                {
                    ClsGetConnection1.ClsGetConMSSQL();
                    myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                    myconnection.Open();

                    string sqlstatement;
                    sqlstatement = "UPDATE tblSecurityDate SET BeginDate=@_BeginDate, Enddate=@_EndDate";

                    mycommand = new SqlCommand(sqlstatement, myconnection);
                    mycommand.Parameters.Add("_BeginDate", SqlDbType.SmallDateTime).Value = txtBeginDate.Text;
                    mycommand.Parameters.Add("_EndDate", SqlDbType.SmallDateTime).Value = txtEndDate.Text;
                    
                    int n1 = mycommand.ExecuteNonQuery();
                    myconnection.Close();
                    MessageBox.Show("Finished", "GL");
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                myconnection.Close();
            }

    }
        private void txtBeginDate_Validating(object sender, CancelEventArgs e)
        {
            if (new ClsValidation().errordate(txtBeginDate.Text) == true)
            {
                MessageBox.Show("Invalid Date", "GL");
                txtBeginDate.Focus();
            }

        }

        private void txtEndDate_Validating(object sender, CancelEventArgs e)
        {
            if (new ClsValidation().errordate(txtEndDate.Text) == true)
            {
                MessageBox.Show("Invalid Date", "GL");
                txtEndDate.Focus();
            }

        }
    }
}
