﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Threading;
using CrystalDecisions.CrystalReports.Engine;

namespace TCIGL
{
    public partial class frmVoucherPI : Form
    {
        string varoutdate = "No";
        public static DataGridView glbldgv2;
        public static ComboBox glblcboBN;
        SqlConnection myconnection;
        SqlCommand mycommand;
        SqlCommand mycommanddgv2;
        //SqlCommand mycommanddgv3;
        ClsAutoNumber ClsAutoNumber1 = new ClsAutoNumber();
        ClsBuildComboBox ClsBuildComboBox1 = new ClsBuildComboBox();
        ClsValidation ClsValidation1 = new ClsValidation();
        ClsGetSomething ClsGetSomething1 = new ClsGetSomething();
        ClsGetSomethingEntry ClsGetSomethingEntry1 = new ClsGetSomethingEntry();
        ClsPermission ClsPermission1 = new ClsPermission();
        ClsBuildEntryComboBox ClsBuildEntryComboBox1 = new ClsBuildEntryComboBox();
        ClsGetConnection ClsGetConnection1 = new ClsGetConnection();
        ClsDefaultBranch ClsDefaultBranch1 = new ClsDefaultBranch();
        SqlDataReader SqlDataReader1;
        ClsCompName ClsCompName1 = new ClsCompName();

        string dgvdata = null;
        public static TextBox glblSPO;
        public static TextBox glbltxtTotDisct, glbltxtTotalVAT, glbltxtTotCost, glbltxtTotPayables, glbltxtTotQty;
        public static Button glblbtnSave;

        ClsGetSomethingOthers ClsGetSomethingOthers1 = new ClsGetSomethingOthers();
        int varintTableDoor = 0;
        int number = 0;
        private string privarstrVoidIC = null;
        public frmVoucherPI()
        {
            InitializeComponent();
            {
                ClsGetSomethingOthers1.ClsGetVoidRef("PI", "5");
                privarstrVoidIC = ClsGetSomethingOthers1.plsVoidIC;
                if (new ClsValidation().emptytxt(privarstrVoidIC))
                { }
                else
                {
                    ClsGetSomethingOthers1.ClsDeleteErrorTransaction("PI", "5");
                }
            }
        }


        private void buildcboCustCode()
        {
            cboControlNo.DataSource = null;
            ClsBuildComboBox1.ARPCN.Clear();
            ClsBuildComboBox1.ClsBuildCustControlno();
            this.cboControlNo.DataSource = (ClsBuildComboBox1.ARPCN);
            this.cboControlNo.DisplayMember = "Display";
            this.cboControlNo.ValueMember = "Value";
        }
      
        private void SaveTransact()
        {
            try
            {
                DateTime DT = DateTime.Now;
                string sqlstatement;
                string sqlstatementdgv2;

               
                sqlstatement = "INSERT INTO tblPI1 (IC, DocNum, Voucher, UserCode, Reference, TDate, ControlNo, DelDate, CNCode, DE, BankCode, Term)";
                sqlstatement += " Values (@_IC, @_DocNum, @_Voucher, @_UserCode, @_Reference, @_TDate, @_ControlNo, @_DelDate, @_CNCode, @_DE, @_BankCode, @_Term)";
                sqlstatementdgv2 = "INSERT INTO tblPI2 (IC, POut, UP, StockNumber, RowNum, Remarks, ProductDesign) Values (@_IC, @_POut, @_UP, @_StockNumber, @_RowNum, @_Remarks, @_ProductDesign)";

                ClsAutoNumber1.VoucherAutoNumPI("PI");
                txtDocNum.Text = (ClsAutoNumber1.plsnumber);

                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();

                mycommand = new SqlCommand(sqlstatement, myconnection);
                mycommand.Parameters.Add("_IC", SqlDbType.VarChar).Value = "PI" + Form1.glbluc.Text + (ClsDefaultBranch1.plsvardb);
                mycommand.Parameters.Add("_DocNum", SqlDbType.VarChar).Value = Form1.glbluc.Text;
                mycommand.Parameters.Add("_Voucher", SqlDbType.VarChar).Value = "PI";
                mycommand.Parameters.Add("_UserCode", SqlDbType.VarChar).Value = Form1.glbluc.Text;
                mycommand.Parameters.Add("_TDate", SqlDbType.Date).Value = txtTDate.Text;
                mycommand.Parameters.Add("_Reference", SqlDbType.VarChar).Value = txtreference.Text;              
                mycommand.Parameters.Add("_ControlNo", SqlDbType.VarChar).Value = cboControlNo.SelectedValue;
                mycommand.Parameters.Add("_DelDate", SqlDbType.Date).Value = txtDelDate.Text;
                mycommand.Parameters.Add("_CNCode", SqlDbType.Char).Value = (ClsDefaultBranch1.plsvardb);
                mycommand.Parameters.Add("_DE", SqlDbType.Date).Value = DT;
                mycommand.Parameters.Add("_BankCode", SqlDbType.Char).Value = cboBankName.SelectedValue.ToString();
                mycommand.Parameters.Add("_Term", SqlDbType.TinyInt).Value = txtTerm.Text;

                int n1 = mycommand.ExecuteNonQuery();


                DataGridViewRow row1 = null;

                for (int x = 0; x < dgv2.Rows.Count - 1; x++)
                {
                    row1 = dgv2.Rows[x];
                    mycommanddgv2 = new SqlCommand(sqlstatementdgv2, myconnection);
                    mycommanddgv2.Parameters.Add("_IC", SqlDbType.VarChar).Value = "PI" + Form1.glbluc.Text + (ClsDefaultBranch1.plsvardb);
                    mycommanddgv2.Parameters.Add("_POut", SqlDbType.Money).Value = row1.Cells[0].Value;
                    mycommanddgv2.Parameters.Add("_StockNumber", SqlDbType.VarChar).Value = row1.Cells[2].Value;
                    mycommanddgv2.Parameters.Add("_UP", SqlDbType.Money).Value = row1.Cells[5].Value;
                    mycommanddgv2.Parameters.Add("_RowNum", SqlDbType.SmallInt).Value = (Convert.ToInt32(x) + 1).ToString();
                    mycommanddgv2.Parameters.Add("_Remarks", SqlDbType.VarChar).Value = row1.Cells[8].Value.ToString();
                    mycommanddgv2.Parameters.Add("_ProductDesign", SqlDbType.VarChar).Value = row1.Cells[7].Value.ToString();
                    int n2 = mycommanddgv2.ExecuteNonQuery();
                }

                myconnection.Close();
                ClsGetSomethingOthers1.ClsFinalize("PI", txtDocNum.Text, "5");

                if (cbSP.Checked)
                {
                    int varnocopy = int.Parse(frmMain.glbltxtNoCopy.Text);
                    for (int i = 1; i <= varnocopy; i++)
                    {
                        printcurvoucher();
                    }
                }


                ClsAutoNumber1.VoucherAutoNumPI("PI");
                txtDocNum.Text = (ClsAutoNumber1.plsnumber);
                clearscreen();
            }
            catch
            {
                MessageBox.Show("Error, please click OK", "GL");
                this.Close();
            }
            finally
            {
                myconnection.Close();
            }
        }
        private void printcurvoucher()
        {
            string sqlstatement = "SELECT * FROM ViewBookPI WHERE DocNum ='" + txtDocNum.Text + "' AND CNCode = '" + ClsDefaultBranch1.plsvardb + "' ORDER BY RowNum";

            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();
            mycommand = myconnection.CreateCommand();
            mycommand.CommandText = sqlstatement;
            mycommand.CommandTimeout = 900;
            SqlDataReader1 = mycommand.ExecuteReader();
            DataTable DataTable1 = new DataTable();
            DataTable1.Load(SqlDataReader1);
            myconnection.Close();

            if (DataTable1.Rows.Count == 0)
            {
                MessageBox.Show("No data found", "GL");
                return;
            }

            CRprevPI objRpt = new CRprevPI();
            TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            ClsCompName1.ClsCompNameMain();
            vartxtcompany.Text = ClsCompName1.varcn;

            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            ClsCompName1.ClsCompNamebranchAddress(ClsDefaultBranch1.plsvardb);
            vartxtaddress.Text = (ClsCompName1.plsCRaddress);

            objRpt.SetDataSource(DataTable1);
            System.Drawing.Printing.PrintDocument doctoprint = new System.Drawing.Printing.PrintDocument();
            int rawKind = 0;
            for (int i = 0; i <= doctoprint.PrinterSettings.PaperSizes.Count - 1; i++)
            {
                if (doctoprint.PrinterSettings.PaperSizes[i].PaperName == "C1-HalfShort")
                {
                    rawKind = Convert.ToInt32(doctoprint.PrinterSettings.PaperSizes[i].GetType().GetField("kind",
                    System.Reflection.BindingFlags.Instance |
                    System.Reflection.BindingFlags.NonPublic).GetValue(doctoprint.PrinterSettings.PaperSizes[i]));
                    break; // TODO: might not be correct. Was : Exit For
                }
            }
            objRpt.PrintOptions.PaperSize = (CrystalDecisions.Shared.PaperSize)rawKind;

            objRpt.Refresh();
            objRpt.PrintToPrinter(1, false, 0, 0);
        }
        private void clearscreen()
        {
            dgv2.Rows.Clear();
            txtreference.Text = "";
            cboControlNo.SelectedValue  = "";
            // txtCheckNo.Text = "NA";
            //  txtCAmount.Text = "0.00";
            //cboPC.Text = "";
            txtTDate.Focus();
            txtTotAmount.Text = "0.00";
            txtTotQty.Text = "0.00";
            dgvdata = null;
            txtTerm.Text = "0";
        }
       


        private void btnSave_Click(object sender, EventArgs e)
        {
                ClsValidation1.securedate(DateTime.Parse(txtTDate.Text));
                varoutdate = (ClsValidation1.plsoutdate);
                for (int x = 0; x < dgv2.Rows.Count - 1; x++)
                {
                    dgvdata = (dgv2.Rows[x].Cells[0].FormattedValue.ToString());

                    if ((dgv2.Rows[x].Cells[7].Value == null) || (dgv2.Rows[x].Cells[8].Value == null))
                    {
                        MessageBox.Show("Empty value for Design or Remarks");
                        dgv2.Focus();
                        return;
                    }
                }

                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();

                if (new Clsexist().RecordExists(ref myconnection, "SELECT Reference FROM tblPI1 WHERE Reference ='" + txtreference.Text + "'"))
                {
                    myconnection.Close();
                    MessageBox.Show("Duplicate entry", "GL");
                    txtreference.Focus();
                }

                else if ((txtTDate.Text == "  /  /"))
                {
                    myconnection.Close();
                    MessageBox.Show("Please complete your entry", "GL");
                    txtTDate.Focus();
                }
                else if ((new ClsValidation().emptytxt(cboControlNo.Text)) || (new ClsValidation().emptytxt(txtreference.Text)))
                {
                    myconnection.Close();
                    MessageBox.Show("Please complete your entry", "GL");
                    txtTDate.Focus();
                }
                else if (varoutdate == "Yes")
                {
                    myconnection.Close();
                    MessageBox.Show("Date is out of range", "GL");
                    txtTDate.Focus();
                }
                else if (new ClsValidation().emptytxt(dgvdata))
                {
                    myconnection.Close();
                    MessageBox.Show("Incomplete Record", "IS");
                    txtTDate.Focus();
                }
                else
                {
                    myconnection.Close();
                    privarstrVoidIC = null;
                    ClsGetSomethingOthers1.ClsGetTDoor("PI");
                    varintTableDoor = int.Parse(ClsGetSomethingOthers1.plsTableDoor);
                    number = 0;
                    while (varintTableDoor == 1 && number <= 20)
                    {
                        number = number + 1;
                        Thread.Sleep(200);
                        varintTableDoor = int.Parse(ClsGetSomethingOthers1.plsTableDoor);
                    }

                    if (varintTableDoor == 0 && number <= 20)
                    {

                        ClsGetSomethingOthers1.ClsGetVoidRef("PI", "5");
                        privarstrVoidIC = ClsGetSomethingOthers1.plsVoidIC;
                        if (new ClsValidation().emptytxt(privarstrVoidIC))
                        {
                            ClsGetSomethingOthers1.ClsOneTheDoor("PI");
                           SaveTransact();
                            ClsGetSomethingOthers1.ClsZeroTheDoor("PI");
                        }
                        else
                        {
                            ClsGetSomethingOthers1.ClsDeleteErrorTransaction("PI", "5");
                            MessageBox.Show("Transaction not saved", "GL");
                        }
                    }
                    else if (varintTableDoor == 1 && number == 21)
                    {
                        MessageBox.Show("Contact your adminnistrator", "GL");
                    }

                }
        }

  

        private void cboCustCode_Validating(object sender, CancelEventArgs e)
        {
                if (new ClsValidation().emptytxt(cboControlNo.Text))
                {
                }
                else if (cboControlNo.Text != null && cboControlNo.SelectedValue == null)
                {
                    MessageBox.Show("Not found", "GL");
                    cboControlNo.Focus();
                }
                else
                {
                    ClsGetSomething1.ClsGetCustData(cboControlNo.SelectedValue.ToString());
                }

        }

        private void frmVoucherPI_Load(object sender, EventArgs e)
        {
            ClsPermission1.ClsObjects(this.Text);
            if (new ClsValidation().emptytxt(ClsPermission1.plstxtObject))
            {
                MessageBox.Show("You do not have necessary permission to open this file", "GL");
                this.Close();
            }
            else
            {
                ClsAutoNumber1.VoucherAutoNumPI("PI");
                txtDocNum.Text = (ClsAutoNumber1.plsnumber);
                ClsGetSomething1.ClsGetDefaultDate();
                txtTDate.Text = ClsGetSomething1.plsdefdate;
                txtDelDate.Text = ClsGetSomething1.plsdefdate;
                buildcboCustCode();
                buildentrycboBankName();
                cboControlNo.SelectedValue = "";
                glblcboBN = cboBankName;
                glbldgv2 = dgv2;
                glbltxtTotDisct=txtTotQty;
                glbltxtTotalVAT=txtTotAmount;
                glbltxtTotQty = txtTotQty;
                glblbtnSave = btnSave;
                //  cboCustCode.Text = "";
                privarstrVoidIC = null;
                ClsGetSomethingOthers1.ClsGetVoidRef("PI", "5");
                privarstrVoidIC = ClsGetSomethingOthers1.plsVoidIC;
                if (new ClsValidation().emptytxt(privarstrVoidIC))
                { }
                else
                {
                    ClsGetSomethingOthers1.ClsDeleteErrorTransaction("PI", "5");
                    privarstrVoidIC = null;
                }
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
            frmTransactEntryPI frmTransactEntryPI1 = new frmTransactEntryPI();
            frmTransactEntryPI1.Close();
        }

        private void btnPE_Click(object sender, EventArgs e)
        {
            frmTransactEntryPI frmTransactEntryPI1 = new frmTransactEntryPI();
            frmTransactEntryPI1.Show();
            btnPE.Visible = false;
            label22.Visible = true;
        }

       
        private void frmVoucherPI_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F5)
            {
                if ((txtTDate.Text == "  /  /"))
                {
                    MessageBox.Show("Please complete your entry", "GL");
                    txtTDate.Focus();
                }
                else if ((new ClsValidation().emptytxt(cboControlNo.Text)) || (new ClsValidation().emptytxt(txtreference.Text)))
                {
                    MessageBox.Show("Please complete your entry", "GL");
                    txtTDate.Focus();
                }
                else
                {
                    //frmTransactEntryCI.glbltxtD1.Enabled = false;
                    //frmTransactEntryCI.glbltxtD2.Enabled = false;
                    //frmTransactEntryCI.glbltxtD3.Enabled = false;
                    Form NonPoultry = Application.OpenForms["frmTransactEntryPI"];
                    if (NonPoultry != null)
                    {
                        //Application.OpenForms["frmTransactEntryCI"].BringToFront();
                        Application.OpenForms["frmTransactEntryPI"].Show();
                    }
                    else
                    {
                        MessageBox.Show("Not applicable at this moment", "GL");
                    }
                }
            }
     
        }

        private void txtTDate_Validating(object sender, CancelEventArgs e)
        {
            if (new ClsValidation().errordate(txtTDate.Text) == true)
            {
                MessageBox.Show("Invalid Date", "GL");
                txtTDate.Focus();
            }
        }

        private void dgv2_UserDeletedRow(object sender, DataGridViewRowEventArgs e)
        {
            dgv2total();
        }

        private void dgv1total()
        {
           
        }
        private void dgv2total()
        {
            double dbltxtTotDisct = 0;
            //double dbltxtTotalVAT = 0;
            //double dbltxtTotCost = 0;
            {
                for (int x = 0; x < frmVoucherPI.glbldgv2.Rows.Count - 1; x++)
                {
                    string vartxtD1 = frmVoucherPI.glbldgv2.Rows[x].Cells[5].FormattedValue.ToString();
                    string vartxtD2 = frmVoucherPI.glbldgv2.Rows[x].Cells[6].FormattedValue.ToString();
                    dbltxtTotDisct += double.Parse(vartxtD1) + double.Parse(vartxtD2);
                }
                for (int x = 0; x < frmVoucherPI.glbldgv2.Rows.Count - 1; x++)
                {
                    //dbltxtTotalVAT += double.Parse(frmVoucherPI.glbldgv2.Rows[x].Cells[8].FormattedValue.ToString());
                }

                for (int x = 0; x < frmVoucherPI.glbldgv2.Rows.Count - 1; x++)
                {
                    //dbltxtTotCost += double.Parse(frmVoucherPI.glbldgv2.Rows[x].Cells[10].FormattedValue.ToString());
                }

                //frmVoucherPI.glbltxtTotDisct.Text = dbltxtTotDisct.ToString("N2");
                //frmVoucherPI.glbltxtTotalVAT.Text = dbltxtTotalVAT.ToString("N2");
                //frmVoucherPI.glbltxtTotCost.Text = dbltxtTotCost.ToString("N2");

            }

        }

        private void txtreference_Validating(object sender, CancelEventArgs e)
        {
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();

            if (new Clsexist().RecordExists(ref myconnection, "SELECT Reference FROM tblPI1 WHERE Reference ='" + txtreference.Text + "'"))
            {
                myconnection.Close();
                MessageBox.Show("Duplicate entry", "GL");
                txtreference.Focus();
            }
            myconnection.Close();
        }
        private void nextfieldenter1(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.Equals(Keys.Enter))
            {
                SendKeys.Send("{TAB}");
            }
            else if ((e.KeyCode.Equals(Keys.Up)) || (e.KeyCode.Equals(Keys.Left)))
            {
                SendKeys.Send("+{TAB}");
            }
            else if ((e.KeyCode.Equals(Keys.Down)) || (e.KeyCode.Equals(Keys.Right)))
            {
                SendKeys.Send("{TAB}");
            }

        }

        

        private void nextfieldenter2(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.Equals(Keys.Enter))
            {
                SendKeys.Send("{TAB}");
            }

        }

        private void frmVoucherPI_FormClosing(object sender, FormClosingEventArgs e)
        {
            Form NonPoultry = Application.OpenForms["frmTransactEntryPI"];
            if (NonPoultry != null)
            {
                frmTransactEntryPI CloseNonPoultry = (frmTransactEntryPI)Application.OpenForms["frmTransactEntryPI"];
                CloseNonPoultry.Close();
            }
        }

        private void buildentrycboBankName()
        {
          
            cboBankName.DataSource = null;
            ClsBuildComboBox1.PIBN.Clear();
            ClsBuildComboBox1.ClsBuildBankNameNo();
            this.cboBankName.DataSource = (ClsBuildComboBox1.PIBN);
            this.cboBankName.DisplayMember = "Display";
            this.cboBankName.ValueMember = "Value";
          

        }
      
    }
}
