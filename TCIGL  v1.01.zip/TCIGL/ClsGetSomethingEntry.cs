﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;

namespace TCIGL
{
    class ClsGetSomethingEntry
    {
        public string plsvarWHDesc;
        public string plsvarBDDesc;
        public string plsvarBDAccount;
        public string plsvarBDContact;
        public string plsvarInvClassCode, plsvarAddress;
        SqlConnection myconnection;
        SqlDataReader dr;
        SqlCommand mycommand;
        ClsGetConnection ClsGetConnection1 = new ClsGetConnection();

        public void ClsGetWHDesc(string strWHCode)
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();

                mycommand = new SqlCommand("SELECT WHDesc FROM tblWarehouse WHERE WHCode='" + strWHCode + "'", myconnection);
                dr = mycommand.ExecuteReader();
                while (dr.Read())
                {
                    plsvarWHDesc = dr["WHDesc"].ToString();
                }
                myconnection.Close();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                //dr.Close();
                myconnection.Close();
            }
        }

        public void ClsGetBDDesc(string strBDCode)
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();

                mycommand = new SqlCommand("SELECT BankName, AcctNo, TelNum, Address FROM tblBankDetail WHERE BankCode='" + strBDCode + "'", myconnection);
                dr = mycommand.ExecuteReader();
                while (dr.Read())
                {
                    plsvarBDDesc = dr["BankName"].ToString();
                    plsvarBDAccount = dr["AcctNo"].ToString();
                    plsvarBDContact = dr["TelNum"].ToString();
                    plsvarAddress = dr["Address"].ToString();
                }
                myconnection.Close();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                //dr.Close();
                myconnection.Close();
            }
        }


        public void ClsGetInvClassCode(string strStockNumber)
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();

                mycommand = new SqlCommand("SELECT InvClassCode FROM tblStocks WHERE StockNumber='" + strStockNumber + "'", myconnection);
                dr = mycommand.ExecuteReader();
                while (dr.Read())
                {
                    plsvarInvClassCode = dr["InvClassCode"].ToString();
                }
                myconnection.Close();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                //dr.Close();
                myconnection.Close();
            }
        }
    }
}
