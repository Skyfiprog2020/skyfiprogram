﻿namespace TCIGL
{
    partial class frmEntryProductAdd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtStockNumber = new System.Windows.Forms.TextBox();
            this.txtStockCode = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtStockDesc = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cboCatCode = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cboSupplierCode = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtUCost = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtReorderPoint = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtMaintainingBal = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtSP = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.txtUM = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtSize = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.cboInvClassCode = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtStockNumber
            // 
            this.txtStockNumber.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtStockNumber.Location = new System.Drawing.Point(350, 21);
            this.txtStockNumber.Name = "txtStockNumber";
            this.txtStockNumber.ReadOnly = true;
            this.txtStockNumber.Size = new System.Drawing.Size(78, 26);
            this.txtStockNumber.TabIndex = 20;
            this.txtStockNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtStockCode
            // 
            this.txtStockCode.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtStockCode.Location = new System.Drawing.Point(21, 68);
            this.txtStockCode.Name = "txtStockCode";
            this.txtStockCode.Size = new System.Drawing.Size(407, 26);
            this.txtStockCode.TabIndex = 0;
            this.txtStockCode.KeyDown += new System.Windows.Forms.KeyEventHandler(this.nextfieldenter1);
            this.txtStockCode.Validating += new System.ComponentModel.CancelEventHandler(this.txtStockCode_Validating);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(17, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 19);
            this.label1.TabIndex = 5;
            this.label1.Text = "Code :";
            // 
            // txtStockDesc
            // 
            this.txtStockDesc.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtStockDesc.Location = new System.Drawing.Point(21, 127);
            this.txtStockDesc.Name = "txtStockDesc";
            this.txtStockDesc.Size = new System.Drawing.Size(407, 26);
            this.txtStockDesc.TabIndex = 1;
            this.txtStockDesc.KeyDown += new System.Windows.Forms.KeyEventHandler(this.nextfieldenter1);
            this.txtStockDesc.Validating += new System.ComponentModel.CancelEventHandler(this.txtStockDesc_Validating);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(17, 105);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(137, 19);
            this.label2.TabIndex = 6;
            this.label2.Text = "Product Description :";
            // 
            // cboCatCode
            // 
            this.cboCatCode.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cboCatCode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cboCatCode.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboCatCode.FormattingEnabled = true;
            this.cboCatCode.Location = new System.Drawing.Point(21, 245);
            this.cboCatCode.Name = "cboCatCode";
            this.cboCatCode.Size = new System.Drawing.Size(407, 27);
            this.cboCatCode.TabIndex = 4;
            this.cboCatCode.KeyDown += new System.Windows.Forms.KeyEventHandler(this.nextfieldenter2);
            this.cboCatCode.Validating += new System.ComponentModel.CancelEventHandler(this.cboCatCode_Validating);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(17, 225);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 19);
            this.label3.TabIndex = 9;
            this.label3.Text = "Category :";
            // 
            // cboSupplierCode
            // 
            this.cboSupplierCode.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cboSupplierCode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cboSupplierCode.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboSupplierCode.FormattingEnabled = true;
            this.cboSupplierCode.Location = new System.Drawing.Point(21, 305);
            this.cboSupplierCode.Name = "cboSupplierCode";
            this.cboSupplierCode.Size = new System.Drawing.Size(407, 27);
            this.cboSupplierCode.TabIndex = 5;
            this.cboSupplierCode.KeyDown += new System.Windows.Forms.KeyEventHandler(this.nextfieldenter2);
            this.cboSupplierCode.Validating += new System.ComponentModel.CancelEventHandler(this.cboSupplierCode_Validating);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(17, 283);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(66, 19);
            this.label4.TabIndex = 11;
            this.label4.Text = "Supplier :";
            // 
            // txtUCost
            // 
            this.txtUCost.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUCost.Location = new System.Drawing.Point(21, 419);
            this.txtUCost.Name = "txtUCost";
            this.txtUCost.Size = new System.Drawing.Size(133, 26);
            this.txtUCost.TabIndex = 7;
            this.txtUCost.Text = "0.0000";
            this.txtUCost.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtUCost.KeyDown += new System.Windows.Forms.KeyEventHandler(this.nextfieldenter1);
            this.txtUCost.Validating += new System.ComponentModel.CancelEventHandler(this.txtUCost_Validating);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(17, 397);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(74, 19);
            this.label10.TabIndex = 18;
            this.label10.Text = "Unit Cost :";
            // 
            // txtReorderPoint
            // 
            this.txtReorderPoint.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtReorderPoint.Location = new System.Drawing.Point(21, 478);
            this.txtReorderPoint.Name = "txtReorderPoint";
            this.txtReorderPoint.Size = new System.Drawing.Size(133, 26);
            this.txtReorderPoint.TabIndex = 9;
            this.txtReorderPoint.Text = "0";
            this.txtReorderPoint.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtReorderPoint.KeyDown += new System.Windows.Forms.KeyEventHandler(this.nextfieldenter1);
            this.txtReorderPoint.Validating += new System.ComponentModel.CancelEventHandler(this.txtReorderPoint_Validating);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(17, 457);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(101, 19);
            this.label7.TabIndex = 24;
            this.label7.Text = "Reorder Point :";
            // 
            // txtMaintainingBal
            // 
            this.txtMaintainingBal.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaintainingBal.Location = new System.Drawing.Point(284, 478);
            this.txtMaintainingBal.Name = "txtMaintainingBal";
            this.txtMaintainingBal.Size = new System.Drawing.Size(144, 26);
            this.txtMaintainingBal.TabIndex = 10;
            this.txtMaintainingBal.Text = "0";
            this.txtMaintainingBal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtMaintainingBal.KeyDown += new System.Windows.Forms.KeyEventHandler(this.nextfieldenter1);
            this.txtMaintainingBal.Validating += new System.ComponentModel.CancelEventHandler(this.txtMaintainingBal_Validating);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(280, 457);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(137, 19);
            this.label8.TabIndex = 26;
            this.label8.Text = "Maintaining Balance :";
            // 
            // txtSP
            // 
            this.txtSP.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSP.Location = new System.Drawing.Point(284, 419);
            this.txtSP.Name = "txtSP";
            this.txtSP.Size = new System.Drawing.Size(144, 26);
            this.txtSP.TabIndex = 8;
            this.txtSP.Text = "0.00";
            this.txtSP.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtSP.KeyDown += new System.Windows.Forms.KeyEventHandler(this.nextfieldenter1);
            this.txtSP.Validating += new System.ComponentModel.CancelEventHandler(this.txtSP_Validating);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(280, 397);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(90, 19);
            this.label13.TabIndex = 34;
            this.label13.Text = "Selling Price :";
            // 
            // btnCancel
            // 
            this.btnCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel.Location = new System.Drawing.Point(353, 534);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 35);
            this.btnCancel.TabIndex = 13;
            this.btnCancel.Text = "&Close";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSave
            // 
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(272, 534);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 35);
            this.btnSave.TabIndex = 12;
            this.btnSave.Text = "&Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // txtUM
            // 
            this.txtUM.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUM.Location = new System.Drawing.Point(21, 186);
            this.txtUM.Name = "txtUM";
            this.txtUM.Size = new System.Drawing.Size(179, 26);
            this.txtUM.TabIndex = 2;
            this.txtUM.KeyDown += new System.Windows.Forms.KeyEventHandler(this.nextfieldenter1);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(17, 164);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(114, 19);
            this.label16.TabIndex = 40;
            this.label16.Text = "Unit of Measure :";
            // 
            // txtSize
            // 
            this.txtSize.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSize.Location = new System.Drawing.Point(227, 186);
            this.txtSize.Name = "txtSize";
            this.txtSize.Size = new System.Drawing.Size(201, 26);
            this.txtSize.TabIndex = 3;
            this.txtSize.Text = "NA";
            this.txtSize.KeyDown += new System.Windows.Forms.KeyEventHandler(this.nextfieldenter1);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(227, 164);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(37, 19);
            this.label5.TabIndex = 42;
            this.label5.Text = "Size:";
            // 
            // cboInvClassCode
            // 
            this.cboInvClassCode.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cboInvClassCode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cboInvClassCode.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboInvClassCode.FormattingEnabled = true;
            this.cboInvClassCode.Location = new System.Drawing.Point(24, 362);
            this.cboInvClassCode.Name = "cboInvClassCode";
            this.cboInvClassCode.Size = new System.Drawing.Size(407, 27);
            this.cboInvClassCode.TabIndex = 6;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(20, 340);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(149, 19);
            this.label6.TabIndex = 44;
            this.label6.Text = "Inventory Classification";
            // 
            // frmEntryProductAdd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(450, 580);
            this.Controls.Add(this.cboInvClassCode);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtSize);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtUM);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.txtSP);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.txtMaintainingBal);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtReorderPoint);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtUCost);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.cboSupplierCode);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cboCatCode);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtStockCode);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtStockDesc);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtStockNumber);
            this.Name = "frmEntryProductAdd";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Product - Add";
            this.Load += new System.EventHandler(this.frmProductAdd_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtStockNumber;
        private System.Windows.Forms.TextBox txtStockCode;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtStockDesc;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cboCatCode;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cboSupplierCode;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtUCost;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtReorderPoint;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtMaintainingBal;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtSP;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.TextBox txtUM;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtSize;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cboInvClassCode;
        private System.Windows.Forms.Label label6;
    }
}