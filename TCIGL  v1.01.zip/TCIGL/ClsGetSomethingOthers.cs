﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;

namespace TCIGL
{
    class ClsGetSomethingOthers
    {
        public string plsTableDoor, plsVoidIC;
        SqlConnection myconnection;
        SqlDataReader dr;
        SqlCommand mycommand;
        ClsGetConnection ClsGetConnection1 = new ClsGetConnection();
        ClsDefaultBranch ClsDefaultBranch1 = new ClsDefaultBranch();

        public void ClsGetTDoor(string varstrVoucher)
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = new SqlCommand("Select TableDoor FROM tblTDoor WHERE Voucher='"+varstrVoucher+"'", myconnection);
                dr = mycommand.ExecuteReader();
                while (dr.Read())
                {
                    plsTableDoor = dr["TableDoor"].ToString();
                }
                dr.Close();
                myconnection.Close();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                //dr.Close();
                myconnection.Close();
            }
        }

        public void ClsOneTheDoor(string varstrVoucher)
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();

                string sqlstatement;
                sqlstatement = "UPDATE tblTDoor SET TableDoor=@_TableDoor WHERE Voucher ='"+varstrVoucher+"'";
                mycommand = new SqlCommand(sqlstatement, myconnection);
                mycommand.Parameters.Add("_TableDoor", SqlDbType.Int).Value = 1;
                int n1 = mycommand.ExecuteNonQuery();
                myconnection.Close();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                //dr.Close();
                myconnection.Close();
            }
        }

        public void ClsZeroTheDoor(string varstrVoucher)
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();

                string sqlstatement;
                sqlstatement = "UPDATE tblTDoor SET TableDoor=@_TableDoor WHERE Voucher ='" + varstrVoucher + "'";
                mycommand = new SqlCommand(sqlstatement, myconnection);
                mycommand.Parameters.Add("_TableDoor", SqlDbType.Int).Value = 0;
                int n1 = mycommand.ExecuteNonQuery();
                myconnection.Close();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                myconnection.Close();
            }
        }

        public void ClsDeleteErrorTransaction(string varstrVoucher, string strTransactType)
        {
            try
            {
                if (strTransactType == "1")
                {
                    ClsGetConnection1.ClsGetConMSSQL();
                    myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                    myconnection.Open();

                    SqlCommand mycommand = new SqlCommand("usp_DelVoid", myconnection);
                    mycommand.CommandType = CommandType.StoredProcedure;

                    mycommand.Parameters.Add("@ParamVoucher", SqlDbType.VarChar).Value = varstrVoucher;
                    mycommand.Parameters.Add("@ParamUserCode", SqlDbType.VarChar).Value = Form1.glbluc.Text;
                    mycommand.Parameters.Add("@ParamCNCode", SqlDbType.VarChar).Value = ClsDefaultBranch1.plsvardb;

                    int n1 = mycommand.ExecuteNonQuery();
                    myconnection.Close();
                }
                else if (strTransactType == "2")
                {
                    ClsGetConnection1.ClsGetConMSSQL();
                    myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                    myconnection.Open();

                    SqlCommand mycommand = new SqlCommand("usp_DelVoidPO", myconnection);
                    mycommand.CommandType = CommandType.StoredProcedure;

                    mycommand.Parameters.Add("@ParamVoucher", SqlDbType.VarChar).Value = varstrVoucher;
                    mycommand.Parameters.Add("@ParamUserCode", SqlDbType.VarChar).Value = Form1.glbluc.Text;
                    mycommand.Parameters.Add("@ParamCNCode", SqlDbType.VarChar).Value = ClsDefaultBranch1.plsvardb;

                    int n1 = mycommand.ExecuteNonQuery();
                    myconnection.Close();
                }

                else if (strTransactType == "3")
                {
                    ClsGetConnection1.ClsGetConMSSQL();
                    myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                    myconnection.Open();

                    SqlCommand mycommand = new SqlCommand("usp_DelVoidSO", myconnection);
                    mycommand.CommandType = CommandType.StoredProcedure;

                    mycommand.Parameters.Add("@ParamVoucher", SqlDbType.VarChar).Value = varstrVoucher;
                    mycommand.Parameters.Add("@ParamUserCode", SqlDbType.VarChar).Value = Form1.glbluc.Text;
                    mycommand.Parameters.Add("@ParamCNCode", SqlDbType.VarChar).Value = ClsDefaultBranch1.plsvardb;

                    int n1 = mycommand.ExecuteNonQuery();
                    myconnection.Close();
                }

                else if (strTransactType == "4")
                {
                    ClsGetConnection1.ClsGetConMSSQL();
                    myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                    myconnection.Open();

                    SqlCommand mycommand = new SqlCommand("usp_DelVoidAI", myconnection);
                    mycommand.CommandType = CommandType.StoredProcedure;

                    mycommand.Parameters.Add("@ParamVoucher", SqlDbType.VarChar).Value = varstrVoucher;
                    mycommand.Parameters.Add("@ParamUserCode", SqlDbType.VarChar).Value = Form1.glbluc.Text;
                    mycommand.Parameters.Add("@ParamCNCode", SqlDbType.VarChar).Value = ClsDefaultBranch1.plsvardb;

                    int n1 = mycommand.ExecuteNonQuery();
                    myconnection.Close();
                }
                else if (strTransactType == "5")
                {
                    ClsGetConnection1.ClsGetConMSSQL();
                    myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                    myconnection.Open();

                    SqlCommand mycommand = new SqlCommand("usp_DelVoidPI", myconnection);
                    mycommand.CommandType = CommandType.StoredProcedure;

                    mycommand.Parameters.Add("@ParamVoucher", SqlDbType.VarChar).Value = varstrVoucher;
                    mycommand.Parameters.Add("@ParamUserCode", SqlDbType.VarChar).Value = Form1.glbluc.Text;
                    mycommand.Parameters.Add("@ParamCNCode", SqlDbType.VarChar).Value = ClsDefaultBranch1.plsvardb;

                    int n1 = mycommand.ExecuteNonQuery();
                    myconnection.Close();
                }
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                myconnection.Close();
            }
        }
        public void ClsFinalize(string varstrVoucher, string varstrDocNum, string strTransactType)
        {
            try
            {
                if (strTransactType == "1")
                {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();

                string sqlstatement;
                sqlstatement = "UPDATE ViewOnlineEditNumber SET IC=@_IC, DocNum=@_DocNum, Void=@_Void WHERE Voucher ='" + varstrVoucher + "' AND DocNum='" + Form1.glbluc.Text + "' AND CNCode='" + ClsDefaultBranch1.plsvardb + "'";

                    //sqlstatement = "UPDATE tblMain1 SET IC=@_IC, DocNum=@_DocNum, Void=@_Void WHERE Voucher ='" + varstrVoucher + "' AND DocNum='" + Form1.glbluc.Text + "'";
                mycommand = new SqlCommand(sqlstatement, myconnection);
                mycommand.Parameters.Add("_IC", SqlDbType.VarChar).Value = varstrVoucher + varstrDocNum + ClsDefaultBranch1.plsvardb;
                mycommand.Parameters.Add("_DocNum", SqlDbType.VarChar).Value = varstrDocNum;
                mycommand.Parameters.Add("_Void", SqlDbType.Bit).Value = 0;
                int n1 = mycommand.ExecuteNonQuery();
                myconnection.Close();
                }
                else if (strTransactType == "2")
                {
                    ClsGetConnection1.ClsGetConMSSQL();
                    myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                    myconnection.Open();

                    string sqlstatement;
                    sqlstatement = "UPDATE ViewOnlineEditNumberPO SET IC=@_IC, DocNum=@_DocNum, Void=@_Void WHERE Voucher ='" + varstrVoucher + "' AND DocNum='" + Form1.glbluc.Text + "' AND CNCode='" + ClsDefaultBranch1.plsvardb + "'";
                    mycommand = new SqlCommand(sqlstatement, myconnection);
                    mycommand.Parameters.Add("_IC", SqlDbType.VarChar).Value = varstrVoucher + varstrDocNum + ClsDefaultBranch1.plsvardb;
                    mycommand.Parameters.Add("_DocNum", SqlDbType.VarChar).Value = varstrDocNum;
                    mycommand.Parameters.Add("_Void", SqlDbType.Bit).Value = 0;
                    int n1 = mycommand.ExecuteNonQuery();
                    myconnection.Close();
                }
                else if (strTransactType == "3")
                {
                    ClsGetConnection1.ClsGetConMSSQL();
                    myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                    myconnection.Open();

                    string sqlstatement;
                    sqlstatement = "UPDATE ViewOnlineEditNumberSO SET IC=@_IC, DocNum=@_DocNum, Void=@_Void WHERE Voucher ='" + varstrVoucher + "' AND DocNum='" + Form1.glbluc.Text + "' AND CNCode='" + ClsDefaultBranch1.plsvardb + "'";
                    mycommand = new SqlCommand(sqlstatement, myconnection);
                    mycommand.Parameters.Add("_IC", SqlDbType.VarChar).Value = varstrVoucher + varstrDocNum + ClsDefaultBranch1.plsvardb;
                    mycommand.Parameters.Add("_DocNum", SqlDbType.VarChar).Value = varstrDocNum;
                    mycommand.Parameters.Add("_Void", SqlDbType.Bit).Value = 0;
                    int n1 = mycommand.ExecuteNonQuery();
                    myconnection.Close();
                }
                else if (strTransactType == "4")
                {
                    ClsGetConnection1.ClsGetConMSSQL();
                    myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                    myconnection.Open();

                    string sqlstatement;
                    sqlstatement = "UPDATE ViewOnlineEditNumberAI SET IC=@_IC, DocNum=@_DocNum, Void=@_Void WHERE Voucher ='" + varstrVoucher + "' AND DocNum='" + Form1.glbluc.Text + "' AND CNCode='" + ClsDefaultBranch1.plsvardb + "'";
                    mycommand = new SqlCommand(sqlstatement, myconnection);
                    mycommand.Parameters.Add("_IC", SqlDbType.VarChar).Value = varstrVoucher + varstrDocNum + ClsDefaultBranch1.plsvardb;
                    mycommand.Parameters.Add("_DocNum", SqlDbType.VarChar).Value = varstrDocNum;
                    mycommand.Parameters.Add("_Void", SqlDbType.Bit).Value = 0;
                    int n1 = mycommand.ExecuteNonQuery();
                    myconnection.Close();
                }
                else if (strTransactType == "5")
                {
                    ClsGetConnection1.ClsGetConMSSQL();
                    myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                    myconnection.Open();

                    string sqlstatement;
                    sqlstatement = "UPDATE ViewOnlineEditNumberPI SET IC=@_IC, DocNum=@_DocNum, Void=@_Void WHERE Voucher ='" + varstrVoucher + "' AND DocNum='" + Form1.glbluc.Text + "' AND CNCode='" + ClsDefaultBranch1.plsvardb + "'";
                    mycommand = new SqlCommand(sqlstatement, myconnection);
                    mycommand.Parameters.Add("_IC", SqlDbType.VarChar).Value = varstrVoucher + varstrDocNum + ClsDefaultBranch1.plsvardb;
                    mycommand.Parameters.Add("_DocNum", SqlDbType.VarChar).Value = varstrDocNum;
                    mycommand.Parameters.Add("_Void", SqlDbType.Bit).Value = 0;
                    int n1 = mycommand.ExecuteNonQuery();
                    myconnection.Close();
                }
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                //dr.Close();
                myconnection.Close();
            }
        }

        public void ClsGetVoidRef(string varstrVoucher, string strTransactType)
        {
            try
            {
                if (strTransactType == "1")
                {
                    ClsGetConnection1.ClsGetConMSSQL();
                    myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                    myconnection.Open();
                    mycommand = new SqlCommand("Select IC FROM tblMain1 WHERE IC='" + varstrVoucher + "'+'" + Form1.glbluc.Text + "'+'" + (ClsDefaultBranch1.plsvardb) + "'", myconnection);
                    dr = mycommand.ExecuteReader();
                    while (dr.Read())
                    {
                        plsVoidIC = dr["IC"].ToString();
                    }
                    dr.Close();
                    myconnection.Close();
                }
                else if (strTransactType == "2")
                {
                    ClsGetConnection1.ClsGetConMSSQL();
                    myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                    myconnection.Open();
                    mycommand = new SqlCommand("Select IC FROM tblPO1 WHERE IC='" + varstrVoucher + "'+'" + Form1.glbluc.Text + "'+'" + (ClsDefaultBranch1.plsvardb) + "'", myconnection);
                    dr = mycommand.ExecuteReader();
                    while (dr.Read())
                    {
                        plsVoidIC = dr["IC"].ToString();
                    }
                    dr.Close();
                    myconnection.Close();
                }
                else if (strTransactType == "3")
                {
                    ClsGetConnection1.ClsGetConMSSQL();
                    myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                    myconnection.Open();
                    mycommand = new SqlCommand("Select IC FROM tblMain6 WHERE IC='" + varstrVoucher + "'+'" + Form1.glbluc.Text + "'+'" + (ClsDefaultBranch1.plsvardb) + "'", myconnection);
                    dr = mycommand.ExecuteReader();
                    while (dr.Read())
                    {
                        plsVoidIC = dr["IC"].ToString();
                    }
                    dr.Close();
                    myconnection.Close();
                }
                else if (strTransactType == "4")
                {
                    ClsGetConnection1.ClsGetConMSSQL();
                    myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                    myconnection.Open();
                    mycommand = new SqlCommand("Select IC FROM tblMain4 WHERE IC='" + varstrVoucher + "'+'" + Form1.glbluc.Text + "'+'" + (ClsDefaultBranch1.plsvardb) + "'", myconnection);
                    dr = mycommand.ExecuteReader();
                    while (dr.Read())
                    {
                        plsVoidIC = dr["IC"].ToString();
                    }
                    dr.Close();
                    myconnection.Close();
                }
                else if (strTransactType == "5")
                {
                    ClsGetConnection1.ClsGetConMSSQL();
                    myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                    myconnection.Open();
                    mycommand = new SqlCommand("Select IC FROM tblPI1 WHERE IC='" + varstrVoucher + "'+'" + Form1.glbluc.Text + "'+'" + (ClsDefaultBranch1.plsvardb) + "'", myconnection);
                    dr = mycommand.ExecuteReader();
                    while (dr.Read())
                    {
                        plsVoidIC = dr["IC"].ToString();
                    }
                    dr.Close();
                    myconnection.Close();
                }
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                //dr.Close();
                myconnection.Close();
            }
        }
    }
}
