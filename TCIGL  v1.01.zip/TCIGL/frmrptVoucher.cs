﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using CrystalDecisions.CrystalReports.Engine;
using System.Data.SqlClient;

namespace TCIGL
{
    public partial class frmrptVoucher : Form
    {
        private SqlConnection myconnection; ClsGetConnection ClsGetConnection1 = new ClsGetConnection();
        SqlCommand mycommand;
        BindingSource dbind = new BindingSource();
        SqlDataReader dr;
        SqlDataReader SqlDataReader1;
        ClsBuildComboBox ClsBuildComboBox1 = new ClsBuildComboBox();
        ClsDefaultBranch ClsDefaultBranch1 = new ClsDefaultBranch();
        ClsCompName ClsCompName1 = new ClsCompName();
        ClsAutoNumber ClsAutoNumber1 = new ClsAutoNumber();
        ClsPermission ClsPermission1 = new ClsPermission();
        string CheckAmt, AmtInWords;
        string strchoose = "1";
        public frmrptVoucher()
        {
            InitializeComponent();

            cbortprint.DisplayMember = "Text";
            cbortprint.ValueMember = "Value";

            var items = new[]
            { 
             new { Text = "Accounts Payable Voucher", Value = "01" }, 
             new { Text = "Accounts Receivable Voucher", Value = "02" }, 
             new { Text = "Check Voucher", Value = "03" }, 
             new { Text = "Official Receipts", Value = "04" }, 
             new { Text = "Remittance Voucher", Value = "05" }, 
             new { Text = "Journal Voucher", Value = "06" }, 
             new { Text = "Purchase Order", Value = "07" }, 
             new { Text = "Purchase Delivery", Value = "08" }, 
             new { Text = "Purchase Delivery - Accounting Entry", Value = "22" }, 
             new { Text = "Return to Supplier", Value = "09" }, 
             new { Text = "Return to Supplier - Accounting Entry", Value = "25" }, 
             new { Text = "Charge Invoice", Value = "10" }, 
             new { Text = "Charge Invoice - Accounting Entry", Value = "21" },
             new { Text = "Cash Sales", Value = "11" },
             new { Text = "Cash Sales - Accounting Entry", Value = "23" }, 
             new { Text = "Return Slip", Value = "12" }, 
             new { Text = "Return Slip - Accounting Entry", Value = "24" }, 
             new { Text = "Transfer Slip", Value = "13" },          
             new { Text = "Adjustment Slip", Value = "14" }, 
             new { Text = "Adjustment Slip - Accounting Entry", Value = "20" }, 
             new { Text = "Withdrawal Slip", Value = "15" }, 
             new { Text = "Withdrawal Slip - Accounting Entry", Value = "26" },
             new { Text = "WS - Office Supplies", Value = "29" }, 
             new { Text = "WS - Office Supplies - Accounting Entry", Value = "30" }, 
             new { Text = "Production Slip", Value = "16" }, 
             new { Text = "Production Slip - Accounting Entry", Value = "27" }, 
             new { Text = "Actual Inventory", Value = "17" }, 
             new { Text = "Cash Receipt Voucher", Value = "18" },
             new { Text = "Proforma Invoice", Value = "19" },
             new { Text = "Job Order", Value = "28" },
            };
            cbortprint.DataSource = items;
        }

        private void frmrptVoucher1_Load(object sender, EventArgs e)
        {
            ClsPermission1.ClsObjects(this.Text);
            if (new ClsValidation().emptytxt(ClsPermission1.plstxtObject))
            {
                MessageBox.Show("You do not have necessary permission to open this file", "GL");
                this.Close();
            }
            else
            {
                buildcboCNCode();
                cboCNCode.SelectedValue = (ClsDefaultBranch1.plsvardb);
                this.WindowState = FormWindowState.Maximized;
            }
        }

        private void buildcboCNCode()
        {
            cboCNCode.DataSource = null;
            ClsBuildComboBox1.ARBranch.Clear();
            ClsBuildComboBox1.ClsBuildBranch();
            this.cboCNCode.DataSource = (ClsBuildComboBox1.ARBranch);
            this.cboCNCode.DisplayMember = "Display";
            this.cboCNCode.ValueMember = "Value";
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void prevprint()
        {
            if (new ClsValidation().emptytxt(txtDocNum.Text))
            {
                MessageBox.Show("Please complete your entry", "GL");
                txtDocNum.Focus();
            }
            else if (new ClsValidation().emptytxt(cbortprint.Text))
            {
                MessageBox.Show("Please complete your entry", "GL");
                cbortprint.Focus();
            }
            else
            {
                if (cbortprint.SelectedValue.ToString() == "01") //"Accounts Payable Voucher"
                {
                    prevAPV();
                }
                else if (cbortprint.SelectedValue.ToString() == "02") //"Accounts Receivable Voucher")
                {
                    prevARV();
                }
                else if (cbortprint.SelectedValue.ToString() == "03")//"Check Voucher"
                {
                    prevCV();
                }
                else if (cbortprint.SelectedValue.ToString() == "04")//"Official Receipts"
                {
                    prevOR();
                }
                else if (cbortprint.SelectedValue.ToString() == "05")//"Remittance Voucher"
                {
                    prevRV();
                }
                else if (cbortprint.SelectedValue.ToString() =="06")// "Journal Voucher"
                {
                    prevJV();
                }
                else if (cbortprint.SelectedValue.ToString() =="07")// "Purchase Order")
                {
                    prevPO();
                }
                else if (cbortprint.SelectedValue.ToString() == "08")//"Purchase Delivery"
                {
                    prevPD();
                }
                else if (cbortprint.SelectedValue.ToString() == "09")//"Return to Supplier")
                {
                    prevRTS();
                }
                else if (cbortprint.SelectedValue.ToString() == "10")//"Charge Invoice"
                {
                    prevCI();
                }
                else if (cbortprint.SelectedValue.ToString() == "11")//"Cash Sales"
                {
                    prevCS();
                }
                else if (cbortprint.SelectedValue.ToString() == "12")//"Return Slip"
                {
                    prevRS();
                }
                else if (cbortprint.SelectedValue.ToString() == "13")//"Transfer Slip"
                {
                    prevTS();
                }
                else if (cbortprint.SelectedValue.ToString() == "14") //"Adjustment Slip"
                {
                    prevAS();
                }
                else if (cbortprint.SelectedValue.ToString() == "15")//"Withdrawal Slip"
                {
                    prevWS();
                }
                else if (cbortprint.SelectedValue.ToString() == "16") //"Production Slip"
                {
                    prevPS();
                }
                else if (cbortprint.SelectedValue.ToString() == "17") //"Actual Inventory"
                {
                    prevAI();
                }
                else if (cbortprint.SelectedValue.ToString() == "18") //"Cash Receipt Voucher"
                {
                    prevCRV();
                }
                else if (cbortprint.SelectedValue.ToString() == "19") //"Proforma Invoice"
                {
                    prevPI();
                }
                else if (cbortprint.SelectedValue.ToString() == "20") //"Adjustment Slip - Accounting Entry"
                {
                    prevASAE();
                }
                else if (cbortprint.SelectedValue.ToString() == "21") //"Charge Invoice - Accounting Entry"
                {
                    prevCIAE();
                }
                else if (cbortprint.SelectedValue.ToString() == "22") //"Purchase Delivery - Accounting Entry"
                {
                    prevPDAE(); 
                }
                else if (cbortprint.SelectedValue.ToString() == "23") //"Cash Sales - Accounting Entry"
                {
                    prevCSAE();
                }
                else if (cbortprint.SelectedValue.ToString() == "24") //"Return Slip - Accounting Entry"
                {
                    prevRSAE();
                }
                else if (cbortprint.SelectedValue.ToString() == "25") //"Return to Supplier - Accounting Entry"
                {
                    prevRSTAE();
                }

                else if (cbortprint.SelectedValue.ToString() == "26") //"Withdrawal Slip - Accounting Entry"
                {
                    prevWSAE();
                }
                else if (cbortprint.SelectedValue.ToString() == "27") //"Production Slip - Accounting Entry"
                {
                    prevPSAE();
                }
                else if (cbortprint.SelectedValue.ToString() == "28") //"Job Order"
                {
                    prevJO();
                }
                else if (cbortprint.SelectedValue.ToString() == "29") //"Office Supplies"
                {
                    preOS();
                }
                else if (cbortprint.SelectedValue.ToString() == "30") //"Withdrawal Slip - Office Supplies - Accounting Entry"
                {
                    prevOSAE();
                }

            }
        }

        private void btnPreview_Click(object sender, EventArgs e)
        {
            strchoose = "1";
            prevprint();
        }

        private void prevAPV()
        {
            string sqlstatement = "SELECT * FROM viewbookapv WHERE DocNum ='" + txtDocNum.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "'";
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();
            mycommand = myconnection.CreateCommand();
            mycommand.CommandText = sqlstatement;
            mycommand.CommandTimeout = 900;
            SqlDataReader1 = mycommand.ExecuteReader();
            DataTable DataTable1 = new DataTable();
            DataTable1.Load(SqlDataReader1);
            myconnection.Close();

            if (DataTable1.Rows.Count == 0)
            {
                MessageBox.Show("No data found", "GL");
                return;
            }


            CRprevapv objRpt = new CRprevapv();
            TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            ClsCompName1.ClsCompNameMain();
            vartxtcompany.Text = ClsCompName1.varcn;

            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            ClsCompName1.ClsCompNamebranchAddress(Form1.glbltxtCNCode.Text);
            vartxtaddress.Text = ClsCompName1.plsCRaddress;


            objRpt.SetDataSource(DataTable1);
            //crystalReportViewer1.ReportSource = objRpt;
            //crystalReportViewer1.Refresh();

            System.Drawing.Printing.PrintDocument doctoprint = new System.Drawing.Printing.PrintDocument();
            //  doctoprint.PrinterSettings.PrinterName = "EPSON LX-300+ /II";
            int rawKind = 0;
            for (int i = 0; i <= doctoprint.PrinterSettings.PaperSizes.Count - 1; i++)
            {
                if (doctoprint.PrinterSettings.PaperSizes[i].PaperName == "C1-HalfShort")
                {
                    rawKind = Convert.ToInt32(doctoprint.PrinterSettings.PaperSizes[i].GetType().GetField("kind",
                    System.Reflection.BindingFlags.Instance |
                    System.Reflection.BindingFlags.NonPublic).GetValue(doctoprint.PrinterSettings.PaperSizes[i]));
                    break; // TODO: might not be correct. Was : Exit For
                }
            }
            objRpt.PrintOptions.PaperSize = (CrystalDecisions.Shared.PaperSize)rawKind;
            //CrystalDecisions.Shared.PageMargins pMargin = new CrystalDecisions.Shared.PageMargins(0, 0, 0, 0);
            //objRpt.PrintOptions.ApplyPageMargins(pMargin);
            if (strchoose == "1")
            {
                crystalReportViewer1.ReportSource = objRpt;
            }
            else
            {
                objRpt.Refresh();
                objRpt.PrintToPrinter(1, false, 0, 0);
            }

        }
        private void prevJO()
        {
            string sqlstatement = "SELECT * FROM ViewBookPI WHERE DocNum ='" + txtDocNum.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "'";
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();
            mycommand = myconnection.CreateCommand();
            mycommand.CommandText = sqlstatement;
            mycommand.CommandTimeout = 900;
            SqlDataReader1 = mycommand.ExecuteReader();
            DataTable DataTable1 = new DataTable();
            DataTable1.Load(SqlDataReader1);
            myconnection.Close();

            if (DataTable1.Rows.Count == 0)
            {
                MessageBox.Show("No data found", "GL");
                return;
            }


            CRprevJO objRpt = new CRprevJO();
            TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            ClsCompName1.ClsCompNameMain();
            vartxtcompany.Text = ClsCompName1.varcn;

            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            ClsCompName1.ClsCompNamebranchAddress(Form1.glbltxtCNCode.Text);
            vartxtaddress.Text = ClsCompName1.plsCRaddress;

            objRpt.SetDataSource(DataTable1);
            //crystalReportViewer1.ReportSource = objRpt;
            //crystalReportViewer1.Refresh();

            System.Drawing.Printing.PrintDocument doctoprint = new System.Drawing.Printing.PrintDocument();
            //  doctoprint.PrinterSettings.PrinterName = "EPSON LX-300+ /II";
            int rawKind = 0;
            for (int i = 0; i <= doctoprint.PrinterSettings.PaperSizes.Count - 1; i++)
            {
                if (doctoprint.PrinterSettings.PaperSizes[i].PaperName == "C1-HalfShort")
                {
                    rawKind = Convert.ToInt32(doctoprint.PrinterSettings.PaperSizes[i].GetType().GetField("kind",
                    System.Reflection.BindingFlags.Instance |
                    System.Reflection.BindingFlags.NonPublic).GetValue(doctoprint.PrinterSettings.PaperSizes[i]));
                    break; // TODO: might not be correct. Was : Exit For
                }
            }
            objRpt.PrintOptions.PaperSize = (CrystalDecisions.Shared.PaperSize)rawKind;
            //CrystalDecisions.Shared.PageMargins pMargin = new CrystalDecisions.Shared.PageMargins(0, 0, 0, 0);
            //objRpt.PrintOptions.ApplyPageMargins(pMargin);
            if (strchoose == "1")
            {
                crystalReportViewer1.ReportSource = objRpt;
            }
            else
            {
                objRpt.Refresh();
                objRpt.PrintToPrinter(1, false, 0, 0);
            }

        }
        private void prevPSAE()
        {
            string sqlstatement = "SELECT * FROM ViewBookPS WHERE DocNum ='" + txtDocNum.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "'";
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();
            mycommand = myconnection.CreateCommand();
            mycommand.CommandText = sqlstatement;
            mycommand.CommandTimeout = 900;
            SqlDataReader1 = mycommand.ExecuteReader();
            DataTable DataTable1 = new DataTable();
            DataTable1.Load(SqlDataReader1);
            myconnection.Close();

            if (DataTable1.Rows.Count == 0)
            {
                MessageBox.Show("No data found", "GL");
                return;
            }


            CRPrevPSAE objRpt = new CRPrevPSAE();
            TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            ClsCompName1.ClsCompNameMain();
            vartxtcompany.Text = ClsCompName1.varcn;

            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            ClsCompName1.ClsCompNamebranchAddress(Form1.glbltxtCNCode.Text);
            vartxtaddress.Text = ClsCompName1.plsCRaddress;


            objRpt.SetDataSource(DataTable1);
            //crystalReportViewer1.ReportSource = objRpt;
            //crystalReportViewer1.Refresh();

            System.Drawing.Printing.PrintDocument doctoprint = new System.Drawing.Printing.PrintDocument();
            //  doctoprint.PrinterSettings.PrinterName = "EPSON LX-300+ /II";
            int rawKind = 0;
            for (int i = 0; i <= doctoprint.PrinterSettings.PaperSizes.Count - 1; i++)
            {
                if (doctoprint.PrinterSettings.PaperSizes[i].PaperName == "C1-HalfShort")
                {
                    rawKind = Convert.ToInt32(doctoprint.PrinterSettings.PaperSizes[i].GetType().GetField("kind",
                    System.Reflection.BindingFlags.Instance |
                    System.Reflection.BindingFlags.NonPublic).GetValue(doctoprint.PrinterSettings.PaperSizes[i]));
                    break; // TODO: might not be correct. Was : Exit For
                }
            }
            objRpt.PrintOptions.PaperSize = (CrystalDecisions.Shared.PaperSize)rawKind;
            //CrystalDecisions.Shared.PageMargins pMargin = new CrystalDecisions.Shared.PageMargins(0, 0, 0, 0);
            //objRpt.PrintOptions.ApplyPageMargins(pMargin);
            if (strchoose == "1")
            {
                crystalReportViewer1.ReportSource = objRpt;
            }
            else
            {
                objRpt.Refresh();
                objRpt.PrintToPrinter(1, false, 0, 0);
            }

        }

        private void prevWSAE()
        {
            string sqlstatement = "SELECT * FROM ViewBookWS WHERE DocNum ='" + txtDocNum.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "'";
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();
            mycommand = myconnection.CreateCommand();
            mycommand.CommandText = sqlstatement;
            mycommand.CommandTimeout = 900;
            SqlDataReader1 = mycommand.ExecuteReader();
            DataTable DataTable1 = new DataTable();
            DataTable1.Load(SqlDataReader1);
            myconnection.Close();

            if (DataTable1.Rows.Count == 0)
            {
                MessageBox.Show("No data found", "GL");
                return;
            }


            CRprevWSAE objRpt = new CRprevWSAE();
            TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            ClsCompName1.ClsCompNameMain();
            vartxtcompany.Text = ClsCompName1.varcn;

            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            ClsCompName1.ClsCompNamebranchAddress(Form1.glbltxtCNCode.Text);
            vartxtaddress.Text = ClsCompName1.plsCRaddress;


            objRpt.SetDataSource(DataTable1);
            //crystalReportViewer1.ReportSource = objRpt;
            //crystalReportViewer1.Refresh();

            System.Drawing.Printing.PrintDocument doctoprint = new System.Drawing.Printing.PrintDocument();
            //  doctoprint.PrinterSettings.PrinterName = "EPSON LX-300+ /II";
            int rawKind = 0;
            for (int i = 0; i <= doctoprint.PrinterSettings.PaperSizes.Count - 1; i++)
            {
                if (doctoprint.PrinterSettings.PaperSizes[i].PaperName == "C1-HalfShort")
                {
                    rawKind = Convert.ToInt32(doctoprint.PrinterSettings.PaperSizes[i].GetType().GetField("kind",
                    System.Reflection.BindingFlags.Instance |
                    System.Reflection.BindingFlags.NonPublic).GetValue(doctoprint.PrinterSettings.PaperSizes[i]));
                    break; // TODO: might not be correct. Was : Exit For
                }
            }
            objRpt.PrintOptions.PaperSize = (CrystalDecisions.Shared.PaperSize)rawKind;
            //CrystalDecisions.Shared.PageMargins pMargin = new CrystalDecisions.Shared.PageMargins(0, 0, 0, 0);
            //objRpt.PrintOptions.ApplyPageMargins(pMargin);
            if (strchoose == "1")
            {
                crystalReportViewer1.ReportSource = objRpt;
            }
            else
            {
                objRpt.Refresh();
                objRpt.PrintToPrinter(1, false, 0, 0);
            }

        }

    
        private void prevRSTAE()
        {
            string sqlstatement = "SELECT * FROM ViewBookRTS WHERE DocNum ='" + txtDocNum.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "'";
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();
            mycommand = myconnection.CreateCommand();
            mycommand.CommandText = sqlstatement;
            mycommand.CommandTimeout = 900;
            SqlDataReader1 = mycommand.ExecuteReader();
            DataTable DataTable1 = new DataTable();
            DataTable1.Load(SqlDataReader1);
            myconnection.Close();

            if (DataTable1.Rows.Count == 0)
            {
                MessageBox.Show("No data found", "GL");
                return;
            }


            CRprevRTSAE objRpt = new CRprevRTSAE();
            TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            ClsCompName1.ClsCompNameMain();
            vartxtcompany.Text = ClsCompName1.varcn;

            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            ClsCompName1.ClsCompNamebranchAddress(Form1.glbltxtCNCode.Text);
            vartxtaddress.Text = ClsCompName1.plsCRaddress;


            objRpt.SetDataSource(DataTable1);
            //crystalReportViewer1.ReportSource = objRpt;
            //crystalReportViewer1.Refresh();

            System.Drawing.Printing.PrintDocument doctoprint = new System.Drawing.Printing.PrintDocument();
            //  doctoprint.PrinterSettings.PrinterName = "EPSON LX-300+ /II";
            int rawKind = 0;
            for (int i = 0; i <= doctoprint.PrinterSettings.PaperSizes.Count - 1; i++)
            {
                if (doctoprint.PrinterSettings.PaperSizes[i].PaperName == "C1-HalfShort")
                {
                    rawKind = Convert.ToInt32(doctoprint.PrinterSettings.PaperSizes[i].GetType().GetField("kind",
                    System.Reflection.BindingFlags.Instance |
                    System.Reflection.BindingFlags.NonPublic).GetValue(doctoprint.PrinterSettings.PaperSizes[i]));
                    break; // TODO: might not be correct. Was : Exit For
                }
            }
            objRpt.PrintOptions.PaperSize = (CrystalDecisions.Shared.PaperSize)rawKind;
            //CrystalDecisions.Shared.PageMargins pMargin = new CrystalDecisions.Shared.PageMargins(0, 0, 0, 0);
            //objRpt.PrintOptions.ApplyPageMargins(pMargin);
            if (strchoose == "1")
            {
                crystalReportViewer1.ReportSource = objRpt;
            }
            else
            {
                objRpt.Refresh();
                objRpt.PrintToPrinter(1, false, 0, 0);
            }

        }

        private void prevRSAE()
        {
            string sqlstatement = "SELECT * FROM ViewBookRS WHERE DocNum ='" + txtDocNum.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "'";
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();
            mycommand = myconnection.CreateCommand();
            mycommand.CommandText = sqlstatement;
            mycommand.CommandTimeout = 900;
            SqlDataReader1 = mycommand.ExecuteReader();
            DataTable DataTable1 = new DataTable();
            DataTable1.Load(SqlDataReader1);
            myconnection.Close();

            if (DataTable1.Rows.Count == 0)
            {
                MessageBox.Show("No data found", "GL");
                return;
            }


            CRPrevRSAE objRpt = new CRPrevRSAE();
            TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            ClsCompName1.ClsCompNameMain();
            vartxtcompany.Text = ClsCompName1.varcn;

            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            ClsCompName1.ClsCompNamebranchAddress(Form1.glbltxtCNCode.Text);
            vartxtaddress.Text = ClsCompName1.plsCRaddress;


            objRpt.SetDataSource(DataTable1);
            //crystalReportViewer1.ReportSource = objRpt;
            //crystalReportViewer1.Refresh();

            System.Drawing.Printing.PrintDocument doctoprint = new System.Drawing.Printing.PrintDocument();
            //  doctoprint.PrinterSettings.PrinterName = "EPSON LX-300+ /II";
            int rawKind = 0;
            for (int i = 0; i <= doctoprint.PrinterSettings.PaperSizes.Count - 1; i++)
            {
                if (doctoprint.PrinterSettings.PaperSizes[i].PaperName == "C1-HalfShort")
                {
                    rawKind = Convert.ToInt32(doctoprint.PrinterSettings.PaperSizes[i].GetType().GetField("kind",
                    System.Reflection.BindingFlags.Instance |
                    System.Reflection.BindingFlags.NonPublic).GetValue(doctoprint.PrinterSettings.PaperSizes[i]));
                    break; // TODO: might not be correct. Was : Exit For
                }
            }
            objRpt.PrintOptions.PaperSize = (CrystalDecisions.Shared.PaperSize)rawKind;
            //CrystalDecisions.Shared.PageMargins pMargin = new CrystalDecisions.Shared.PageMargins(0, 0, 0, 0);
            //objRpt.PrintOptions.ApplyPageMargins(pMargin);
            if (strchoose == "1")
            {
                crystalReportViewer1.ReportSource = objRpt;
            }
            else
            {
                objRpt.Refresh();
                objRpt.PrintToPrinter(1, false, 0, 0);
            }

        }

        private void prevCSAE()
        {
            string sqlstatement = "SELECT * FROM ViewBookCS WHERE DocNum ='" + txtDocNum.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "'";
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();
            mycommand = myconnection.CreateCommand();
            mycommand.CommandText = sqlstatement;
            mycommand.CommandTimeout = 900;
            SqlDataReader1 = mycommand.ExecuteReader();
            DataTable DataTable1 = new DataTable();
            DataTable1.Load(SqlDataReader1);
            myconnection.Close();

            if (DataTable1.Rows.Count == 0)
            {
                MessageBox.Show("No data found", "GL");
                return;
            }


            CRPrevCSAE objRpt = new CRPrevCSAE();
            TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            ClsCompName1.ClsCompNameMain();
            vartxtcompany.Text = ClsCompName1.varcn;

            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            ClsCompName1.ClsCompNamebranchAddress(Form1.glbltxtCNCode.Text);
            vartxtaddress.Text = ClsCompName1.plsCRaddress;


            objRpt.SetDataSource(DataTable1);
            //crystalReportViewer1.ReportSource = objRpt;
            //crystalReportViewer1.Refresh();

            System.Drawing.Printing.PrintDocument doctoprint = new System.Drawing.Printing.PrintDocument();
            //  doctoprint.PrinterSettings.PrinterName = "EPSON LX-300+ /II";
            int rawKind = 0;
            for (int i = 0; i <= doctoprint.PrinterSettings.PaperSizes.Count - 1; i++)
            {
                if (doctoprint.PrinterSettings.PaperSizes[i].PaperName == "C1-HalfShort")
                {
                    rawKind = Convert.ToInt32(doctoprint.PrinterSettings.PaperSizes[i].GetType().GetField("kind",
                    System.Reflection.BindingFlags.Instance |
                    System.Reflection.BindingFlags.NonPublic).GetValue(doctoprint.PrinterSettings.PaperSizes[i]));
                    break; // TODO: might not be correct. Was : Exit For
                }
            }
            objRpt.PrintOptions.PaperSize = (CrystalDecisions.Shared.PaperSize)rawKind;
            //CrystalDecisions.Shared.PageMargins pMargin = new CrystalDecisions.Shared.PageMargins(0, 0, 0, 0);
            //objRpt.PrintOptions.ApplyPageMargins(pMargin);
            if (strchoose == "1")
            {
                crystalReportViewer1.ReportSource = objRpt;
            }
            else
            {
                objRpt.Refresh();
                objRpt.PrintToPrinter(1, false, 0, 0);
            }

        }


        private void prevPDAE()
        {
            string sqlstatement = "SELECT * FROM ViewBookPD WHERE DocNum ='" + txtDocNum.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "'";
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();
            mycommand = myconnection.CreateCommand();
            mycommand.CommandText = sqlstatement;
            mycommand.CommandTimeout = 900;
            SqlDataReader1 = mycommand.ExecuteReader();
            DataTable DataTable1 = new DataTable();
            DataTable1.Load(SqlDataReader1);
            myconnection.Close();

            if (DataTable1.Rows.Count == 0)
            {
                MessageBox.Show("No data found", "GL");
                return;
            }


            CRprevPDAE objRpt = new CRprevPDAE();
            TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            ClsCompName1.ClsCompNameMain();
            vartxtcompany.Text = ClsCompName1.varcn;

            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            ClsCompName1.ClsCompNamebranchAddress(Form1.glbltxtCNCode.Text);
            vartxtaddress.Text = ClsCompName1.plsCRaddress;


            objRpt.SetDataSource(DataTable1);
            //crystalReportViewer1.ReportSource = objRpt;
            //crystalReportViewer1.Refresh();

            System.Drawing.Printing.PrintDocument doctoprint = new System.Drawing.Printing.PrintDocument();
            //  doctoprint.PrinterSettings.PrinterName = "EPSON LX-300+ /II";
            int rawKind = 0;
            for (int i = 0; i <= doctoprint.PrinterSettings.PaperSizes.Count - 1; i++)
            {
                if (doctoprint.PrinterSettings.PaperSizes[i].PaperName == "C1-HalfShort")
                {
                    rawKind = Convert.ToInt32(doctoprint.PrinterSettings.PaperSizes[i].GetType().GetField("kind",
                    System.Reflection.BindingFlags.Instance |
                    System.Reflection.BindingFlags.NonPublic).GetValue(doctoprint.PrinterSettings.PaperSizes[i]));
                    break; // TODO: might not be correct. Was : Exit For
                }
            }
            objRpt.PrintOptions.PaperSize = (CrystalDecisions.Shared.PaperSize)rawKind;
            //CrystalDecisions.Shared.PageMargins pMargin = new CrystalDecisions.Shared.PageMargins(0, 0, 0, 0);
            //objRpt.PrintOptions.ApplyPageMargins(pMargin);
            if (strchoose == "1")
            {
                crystalReportViewer1.ReportSource = objRpt;
            }
            else
            {
                objRpt.Refresh();
                objRpt.PrintToPrinter(1, false, 0, 0);
            }

        }


        private void prevCIAE()
        {
            string sqlstatement = "SELECT * FROM ViewBookCI WHERE DocNum ='" + txtDocNum.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "'";
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();
            mycommand = myconnection.CreateCommand();
            mycommand.CommandText = sqlstatement;
            mycommand.CommandTimeout = 900;
            SqlDataReader1 = mycommand.ExecuteReader();
            DataTable DataTable1 = new DataTable();
            DataTable1.Load(SqlDataReader1);
            myconnection.Close();

            if (DataTable1.Rows.Count == 0)
            {
                MessageBox.Show("No data found", "GL");
                return;
            }


            CRPrevCIAE objRpt = new CRPrevCIAE();
            TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            ClsCompName1.ClsCompNameMain();
            vartxtcompany.Text = ClsCompName1.varcn;

            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            ClsCompName1.ClsCompNamebranchAddress(Form1.glbltxtCNCode.Text);
            vartxtaddress.Text = ClsCompName1.plsCRaddress;


            objRpt.SetDataSource(DataTable1);
            //crystalReportViewer1.ReportSource = objRpt;
            //crystalReportViewer1.Refresh();

            System.Drawing.Printing.PrintDocument doctoprint = new System.Drawing.Printing.PrintDocument();
            //  doctoprint.PrinterSettings.PrinterName = "EPSON LX-300+ /II";
            int rawKind = 0;
            for (int i = 0; i <= doctoprint.PrinterSettings.PaperSizes.Count - 1; i++)
            {
                if (doctoprint.PrinterSettings.PaperSizes[i].PaperName == "C1-HalfShort")
                {
                    rawKind = Convert.ToInt32(doctoprint.PrinterSettings.PaperSizes[i].GetType().GetField("kind",
                    System.Reflection.BindingFlags.Instance |
                    System.Reflection.BindingFlags.NonPublic).GetValue(doctoprint.PrinterSettings.PaperSizes[i]));
                    break; // TODO: might not be correct. Was : Exit For
                }
            }
            objRpt.PrintOptions.PaperSize = (CrystalDecisions.Shared.PaperSize)rawKind;
            //CrystalDecisions.Shared.PageMargins pMargin = new CrystalDecisions.Shared.PageMargins(0, 0, 0, 0);
            //objRpt.PrintOptions.ApplyPageMargins(pMargin);
            if (strchoose == "1")
            {
                crystalReportViewer1.ReportSource = objRpt;
            }
            else
            {
                objRpt.Refresh();
                objRpt.PrintToPrinter(1, false, 0, 0);
            }

        }


        private void prevASAE()
        {
            string sqlstatement = "SELECT * FROM ViewBookAS WHERE DocNum ='" + txtDocNum.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "'";
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();
            mycommand = myconnection.CreateCommand();
            mycommand.CommandText = sqlstatement;
            mycommand.CommandTimeout = 900;
            SqlDataReader1 = mycommand.ExecuteReader();
            DataTable DataTable1 = new DataTable();
            DataTable1.Load(SqlDataReader1);
            myconnection.Close();

            if (DataTable1.Rows.Count == 0)
            {
                MessageBox.Show("No data found", "GL");
                return;
            }


            CRPrevASAE objRpt = new CRPrevASAE();
            TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            ClsCompName1.ClsCompNameMain();
            vartxtcompany.Text = ClsCompName1.varcn;

            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            ClsCompName1.ClsCompNamebranchAddress(Form1.glbltxtCNCode.Text);
            vartxtaddress.Text = ClsCompName1.plsCRaddress;


            objRpt.SetDataSource(DataTable1);
            //crystalReportViewer1.ReportSource = objRpt;
            //crystalReportViewer1.Refresh();

            System.Drawing.Printing.PrintDocument doctoprint = new System.Drawing.Printing.PrintDocument();
            //  doctoprint.PrinterSettings.PrinterName = "EPSON LX-300+ /II";
            int rawKind = 0;
            for (int i = 0; i <= doctoprint.PrinterSettings.PaperSizes.Count - 1; i++)
            {
                if (doctoprint.PrinterSettings.PaperSizes[i].PaperName == "C1-HalfShort")
                {
                    rawKind = Convert.ToInt32(doctoprint.PrinterSettings.PaperSizes[i].GetType().GetField("kind",
                    System.Reflection.BindingFlags.Instance |
                    System.Reflection.BindingFlags.NonPublic).GetValue(doctoprint.PrinterSettings.PaperSizes[i]));
                    break; // TODO: might not be correct. Was : Exit For
                }
            }
            objRpt.PrintOptions.PaperSize = (CrystalDecisions.Shared.PaperSize)rawKind;
            //CrystalDecisions.Shared.PageMargins pMargin = new CrystalDecisions.Shared.PageMargins(0, 0, 0, 0);
            //objRpt.PrintOptions.ApplyPageMargins(pMargin);
            if (strchoose == "1")
            {
                crystalReportViewer1.ReportSource = objRpt;
            }
            else
            {
                objRpt.Refresh();
                objRpt.PrintToPrinter(1, false, 0, 0);
            }

        }
        private void prevOSAE()
        {
            string sqlstatement = "SELECT * FROM ViewBookOS WHERE DocNum ='" + txtDocNum.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "'";
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();
            mycommand = myconnection.CreateCommand();
            mycommand.CommandText = sqlstatement;
            mycommand.CommandTimeout = 900;
            SqlDataReader1 = mycommand.ExecuteReader();
            DataTable DataTable1 = new DataTable();
            DataTable1.Load(SqlDataReader1);
            myconnection.Close();

            if (DataTable1.Rows.Count == 0)
            {
                MessageBox.Show("No data found", "GL");
                return;
            }


            CRprevOSAE objRpt = new CRprevOSAE();
            TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            ClsCompName1.ClsCompNameMain();
            vartxtcompany.Text = ClsCompName1.varcn;

            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            ClsCompName1.ClsCompNamebranchAddress(Form1.glbltxtCNCode.Text);
            vartxtaddress.Text = ClsCompName1.plsCRaddress;


            objRpt.SetDataSource(DataTable1);
            //crystalReportViewer1.ReportSource = objRpt;
            //crystalReportViewer1.Refresh();

            System.Drawing.Printing.PrintDocument doctoprint = new System.Drawing.Printing.PrintDocument();
            //  doctoprint.PrinterSettings.PrinterName = "EPSON LX-300+ /II";
            int rawKind = 0;
            for (int i = 0; i <= doctoprint.PrinterSettings.PaperSizes.Count - 1; i++)
            {
                if (doctoprint.PrinterSettings.PaperSizes[i].PaperName == "C1-HalfShort")
                {
                    rawKind = Convert.ToInt32(doctoprint.PrinterSettings.PaperSizes[i].GetType().GetField("kind",
                    System.Reflection.BindingFlags.Instance |
                    System.Reflection.BindingFlags.NonPublic).GetValue(doctoprint.PrinterSettings.PaperSizes[i]));
                    break; // TODO: might not be correct. Was : Exit For
                }
            }
            objRpt.PrintOptions.PaperSize = (CrystalDecisions.Shared.PaperSize)rawKind;
            //CrystalDecisions.Shared.PageMargins pMargin = new CrystalDecisions.Shared.PageMargins(0, 0, 0, 0);
            //objRpt.PrintOptions.ApplyPageMargins(pMargin);
            if (strchoose == "1")
            {
                crystalReportViewer1.ReportSource = objRpt;
            }
            else
            {
                objRpt.Refresh();
                objRpt.PrintToPrinter(1, false, 0, 0);
            }

        }
        private void prevARV()
        {
            string sqlstatement = "SELECT * FROM ViewBookARV WHERE DocNum ='" + txtDocNum.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "'";

            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();
            mycommand = myconnection.CreateCommand();
            mycommand.CommandText = sqlstatement;
            mycommand.CommandTimeout = 900;
            SqlDataReader1 = mycommand.ExecuteReader();
            DataTable DataTable1 = new DataTable();
            DataTable1.Load(SqlDataReader1);
            myconnection.Close();

            if (DataTable1.Rows.Count == 0)
            {
                MessageBox.Show("No data found", "GL");
                return;
            }

            CRprevarv objRpt = new CRprevarv();
            TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            ClsCompName1.ClsCompNameMain();
            vartxtcompany.Text = ClsCompName1.varcn;

            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            ClsCompName1.ClsCompNamebranchAddress(Form1.glbltxtCNCode.Text);
            vartxtaddress.Text = ClsCompName1.plsCRaddress;

            objRpt.SetDataSource(DataTable1);
            //crystalReportViewer1.ReportSource = objRpt;
            //crystalReportViewer1.Refresh();

            System.Drawing.Printing.PrintDocument doctoprint = new System.Drawing.Printing.PrintDocument();
            //  doctoprint.PrinterSettings.PrinterName = "EPSON LX-300+ /II";
            int rawKind = 0;
            for (int i = 0; i <= doctoprint.PrinterSettings.PaperSizes.Count - 1; i++)
            {
                if (doctoprint.PrinterSettings.PaperSizes[i].PaperName == "C1-HalfShort")
                {
                    rawKind = Convert.ToInt32(doctoprint.PrinterSettings.PaperSizes[i].GetType().GetField("kind",
                    System.Reflection.BindingFlags.Instance |
                    System.Reflection.BindingFlags.NonPublic).GetValue(doctoprint.PrinterSettings.PaperSizes[i]));
                    break; // TODO: might not be correct. Was : Exit For
                }
            }
            objRpt.PrintOptions.PaperSize = (CrystalDecisions.Shared.PaperSize)rawKind;
            //CrystalDecisions.Shared.PageMargins pMargin = new CrystalDecisions.Shared.PageMargins(0, 0, 0, 0);
            //objRpt.PrintOptions.ApplyPageMargins(pMargin);
            if (strchoose == "1")
            {
                crystalReportViewer1.ReportSource = objRpt;
            }
            else
            {
                objRpt.Refresh();
                objRpt.PrintToPrinter(1, false, 0, 0);
            }
        }

        private void prevCV()
        {
            string sqlstatement;

            ClsGetConnection1.ClsGetConMSSQL(); myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();

            sqlstatement = "SELECT * FROM ViewBookCV WHERE DocNum ='" + txtDocNum.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "'";
           // sqlstatement = "SELECT * FROM ViewBookCV";

            mycommand = new SqlCommand(sqlstatement, myconnection);
            dr = mycommand.ExecuteReader();
            while (dr.Read())
            {
                CheckAmt = Convert.ToDouble(dr["CAmount"]).ToString("N2");
            }
            SqlDataReader1 = dr;
            DataTable DataTable1 = new DataTable();
            DataTable1.Load(SqlDataReader1);
            dr.Close();

            double waa = double.Parse(CheckAmt);
            int wab = (int)waa;

            string wac = (decamout.Calculateamount(waa, wab)).ToString();
            string damtcent = Convert.ToDouble(wac).ToString("N2");
            convertcents cvcnts = new convertcents();
            string dwordcent = cvcnts.getconvertcents(damtcent);

            double a = double.Parse(CheckAmt);
            int b = (int)a;
            NumberToWordsConvertor ntwc = new NumberToWordsConvertor();
            string trimdamt = ntwc.NumberToWords(b);
            AmtInWords = trimdamt.Trim() + " Pesos And " + dwordcent;

            SqlDataAdapter dscmd = new SqlDataAdapter(sqlstatement, myconnection);
            DSBooks dsplrv = new DSBooks();
            dscmd.Fill(dsplrv, "viewbookcv");

            myconnection.Close();

            //if (DataTable1.Rows.Count == 0)
            //{
            //    MessageBox.Show("No data found", "GL");
            //    return;
            //}

            CRprevcv objRpt = new CRprevcv();
            TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            ClsCompName1.ClsCompNameMain();
            vartxtcompany.Text = ClsCompName1.varcn;

            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            ClsCompName1.ClsCompNamebranchAddress(Form1.glbltxtCNCode.Text);
            vartxtaddress.Text = ClsCompName1.plsCRaddress;

            TextObject varTextAmtWords = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["TextAmtWords"];
            varTextAmtWords.Text = AmtInWords;

            objRpt.SetDataSource(dsplrv.Tables[1]);
            //crystalReportViewer1.ReportSource = objRpt;
            //crystalReportViewer1.Refresh();

            System.Drawing.Printing.PrintDocument doctoprint = new System.Drawing.Printing.PrintDocument();
            // doctoprint.PrinterSettings.PrinterName = "EPSON LX-300+ /II";
            //doctoprint.PrinterSettings.PrinterName = "Microsoft XPS Document Writer";
            int rawKind = 0;
            for (int i = 0; i <= doctoprint.PrinterSettings.PaperSizes.Count - 1; i++)
            {
                if (doctoprint.PrinterSettings.PaperSizes[i].PaperName == "C1-HalfShort")
                {
                    rawKind = Convert.ToInt32(doctoprint.PrinterSettings.PaperSizes[i].GetType().GetField("kind",
                    System.Reflection.BindingFlags.Instance |
                    System.Reflection.BindingFlags.NonPublic).GetValue(doctoprint.PrinterSettings.PaperSizes[i]));
                    break; // TODO: might not be correct. Was : Exit For
                }
            }
            objRpt.PrintOptions.PaperSize = (CrystalDecisions.Shared.PaperSize)rawKind;
            //CrystalDecisions.Shared.PageMargins pMargin = new CrystalDecisions.Shared.PageMargins(0, 0, 0, 0);
            //objRpt.PrintOptions.ApplyPageMargins(pMargin);
            if (strchoose == "1")
            {
                crystalReportViewer1.ReportSource = objRpt;
            }
            else
            {
                objRpt.Refresh();
                objRpt.PrintToPrinter(1, false, 0, 0);
            }
        }


        private void prevOR()
        {
            string sqlstatement = "SELECT * FROM viewbookor WHERE DocNum ='" + txtDocNum.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "'";
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();
            mycommand = myconnection.CreateCommand();
            mycommand.CommandText = sqlstatement;
            mycommand.CommandTimeout = 900;
            SqlDataReader1 = mycommand.ExecuteReader();
            DataTable DataTable1 = new DataTable();
            DataTable1.Load(SqlDataReader1);
            myconnection.Close();

            if (DataTable1.Rows.Count == 0)
            {
                MessageBox.Show("No data found", "GL");
                return;
            }

            CRprevor objRpt = new CRprevor();
            TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            ClsCompName1.ClsCompNameMain();
            vartxtcompany.Text = ClsCompName1.varcn;

            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            ClsCompName1.ClsCompNamebranchAddress(Form1.glbltxtCNCode.Text);
            vartxtaddress.Text = ClsCompName1.plsCRaddress;

            objRpt.SetDataSource(DataTable1);
            //crystalReportViewer1.ReportSource = objRpt;
            //crystalReportViewer1.Refresh();

            System.Drawing.Printing.PrintDocument doctoprint = new System.Drawing.Printing.PrintDocument();
            //  doctoprint.PrinterSettings.PrinterName = "EPSON LX-300+ /II";
            int rawKind = 0;
            for (int i = 0; i <= doctoprint.PrinterSettings.PaperSizes.Count - 1; i++)
            {
                if (doctoprint.PrinterSettings.PaperSizes[i].PaperName == "C1-HalfShort")
                {
                    rawKind = Convert.ToInt32(doctoprint.PrinterSettings.PaperSizes[i].GetType().GetField("kind",
                    System.Reflection.BindingFlags.Instance |
                    System.Reflection.BindingFlags.NonPublic).GetValue(doctoprint.PrinterSettings.PaperSizes[i]));
                    break; // TODO: might not be correct. Was : Exit For
                }
            }
            objRpt.PrintOptions.PaperSize = (CrystalDecisions.Shared.PaperSize)rawKind;
            //CrystalDecisions.Shared.PageMargins pMargin = new CrystalDecisions.Shared.PageMargins(0, 0, 0, 0);
            //objRpt.PrintOptions.ApplyPageMargins(pMargin);
            if (strchoose == "1")
            {
                crystalReportViewer1.ReportSource = objRpt;
            }
            else
            {
                objRpt.Refresh();
                objRpt.PrintToPrinter(1, false, 0, 0);
            }
        }

        private void prevRV()
        {
            string sqlstatement = "SELECT * FROM viewbookRV WHERE DocNum ='" + txtDocNum.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "'";

            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();
            mycommand = myconnection.CreateCommand();
            mycommand.CommandText = sqlstatement;
            mycommand.CommandTimeout = 900;
            SqlDataReader1 = mycommand.ExecuteReader();
            DataTable DataTable1 = new DataTable();
            DataTable1.Load(SqlDataReader1);
            myconnection.Close();

            if (DataTable1.Rows.Count == 0)
            {
                MessageBox.Show("No data found", "GL");
                return;
            }

            CRprevRV objRpt = new CRprevRV();
            TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            ClsCompName1.ClsCompNameMain();
            vartxtcompany.Text = ClsCompName1.varcn;

            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            ClsCompName1.ClsCompNamebranchAddress(Form1.glbltxtCNCode.Text);
            vartxtaddress.Text = ClsCompName1.plsCRaddress;

            objRpt.SetDataSource(DataTable1);
            //crystalReportViewer1.ReportSource = objRpt;
            //crystalReportViewer1.Refresh();

            System.Drawing.Printing.PrintDocument doctoprint = new System.Drawing.Printing.PrintDocument();
            //  doctoprint.PrinterSettings.PrinterName = "EPSON LX-300+ /II";
            int rawKind = 0;
            for (int i = 0; i <= doctoprint.PrinterSettings.PaperSizes.Count - 1; i++)
            {
                if (doctoprint.PrinterSettings.PaperSizes[i].PaperName == "C1-HalfShort")
                {
                    rawKind = Convert.ToInt32(doctoprint.PrinterSettings.PaperSizes[i].GetType().GetField("kind",
                    System.Reflection.BindingFlags.Instance |
                    System.Reflection.BindingFlags.NonPublic).GetValue(doctoprint.PrinterSettings.PaperSizes[i]));
                    break; // TODO: might not be correct. Was : Exit For
                }
            }
            objRpt.PrintOptions.PaperSize = (CrystalDecisions.Shared.PaperSize)rawKind;
            //CrystalDecisions.Shared.PageMargins pMargin = new CrystalDecisions.Shared.PageMargins(0, 0, 0, 0);
            //objRpt.PrintOptions.ApplyPageMargins(pMargin);
            if (strchoose == "1")
            {
                crystalReportViewer1.ReportSource = objRpt;
            }
            else
            {
                objRpt.Refresh();
                objRpt.PrintToPrinter(1, false, 0, 0);
            }
        }

        private void prevJV()
        {
            string sqlstatement = "SELECT * FROM viewbookjv WHERE DocNum ='" + txtDocNum.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "'";
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();
            mycommand = myconnection.CreateCommand();
            mycommand.CommandText = sqlstatement;
            mycommand.CommandTimeout = 900;
            SqlDataReader1 = mycommand.ExecuteReader();
            DataTable DataTable1 = new DataTable();
            DataTable1.Load(SqlDataReader1);
            myconnection.Close();

            if (DataTable1.Rows.Count == 0)
            {
                MessageBox.Show("No data found", "GL");
                return;
            }

            CRprevjv objRpt = new CRprevjv();
            TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            ClsCompName1.ClsCompNameMain();
            vartxtcompany.Text = ClsCompName1.varcn;

            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            ClsCompName1.ClsCompNamebranchAddress(Form1.glbltxtCNCode.Text);
            vartxtaddress.Text = ClsCompName1.plsCRaddress;

            objRpt.SetDataSource(DataTable1);
            //crystalReportViewer1.ReportSource = objRpt;
            //crystalReportViewer1.Refresh();

            System.Drawing.Printing.PrintDocument doctoprint = new System.Drawing.Printing.PrintDocument();
            //  doctoprint.PrinterSettings.PrinterName = "EPSON LX-300+ /II";
            int rawKind = 0;
            for (int i = 0; i <= doctoprint.PrinterSettings.PaperSizes.Count - 1; i++)
            {
                if (doctoprint.PrinterSettings.PaperSizes[i].PaperName == "C1-HalfShort")
                {
                    rawKind = Convert.ToInt32(doctoprint.PrinterSettings.PaperSizes[i].GetType().GetField("kind",
                    System.Reflection.BindingFlags.Instance |
                    System.Reflection.BindingFlags.NonPublic).GetValue(doctoprint.PrinterSettings.PaperSizes[i]));
                    break; // TODO: might not be correct. Was : Exit For
                }
            }
            objRpt.PrintOptions.PaperSize = (CrystalDecisions.Shared.PaperSize)rawKind;
            //CrystalDecisions.Shared.PageMargins pMargin = new CrystalDecisions.Shared.PageMargins(0, 0, 0, 0);
            //objRpt.PrintOptions.ApplyPageMargins(pMargin);
            if (strchoose == "1")
            {
                crystalReportViewer1.ReportSource = objRpt;
            }
            else
            {
                objRpt.Refresh();
                objRpt.PrintToPrinter(1, false, 0, 0);
            }
        }

        private void prevPO()
        {
            string sqlstatement = "SELECT * FROM ViewDetailsBookPO WHERE DocNum ='" + txtDocNum.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "' ORDER BY RowNum";

            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();
            mycommand = myconnection.CreateCommand();
            mycommand.CommandText = sqlstatement;
            mycommand.CommandTimeout = 900;
            SqlDataReader1 = mycommand.ExecuteReader();
            DataTable DataTable1 = new DataTable();
            DataTable1.Load(SqlDataReader1);
            myconnection.Close();

            if (DataTable1.Rows.Count == 0)
            {
                MessageBox.Show("No data found", "GL");
                return;
            }

            CRprevPO objRpt = new CRprevPO();
            TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            ClsCompName1.ClsCompNameMain();
            vartxtcompany.Text = ClsCompName1.varcn;

            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            ClsCompName1.ClsCompNamebranchAddress(Form1.glbltxtCNCode.Text);
            vartxtaddress.Text = ClsCompName1.plsCRaddress;

            objRpt.SetDataSource(DataTable1);
            //crystalReportViewer1.ReportSource = objRpt;
            //crystalReportViewer1.Refresh();

            System.Drawing.Printing.PrintDocument doctoprint = new System.Drawing.Printing.PrintDocument();
            //  doctoprint.PrinterSettings.PrinterName = "EPSON LX-300+ /II";
            int rawKind = 0;
            for (int i = 0; i <= doctoprint.PrinterSettings.PaperSizes.Count - 1; i++)
            {
                if (doctoprint.PrinterSettings.PaperSizes[i].PaperName == "C1-HalfShort")
                {
                    rawKind = Convert.ToInt32(doctoprint.PrinterSettings.PaperSizes[i].GetType().GetField("kind",
                    System.Reflection.BindingFlags.Instance |
                    System.Reflection.BindingFlags.NonPublic).GetValue(doctoprint.PrinterSettings.PaperSizes[i]));
                    break; // TODO: might not be correct. Was : Exit For
                }
            }
            objRpt.PrintOptions.PaperSize = (CrystalDecisions.Shared.PaperSize)rawKind;
            //CrystalDecisions.Shared.PageMargins pMargin = new CrystalDecisions.Shared.PageMargins(0, 0, 0, 0);
            //objRpt.PrintOptions.ApplyPageMargins(pMargin);
            if (strchoose == "1")
            {
                crystalReportViewer1.ReportSource = objRpt;
            }
            else
            {
                objRpt.Refresh();
                objRpt.PrintToPrinter(1, false, 0, 0);
            }
        }

        private void prevPD()
        {
            string sqlstatement = "SELECT * FROM ViewDetailsBookPD WHERE DocNum ='" + txtDocNum.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "' ORDER BY RowNum";
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();
            mycommand = myconnection.CreateCommand();
            mycommand.CommandText = sqlstatement;
            mycommand.CommandTimeout = 900;
            SqlDataReader1 = mycommand.ExecuteReader();
            DataTable DataTable1 = new DataTable();
            DataTable1.Load(SqlDataReader1);
            myconnection.Close();

            if (DataTable1.Rows.Count == 0)
            {
                MessageBox.Show("No data found", "GL");
                return;
            }

            CRprevPD objRpt = new CRprevPD();
            TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            ClsCompName1.ClsCompNameMain();
            vartxtcompany.Text = ClsCompName1.varcn;

            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            ClsCompName1.ClsCompNamebranchAddress(Form1.glbltxtCNCode.Text);
            vartxtaddress.Text = ClsCompName1.plsCRaddress;

            objRpt.SetDataSource(DataTable1);
            //crystalReportViewer1.ReportSource = objRpt;
            //crystalReportViewer1.Refresh();

            System.Drawing.Printing.PrintDocument doctoprint = new System.Drawing.Printing.PrintDocument();
            //  doctoprint.PrinterSettings.PrinterName = "EPSON LX-300+ /II";
            int rawKind = 0;
            for (int i = 0; i <= doctoprint.PrinterSettings.PaperSizes.Count - 1; i++)
            {
                if (doctoprint.PrinterSettings.PaperSizes[i].PaperName == "C1-HalfShort")
                {
                    rawKind = Convert.ToInt32(doctoprint.PrinterSettings.PaperSizes[i].GetType().GetField("kind",
                    System.Reflection.BindingFlags.Instance |
                    System.Reflection.BindingFlags.NonPublic).GetValue(doctoprint.PrinterSettings.PaperSizes[i]));
                    break; // TODO: might not be correct. Was : Exit For
                }
            }
            objRpt.PrintOptions.PaperSize = (CrystalDecisions.Shared.PaperSize)rawKind;
            //CrystalDecisions.Shared.PageMargins pMargin = new CrystalDecisions.Shared.PageMargins(0, 0, 0, 0);
            //objRpt.PrintOptions.ApplyPageMargins(pMargin);
            if (strchoose == "1")
            {
                crystalReportViewer1.ReportSource = objRpt;
            }
            else
            {
                objRpt.Refresh();
                objRpt.PrintToPrinter(1, false, 0, 0);
            }
        }

        private void prevRTS()
        {
            string sqlstatement = "SELECT * FROM ViewDetailsBookRTS WHERE DocNum ='" + txtDocNum.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "' ORDER BY RowNum";

            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();
            mycommand = myconnection.CreateCommand();
            mycommand.CommandText = sqlstatement;
            mycommand.CommandTimeout = 900;
            SqlDataReader1 = mycommand.ExecuteReader();
            DataTable DataTable1 = new DataTable();
            DataTable1.Load(SqlDataReader1);
            myconnection.Close();

            if (DataTable1.Rows.Count == 0)
            {
                MessageBox.Show("No data found", "GL");
                return;
            }

            CRprevRTS objRpt = new CRprevRTS();
            TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            ClsCompName1.ClsCompNameMain();
            vartxtcompany.Text = ClsCompName1.varcn;

            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            ClsCompName1.ClsCompNamebranchAddress(Form1.glbltxtCNCode.Text);
            vartxtaddress.Text = ClsCompName1.plsCRaddress;

            objRpt.SetDataSource(DataTable1);
            //crystalReportViewer1.ReportSource = objRpt;
            //crystalReportViewer1.Refresh();

            System.Drawing.Printing.PrintDocument doctoprint = new System.Drawing.Printing.PrintDocument();
            //  doctoprint.PrinterSettings.PrinterName = "EPSON LX-300+ /II";
            int rawKind = 0;
            for (int i = 0; i <= doctoprint.PrinterSettings.PaperSizes.Count - 1; i++)
            {
                if (doctoprint.PrinterSettings.PaperSizes[i].PaperName == "C1-HalfShort")
                {
                    rawKind = Convert.ToInt32(doctoprint.PrinterSettings.PaperSizes[i].GetType().GetField("kind",
                    System.Reflection.BindingFlags.Instance |
                    System.Reflection.BindingFlags.NonPublic).GetValue(doctoprint.PrinterSettings.PaperSizes[i]));
                    break; // TODO: might not be correct. Was : Exit For
                }
            }
            objRpt.PrintOptions.PaperSize = (CrystalDecisions.Shared.PaperSize)rawKind;
            //CrystalDecisions.Shared.PageMargins pMargin = new CrystalDecisions.Shared.PageMargins(0, 0, 0, 0);
            //objRpt.PrintOptions.ApplyPageMargins(pMargin);
            if (strchoose == "1")
            {
                crystalReportViewer1.ReportSource = objRpt;
            }
            else
            {
                objRpt.Refresh();
                objRpt.PrintToPrinter(1, false, 0, 0);
            }
        }
        private void prevCI()
            {
                string sqlstatement = "SELECT * FROM ViewDetailsBookCI WHERE DocNum ='" + txtDocNum.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "' ORDER BY RowNum";

                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = myconnection.CreateCommand();
                mycommand.CommandText = sqlstatement;
                mycommand.CommandTimeout = 900;
                SqlDataReader1 = mycommand.ExecuteReader();
                DataTable DataTable1 = new DataTable();
                DataTable1.Load(SqlDataReader1);
                myconnection.Close();

                if (DataTable1.Rows.Count == 0)
                {
                    MessageBox.Show("No data found", "GL");
                    return;
                }

                CRprevCI objRpt = new CRprevCI();
                TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
                ClsCompName1.ClsCompNameMain();
                vartxtcompany.Text = ClsCompName1.varcn;

                TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
                ClsCompName1.ClsCompNamebranchAddress(Form1.glbltxtCNCode.Text);
                vartxtaddress.Text = ClsCompName1.plsCRaddress;

                objRpt.SetDataSource(DataTable1);
                //crystalReportViewer1.ReportSource = objRpt;
                //crystalReportViewer1.Refresh();

                System.Drawing.Printing.PrintDocument doctoprint = new System.Drawing.Printing.PrintDocument();
                //  doctoprint.PrinterSettings.PrinterName = "EPSON LX-300+ /II";
                int rawKind = 0;
                for (int i = 0; i <= doctoprint.PrinterSettings.PaperSizes.Count - 1; i++)
                {
                    if (doctoprint.PrinterSettings.PaperSizes[i].PaperName == "C1-HalfShort")
                    {
                        rawKind = Convert.ToInt32(doctoprint.PrinterSettings.PaperSizes[i].GetType().GetField("kind",
                        System.Reflection.BindingFlags.Instance |
                        System.Reflection.BindingFlags.NonPublic).GetValue(doctoprint.PrinterSettings.PaperSizes[i]));
                        break; // TODO: might not be correct. Was : Exit For
                    }
                }
                objRpt.PrintOptions.PaperSize = (CrystalDecisions.Shared.PaperSize)rawKind;
                //CrystalDecisions.Shared.PageMargins pMargin = new CrystalDecisions.Shared.PageMargins(0, 0, 0, 0);
                //objRpt.PrintOptions.ApplyPageMargins(pMargin);
                if (strchoose == "1")
                {
                    crystalReportViewer1.ReportSource = objRpt;
                }
                else
                {
                    objRpt.Refresh();
                    objRpt.PrintToPrinter(1, false, 0, 0);
                }
        }

        private void prevCS()
            {
                string sqlstatement = "SELECT * FROM ViewDetailsBookCS WHERE DocNum ='" + txtDocNum.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "' ORDER BY RowNum";

                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = myconnection.CreateCommand();
                mycommand.CommandText = sqlstatement;
                mycommand.CommandTimeout = 900;
                SqlDataReader1 = mycommand.ExecuteReader();
                DataTable DataTable1 = new DataTable();
                DataTable1.Load(SqlDataReader1);
                myconnection.Close();

                if (DataTable1.Rows.Count == 0)
                {
                    MessageBox.Show("No data found", "GL");
                    return;
                }

                CRprevCS objRpt = new CRprevCS();
                TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
                ClsCompName1.ClsCompNameMain();
                vartxtcompany.Text = ClsCompName1.varcn;

                TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
                ClsCompName1.ClsCompNamebranchAddress(Form1.glbltxtCNCode.Text);
                vartxtaddress.Text = ClsCompName1.plsCRaddress;

                objRpt.SetDataSource(DataTable1);
                //crystalReportViewer1.ReportSource = objRpt;
                //crystalReportViewer1.Refresh();

                System.Drawing.Printing.PrintDocument doctoprint = new System.Drawing.Printing.PrintDocument();
                //  doctoprint.PrinterSettings.PrinterName = "EPSON LX-300+ /II";
                int rawKind = 0;
                for (int i = 0; i <= doctoprint.PrinterSettings.PaperSizes.Count - 1; i++)
                {
                    if (doctoprint.PrinterSettings.PaperSizes[i].PaperName == "C1-HalfShort")
                    {
                        rawKind = Convert.ToInt32(doctoprint.PrinterSettings.PaperSizes[i].GetType().GetField("kind",
                        System.Reflection.BindingFlags.Instance |
                        System.Reflection.BindingFlags.NonPublic).GetValue(doctoprint.PrinterSettings.PaperSizes[i]));
                        break; // TODO: might not be correct. Was : Exit For
                    }
                }
                objRpt.PrintOptions.PaperSize = (CrystalDecisions.Shared.PaperSize)rawKind;
                //CrystalDecisions.Shared.PageMargins pMargin = new CrystalDecisions.Shared.PageMargins(0, 0, 0, 0);
                //objRpt.PrintOptions.ApplyPageMargins(pMargin);
                if (strchoose == "1")
                {
                    crystalReportViewer1.ReportSource = objRpt;
                }
                else
                {
                    objRpt.Refresh();
                    objRpt.PrintToPrinter(1, false, 0, 0);
                }
        }
        private void prevAS()
        {
            string sqlstatement = "SELECT * FROM ViewDetailsBookAS WHERE DocNum ='" + txtDocNum.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "' ORDER BY RowNum";

            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();
            mycommand = myconnection.CreateCommand();
            mycommand.CommandText = sqlstatement;
            mycommand.CommandTimeout = 900;
            SqlDataReader1 = mycommand.ExecuteReader();
            DataTable DataTable1 = new DataTable();
            DataTable1.Load(SqlDataReader1);
            myconnection.Close();

            if (DataTable1.Rows.Count == 0)
            {
                MessageBox.Show("No data found", "GL");
                return;
            }

            CRprevAS objRpt = new CRprevAS();
            TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            ClsCompName1.ClsCompNameMain();
            vartxtcompany.Text = ClsCompName1.varcn;

            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            ClsCompName1.ClsCompNamebranchAddress(Form1.glbltxtCNCode.Text);
            vartxtaddress.Text = ClsCompName1.plsCRaddress;

            objRpt.SetDataSource(DataTable1);
            //crystalReportViewer1.ReportSource = objRpt;
            //crystalReportViewer1.Refresh();

            System.Drawing.Printing.PrintDocument doctoprint = new System.Drawing.Printing.PrintDocument();
            //  doctoprint.PrinterSettings.PrinterName = "EPSON LX-300+ /II";
            int rawKind = 0;
            for (int i = 0; i <= doctoprint.PrinterSettings.PaperSizes.Count - 1; i++)
            {
                if (doctoprint.PrinterSettings.PaperSizes[i].PaperName == "C1-HalfShort")
                {
                    rawKind = Convert.ToInt32(doctoprint.PrinterSettings.PaperSizes[i].GetType().GetField("kind",
                    System.Reflection.BindingFlags.Instance |
                    System.Reflection.BindingFlags.NonPublic).GetValue(doctoprint.PrinterSettings.PaperSizes[i]));
                    break; // TODO: might not be correct. Was : Exit For
                }
            }
            objRpt.PrintOptions.PaperSize = (CrystalDecisions.Shared.PaperSize)rawKind;
            //CrystalDecisions.Shared.PageMargins pMargin = new CrystalDecisions.Shared.PageMargins(0, 0, 0, 0);
            //objRpt.PrintOptions.ApplyPageMargins(pMargin);
            if (strchoose == "1")
            {
                crystalReportViewer1.ReportSource = objRpt;
            }
            else
            {
                objRpt.Refresh();
                objRpt.PrintToPrinter(1, false, 0, 0);
            }
        }

            private void prevTS()
            {
                string sqlstatement = "SELECT * FROM ViewDetailsBookTS WHERE DocNum ='" + txtDocNum.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "' ORDER BY RowNum";

                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = myconnection.CreateCommand();
                mycommand.CommandText = sqlstatement;
                mycommand.CommandTimeout = 900;
                SqlDataReader1 = mycommand.ExecuteReader();
                DataTable DataTable1 = new DataTable();
                DataTable1.Load(SqlDataReader1);
                myconnection.Close();

                if (DataTable1.Rows.Count == 0)
                {
                    MessageBox.Show("No data found", "GL");
                    return;
                }

                CRprevTS objRpt = new CRprevTS();
                TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
                ClsCompName1.ClsCompNameMain();
                vartxtcompany.Text = ClsCompName1.varcn;

                TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
                ClsCompName1.ClsCompNamebranchAddress(Form1.glbltxtCNCode.Text);
                vartxtaddress.Text = ClsCompName1.plsCRaddress;


                objRpt.SetDataSource(DataTable1);
                //crystalReportViewer1.ReportSource = objRpt;
                //crystalReportViewer1.Refresh();

                System.Drawing.Printing.PrintDocument doctoprint = new System.Drawing.Printing.PrintDocument();
                //  doctoprint.PrinterSettings.PrinterName = "EPSON LX-300+ /II";
                int rawKind = 0;
                for (int i = 0; i <= doctoprint.PrinterSettings.PaperSizes.Count - 1; i++)
                {
                    if (doctoprint.PrinterSettings.PaperSizes[i].PaperName == "C1-HalfShort")
                    {
                        rawKind = Convert.ToInt32(doctoprint.PrinterSettings.PaperSizes[i].GetType().GetField("kind",
                        System.Reflection.BindingFlags.Instance |
                        System.Reflection.BindingFlags.NonPublic).GetValue(doctoprint.PrinterSettings.PaperSizes[i]));
                        break; // TODO: might not be correct. Was : Exit For
                    }
                }
                objRpt.PrintOptions.PaperSize = (CrystalDecisions.Shared.PaperSize)rawKind;
                //CrystalDecisions.Shared.PageMargins pMargin = new CrystalDecisions.Shared.PageMargins(0, 0, 0, 0);
                //objRpt.PrintOptions.ApplyPageMargins(pMargin);
                if (strchoose == "1")
                {
                    crystalReportViewer1.ReportSource = objRpt;
                }
                else
                {
                    objRpt.Refresh();
                    objRpt.PrintToPrinter(1, false, 0, 0);
                }
            }

        private void prevRS()
        {
            string sqlstatement = "SELECT * FROM ViewDetailsBookRS WHERE DocNum ='" + txtDocNum.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "' ORDER BY RowNum";

            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();
            mycommand = myconnection.CreateCommand();
            mycommand.CommandText = sqlstatement;
            mycommand.CommandTimeout = 900;
            SqlDataReader1 = mycommand.ExecuteReader();
            DataTable DataTable1 = new DataTable();
            DataTable1.Load(SqlDataReader1);
            myconnection.Close();

            if (DataTable1.Rows.Count == 0)
            {
                MessageBox.Show("No data found", "GL");
                return;
            }


            CRprevRS objRpt = new CRprevRS();
            TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            ClsCompName1.ClsCompNameMain();
            vartxtcompany.Text = ClsCompName1.varcn;

            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            ClsCompName1.ClsCompNamebranchAddress(Form1.glbltxtCNCode.Text);
            vartxtaddress.Text = ClsCompName1.plsCRaddress;

            objRpt.SetDataSource(DataTable1);
            //crystalReportViewer1.ReportSource = objRpt;
            //crystalReportViewer1.Refresh();

            System.Drawing.Printing.PrintDocument doctoprint = new System.Drawing.Printing.PrintDocument();
            //  doctoprint.PrinterSettings.PrinterName = "EPSON LX-300+ /II";
            int rawKind = 0;
            for (int i = 0; i <= doctoprint.PrinterSettings.PaperSizes.Count - 1; i++)
            {
                if (doctoprint.PrinterSettings.PaperSizes[i].PaperName == "C1-HalfShort")
                {
                    rawKind = Convert.ToInt32(doctoprint.PrinterSettings.PaperSizes[i].GetType().GetField("kind",
                    System.Reflection.BindingFlags.Instance |
                    System.Reflection.BindingFlags.NonPublic).GetValue(doctoprint.PrinterSettings.PaperSizes[i]));
                    break; // TODO: might not be correct. Was : Exit For
                }
            }
            objRpt.PrintOptions.PaperSize = (CrystalDecisions.Shared.PaperSize)rawKind;
            //CrystalDecisions.Shared.PageMargins pMargin = new CrystalDecisions.Shared.PageMargins(0, 0, 0, 0);
            //objRpt.PrintOptions.ApplyPageMargins(pMargin);
            if (strchoose == "1")
            {
                crystalReportViewer1.ReportSource = objRpt;
            }
            else
            {
                objRpt.Refresh();
                objRpt.PrintToPrinter(1, false, 0, 0);
            }
        }
        private void preOS()
        {
            string sqlstatement = "SELECT * FROM ViewDetailsBookOS WHERE DocNum ='" + txtDocNum.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "' ORDER BY RowNum";

            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();
            mycommand = myconnection.CreateCommand();
            mycommand.CommandText = sqlstatement;
            mycommand.CommandTimeout = 900;
            SqlDataReader1 = mycommand.ExecuteReader();
            DataTable DataTable1 = new DataTable();
            DataTable1.Load(SqlDataReader1);
            myconnection.Close();

            if (DataTable1.Rows.Count == 0)
            {
                MessageBox.Show("No data found", "GL");
                return;
            }

            CRprevOS objRpt = new CRprevOS();
            TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            ClsCompName1.ClsCompNameMain();
            vartxtcompany.Text = ClsCompName1.varcn;

            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            ClsCompName1.ClsCompNamebranchAddress(Form1.glbltxtCNCode.Text);
            vartxtaddress.Text = ClsCompName1.plsCRaddress;

            objRpt.SetDataSource(DataTable1);
            //crystalReportViewer1.ReportSource = objRpt;
            //crystalReportViewer1.Refresh();

            System.Drawing.Printing.PrintDocument doctoprint = new System.Drawing.Printing.PrintDocument();
            //  doctoprint.PrinterSettings.PrinterName = "EPSON LX-300+ /II";
            int rawKind = 0;
            for (int i = 0; i <= doctoprint.PrinterSettings.PaperSizes.Count - 1; i++)
            {
                if (doctoprint.PrinterSettings.PaperSizes[i].PaperName == "C1-HalfShort")
                {
                    rawKind = Convert.ToInt32(doctoprint.PrinterSettings.PaperSizes[i].GetType().GetField("kind",
                    System.Reflection.BindingFlags.Instance |
                    System.Reflection.BindingFlags.NonPublic).GetValue(doctoprint.PrinterSettings.PaperSizes[i]));
                    break; // TODO: might not be correct. Was : Exit For
                }
            }
            objRpt.PrintOptions.PaperSize = (CrystalDecisions.Shared.PaperSize)rawKind;
            //CrystalDecisions.Shared.PageMargins pMargin = new CrystalDecisions.Shared.PageMargins(0, 0, 0, 0);
            //objRpt.PrintOptions.ApplyPageMargins(pMargin);
            if (strchoose == "1")
            {
                crystalReportViewer1.ReportSource = objRpt;
            }
            else
            {
                objRpt.Refresh();
                objRpt.PrintToPrinter(1, false, 0, 0);
            }
        }

        private void prevWS()
        {
            string sqlstatement = "SELECT * FROM ViewDetailsBookWS WHERE DocNum ='" + txtDocNum.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "' ORDER BY RowNum";

            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();
            mycommand = myconnection.CreateCommand();
            mycommand.CommandText = sqlstatement;
            mycommand.CommandTimeout = 900;
            SqlDataReader1 = mycommand.ExecuteReader();
            DataTable DataTable1 = new DataTable();
            DataTable1.Load(SqlDataReader1);
            myconnection.Close();

            if (DataTable1.Rows.Count == 0)
            {
                MessageBox.Show("No data found", "GL");
                return;
            }

            CRprevWS objRpt = new CRprevWS();
            TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            ClsCompName1.ClsCompNameMain();
            vartxtcompany.Text = ClsCompName1.varcn;

            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            ClsCompName1.ClsCompNamebranchAddress(Form1.glbltxtCNCode.Text);
            vartxtaddress.Text = ClsCompName1.plsCRaddress;

            objRpt.SetDataSource(DataTable1);
            //crystalReportViewer1.ReportSource = objRpt;
            //crystalReportViewer1.Refresh();

            System.Drawing.Printing.PrintDocument doctoprint = new System.Drawing.Printing.PrintDocument();
            //  doctoprint.PrinterSettings.PrinterName = "EPSON LX-300+ /II";
            int rawKind = 0;
            for (int i = 0; i <= doctoprint.PrinterSettings.PaperSizes.Count - 1; i++)
            {
                if (doctoprint.PrinterSettings.PaperSizes[i].PaperName == "C1-HalfShort")
                {
                    rawKind = Convert.ToInt32(doctoprint.PrinterSettings.PaperSizes[i].GetType().GetField("kind",
                    System.Reflection.BindingFlags.Instance |
                    System.Reflection.BindingFlags.NonPublic).GetValue(doctoprint.PrinterSettings.PaperSizes[i]));
                    break; // TODO: might not be correct. Was : Exit For
                }
            }
            objRpt.PrintOptions.PaperSize = (CrystalDecisions.Shared.PaperSize)rawKind;
            //CrystalDecisions.Shared.PageMargins pMargin = new CrystalDecisions.Shared.PageMargins(0, 0, 0, 0);
            //objRpt.PrintOptions.ApplyPageMargins(pMargin);
            if (strchoose == "1")
            {
                crystalReportViewer1.ReportSource = objRpt;
            }
            else
            {
                objRpt.Refresh();
                objRpt.PrintToPrinter(1, false, 0, 0);
            }
        }

        private void prevPS()
        {
            string sqlstatement = "SELECT * FROM ViewDetailsBookPS WHERE DocNum ='" + txtDocNum.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "' ORDER BY RowNum";

            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();
            mycommand = myconnection.CreateCommand();
            mycommand.CommandText = sqlstatement;
            mycommand.CommandTimeout = 900;
            SqlDataReader1 = mycommand.ExecuteReader();
            DataTable DataTable1 = new DataTable();
            DataTable1.Load(SqlDataReader1);
            myconnection.Close();

            if (DataTable1.Rows.Count == 0)
            {
                MessageBox.Show("No data found", "GL");
                return;
            }

            CRprevPS objRpt = new CRprevPS();
            TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            ClsCompName1.ClsCompNameMain();
            vartxtcompany.Text = ClsCompName1.varcn;

            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            ClsCompName1.ClsCompNamebranchAddress(Form1.glbltxtCNCode.Text);
            vartxtaddress.Text = ClsCompName1.plsCRaddress;

            objRpt.SetDataSource(DataTable1);
            //crystalReportViewer1.ReportSource = objRpt;
            //crystalReportViewer1.Refresh();

            System.Drawing.Printing.PrintDocument doctoprint = new System.Drawing.Printing.PrintDocument();
            //  doctoprint.PrinterSettings.PrinterName = "EPSON LX-300+ /II";
            int rawKind = 0;
            for (int i = 0; i <= doctoprint.PrinterSettings.PaperSizes.Count - 1; i++)
            {
                if (doctoprint.PrinterSettings.PaperSizes[i].PaperName == "C1-HalfShort")
                {
                    rawKind = Convert.ToInt32(doctoprint.PrinterSettings.PaperSizes[i].GetType().GetField("kind",
                    System.Reflection.BindingFlags.Instance |
                    System.Reflection.BindingFlags.NonPublic).GetValue(doctoprint.PrinterSettings.PaperSizes[i]));
                    break; // TODO: might not be correct. Was : Exit For
                }
            }
            objRpt.PrintOptions.PaperSize = (CrystalDecisions.Shared.PaperSize)rawKind;
            //CrystalDecisions.Shared.PageMargins pMargin = new CrystalDecisions.Shared.PageMargins(0, 0, 0, 0);
            //objRpt.PrintOptions.ApplyPageMargins(pMargin);
            if (strchoose == "1")
            {
                crystalReportViewer1.ReportSource = objRpt;
            }
            else
            {
                objRpt.Refresh();
                objRpt.PrintToPrinter(1, false, 0, 0);
            }
        }

        private void prevAI()
        {
            string sqlstatement = "SELECT * FROM ViewDetailsBookAI WHERE DocNum ='" + txtDocNum.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "' ORDER BY RowNum";

            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();
            mycommand = myconnection.CreateCommand();
            mycommand.CommandText = sqlstatement;
            mycommand.CommandTimeout = 900;
            SqlDataReader1 = mycommand.ExecuteReader();
            DataTable DataTable1 = new DataTable();
            DataTable1.Load(SqlDataReader1);
            myconnection.Close();

            if (DataTable1.Rows.Count == 0)
            {
                MessageBox.Show("No data found", "GL");
                return;
            }

            CRprevAI objRpt = new CRprevAI();
            TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            ClsCompName1.ClsCompNameMain();
            vartxtcompany.Text = ClsCompName1.varcn;

            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            ClsCompName1.ClsCompNamebranchAddress(Form1.glbltxtCNCode.Text);
            vartxtaddress.Text = ClsCompName1.plsCRaddress;

            objRpt.SetDataSource(DataTable1);
            //crystalReportViewer1.ReportSource = objRpt;
            //crystalReportViewer1.Refresh();

            if (strchoose == "1")
            {
                crystalReportViewer1.ReportSource = objRpt;
            }
            else
            {
                objRpt.Refresh();
                objRpt.PrintToPrinter(1, false, 0, 0);
            }
        }
        private void prevPI()
        {
            string sqlstatement = "SELECT * FROM ViewBookPI WHERE DocNum ='" + txtDocNum.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "'";
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();
            mycommand = myconnection.CreateCommand();
            mycommand.CommandText = sqlstatement;
            mycommand.CommandTimeout = 900;
            SqlDataReader1 = mycommand.ExecuteReader();
            DataTable DataTable1 = new DataTable();
            DataTable1.Load(SqlDataReader1);
            myconnection.Close();

            if (DataTable1.Rows.Count == 0)
            {
                MessageBox.Show("No data found", "GL");
                return;
            }


            CRprevPI objRpt = new CRprevPI();
            TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            ClsCompName1.ClsCompNameMain();
            vartxtcompany.Text = ClsCompName1.varcn;

            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            ClsCompName1.ClsCompNamebranchAddress(Form1.glbltxtCNCode.Text);
            vartxtaddress.Text = ClsCompName1.plsCRaddress;


            objRpt.SetDataSource(DataTable1);
            crystalReportViewer1.ReportSource = objRpt;
            crystalReportViewer1.Refresh();

            //System.Drawing.Printing.PrintDocument doctoprint = new System.Drawing.Printing.PrintDocument();
            ////  doctoprint.PrinterSettings.PrinterName = "EPSON LX-300+ /II";
            //int rawKind = 0;
            //for (int i = 0; i <= doctoprint.PrinterSettings.PaperSizes.Count - 1; i++)
            //{
            //    if (doctoprint.PrinterSettings.PaperSizes[i].PaperName == "C1-HalfShort")
            //    {
            //        rawKind = Convert.ToInt32(doctoprint.PrinterSettings.PaperSizes[i].GetType().GetField("kind",
            //        System.Reflection.BindingFlags.Instance |
            //        System.Reflection.BindingFlags.NonPublic).GetValue(doctoprint.PrinterSettings.PaperSizes[i]));
            //        break; // TODO: might not be correct. Was : Exit For
            //    }
            //}
            //objRpt.PrintOptions.PaperSize = (CrystalDecisions.Shared.PaperSize)rawKind;
            ////CrystalDecisions.Shared.PageMargins pMargin = new CrystalDecisions.Shared.PageMargins(0, 0, 0, 0);
            ////objRpt.PrintOptions.ApplyPageMargins(pMargin);
            //if (strchoose == "1")
            //{
            //    crystalReportViewer1.ReportSource = objRpt;
            //}
            //else
            //{
            //    objRpt.Refresh();
            //    objRpt.PrintToPrinter(1, false, 0, 0);
            //}

        }

        private void prevCRV()
        {
            string sqlstatement = "SELECT * FROM ViewBookCRV WHERE DocNum ='" + txtDocNum.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "' ORDER BY RowNum";

            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();
            mycommand = myconnection.CreateCommand();
            mycommand.CommandText = sqlstatement;
            mycommand.CommandTimeout = 900;
            SqlDataReader1 = mycommand.ExecuteReader();
            DataTable DataTable1 = new DataTable();
            DataTable1.Load(SqlDataReader1);
            myconnection.Close();

            if (DataTable1.Rows.Count == 0)
            {
                MessageBox.Show("No data found", "GL");
                return;
            }

            CRprevCRV objRpt = new CRprevCRV();
            TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            ClsCompName1.ClsCompNameMain();
            vartxtcompany.Text = ClsCompName1.varcn;

            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            ClsCompName1.ClsCompNamebranchAddress(Form1.glbltxtCNCode.Text);
            vartxtaddress.Text = ClsCompName1.plsCRaddress;

            objRpt.SetDataSource(DataTable1);
            //crystalReportViewer1.ReportSource = objRpt;
            //crystalReportViewer1.Refresh();

            System.Drawing.Printing.PrintDocument doctoprint = new System.Drawing.Printing.PrintDocument();
            //  doctoprint.PrinterSettings.PrinterName = "EPSON LX-300+ /II";
            int rawKind = 0;
            for (int i = 0; i <= doctoprint.PrinterSettings.PaperSizes.Count - 1; i++)
            {
                if (doctoprint.PrinterSettings.PaperSizes[i].PaperName == "C1-HalfShort")
                {
                    rawKind = Convert.ToInt32(doctoprint.PrinterSettings.PaperSizes[i].GetType().GetField("kind",
                    System.Reflection.BindingFlags.Instance |
                    System.Reflection.BindingFlags.NonPublic).GetValue(doctoprint.PrinterSettings.PaperSizes[i]));
                    break; // TODO: might not be correct. Was : Exit For
                }
            }
            objRpt.PrintOptions.PaperSize = (CrystalDecisions.Shared.PaperSize)rawKind;
            //CrystalDecisions.Shared.PageMargins pMargin = new CrystalDecisions.Shared.PageMargins(0, 0, 0, 0);
            //objRpt.PrintOptions.ApplyPageMargins(pMargin);
            if (strchoose == "1")
            {
                crystalReportViewer1.ReportSource = objRpt;
            }
            else
            {
                objRpt.Refresh();
                objRpt.PrintToPrinter(1, false, 0, 0);
            }
        }

        private void cboCName_Validating(object sender, CancelEventArgs e)
        {
            if (new ClsValidation().emptytxt(cboCNCode.Text))
            {
            }
            else if (cboCNCode.Text != null && cboCNCode.SelectedValue == null)
            {
                MessageBox.Show("Not found", "GL");
                cboCNCode.Focus();
            }
        }

        private void cbortprint_Validating(object sender, CancelEventArgs e)
        {
            if (cbortprint.SelectedValue.ToString() == "01")//"Accounts Payable Voucher"
            {
                ClsAutoNumber1.VoucherLatestNum("APV", cboCNCode.SelectedValue.ToString());
                txtDocNum.Text = (ClsAutoNumber1.plsnumber);
            }
            else if (cbortprint.SelectedValue.ToString() == "02")//"Accounts Receivable Voucher"
            {
                ClsAutoNumber1.VoucherLatestNum("ARV", cboCNCode.SelectedValue.ToString());
                txtDocNum.Text = (ClsAutoNumber1.plsnumber);
            }
            else if (cbortprint.SelectedValue.ToString() == "03")//"Check Voucher"
            {
                ClsAutoNumber1.VoucherLatestNum("CV", cboCNCode.SelectedValue.ToString());
                txtDocNum.Text = (ClsAutoNumber1.plsnumber);
            }
            else if (cbortprint.SelectedValue.ToString() == "04") //"Official Receipts"
            {
                ClsAutoNumber1.VoucherLatestNum("OR", cboCNCode.SelectedValue.ToString());
                txtDocNum.Text = (ClsAutoNumber1.plsnumber);
            }
            else if (cbortprint.SelectedValue.ToString() == "05") //"Remittance Voucher"
            {
                ClsAutoNumber1.VoucherLatestNum("RV", cboCNCode.SelectedValue.ToString());
                txtDocNum.Text = (ClsAutoNumber1.plsnumber);
            }
            else if (cbortprint.SelectedValue.ToString() == "06") //"Journal Voucher"
            {
                ClsAutoNumber1.VoucherLatestNum("JV", cboCNCode.SelectedValue.ToString());
                txtDocNum.Text = (ClsAutoNumber1.plsnumber);
            }
            else if (cbortprint.SelectedValue.ToString() == "07") //"Purchase Order"
            {
                ClsAutoNumber1.VoucherLatestNumPO("PO", cboCNCode.SelectedValue.ToString());
                txtDocNum.Text = (ClsAutoNumber1.plsnumber);
            }
            else if (cbortprint.SelectedValue.ToString() == "08" || cbortprint.SelectedValue.ToString() == "22") //"Purchase Delivery"
            {
                ClsAutoNumber1.VoucherLatestNum("PD", cboCNCode.SelectedValue.ToString());
                txtDocNum.Text = (ClsAutoNumber1.plsnumber);
            }
            else if (cbortprint.SelectedValue.ToString() == "09" || cbortprint.SelectedValue.ToString() == "25") //"Return to Supplier"
            {
                ClsAutoNumber1.VoucherLatestNum("RTS", cboCNCode.SelectedValue.ToString());
                txtDocNum.Text = (ClsAutoNumber1.plsnumber);
            }
            else if (cbortprint.SelectedValue.ToString() == "10" || cbortprint.SelectedValue.ToString() == "21") //"Charge Invoice"
            {
                ClsAutoNumber1.VoucherLatestNum("CI", cboCNCode.SelectedValue.ToString());
                txtDocNum.Text = (ClsAutoNumber1.plsnumber);
            }
            else if (cbortprint.SelectedValue.ToString() == "11" || cbortprint.SelectedValue.ToString() == "23") //"Cash Sales"
            {
                ClsAutoNumber1.VoucherLatestNum("CS", cboCNCode.SelectedValue.ToString());
                txtDocNum.Text = (ClsAutoNumber1.plsnumber);
            }
            else if (cbortprint.SelectedValue.ToString() == "12" || cbortprint.SelectedValue.ToString() == "24") //"Return Slip"
            {
                ClsAutoNumber1.VoucherLatestNum("RS", cboCNCode.SelectedValue.ToString());
                txtDocNum.Text = (ClsAutoNumber1.plsnumber);
            }
            else if (cbortprint.SelectedValue.ToString() == "13") //"Transfer Slip"
            {
                ClsAutoNumber1.VoucherLatestNum("TS", cboCNCode.SelectedValue.ToString());
                txtDocNum.Text = (ClsAutoNumber1.plsnumber);
            }
            else if (cbortprint.SelectedValue.ToString() == "14" || cbortprint.SelectedValue.ToString() == "20") //"Adjustment Slip"
            {
                ClsAutoNumber1.VoucherLatestNum("AS", cboCNCode.SelectedValue.ToString());
                txtDocNum.Text = (ClsAutoNumber1.plsnumber);
            }
            else if (cbortprint.SelectedValue.ToString() == "15" || cbortprint.SelectedValue.ToString() == "26") //"Withdrawal Slip"
            {
                ClsAutoNumber1.VoucherLatestNum("WS", cboCNCode.SelectedValue.ToString());
                txtDocNum.Text = (ClsAutoNumber1.plsnumber);
            }
            else if (cbortprint.SelectedValue.ToString() == "16" || cbortprint.SelectedValue.ToString() == "27") //"Production Slip"
            {
                ClsAutoNumber1.VoucherLatestNum("PS", cboCNCode.SelectedValue.ToString());
                txtDocNum.Text = (ClsAutoNumber1.plsnumber);
            }
            else if (cbortprint.SelectedValue.ToString() == "17") //"Actual Inventory"
            {
                ClsAutoNumber1.VoucherLatestNumAI("AI", cboCNCode.SelectedValue.ToString());
                txtDocNum.Text = (ClsAutoNumber1.plsnumber);
            }
            else if (cbortprint.SelectedValue.ToString() == "18") //"CRV"
            {
                ClsAutoNumber1.VoucherLatestNum("CRV", cboCNCode.SelectedValue.ToString());
                txtDocNum.Text = (ClsAutoNumber1.plsnumber);
            }
            else if (cbortprint.SelectedValue.ToString() == "19" || cbortprint.SelectedValue.ToString() == "28") //"PI" "JO"
            {
                ClsAutoNumber1.VoucherLatestNumPI();
                txtDocNum.Text = (ClsAutoNumber1.plsnumber);
            }
            else if (cbortprint.SelectedValue.ToString() == "29" || cbortprint.SelectedValue.ToString() == "30") //"Withdrawal Slip"
            {
                ClsAutoNumber1.VoucherLatestNum("OS", cboCNCode.SelectedValue.ToString());
                txtDocNum.Text = (ClsAutoNumber1.plsnumber);
            }

        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            strchoose = "2";
            prevprint();

        }

        private void nextfieldenter1(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.Equals(Keys.Enter))
            {
                SendKeys.Send("{TAB}");
            }
            else if ((e.KeyCode.Equals(Keys.Up)) || (e.KeyCode.Equals(Keys.Left)))
            {
                SendKeys.Send("+{TAB}");
            }
            else if ((e.KeyCode.Equals(Keys.Down)) || (e.KeyCode.Equals(Keys.Right)))
            {
                SendKeys.Send("{TAB}");
            }

        }

        private void nextfieldenter2(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.Equals(Keys.Enter))
            {
                SendKeys.Send("{TAB}");
            }

        }

     }
}
