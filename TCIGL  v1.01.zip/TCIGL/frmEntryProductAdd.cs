﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TCIGL
{
    public partial class frmEntryProductAdd : Form
    {
        SqlConnection myconnection;
        SqlCommand mycommand;
        ClsAutoNumber ClsAutoNumber1 = new ClsAutoNumber();
        ClsValidation ClsValidation1 = new ClsValidation();
        ClsBuildComboBox ClsBuildComboBox1 = new ClsBuildComboBox();
        ClsGetConnection ClsGetConnection1 = new ClsGetConnection();
        ClsBuildEntryComboBox ClsBuildEntryComboBox1 = new ClsBuildEntryComboBox();
        ClsPermission ClsPermission1 = new ClsPermission();
        public frmEntryProductAdd()
        {
            InitializeComponent();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        //public void createconnection()
        //{
        //    ClsGetConnection1.ClsGetConMSSQL();
        //    myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
        //}
        private void frmProductAdd_Load(object sender, EventArgs e)
        {
              ClsPermission1.ClsObjects(this.Text);
              if (new ClsValidation().emptytxt(ClsPermission1.plstxtObject))
              {
                  MessageBox.Show("You do not have necessary permission to open this file", "GL");
                  this.Close();
              }
              else
              {
                  ClsAutoNumber1.ProductAddAutNum();
                  txtStockNumber.Text = (ClsAutoNumber1.plsnumber);
                  buildcboCatCode();
                  buildcboInvClassCode();
                  buildcboSupplierCode();
                  cboSupplierCode.SelectedValue = "";
                  cboInvClassCode.SelectedValue = "";
                  cboCatCode.SelectedValue = "";
              }
        }
        private void buildcboCatCode()
        {
            cboCatCode.DataSource = null;
            ClsBuildEntryComboBox1.ARCatCode.Clear();
            ClsBuildEntryComboBox1.ClsBuildCatCode();
            this.cboCatCode.DataSource = (ClsBuildEntryComboBox1.ARCatCode);
            this.cboCatCode.DisplayMember = "Display";
            this.cboCatCode.ValueMember = "Value";
        }

        private void buildcboInvClassCode()
        {
            cboInvClassCode.DataSource = null;
            ClsBuildComboBox1.InvClassCode.Clear();
            ClsBuildComboBox1.ClsBuildInviClassCode();
            cboInvClassCode.DataSource = (ClsBuildComboBox1.InvClassCode);
            cboInvClassCode.DisplayMember = "Display";
            cboInvClassCode.ValueMember = "Value";
        }

        private void buildcboSupplierCode()
        {
            cboSupplierCode.DataSource = null;
            ClsBuildEntryComboBox1.ARSupplierCode.Clear();
            ClsBuildEntryComboBox1.ClsBuildSupplierCode();
            this.cboSupplierCode.DataSource = (ClsBuildEntryComboBox1.ARSupplierCode);
            this.cboSupplierCode.DisplayMember = "Display";
            this.cboSupplierCode.ValueMember = "Value";
        }
 

        private void btnSave_Click(object sender, EventArgs e)
        {
            Save();
        }
        private void Save()
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
               if (new ClsValidation().emptytxt(txtStockDesc.Text) || new ClsValidation().emptytxt(txtStockDesc.Text) || new ClsValidation().emptytxt(cboCatCode.Text)
                || new ClsValidation().emptytxt(txtStockCode.Text) || new ClsValidation().emptytxt(cboSupplierCode.Text) || new ClsValidation().emptytxt(txtUM.Text) || new ClsValidation().emptytxt(txtSize.Text) || new ClsValidation().emptytxt(cboInvClassCode.Text))
                {
                    myconnection.Close();
                    MessageBox.Show("Please complete your entry", "STOCK ADD");
                    txtStockCode.Focus();
                }
                else
                {
                    ClsAutoNumber1.ProductAddAutNum();
                    txtStockNumber.Text = (ClsAutoNumber1.plsnumber);
                    string sqlstatement;
                    sqlstatement = "INSERT INTO tblStocks (StockNumber, StockCode, StockDesc, UM, CatCode, SupplierCode, UCost, SellingPrice, ReorderPoint, MaintainingBal, Size, InvClassCode)";
                    sqlstatement += "Values (@_StockNumber, @_StockCode, @_StockDesc, @_UM, @_CatCode, @_SupplierCode, @_UCost, @_SellingPrice, @_ReorderPoint, @_MaintainingBal, @_Size, @_InvClassCode)";
                    mycommand = new SqlCommand(sqlstatement, myconnection);
                    mycommand.Parameters.Add("_StockNumber", SqlDbType.VarChar).Value = txtStockNumber.Text;
                    mycommand.Parameters.Add("_StockCode", SqlDbType.VarChar).Value = txtStockCode.Text;
                    mycommand.Parameters.Add("_StockDesc", SqlDbType.VarChar).Value = txtStockDesc.Text;
                    mycommand.Parameters.Add("_UM", SqlDbType.VarChar).Value = txtUM.Text;
                    mycommand.Parameters.Add("_CatCode", SqlDbType.Char).Value = cboCatCode.SelectedValue.ToString();
                    mycommand.Parameters.Add("_SupplierCode", SqlDbType.Char).Value = cboSupplierCode.SelectedValue.ToString();
                    mycommand.Parameters.Add("_UCost", SqlDbType.Money).Value = txtUCost.Text;
                    mycommand.Parameters.Add("_SellingPrice", SqlDbType.Money).Value = txtSP.Text;
                    mycommand.Parameters.Add("_ReorderPoint", SqlDbType.Money).Value = txtReorderPoint.Text;
                    mycommand.Parameters.Add("_MaintainingBal", SqlDbType.Money).Value = txtMaintainingBal.Text;
                    mycommand.Parameters.Add("_Size", SqlDbType.VarChar).Value = txtSize.Text;
                    mycommand.Parameters.Add("_InvClassCode", SqlDbType.Char).Value = cboInvClassCode.SelectedValue.ToString();


                    int n1 = mycommand.ExecuteNonQuery();
                    myconnection.Close();
                    ClsAutoNumber1.ProductAddAutNum();
                    txtStockNumber.Text = (ClsAutoNumber1.plsnumber);
                    txtStockCode.Clear();
                    txtStockCode.Focus();
                    txtStockDesc.Clear();
                    txtUM.Clear();
                    cboCatCode.SelectedValue = "";
                    cboSupplierCode.SelectedValue = "";
                    txtUCost.Text = "0.00";
                    txtSP.Text = "0.00";
                    txtReorderPoint.Text = "0";
                    txtMaintainingBal.Text = "0";                    
                    txtSize.Text = "NA";
                }
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                //dr.Close();
                myconnection.Close();
            }
        }

        private void txtUCost_Validating(object sender, CancelEventArgs e)
        {
            if (new ClsValidation().isDouble(txtUCost.Text) == true)
            {
                MessageBox.Show("Invalid Amount", "PRODUCT ADD");
                txtUCost.Focus();
            }
            else
            {
                txtUCost.Text = Convert.ToDouble(txtUCost.Text).ToString("N4");
            }
        }

   

        private void txtReorderPoint_Validating(object sender, CancelEventArgs e)
        {
            if (new ClsValidation().isInt(txtReorderPoint.Text) == true)
            {
                MessageBox.Show("Invalid Number", "GL");
                txtReorderPoint.Focus();
            }
        }

        private void txtMaintainingBal_Validating(object sender, CancelEventArgs e)
        {
            if (new ClsValidation().isInt(txtMaintainingBal.Text) == true)
            {
                MessageBox.Show("Invalid Number", "GL");
                txtMaintainingBal.Focus();
            }
        }

        private void txtSP_Validating(object sender, CancelEventArgs e)
        {
            if (new ClsValidation().isDouble(txtSP.Text) == true)
            {
                MessageBox.Show("Invalid Amount", "PRODUCT ADD");
                txtSP.Focus();
            }
            else
            {
                txtSP.Text = Convert.ToDouble(txtSP.Text).ToString("N2");
            }
        }

        private void nextfieldenter1(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.Equals(Keys.Enter))
            {
                SendKeys.Send("{TAB}");
            }
            else if ((e.KeyCode.Equals(Keys.Up)) || (e.KeyCode.Equals(Keys.Left)))
            {
                SendKeys.Send("+{TAB}");
            }
            else if ((e.KeyCode.Equals(Keys.Down)) || (e.KeyCode.Equals(Keys.Right)))
            {
                SendKeys.Send("{TAB}");
            }
        }
        private void nextfieldenter2(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.Equals(Keys.Enter))
            {
                SendKeys.Send("{TAB}");
            }
        }

        private void cboCatCode_Validating(object sender, CancelEventArgs e)
        {
            if (new ClsValidation().emptytxt(cboCatCode.Text))
            {
            }
            else if (cboCatCode.Text != null && cboCatCode.SelectedValue == null)
            {
                MessageBox.Show("Not found", "GL");
                cboCatCode.Focus();
            }
        }

        private void cboSupplierCode_Validating(object sender, CancelEventArgs e)
        {
            if (new ClsValidation().emptytxt(cboSupplierCode.Text))
            {
            }
            else if (cboSupplierCode.Text != null && cboSupplierCode.SelectedValue == null)
            {
                MessageBox.Show("Not found", "GL");
                cboSupplierCode.Focus();
            }
        }

        private void txtStockDesc_Validating(object sender, CancelEventArgs e)
        {
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();
            if (new Clsexist().RecordExists(ref myconnection, "SELECT StockDesc FROM tblStocks WHERE StockDesc = '" + txtStockDesc.Text + "'"))
            {
                MessageBox.Show("Duplicate Product Name", "STOCK ADD");
                txtStockDesc.Focus();
            }
            myconnection.Close();
        }

        private void txtStockCode_Validating(object sender, CancelEventArgs e)
        {
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();
            if (new Clsexist().RecordExists(ref myconnection, "SELECT StockCode FROM tblStocks WHERE StockCode = '" + txtStockCode.Text + "'"))
            {
                myconnection.Close();
                MessageBox.Show("Duplicate Product Code", "STOCK ADD");
                txtStockCode.Focus();
            }
            myconnection.Close();
        }
    }
}
