﻿namespace TCIGL
{
    partial class frmVoucherCS
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            this.label2 = new System.Windows.Forms.Label();
            this.txtTDate = new System.Windows.Forms.MaskedTextBox();
            this.txtreference = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.cboControlNo = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtRemarks = new System.Windows.Forms.TextBox();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.txtDocNum = new System.Windows.Forms.TextBox();
            this.txtTotCost = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtTotDisct = new System.Windows.Forms.TextBox();
            this.txtTotNet = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtCheckNo = new System.Windows.Forms.TextBox();
            this.txtCAmount = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.btnPE = new System.Windows.Forms.Button();
            this.cboASMCode = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtSPO = new System.Windows.Forms.TextBox();
            this.txtTotVAT = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtdrtot = new System.Windows.Forms.TextBox();
            this.txtcrtot = new System.Windows.Forms.TextBox();
            this.txtDifference = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtTReceivable = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.cboWHCode = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.cbSP = new System.Windows.Forms.CheckBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.txtOverAllDisct = new System.Windows.Forms.TextBox();
            this.cbVAT = new System.Windows.Forms.CheckBox();
            this.txtActDisct = new System.Windows.Forms.TextBox();
            this.dgv1 = new TCIGL.moveNextCellDataGridView();
            this.cboPA = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtrefer = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtDR = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtCR = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumncbdgvSIT = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dgv2 = new TCIGL.moveNextCellDataGridView();
            this.ColumnD1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnStockNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnItem = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnUP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnActDisct = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnPDisct = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnVAT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnTotal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnCost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnWHCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgv1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv2)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(22, 119);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 19);
            this.label2.TabIndex = 31;
            this.label2.Text = "Date:";
            // 
            // txtTDate
            // 
            this.txtTDate.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTDate.Location = new System.Drawing.Point(27, 141);
            this.txtTDate.Mask = "00/00/0000";
            this.txtTDate.Name = "txtTDate";
            this.txtTDate.Size = new System.Drawing.Size(82, 26);
            this.txtTDate.TabIndex = 1;
            this.txtTDate.ValidatingType = typeof(System.DateTime);
            this.txtTDate.KeyDown += new System.Windows.Forms.KeyEventHandler(this.nextfieldenter1);
            this.txtTDate.Validating += new System.ComponentModel.CancelEventHandler(this.txtTDate_Validating);
            // 
            // txtreference
            // 
            this.txtreference.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtreference.Location = new System.Drawing.Point(146, 141);
            this.txtreference.Name = "txtreference";
            this.txtreference.Size = new System.Drawing.Size(127, 26);
            this.txtreference.TabIndex = 2;
            this.txtreference.KeyDown += new System.Windows.Forms.KeyEventHandler(this.nextfieldenter1);
            this.txtreference.Validating += new System.ComponentModel.CancelEventHandler(this.txtreference_Validating);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(142, 119);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 19);
            this.label1.TabIndex = 33;
            this.label1.Text = "Reference:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(303, 59);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 19);
            this.label3.TabIndex = 35;
            this.label3.Text = "Customer:";
            // 
            // cboControlNo
            // 
            this.cboControlNo.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cboControlNo.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cboControlNo.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboControlNo.FormattingEnabled = true;
            this.cboControlNo.Location = new System.Drawing.Point(307, 80);
            this.cboControlNo.Name = "cboControlNo";
            this.cboControlNo.Size = new System.Drawing.Size(267, 27);
            this.cboControlNo.TabIndex = 3;
            this.cboControlNo.KeyDown += new System.Windows.Forms.KeyEventHandler(this.nextfieldenter2);
            this.cboControlNo.Validating += new System.ComponentModel.CancelEventHandler(this.cboCustCode_Validating);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(314, 583);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(66, 19);
            this.label11.TabIndex = 40;
            this.label11.Text = "Remarks:";
            this.label11.Visible = false;
            // 
            // txtRemarks
            // 
            this.txtRemarks.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRemarks.Location = new System.Drawing.Point(599, 142);
            this.txtRemarks.Name = "txtRemarks";
            this.txtRemarks.Size = new System.Drawing.Size(473, 26);
            this.txtRemarks.TabIndex = 7;
            this.txtRemarks.Text = "Cash Sales";
            // 
            // btnClose
            // 
            this.btnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnClose.Location = new System.Drawing.Point(960, 541);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(112, 61);
            this.btnClose.TabIndex = 11;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(842, 541);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(112, 61);
            this.btnSave.TabIndex = 10;
            this.btnSave.Text = "Save - F6";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // txtDocNum
            // 
            this.txtDocNum.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDocNum.Location = new System.Drawing.Point(987, 15);
            this.txtDocNum.Name = "txtDocNum";
            this.txtDocNum.ReadOnly = true;
            this.txtDocNum.Size = new System.Drawing.Size(85, 26);
            this.txtDocNum.TabIndex = 52;
            this.txtDocNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtTotCost
            // 
            this.txtTotCost.Location = new System.Drawing.Point(149, 578);
            this.txtTotCost.Name = "txtTotCost";
            this.txtTotCost.ReadOnly = true;
            this.txtTotCost.Size = new System.Drawing.Size(77, 20);
            this.txtTotCost.TabIndex = 105;
            this.txtTotCost.Text = "0.00";
            this.txtTotCost.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(22, 541);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(116, 15);
            this.label8.TabIndex = 106;
            this.label8.Text = "TOTAL DISCOUNT:";
            // 
            // txtTotDisct
            // 
            this.txtTotDisct.AcceptsReturn = true;
            this.txtTotDisct.Location = new System.Drawing.Point(149, 536);
            this.txtTotDisct.Name = "txtTotDisct";
            this.txtTotDisct.ReadOnly = true;
            this.txtTotDisct.Size = new System.Drawing.Size(77, 20);
            this.txtTotDisct.TabIndex = 156;
            this.txtTotDisct.Text = "0.00";
            this.txtTotDisct.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtTotNet
            // 
            this.txtTotNet.Location = new System.Drawing.Point(149, 557);
            this.txtTotNet.Name = "txtTotNet";
            this.txtTotNet.ReadOnly = true;
            this.txtTotNet.Size = new System.Drawing.Size(77, 20);
            this.txtTotNet.TabIndex = 170;
            this.txtTotNet.Text = "0.00";
            this.txtTotNet.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtTotNet.TextChanged += new System.EventHandler(this.txtTotNet_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(596, 59);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 19);
            this.label4.TabIndex = 173;
            this.label4.Text = "Check No.:";
            // 
            // txtCheckNo
            // 
            this.txtCheckNo.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCheckNo.Location = new System.Drawing.Point(599, 81);
            this.txtCheckNo.Name = "txtCheckNo";
            this.txtCheckNo.Size = new System.Drawing.Size(163, 26);
            this.txtCheckNo.TabIndex = 5;
            this.txtCheckNo.Text = "NA";
            this.txtCheckNo.KeyDown += new System.Windows.Forms.KeyEventHandler(this.nextfieldenter1);
            // 
            // txtCAmount
            // 
            this.txtCAmount.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCAmount.Location = new System.Drawing.Point(912, 81);
            this.txtCAmount.Name = "txtCAmount";
            this.txtCAmount.Size = new System.Drawing.Size(160, 26);
            this.txtCAmount.TabIndex = 6;
            this.txtCAmount.Text = "0.00";
            this.txtCAmount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCAmount.KeyDown += new System.Windows.Forms.KeyEventHandler(this.nextfieldenter1);
            this.txtCAmount.Validating += new System.ComponentModel.CancelEventHandler(this.txtCAmount_Validating);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(908, 59);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(60, 19);
            this.label6.TabIndex = 176;
            this.label6.Text = "Amount:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(23, 562);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(75, 15);
            this.label7.TabIndex = 177;
            this.label7.Text = "NET SALES:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(23, 583);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(85, 15);
            this.label9.TabIndex = 178;
            this.label9.Text = "TOTAL COST:";
            // 
            // btnPE
            // 
            this.btnPE.Location = new System.Drawing.Point(724, 541);
            this.btnPE.Name = "btnPE";
            this.btnPE.Size = new System.Drawing.Size(112, 61);
            this.btnPE.TabIndex = 9;
            this.btnPE.Text = "Product Entry - F5";
            this.btnPE.UseVisualStyleBackColor = true;
            this.btnPE.Click += new System.EventHandler(this.btnPE_Click);
            // 
            // cboASMCode
            // 
            this.cboASMCode.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cboASMCode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cboASMCode.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboASMCode.FormattingEnabled = true;
            this.cboASMCode.Location = new System.Drawing.Point(307, 142);
            this.cboASMCode.Name = "cboASMCode";
            this.cboASMCode.Size = new System.Drawing.Size(267, 27);
            this.cboASMCode.TabIndex = 4;
            this.cboASMCode.KeyDown += new System.Windows.Forms.KeyEventHandler(this.nextfieldenter2);
            this.cboASMCode.Validating += new System.ComponentModel.CancelEventHandler(this.cboSMCode_Validating);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(303, 120);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(69, 19);
            this.label12.TabIndex = 194;
            this.label12.Text = "Salesman:";
            // 
            // txtSPO
            // 
            this.txtSPO.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSPO.Location = new System.Drawing.Point(774, 12);
            this.txtSPO.Name = "txtSPO";
            this.txtSPO.Size = new System.Drawing.Size(62, 22);
            this.txtSPO.TabIndex = 199;
            this.txtSPO.Visible = false;
            // 
            // txtTotVAT
            // 
            this.txtTotVAT.AcceptsReturn = true;
            this.txtTotVAT.Location = new System.Drawing.Point(371, 539);
            this.txtTotVAT.Name = "txtTotVAT";
            this.txtTotVAT.ReadOnly = true;
            this.txtTotVAT.Size = new System.Drawing.Size(77, 20);
            this.txtTotVAT.TabIndex = 201;
            this.txtTotVAT.Text = "0.00";
            this.txtTotVAT.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(289, 541);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(76, 15);
            this.label13.TabIndex = 200;
            this.label13.Text = "TOTAL VAT:";
            // 
            // txtdrtot
            // 
            this.txtdrtot.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdrtot.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.txtdrtot.Location = new System.Drawing.Point(599, 41);
            this.txtdrtot.Name = "txtdrtot";
            this.txtdrtot.ReadOnly = true;
            this.txtdrtot.Size = new System.Drawing.Size(77, 20);
            this.txtdrtot.TabIndex = 204;
            this.txtdrtot.Text = "0.00";
            this.txtdrtot.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtdrtot.Visible = false;
            // 
            // txtcrtot
            // 
            this.txtcrtot.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcrtot.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.txtcrtot.Location = new System.Drawing.Point(684, 15);
            this.txtcrtot.Name = "txtcrtot";
            this.txtcrtot.ReadOnly = true;
            this.txtcrtot.Size = new System.Drawing.Size(64, 20);
            this.txtcrtot.TabIndex = 203;
            this.txtcrtot.Text = "0.00";
            this.txtcrtot.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtcrtot.Visible = false;
            // 
            // txtDifference
            // 
            this.txtDifference.Location = new System.Drawing.Point(599, 15);
            this.txtDifference.Name = "txtDifference";
            this.txtDifference.Size = new System.Drawing.Size(77, 20);
            this.txtDifference.TabIndex = 202;
            this.txtDifference.Text = "0.00";
            this.txtDifference.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtDifference.Visible = false;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(239, 559);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(126, 15);
            this.label14.TabIndex = 206;
            this.label14.Text = "TOTAL RECEIVABLE:";
            // 
            // txtTReceivable
            // 
            this.txtTReceivable.AcceptsReturn = true;
            this.txtTReceivable.Location = new System.Drawing.Point(371, 560);
            this.txtTReceivable.Name = "txtTReceivable";
            this.txtTReceivable.ReadOnly = true;
            this.txtTReceivable.Size = new System.Drawing.Size(77, 20);
            this.txtTReceivable.TabIndex = 205;
            this.txtTReceivable.Text = "0.00";
            this.txtTReceivable.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(595, 120);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(66, 19);
            this.label5.TabIndex = 207;
            this.label5.Text = "Remarks:";
            // 
            // cboWHCode
            // 
            this.cboWHCode.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cboWHCode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cboWHCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboWHCode.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboWHCode.FormattingEnabled = true;
            this.cboWHCode.Location = new System.Drawing.Point(25, 81);
            this.cboWHCode.Name = "cboWHCode";
            this.cboWHCode.Size = new System.Drawing.Size(248, 27);
            this.cboWHCode.TabIndex = 0;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(22, 59);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(80, 19);
            this.label10.TabIndex = 209;
            this.label10.Text = "Warehouse:";
            // 
            // cbSP
            // 
            this.cbSP.AutoSize = true;
            this.cbSP.Location = new System.Drawing.Point(25, 12);
            this.cbSP.Name = "cbSP";
            this.cbSP.Size = new System.Drawing.Size(102, 17);
            this.cbSP.TabIndex = 210;
            this.cbSP.Text = "Save and Print?";
            this.cbSP.UseVisualStyleBackColor = true;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.Red;
            this.label22.Location = new System.Drawing.Point(133, 7);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(262, 22);
            this.label22.TabIndex = 238;
            this.label22.Text = "Press F5 to open entry window";
            this.label22.Visible = false;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(773, 59);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(96, 19);
            this.label15.TabIndex = 242;
            this.label15.Text = "Total Discount";
            // 
            // txtOverAllDisct
            // 
            this.txtOverAllDisct.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOverAllDisct.Location = new System.Drawing.Point(777, 81);
            this.txtOverAllDisct.Name = "txtOverAllDisct";
            this.txtOverAllDisct.Size = new System.Drawing.Size(123, 26);
            this.txtOverAllDisct.TabIndex = 241;
            this.txtOverAllDisct.Text = "0.00";
            this.txtOverAllDisct.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtOverAllDisct.Validating += new System.ComponentModel.CancelEventHandler(this.txtOverAllDisct_Validating);
            // 
            // cbVAT
            // 
            this.cbVAT.AutoSize = true;
            this.cbVAT.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbVAT.Location = new System.Drawing.Point(459, 539);
            this.cbVAT.Name = "cbVAT";
            this.cbVAT.Size = new System.Drawing.Size(59, 24);
            this.cbVAT.TabIndex = 243;
            this.cbVAT.Text = "VAT";
            this.cbVAT.UseVisualStyleBackColor = true;
            this.cbVAT.CheckedChanged += new System.EventHandler(this.cbVAT_CheckedChanged);
            this.cbVAT.Validating += new System.ComponentModel.CancelEventHandler(this.cbVAT_Validating);
            // 
            // txtActDisct
            // 
            this.txtActDisct.Location = new System.Drawing.Point(535, 7);
            this.txtActDisct.Name = "txtActDisct";
            this.txtActDisct.Size = new System.Drawing.Size(45, 20);
            this.txtActDisct.TabIndex = 244;
            this.txtActDisct.Visible = false;
            // 
            // dgv1
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgv1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.cboPA,
            this.txtrefer,
            this.txtDR,
            this.txtCR,
            this.ColumncbdgvSIT});
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv1.DefaultCellStyle = dataGridViewCellStyle6;
            this.dgv1.Location = new System.Drawing.Point(197, -7);
            this.dgv1.Name = "dgv1";
            this.dgv1.Size = new System.Drawing.Size(315, 63);
            this.dgv1.TabIndex = 198;
            this.dgv1.Visible = false;
            // 
            // cboPA
            // 
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.cboPA.DefaultCellStyle = dataGridViewCellStyle2;
            this.cboPA.HeaderText = "Account Number";
            this.cboPA.Name = "cboPA";
            this.cboPA.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.cboPA.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.cboPA.Width = 120;
            // 
            // txtrefer
            // 
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.txtrefer.DefaultCellStyle = dataGridViewCellStyle3;
            this.txtrefer.HeaderText = "Reference";
            this.txtrefer.Name = "txtrefer";
            this.txtrefer.Width = 120;
            // 
            // txtDR
            // 
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.txtDR.DefaultCellStyle = dataGridViewCellStyle4;
            this.txtDR.HeaderText = "Debit";
            this.txtDR.Name = "txtDR";
            // 
            // txtCR
            // 
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.txtCR.DefaultCellStyle = dataGridViewCellStyle5;
            this.txtCR.HeaderText = "Credit";
            this.txtCR.Name = "txtCR";
            // 
            // ColumncbdgvSIT
            // 
            this.ColumncbdgvSIT.HeaderText = "SIT";
            this.ColumncbdgvSIT.Name = "ColumncbdgvSIT";
            this.ColumncbdgvSIT.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.ColumncbdgvSIT.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.ColumncbdgvSIT.Width = 50;
            // 
            // dgv2
            // 
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dgv2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColumnD1,
            this.ColumnStockNumber,
            this.ColumnItem,
            this.ColumnQty,
            this.ColumnUP,
            this.ColumnActDisct,
            this.ColumnPDisct,
            this.ColumnVAT,
            this.ColumnTotal,
            this.ColumnCost,
            this.ColumnWHCode});
            this.dgv2.Location = new System.Drawing.Point(26, 195);
            this.dgv2.Name = "dgv2";
            this.dgv2.ReadOnly = true;
            dataGridViewCellStyle15.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgv2.RowsDefaultCellStyle = dataGridViewCellStyle15;
            this.dgv2.Size = new System.Drawing.Size(1046, 335);
            this.dgv2.TabIndex = 8;
            this.dgv2.UserDeletedRow += new System.Windows.Forms.DataGridViewRowEventHandler(this.dgv2_UserDeletedRow);
            // 
            // ColumnD1
            // 
            this.ColumnD1.HeaderText = "D1";
            this.ColumnD1.Name = "ColumnD1";
            this.ColumnD1.ReadOnly = true;
            this.ColumnD1.Visible = false;
            // 
            // ColumnStockNumber
            // 
            this.ColumnStockNumber.HeaderText = "Stock Number";
            this.ColumnStockNumber.Name = "ColumnStockNumber";
            this.ColumnStockNumber.ReadOnly = true;
            this.ColumnStockNumber.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.ColumnStockNumber.Width = 120;
            // 
            // ColumnItem
            // 
            this.ColumnItem.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ColumnItem.HeaderText = "Description";
            this.ColumnItem.Name = "ColumnItem";
            this.ColumnItem.ReadOnly = true;
            // 
            // ColumnQty
            // 
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.ColumnQty.DefaultCellStyle = dataGridViewCellStyle8;
            this.ColumnQty.HeaderText = "Qty";
            this.ColumnQty.Name = "ColumnQty";
            this.ColumnQty.ReadOnly = true;
            this.ColumnQty.Width = 50;
            // 
            // ColumnUP
            // 
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.ColumnUP.DefaultCellStyle = dataGridViewCellStyle9;
            this.ColumnUP.HeaderText = "Unit Price";
            this.ColumnUP.Name = "ColumnUP";
            this.ColumnUP.ReadOnly = true;
            this.ColumnUP.Width = 90;
            // 
            // ColumnActDisct
            // 
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.ColumnActDisct.DefaultCellStyle = dataGridViewCellStyle10;
            this.ColumnActDisct.HeaderText = "% Disct";
            this.ColumnActDisct.Name = "ColumnActDisct";
            this.ColumnActDisct.ReadOnly = true;
            this.ColumnActDisct.Width = 75;
            // 
            // ColumnPDisct
            // 
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.ColumnPDisct.DefaultCellStyle = dataGridViewCellStyle11;
            this.ColumnPDisct.HeaderText = "P Disct";
            this.ColumnPDisct.Name = "ColumnPDisct";
            this.ColumnPDisct.ReadOnly = true;
            this.ColumnPDisct.Width = 75;
            // 
            // ColumnVAT
            // 
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.ColumnVAT.DefaultCellStyle = dataGridViewCellStyle12;
            this.ColumnVAT.HeaderText = "VAT";
            this.ColumnVAT.Name = "ColumnVAT";
            this.ColumnVAT.ReadOnly = true;
            this.ColumnVAT.Width = 70;
            // 
            // ColumnTotal
            // 
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.ColumnTotal.DefaultCellStyle = dataGridViewCellStyle13;
            this.ColumnTotal.HeaderText = "Total";
            this.ColumnTotal.Name = "ColumnTotal";
            this.ColumnTotal.ReadOnly = true;
            this.ColumnTotal.Width = 90;
            // 
            // ColumnCost
            // 
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.ColumnCost.DefaultCellStyle = dataGridViewCellStyle14;
            this.ColumnCost.HeaderText = "Cost";
            this.ColumnCost.Name = "ColumnCost";
            this.ColumnCost.ReadOnly = true;
            this.ColumnCost.Width = 90;
            // 
            // ColumnWHCode
            // 
            this.ColumnWHCode.HeaderText = "Warehouse";
            this.ColumnWHCode.Name = "ColumnWHCode";
            this.ColumnWHCode.ReadOnly = true;
            this.ColumnWHCode.Visible = false;
            // 
            // frmVoucherCS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnClose;
            this.ClientSize = new System.Drawing.Size(1100, 611);
            this.Controls.Add(this.txtActDisct);
            this.Controls.Add(this.cbVAT);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.txtOverAllDisct);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.cbSP);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.cboWHCode);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.txtTReceivable);
            this.Controls.Add(this.txtdrtot);
            this.Controls.Add(this.txtcrtot);
            this.Controls.Add(this.txtDifference);
            this.Controls.Add(this.txtTotVAT);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.txtSPO);
            this.Controls.Add(this.dgv1);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.cboASMCode);
            this.Controls.Add(this.btnPE);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtCAmount);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtCheckNo);
            this.Controls.Add(this.txtTotNet);
            this.Controls.Add(this.txtTotDisct);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtTotCost);
            this.Controls.Add(this.dgv2);
            this.Controls.Add(this.txtDocNum);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.txtRemarks);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cboControlNo);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtreference);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtTDate);
            this.KeyPreview = true;
            this.Name = "frmVoucherCS";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cash Sales";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmVoucherCS_FormClosing);
            this.Load += new System.EventHandler(this.frmVoucherSales_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frmVoucherSales_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.dgv1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.MaskedTextBox txtTDate;
        private System.Windows.Forms.TextBox txtreference;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cboControlNo;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtRemarks;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.TextBox txtDocNum;
        private moveNextCellDataGridView dgv2;
        private System.Windows.Forms.TextBox txtTotCost;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtTotDisct;
        private System.Windows.Forms.TextBox txtTotNet;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtCheckNo;
        private System.Windows.Forms.TextBox txtCAmount;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnPE;
        private System.Windows.Forms.ComboBox cboASMCode;
        private System.Windows.Forms.Label label12;
        private moveNextCellDataGridView dgv1;
        private System.Windows.Forms.DataGridViewTextBoxColumn cboPA;
        private System.Windows.Forms.DataGridViewTextBoxColumn txtrefer;
        private System.Windows.Forms.DataGridViewTextBoxColumn txtDR;
        private System.Windows.Forms.DataGridViewTextBoxColumn txtCR;
        private System.Windows.Forms.DataGridViewCheckBoxColumn ColumncbdgvSIT;
        private System.Windows.Forms.TextBox txtSPO;
        private System.Windows.Forms.TextBox txtTotVAT;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtdrtot;
        private System.Windows.Forms.TextBox txtcrtot;
        private System.Windows.Forms.TextBox txtDifference;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtTReceivable;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnD1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnStockNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnItem;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnUP;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnActDisct;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnPDisct;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnVAT;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnTotal;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnCost;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnWHCode;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cboWHCode;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.CheckBox cbSP;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtOverAllDisct;
        private System.Windows.Forms.CheckBox cbVAT;
        private System.Windows.Forms.TextBox txtActDisct;
    }
}