﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using CrystalDecisions.CrystalReports.Engine;
using System.Data.SqlClient;

namespace TCIGL
{
    public partial class frmrptAgingStatement : Form
    {
        SqlConnection myconnection;
        SqlCommand mycommand;
        BindingSource dbind = new BindingSource();
        ClsDefaultBranch ClsDefaultBranch1 = new ClsDefaultBranch();
        ClsCompName ClsCompName1 = new ClsCompName();
        ClsBuildComboBox ClsBuildComboBox1 = new ClsBuildComboBox();
        ClsGetSomething ClsGetSomething1 = new ClsGetSomething();
        ClsGetConnection ClsGetConnection1 = new ClsGetConnection(); 

        public frmrptAgingStatement()
        {
            InitializeComponent();
            cbortprint.DisplayMember = "Text";
            cbortprint.ValueMember = "Value";

            var items = new[]
            { 
             new { Text = "Statement of Accounts - 1", Value = "01" }, 
             new { Text = "Statement of Accounts - 2", Value = "02" }, 
            };
            cbortprint.DataSource = items;
        }

        private void frmrptLoanBalances_Load(object sender, EventArgs e)
        {
            buildcboCNCode();
            buildcboControlNo();
            cboCNCode.SelectedValue = (ClsDefaultBranch1.plsvardb);
            ClsGetSomething1.ClsGetDefaultDate ();
            txtEnterDate.Text = ClsGetSomething1.plsdefdate;
            this.WindowState = FormWindowState.Maximized;
        }

        private void buildcboCNCode()
        {
            cboCNCode.DataSource = null;
            ClsBuildComboBox1.ARBranch.Clear();
            ClsBuildComboBox1.ClsBuildBranch();
            this.cboCNCode.DataSource = (ClsBuildComboBox1.ARBranch);
            this.cboCNCode.DisplayMember = "Display";
            this.cboCNCode.ValueMember = "Value";
        }

        private void buildcboControlNo()
        {
            cboControlNo.DataSource = null;
            ClsBuildComboBox1.ARPCNStatement.Clear();
            ClsBuildComboBox1.ClsBuildCustControlnoStatement(cboCNCode.SelectedValue.ToString());
            this.cboControlNo.DataSource = (ClsBuildComboBox1.ARPCNStatement);
            this.cboControlNo.DisplayMember = "Display";
            this.cboControlNo.ValueMember = "Value";
        }

        private void btnPreview_Click(object sender, EventArgs e)
        {
            if ((new ClsValidation().emptytxt(cboControlNo.Text))||(new ClsValidation().emptytxt (cboCNCode.Text)))
            {
                MessageBox.Show("Please complete your entry", "GL");
                cboCNCode.Focus();
            }
            else if (txtEnterDate.Text == "  /  /")
            {
                MessageBox.Show("Please complete your entry", "GL");
                txtEnterDate.Focus();
            }
            else
            {
                if (cbortprint.SelectedValue.ToString()=="01")
                {
                    AgingStatement1();
                }
                else if (cbortprint.SelectedValue.ToString()=="02")
                {
                    AgingStatement2();
                }
                
            }
        }

        private void AgingStatement1()
        {
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();

            mycommand = new SqlCommand("usp_agingstatementcurrent", myconnection);
            mycommand.CommandType = CommandType.StoredProcedure;
            mycommand.Parameters.Add("@Paramenterdate", SqlDbType.DateTime).Value = txtEnterDate.Text;
            mycommand.Parameters.Add("@ParamCNCode", SqlDbType.VarChar).Value = cboCNCode.SelectedValue.ToString();
            mycommand.Parameters.Add("@ParamControlNo", SqlDbType.VarChar).Value = cboControlNo.SelectedValue.ToString();

            SqlDataAdapter dscmd = new SqlDataAdapter();
            dscmd.SelectCommand = mycommand;
            DSAgingAR DSAgingAR1 = new DSAgingAR();
            dscmd.Fill(DSAgingAR1, "viewagingcurrent");
            myconnection.Close();

            CRagingofarStatement objRpt = new CRagingofarStatement();
            TextObject varrpttocompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttoCompany"];
            varrpttocompany.Text = cboCNCode.Text;

            ClsGetSomething1.ClsGetBranchAddress(cboCNCode.SelectedValue.ToString());
            TextObject varrpttoaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttoaddress"];
            varrpttoaddress.Text = ClsGetSomething1.plsvarCAdress;

            TextObject varTextDate = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["TextDate"];
            varTextDate.Text = txtEnterDate.Text;

            TextObject varTextTitle = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["TextTitle"];
            varTextTitle.Text = "STATEMENT OF ACCOUNTS";

            TextObject varTextCustName = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["TextCustName"];
            varTextCustName.Text = cboControlNo.Text;

            ClsGetSomething1.ClsGetCustData(cboControlNo.SelectedValue.ToString());
            TextObject varTextAddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["TextAddress"];
            varTextAddress.Text = ClsGetSomething1.plsvarCustNameAdress;

            objRpt.SetDataSource(DSAgingAR1.Tables[1]);
            crystalReportViewer1.ReportSource = objRpt;
            crystalReportViewer1.Refresh();
        }

        private void AgingStatement2()
        {
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();

            mycommand = new SqlCommand("usp_agingARStatementWPDC", myconnection);
            mycommand.CommandType = CommandType.StoredProcedure;
            mycommand.Parameters.Add("@Paramenterdate", SqlDbType.DateTime).Value = txtEnterDate.Text;
            mycommand.Parameters.Add("@ParamCNCode", SqlDbType.VarChar).Value = cboCNCode.SelectedValue.ToString();
            mycommand.Parameters.Add("@ParamControlNo", SqlDbType.VarChar).Value = cboControlNo.SelectedValue.ToString();

            SqlDataAdapter dscmd = new SqlDataAdapter();
            dscmd.SelectCommand = mycommand;
            DSAgingAR DSAgingAR1 = new DSAgingAR();
            dscmd.Fill(DSAgingAR1, "viewagingcurrent");
            myconnection.Close();

            CRagingofARStatementWPDC objRpt = new CRagingofARStatementWPDC();
            TextObject varrpttocompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttoCompany"];
            varrpttocompany.Text = cboCNCode.Text;

            ClsGetSomething1.ClsGetBranchAddress(cboCNCode.SelectedValue.ToString());
            TextObject varrpttoaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttoaddress"];
            varrpttoaddress.Text = ClsGetSomething1.plsvarCAdress;

            TextObject varTextDate = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["TextDate"];
            varTextDate.Text = txtEnterDate.Text;

            TextObject varTextTitle = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["TextTitle"];
            varTextTitle.Text = "STATEMENT OF ACCOUNTS";

            TextObject varTextCustName = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["TextCustName"];
            varTextCustName.Text = cboControlNo.Text;

            ClsGetSomething1.ClsGetCustData(cboControlNo.SelectedValue.ToString());
            TextObject varTextAddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["TextAddress"];
            varTextAddress.Text = ClsGetSomething1.plsvarCustNameAdress;

            objRpt.SetDataSource(DSAgingAR1.Tables[1]);
            crystalReportViewer1.ReportSource = objRpt;
            crystalReportViewer1.Refresh();
        }


        private void txtEnterDate_Leave(object sender, EventArgs e)
        {
            if (new ClsValidation().errordate(txtEnterDate.Text) == true)
            {
                MessageBox.Show("Invalid Date", "GL");
                txtEnterDate.Focus();
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

   

        private void cboCNCode_Validating(object sender, CancelEventArgs e)
        {
            if (new ClsValidation().emptytxt(cboCNCode.Text))
            {
            }
            else if (cboCNCode.Text != null && cboCNCode.SelectedValue == null)
            {
                MessageBox.Show("Not found", "GL");
                cboCNCode.Focus();
            }
            else
            {
                buildcboControlNo();
            }
        }

        private void cboControlNo_Validating(object sender, CancelEventArgs e)
        {
            if (new ClsValidation().emptytxt(cboControlNo.Text))
            {
            }
            else if (cboControlNo.Text != null && cboControlNo.SelectedValue == null)
            {
                MessageBox.Show("Not found", "GL");
                cboControlNo.Focus();
            }
        }

        private void nextfieldenter1(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.Equals(Keys.Enter))
            {
                SendKeys.Send("{TAB}");
            }
            else if ((e.KeyCode.Equals(Keys.Up)) || (e.KeyCode.Equals(Keys.Left)))
            {
                SendKeys.Send("+{TAB}");
            }
            else if ((e.KeyCode.Equals(Keys.Down)) || (e.KeyCode.Equals(Keys.Right)))
            {
                SendKeys.Send("{TAB}");
            }

        }

        private void nextfieldenter2(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.Equals(Keys.Enter))
            {
                SendKeys.Send("{TAB}");
            }

        }
    }
}
