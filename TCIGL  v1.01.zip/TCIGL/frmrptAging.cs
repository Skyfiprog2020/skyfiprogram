﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using CrystalDecisions.CrystalReports.Engine;
using System.Data.SqlClient;

namespace TCIGL
{
    public partial class frmrptAging : Form
    {
        SqlConnection myconnection;
        SqlCommand mycommand;
        BindingSource dbind = new BindingSource();
        ClsDefaultBranch ClsDefaultBranch1 = new ClsDefaultBranch();
        ClsCompName ClsCompName1 = new ClsCompName();
        ClsBuildComboBox ClsBuildComboBox1 = new ClsBuildComboBox();
        ClsGetSomething ClsGetSomething1 = new ClsGetSomething();
        ClsGetConnection ClsGetConnection1 = new ClsGetConnection(); 

        public frmrptAging()
        {
            InitializeComponent();

            cbortprint.DisplayMember = "Text";
            cbortprint.ValueMember = "Value";

            var items = new[]
            { 
             new { Text = "Aging of Accounts Receivable", Value = "01" }, 
             new { Text = "Aging of Accounts Payable", Value = "02" }, 
             new { Text = "Aging of A/R with PDC", Value = "03" }, 
             new { Text = "Aging of A/P with PDC", Value = "04" }, 
            };
            cbortprint.DataSource = items;
        }

        private void frmrptLoanBalances_Load(object sender, EventArgs e)
        {
            buildcboCName();
            cboCNCode.SelectedValue = (ClsDefaultBranch1.plsvardb);
            ClsGetSomething1.ClsGetDefaultDate ();
            txtEnterDate.Text = ClsGetSomething1.plsdefdate;
            this.WindowState = FormWindowState.Maximized;
            cbortprint.Text = "Aging of Accounts Receivable";
        }

        private void buildcboCName()
        {
            cboCNCode.DataSource = null;
            ClsBuildComboBox1.ARBranch.Clear();
            ClsBuildComboBox1.ClsBuildBranch();
            this.cboCNCode.DataSource = (ClsBuildComboBox1.ARBranch);
            this.cboCNCode.DisplayMember = "Display";
            this.cboCNCode.ValueMember = "Value";
        }
        private void btnPreview_Click(object sender, EventArgs e)
        {
            if ((new ClsValidation().emptytxt(cbortprint.Text))||(new ClsValidation().emptytxt (cboCNCode.Text)))
            {
                MessageBox.Show("Please complete your entry", "GL");
                cbortprint.Focus();
            }
            else if (txtEnterDate.Text == "  /  /")
            {
                MessageBox.Show("Please complete your entry", "GL");
                txtEnterDate.Focus();
            }
            else
            {
                if (cbortprint.SelectedValue.ToString() == "01")//Aging of Accounts Receivable
                {
                    AgingReceive();
                }
                else if (cbortprint.SelectedValue.ToString() == "02")//Aging of Accounts Payable
                {
                    AgingPayable();
                }
                else if (cbortprint.SelectedValue.ToString() == "03")//Aging of A/R with PDC
                {
                    AgingARWithPDC();
                }

                else if (cbortprint.SelectedValue.ToString() == "04")//Aging of A/P with PDC
                {
                    AgingPayableWithPDC();
                }
            }

        }

        private void AgingReceive()
        {
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();

            mycommand = new SqlCommand("usp_agingcurrent", myconnection);
            mycommand.CommandType = CommandType.StoredProcedure;
            mycommand.Parameters.Add("@Paramenterdate", SqlDbType.DateTime).Value = txtEnterDate.Text;
            mycommand.Parameters.Add("@ParamCNCode", SqlDbType.VarChar).Value = cboCNCode.SelectedValue.ToString();

            SqlDataAdapter dscmd = new SqlDataAdapter();
            dscmd.SelectCommand = mycommand;
            DSAgingAR dsiv = new DSAgingAR();
            dscmd.Fill(dsiv, "viewagingcurrent");
            myconnection.Close();

            CRagingofar objRpt = new CRagingofar();
            TextObject varrpttocompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttoCompany"];
            varrpttocompany.Text = cboCNCode.Text;

            ClsGetSomething1.ClsGetBranchAddress(cboCNCode.SelectedValue.ToString());
            TextObject varrpttoaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttoaddress"];
            varrpttoaddress.Text = ClsGetSomething1.plsvarCAdress;

            TextObject varrpttoenterdate = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttoenterdate"];
            varrpttoenterdate.Text = "As of " + txtEnterDate.Text;

            TextObject varTextTitle = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["TextTitle"];
            varTextTitle.Text = "AGING OF ACCOUNTS RECEIVABLE";

            objRpt.SetDataSource(dsiv.Tables[1]);
            crystalReportViewer1.ReportSource = objRpt;
            crystalReportViewer1.Refresh();
        }


        private void AgingPayable()
        {
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();

            mycommand = new SqlCommand("usp_agingapcurrent", myconnection);
            mycommand.CommandType = CommandType.StoredProcedure;
            mycommand.Parameters.Add("@Paramenterdate", SqlDbType.DateTime).Value = txtEnterDate.Text;
            mycommand.Parameters.Add("@ParamCNCode", SqlDbType.VarChar).Value = cboCNCode.SelectedValue.ToString();

            SqlDataAdapter dscmd = new SqlDataAdapter();
            dscmd.SelectCommand = mycommand;
            DSAgingAR dsiv = new DSAgingAR();
            dscmd.Fill(dsiv, "viewagingapcurrent");
            myconnection.Close();

            CRagingofar objRpt = new CRagingofar();
            TextObject varrpttocompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttoCompany"];
            varrpttocompany.Text = cboCNCode.Text;

            ClsGetSomething1.ClsGetBranchAddress(cboCNCode.SelectedValue.ToString());
            TextObject varrpttoaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttoaddress"];
            varrpttoaddress.Text = ClsGetSomething1.plsvarCAdress;

            TextObject varrpttoenterdate = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttoenterdate"];
            varrpttoenterdate.Text = "As of " + txtEnterDate.Text;

            TextObject varTextTitle = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["TextTitle"];
            varTextTitle.Text = "AGING OF ACCOUNTS PAYABLES";

            objRpt.SetDataSource(dsiv.Tables[1]);
            crystalReportViewer1.ReportSource = objRpt;
            crystalReportViewer1.Refresh();
        }

        private void AgingARWithPDC()
        {
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();

            mycommand = new SqlCommand("usp_agingarcurrentWPDC", myconnection);
            mycommand.CommandType = CommandType.StoredProcedure;
            mycommand.Parameters.Add("@Paramenterdate", SqlDbType.DateTime).Value = txtEnterDate.Text;
            mycommand.Parameters.Add("@ParamCNCode", SqlDbType.VarChar).Value = cboCNCode.SelectedValue.ToString();

            SqlDataAdapter dscmd = new SqlDataAdapter();
            dscmd.SelectCommand = mycommand;
            DSAgingAR dsiv = new DSAgingAR();
            dscmd.Fill(dsiv, "viewagingcurrent");
            myconnection.Close();

            CRagingofarwPDC objRpt = new CRagingofarwPDC();
            TextObject varrpttocompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttoCompany"];
            varrpttocompany.Text = cboCNCode.Text;

            ClsGetSomething1.ClsGetBranchAddress(cboCNCode.SelectedValue.ToString());
            TextObject varrpttoaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttoaddress"];
            varrpttoaddress.Text = ClsGetSomething1.plsvarCAdress;

            TextObject varrpttoenterdate = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttoenterdate"];
            varrpttoenterdate.Text = "As of " + txtEnterDate.Text;

            TextObject varTextTitle = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["TextTitle"];
            varTextTitle.Text = "AGING OF ACCOUNTS RECEIVABLE WITH PDC";

            objRpt.SetDataSource(dsiv.Tables[1]);
            crystalReportViewer1.ReportSource = objRpt;
            crystalReportViewer1.Refresh();
        }
        private void AgingPayableWithPDC()
        {
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();

            mycommand = new SqlCommand("usp_agingapcurrentWPDC", myconnection);
            mycommand.CommandType = CommandType.StoredProcedure;
            mycommand.Parameters.Add("@Paramenterdate", SqlDbType.DateTime).Value = txtEnterDate.Text;
            mycommand.Parameters.Add("@ParamCNCode", SqlDbType.VarChar).Value = cboCNCode.SelectedValue.ToString();

            SqlDataAdapter dscmd = new SqlDataAdapter();
            dscmd.SelectCommand = mycommand;
            DSAgingAR dsiv = new DSAgingAR();
            dscmd.Fill(dsiv, "viewagingcurrent");
            myconnection.Close();

            CRagingofarwPDC objRpt = new CRagingofarwPDC();
            TextObject varrpttocompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttoCompany"];
            varrpttocompany.Text = cboCNCode.Text;

            ClsGetSomething1.ClsGetBranchAddress(cboCNCode.SelectedValue.ToString());
            TextObject varrpttoaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttoaddress"];
            varrpttoaddress.Text = ClsGetSomething1.plsvarCAdress;

            TextObject varrpttoenterdate = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttoenterdate"];
            varrpttoenterdate.Text = "As of " + txtEnterDate.Text;

            TextObject varTextTitle = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["TextTitle"];
            varTextTitle.Text = "AGING OF ACCOUNTS PAYABLE WITH PDC";

            objRpt.SetDataSource(dsiv.Tables[1]);
            crystalReportViewer1.ReportSource = objRpt;
            crystalReportViewer1.Refresh();
        }

        private void txtEnterDate_Leave(object sender, EventArgs e)
        {
            if (new ClsValidation().errordate(txtEnterDate.Text) == true)
            {
                MessageBox.Show("Invalid Date", "GL");
                txtEnterDate.Focus();
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cboCNCode_Validating(object sender, CancelEventArgs e)
        {
            if (new ClsValidation().emptytxt(cboCNCode.Text))
            {
            }
            else if (cboCNCode.Text != null && cboCNCode.SelectedValue == null)
            {
                MessageBox.Show("Not found", "GL");
                cboCNCode.Focus();
            }
        }

        private void nextfieldenter1(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.Equals(Keys.Enter))
            {
                SendKeys.Send("{TAB}");
            }
            else if ((e.KeyCode.Equals(Keys.Up)) || (e.KeyCode.Equals(Keys.Left)))
            {
                SendKeys.Send("+{TAB}");
            }
            else if ((e.KeyCode.Equals(Keys.Down)) || (e.KeyCode.Equals(Keys.Right)))
            {
                SendKeys.Send("{TAB}");
            }
        }

        private void nextfieldenter2(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.Equals(Keys.Enter))
            {
                SendKeys.Send("{TAB}");
            }

        }
    }
}
