﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TCIGL
{
    public partial class frmCheckSetting : Form
    {
        SqlConnection myconnection;
        //SqlCommand mycommand;
        ClsGetConnection ClsGetConnection1 = new ClsGetConnection();
        string sql;
        private SqlDataAdapter da;
        private DataTable dataTable = null;
        private BindingSource bindingSource = null;
        ClsPermission ClsPermission1 = new ClsPermission();

        public frmCheckSetting()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void DepositCheckSetUp()
        {
            dgv1.DataSource = null;
            dgv1.Columns.Clear();
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);

            sql = "SELECT BankCode, BankName, XDate, YDate, XCustName, YCustName, XCAmount, YCAmount, XAmtInWord, YAmtInWord, FontName, SizeFont, XCompDoc, YCompDoc FROM tblCheckWriterSetup ORDER BY BankCode";
            da = new SqlDataAdapter(sql, myconnection);
            SqlCommandBuilder commandBuilder = new SqlCommandBuilder(da);
            dataTable = new DataTable();
            da.Fill(dataTable);
            bindingSource = new BindingSource();
            bindingSource.DataSource = dataTable;

            DataGridViewTextBoxColumn ColumnBankCode = new DataGridViewTextBoxColumn();
            ColumnBankCode.HeaderText = "Bank Code";
            ColumnBankCode.Width = 56;
            ColumnBankCode.DataPropertyName = "BankCode";
            ColumnBankCode.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            ColumnBankCode.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            //ColumnBankCode.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            ColumnBankCode.ReadOnly = false;
            ColumnBankCode.Visible = true;
            dgv1.Columns.Add(ColumnBankCode);

            DataGridViewTextBoxColumn ColumnBank = new DataGridViewTextBoxColumn();
            ColumnBank.HeaderText = "Bank";
            ColumnBank.Width = 155;
            ColumnBank.DataPropertyName = "BankName";
            ColumnBank.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            ColumnBank.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            //ColumnBank.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            ColumnBank.ReadOnly = false;
            dgv1.Columns.Add(ColumnBank);

            DataGridViewTextBoxColumn ColumnXDate = new DataGridViewTextBoxColumn();
            ColumnXDate.HeaderText = "Column Date";
            ColumnXDate.Width = 73;
            ColumnXDate.DataPropertyName = "XDate";
            ColumnXDate.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            ColumnXDate.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgv1.Columns.Add(ColumnXDate);


            //Adding  StockNumber TextBox
            DataGridViewTextBoxColumn ColumnYDate = new DataGridViewTextBoxColumn();
            ColumnYDate.HeaderText = "Row Date";
            ColumnYDate.Width = 72;
            ColumnYDate.DataPropertyName = "YDate";
            ColumnYDate.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            ColumnYDate.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnYDate.ReadOnly = false;
            ColumnYDate.Visible = true;
            dgv1.Columns.Add(ColumnYDate);

            DataGridViewTextBoxColumn ColumnXPName = new DataGridViewTextBoxColumn();
            ColumnXPName.HeaderText = "Column Name";
            ColumnXPName.Width = 72;
            ColumnXPName.DataPropertyName = "XCustName";
            ColumnXPName.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            ColumnXPName.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnXPName.ReadOnly = false;
            ColumnXPName.Visible = true;
            dgv1.Columns.Add(ColumnXPName);


            //Adding  BarCode TextBox
            DataGridViewTextBoxColumn ColumnYPName = new DataGridViewTextBoxColumn();
            ColumnYPName.HeaderText = "Row Name";
            ColumnYPName.Width = 72;
            ColumnYPName.DataPropertyName = "YCustName";
            ColumnYPName.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            ColumnYPName.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnYPName.ReadOnly = false;
            ColumnYPName.Visible = true;
            dgv1.Columns.Add(ColumnYPName);            

            DataGridViewTextBoxColumn ColumnXCAmount = new DataGridViewTextBoxColumn();
            ColumnXCAmount.HeaderText = "Column Cash Amt";
            ColumnXCAmount.Width = 72;
            ColumnXCAmount.DataPropertyName = "XCAmount";
            ColumnXCAmount.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            ColumnXCAmount.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnXCAmount.ReadOnly = false;
            ColumnXCAmount.Visible = true;
            dgv1.Columns.Add(ColumnXCAmount);

            DataGridViewTextBoxColumn ColumnYCAmount = new DataGridViewTextBoxColumn();
            ColumnYCAmount.HeaderText = "Row Cash Amt";
            ColumnYCAmount.Width = 72;
            ColumnYCAmount.DataPropertyName = "YCAmount";
            ColumnYCAmount.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            ColumnYCAmount.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnYCAmount.ReadOnly = false;
            ColumnYCAmount.Visible = true;
            dgv1.Columns.Add(ColumnYCAmount);
           
            DataGridViewTextBoxColumn ColumnXAmtInWord = new DataGridViewTextBoxColumn();
            ColumnXAmtInWord.HeaderText = "Column Amt In Word";
            ColumnXAmtInWord.Width = 72;
            ColumnXAmtInWord.DataPropertyName = "XAmtInWord";
            ColumnXAmtInWord.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            ColumnXAmtInWord.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnXAmtInWord.ReadOnly = false;
            ColumnXAmtInWord.Visible = true;
            dgv1.Columns.Add(ColumnXAmtInWord);

            DataGridViewTextBoxColumn ColumnYAmtInWord = new DataGridViewTextBoxColumn();
            ColumnYAmtInWord.HeaderText = "Row Amt In Word";
            ColumnYAmtInWord.Width = 73;
            ColumnYAmtInWord.DataPropertyName = "YAmtInWord";
            ColumnYAmtInWord.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            ColumnYAmtInWord.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnYAmtInWord.ReadOnly = false;
            ColumnYAmtInWord.Visible = true;
            dgv1.Columns.Add(ColumnYAmtInWord);

            DataGridViewTextBoxColumn ColumnFontName = new DataGridViewTextBoxColumn();
            ColumnFontName.HeaderText = "Font Name";
            ColumnFontName.Width = 113;
            ColumnFontName.DataPropertyName = "FontName";
            ColumnFontName.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            ColumnFontName.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            //ColumnFontName.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            ColumnFontName.ReadOnly = false;
            dgv1.Columns.Add(ColumnFontName);
            
            DataGridViewTextBoxColumn ColumnSizeFont = new DataGridViewTextBoxColumn();
            ColumnSizeFont.HeaderText = "Size Font";
            ColumnSizeFont.Width = 72;
            ColumnSizeFont.DataPropertyName = "SizeFont";
            ColumnSizeFont.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            ColumnSizeFont.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnSizeFont.ReadOnly = false;
            ColumnSizeFont.Visible = true;
            dgv1.Columns.Add(ColumnSizeFont);

            DataGridViewTextBoxColumn ColumnXCompDoc = new DataGridViewTextBoxColumn();
            ColumnXCompDoc.HeaderText = "Column Document";
            ColumnXCompDoc.Width = 73;
            ColumnXCompDoc.DataPropertyName = "XCompDoc";
            ColumnXCompDoc.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            ColumnXCompDoc.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnXCompDoc.ReadOnly = false;
            ColumnXCompDoc.Visible = true;
            dgv1.Columns.Add(ColumnXCompDoc);

            DataGridViewTextBoxColumn ColumnYCompDoc = new DataGridViewTextBoxColumn();
            ColumnYCompDoc.HeaderText = "Row Document";
            ColumnYCompDoc.Width = 73;
            ColumnYCompDoc.DataPropertyName = "YCompDoc";
            ColumnYCompDoc.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            ColumnYCompDoc.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnYCompDoc.ReadOnly = false;
            ColumnYCompDoc.Visible = true;
            dgv1.Columns.Add(ColumnYCompDoc);

           

            //Setting Data Source for DataGridView
            dgv1.DataSource = bindingSource;
            //dgv1.AutoResizeColumns();
            //dgv1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            //myconnection.Close();
            //this.WindowState = FormWindowState.Maximized;
            dgv1.AllowUserToAddRows = true;
            //dgv1.Columns[2].DefaultCellStyle.Format = "MM/dd/yyyy";
            //dgv1.Columns[9].DefaultCellStyle.Format = "MM/dd/yyyy";

        }

        private void frmDepositSlipSetting_Load(object sender, EventArgs e)
        {
            ClsPermission1.ClsObjects(this.Text);
            if (new ClsValidation().emptytxt(ClsPermission1.plstxtObject))
            {
                MessageBox.Show("You do not have necessary permission to open this file", "GL");
                this.Close();
            }
            else
            {
                DepositCheckSetUp();
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                da.Update(dataTable);
                MessageBox.Show("Saved", "GL");

            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }
    }
}
