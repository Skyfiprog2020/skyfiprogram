﻿namespace TCIGL
{
    partial class frmVoucherPO
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            this.label2 = new System.Windows.Forms.Label();
            this.txtTDate = new System.Windows.Forms.MaskedTextBox();
            this.txtreference = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.cboControlNo = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtRemarks = new System.Windows.Forms.TextBox();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.txtDocNum = new System.Windows.Forms.TextBox();
            this.txtTotCost = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtTotDisct = new System.Windows.Forms.TextBox();
            this.txtTotalVAT = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.btnPE = new System.Windows.Forms.Button();
            this.txtTerm = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.dgv2 = new TCIGL.moveNextCellDataGridView();
            this.ColumnD1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnStockNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnItem = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnUP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnActDisct = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnPDisct = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnVAT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnTotal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnCost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnRemarks = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnInvClassCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label22 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtTotPayables = new System.Windows.Forms.TextBox();
            this.cbSP = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgv2)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(22, 59);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 19);
            this.label2.TabIndex = 31;
            this.label2.Text = "Date:";
            // 
            // txtTDate
            // 
            this.txtTDate.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTDate.Location = new System.Drawing.Point(26, 80);
            this.txtTDate.Mask = "00/00/0000";
            this.txtTDate.Name = "txtTDate";
            this.txtTDate.Size = new System.Drawing.Size(159, 26);
            this.txtTDate.TabIndex = 0;
            this.txtTDate.ValidatingType = typeof(System.DateTime);
            this.txtTDate.KeyDown += new System.Windows.Forms.KeyEventHandler(this.nextfieldenter1);
            this.txtTDate.Validating += new System.ComponentModel.CancelEventHandler(this.txtTDate_Validating);
            // 
            // txtreference
            // 
            this.txtreference.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtreference.Location = new System.Drawing.Point(26, 142);
            this.txtreference.Name = "txtreference";
            this.txtreference.Size = new System.Drawing.Size(159, 26);
            this.txtreference.TabIndex = 1;
            this.txtreference.KeyDown += new System.Windows.Forms.KeyEventHandler(this.nextfieldenter1);
            this.txtreference.Validating += new System.ComponentModel.CancelEventHandler(this.txtreference_Validating);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(22, 121);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 19);
            this.label1.TabIndex = 33;
            this.label1.Text = "Reference:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(265, 59);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 19);
            this.label3.TabIndex = 35;
            this.label3.Text = "Name:";
            // 
            // cboControlNo
            // 
            this.cboControlNo.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cboControlNo.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cboControlNo.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboControlNo.FormattingEnabled = true;
            this.cboControlNo.Location = new System.Drawing.Point(269, 80);
            this.cboControlNo.Name = "cboControlNo";
            this.cboControlNo.Size = new System.Drawing.Size(514, 27);
            this.cboControlNo.TabIndex = 2;
            this.cboControlNo.KeyDown += new System.Windows.Forms.KeyEventHandler(this.nextfieldenter2);
            this.cboControlNo.Validating += new System.ComponentModel.CancelEventHandler(this.cboCustCode_Validating);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(265, 121);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(66, 19);
            this.label11.TabIndex = 40;
            this.label11.Text = "Remarks:";
            // 
            // txtRemarks
            // 
            this.txtRemarks.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRemarks.Location = new System.Drawing.Point(269, 142);
            this.txtRemarks.Name = "txtRemarks";
            this.txtRemarks.Size = new System.Drawing.Size(805, 26);
            this.txtRemarks.TabIndex = 4;
            this.txtRemarks.Text = "Purchases";
            this.txtRemarks.KeyDown += new System.Windows.Forms.KeyEventHandler(this.nextfieldenter1);
            // 
            // btnClose
            // 
            this.btnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnClose.Location = new System.Drawing.Point(962, 541);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(112, 61);
            this.btnClose.TabIndex = 7;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(844, 541);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(112, 61);
            this.btnSave.TabIndex = 6;
            this.btnSave.Text = "Save - F6";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // txtDocNum
            // 
            this.txtDocNum.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDocNum.Location = new System.Drawing.Point(984, 12);
            this.txtDocNum.Name = "txtDocNum";
            this.txtDocNum.ReadOnly = true;
            this.txtDocNum.Size = new System.Drawing.Size(85, 26);
            this.txtDocNum.TabIndex = 52;
            this.txtDocNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtTotCost
            // 
            this.txtTotCost.Location = new System.Drawing.Point(149, 578);
            this.txtTotCost.Name = "txtTotCost";
            this.txtTotCost.ReadOnly = true;
            this.txtTotCost.Size = new System.Drawing.Size(77, 20);
            this.txtTotCost.TabIndex = 105;
            this.txtTotCost.Text = "0.00";
            this.txtTotCost.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(22, 541);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(116, 15);
            this.label8.TabIndex = 106;
            this.label8.Text = "TOTAL DISCOUNT:";
            // 
            // txtTotDisct
            // 
            this.txtTotDisct.AcceptsReturn = true;
            this.txtTotDisct.Location = new System.Drawing.Point(149, 536);
            this.txtTotDisct.Name = "txtTotDisct";
            this.txtTotDisct.ReadOnly = true;
            this.txtTotDisct.Size = new System.Drawing.Size(77, 20);
            this.txtTotDisct.TabIndex = 156;
            this.txtTotDisct.Text = "0.00";
            this.txtTotDisct.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtTotalVAT
            // 
            this.txtTotalVAT.Location = new System.Drawing.Point(149, 557);
            this.txtTotalVAT.Name = "txtTotalVAT";
            this.txtTotalVAT.ReadOnly = true;
            this.txtTotalVAT.Size = new System.Drawing.Size(77, 20);
            this.txtTotalVAT.TabIndex = 170;
            this.txtTotalVAT.Text = "0.00";
            this.txtTotalVAT.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(23, 562);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(32, 15);
            this.label7.TabIndex = 177;
            this.label7.Text = "VAT:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(23, 583);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(85, 15);
            this.label9.TabIndex = 178;
            this.label9.Text = "TOTAL COST:";
            // 
            // btnPE
            // 
            this.btnPE.Location = new System.Drawing.Point(726, 541);
            this.btnPE.Name = "btnPE";
            this.btnPE.Size = new System.Drawing.Size(112, 61);
            this.btnPE.TabIndex = 5;
            this.btnPE.Text = "Product Entry - F5";
            this.btnPE.UseVisualStyleBackColor = true;
            this.btnPE.Click += new System.EventHandler(this.btnPE_Click);
            // 
            // txtTerm
            // 
            this.txtTerm.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTerm.Location = new System.Drawing.Point(819, 80);
            this.txtTerm.Name = "txtTerm";
            this.txtTerm.Size = new System.Drawing.Size(255, 26);
            this.txtTerm.TabIndex = 3;
            this.txtTerm.Text = "0";
            this.txtTerm.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtTerm.KeyDown += new System.Windows.Forms.KeyEventHandler(this.nextfieldenter1);
            this.txtTerm.Validating += new System.ComponentModel.CancelEventHandler(this.txtTerm_Validating);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(815, 59);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(43, 19);
            this.label4.TabIndex = 180;
            this.label4.Text = "Term:";
            // 
            // dgv2
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgv2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColumnD1,
            this.ColumnStockNumber,
            this.ColumnItem,
            this.ColumnQty,
            this.ColumnUP,
            this.ColumnActDisct,
            this.ColumnPDisct,
            this.ColumnVAT,
            this.ColumnTotal,
            this.ColumnCost,
            this.ColumnRemarks,
            this.ColumnInvClassCode});
            this.dgv2.Location = new System.Drawing.Point(26, 195);
            this.dgv2.Name = "dgv2";
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgv2.RowsDefaultCellStyle = dataGridViewCellStyle9;
            this.dgv2.Size = new System.Drawing.Size(1048, 335);
            this.dgv2.TabIndex = 6;
            this.dgv2.UserDeletedRow += new System.Windows.Forms.DataGridViewRowEventHandler(this.dgv2_UserDeletedRow);
            // 
            // ColumnD1
            // 
            this.ColumnD1.HeaderText = "D1";
            this.ColumnD1.Name = "ColumnD1";
            this.ColumnD1.Visible = false;
            // 
            // ColumnStockNumber
            // 
            this.ColumnStockNumber.HeaderText = "Stock Number";
            this.ColumnStockNumber.Name = "ColumnStockNumber";
            this.ColumnStockNumber.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.ColumnStockNumber.Width = 120;
            // 
            // ColumnItem
            // 
            this.ColumnItem.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ColumnItem.HeaderText = "Description";
            this.ColumnItem.Name = "ColumnItem";
            // 
            // ColumnQty
            // 
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.ColumnQty.DefaultCellStyle = dataGridViewCellStyle2;
            this.ColumnQty.HeaderText = "Qty";
            this.ColumnQty.Name = "ColumnQty";
            this.ColumnQty.Width = 50;
            // 
            // ColumnUP
            // 
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.ColumnUP.DefaultCellStyle = dataGridViewCellStyle3;
            this.ColumnUP.HeaderText = "Unit Price";
            this.ColumnUP.Name = "ColumnUP";
            this.ColumnUP.Width = 90;
            // 
            // ColumnActDisct
            // 
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.ColumnActDisct.DefaultCellStyle = dataGridViewCellStyle4;
            this.ColumnActDisct.HeaderText = "% Disct";
            this.ColumnActDisct.Name = "ColumnActDisct";
            this.ColumnActDisct.Width = 75;
            // 
            // ColumnPDisct
            // 
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.ColumnPDisct.DefaultCellStyle = dataGridViewCellStyle5;
            this.ColumnPDisct.HeaderText = "P Disct";
            this.ColumnPDisct.Name = "ColumnPDisct";
            this.ColumnPDisct.Width = 75;
            // 
            // ColumnVAT
            // 
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.ColumnVAT.DefaultCellStyle = dataGridViewCellStyle6;
            this.ColumnVAT.HeaderText = "VAT";
            this.ColumnVAT.Name = "ColumnVAT";
            this.ColumnVAT.Visible = false;
            this.ColumnVAT.Width = 70;
            // 
            // ColumnTotal
            // 
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.ColumnTotal.DefaultCellStyle = dataGridViewCellStyle7;
            this.ColumnTotal.HeaderText = "Total";
            this.ColumnTotal.Name = "ColumnTotal";
            this.ColumnTotal.Width = 90;
            // 
            // ColumnCost
            // 
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.ColumnCost.DefaultCellStyle = dataGridViewCellStyle8;
            this.ColumnCost.HeaderText = "Cost";
            this.ColumnCost.Name = "ColumnCost";
            this.ColumnCost.Width = 90;
            // 
            // ColumnRemarks
            // 
            this.ColumnRemarks.HeaderText = "Remarks";
            this.ColumnRemarks.Name = "ColumnRemarks";
            this.ColumnRemarks.Width = 150;
            // 
            // ColumnInvClassCode
            // 
            this.ColumnInvClassCode.HeaderText = "InvClassCode";
            this.ColumnInvClassCode.Name = "ColumnInvClassCode";
            this.ColumnInvClassCode.Visible = false;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.Red;
            this.label22.Location = new System.Drawing.Point(22, 12);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(262, 22);
            this.label22.TabIndex = 238;
            this.label22.Text = "Press F5 to open entry window";
            this.label22.Visible = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(267, 538);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(108, 15);
            this.label6.TabIndex = 242;
            this.label6.Text = "TOTAL PAYABLE:";
            // 
            // txtTotPayables
            // 
            this.txtTotPayables.Location = new System.Drawing.Point(376, 536);
            this.txtTotPayables.Name = "txtTotPayables";
            this.txtTotPayables.ReadOnly = true;
            this.txtTotPayables.Size = new System.Drawing.Size(77, 20);
            this.txtTotPayables.TabIndex = 241;
            this.txtTotPayables.Text = "0.00";
            this.txtTotPayables.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // cbSP
            // 
            this.cbSP.AutoSize = true;
            this.cbSP.Location = new System.Drawing.Point(248, 581);
            this.cbSP.Name = "cbSP";
            this.cbSP.Size = new System.Drawing.Size(102, 17);
            this.cbSP.TabIndex = 243;
            this.cbSP.Text = "Save and Print?";
            this.cbSP.UseVisualStyleBackColor = true;
            // 
            // frmVoucherPO
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnClose;
            this.ClientSize = new System.Drawing.Size(1100, 611);
            this.Controls.Add(this.cbSP);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtTotPayables);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtTerm);
            this.Controls.Add(this.btnPE);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtTotalVAT);
            this.Controls.Add(this.txtTotDisct);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtTotCost);
            this.Controls.Add(this.dgv2);
            this.Controls.Add(this.txtDocNum);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.txtRemarks);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cboControlNo);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtreference);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtTDate);
            this.KeyPreview = true;
            this.Name = "frmVoucherPO";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Purchase Order";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmVoucherPO_FormClosing);
            this.Load += new System.EventHandler(this.frmVoucherPO_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frmVoucherPO_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.dgv2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.MaskedTextBox txtTDate;
        private System.Windows.Forms.TextBox txtreference;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cboControlNo;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtRemarks;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.TextBox txtDocNum;
        private moveNextCellDataGridView dgv2;
        private System.Windows.Forms.TextBox txtTotCost;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtTotDisct;
        private System.Windows.Forms.TextBox txtTotalVAT;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnPE;
        private System.Windows.Forms.TextBox txtTerm;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtTotPayables;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnD1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnStockNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnItem;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnUP;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnActDisct;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnPDisct;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnVAT;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnTotal;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnCost;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnRemarks;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnInvClassCode;
        private System.Windows.Forms.CheckBox cbSP;
    }
}