﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TCIGL
{
    public partial class frmCompany : Form
    {
        SqlConnection myconnection;
        SqlCommand mycommand;
        BindingSource dbind = new BindingSource();
        ClsPermission ClsPermission1 = new ClsPermission();
        ClsGetConnection ClsGetConnection1 = new ClsGetConnection();
        ClsCompName ClsCompName1 = new ClsCompName();
 
        public frmCompany()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        private void frmCompany_Load(object sender, EventArgs e)
        {
            ClsPermission1.ClsObjects(this.Text);
            if (new ClsValidation().emptytxt(ClsPermission1.plstxtObject))
            {
                MessageBox.Show("You do not have necessary permission to open this file", "GL");
                this.Close();
            }
            else
            {
                ClsCompName1.ClsCompNameMain();
                txtCompany.Text = ClsCompName1.varcn;
                txtAddress.Text = ClsCompName1.varAddress;
                txtTIN.Text = ClsCompName1.varTIN;

            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {

                if (string.IsNullOrEmpty(txtCompany.Text))
                {
                    MessageBox.Show("Please complete your entry", "GL");
                    txtCompany.Focus();
                }
                else if (string.IsNullOrEmpty(txtAddress.Text))
                {
                    MessageBox.Show("Please complete your entry", "GL");
                    txtAddress.Focus();

                }
                else if (string.IsNullOrEmpty(txtTIN.Text))
                {
                    MessageBox.Show("Please complete your entry", "GL");
                    txtTIN.Focus();

                }
                
                else
                {
                    ClsGetConnection1.ClsGetConMSSQL();
                    myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                    myconnection.Open();

                    string sqlstatement;
                    sqlstatement = "UPDATE tblCompany SET Company=@_Company, Address=@_Address, TIN=@_TIN";

                    mycommand = new SqlCommand(sqlstatement, myconnection);
                    mycommand.Parameters.Add("_Company", SqlDbType.VarChar).Value = txtCompany.Text;
                    mycommand.Parameters.Add("_Address", SqlDbType.VarChar).Value = txtAddress.Text;
                    mycommand.Parameters.Add("_TIN", SqlDbType.VarChar).Value = txtTIN.Text;
                    
                    int n1 = mycommand.ExecuteNonQuery();
                    myconnection.Close();
                    MessageBox.Show("Finished", "GL");
                    this.Close();

                }
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                myconnection.Close();
            }

        }
    }
}
