﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TCIGL
{
    public partial class frmEntryInvClassEdit : Form
    {
        private SqlDataAdapter da;
        private DataTable dataTable = null;
        private SqlConnection myconnection;
        private BindingSource bindingSource = null;
        BindingSource bsource = new BindingSource();
        //   DataSet ds = null;
        string sql;
        ClsPermission ClsPermission1 = new ClsPermission();
        ClsGetConnection ClsGetConnection1 = new ClsGetConnection(); 
        public frmEntryInvClassEdit()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmEntryInvClassEdit_Load(object sender, EventArgs e)
        {
            ClsPermission1.ClsObjects(this.Text);
            if (new ClsValidation().emptytxt(ClsPermission1.plstxtObject))
            {
                MessageBox.Show("You do not have necessary permission to open this file", "GL");
                this.Close();
            }
            else
            {
                LoadData();
            }
        }
        private void LoadData()
        {
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            sql = "SELECT InvClassCode, InvClassDesc FROM tblInvClass";

            da = new SqlDataAdapter(sql, myconnection);
            SqlCommandBuilder commandBuilder = new SqlCommandBuilder(da);

            dataTable = new DataTable();
            da.Fill(dataTable);
            bindingSource = new BindingSource();
            bindingSource.DataSource = dataTable;


            //Adding  GACode TextBox
            DataGridViewTextBoxColumn ColumnInvClassCode = new DataGridViewTextBoxColumn();
            ColumnInvClassCode.HeaderText = "Code";
            //ColumnGACode.Width = 80;
            ColumnInvClassCode.DataPropertyName = "InvClassCode";
            ColumnInvClassCode.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnInvClassCode.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            //ColumnGACode.Visible = false;
            ColumnInvClassCode.ReadOnly = true;
            dgv1.Columns.Add(ColumnInvClassCode);

            //Adding  GADesc TextBox
            DataGridViewTextBoxColumn ColumnInvClassDesc = new DataGridViewTextBoxColumn();
            ColumnInvClassDesc.HeaderText = "Description";
            //ColumnItem.Width = 80;
            ColumnInvClassDesc.DataPropertyName = "InvClassDesc";
            ColumnInvClassDesc.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            ColumnInvClassDesc.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnInvClassDesc.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            //ColumnGADesc.ReadOnly = true;
            dgv1.Columns.Add(ColumnInvClassDesc);
      

            //Setting Data Source for DataGridView
            dgv1.DataSource = bindingSource;
            dgv1.AutoResizeColumns();
            dgv1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            myconnection.Close();
            dgv1.AllowUserToAddRows = false;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                da.Update(dataTable);
                MessageBox.Show("Saved", "GL");
                this.Close();

            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }
    }
}
