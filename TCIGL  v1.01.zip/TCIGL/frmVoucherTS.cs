﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Threading;
using CrystalDecisions.CrystalReports.Engine;
namespace TCIGL
{
    public partial class frmVoucherTS : Form
    {
        string varoutdate = "No";
        public static DataGridView glbldgv2;
        SqlConnection myconnection;
        SqlCommand mycommand;
        SqlCommand mycommanddgv2;
        SqlDataReader SqlDataReader1; 
        ClsAutoNumber ClsAutoNumber1 = new ClsAutoNumber();
        ClsBuildComboBox ClsBuildComboBox1 = new ClsBuildComboBox();
        ClsBuildEntryComboBox ClsBuildEntryComboBox1 = new ClsBuildEntryComboBox(); 
        ClsValidation ClsValidation1 = new ClsValidation();
        ClsGetSomething ClsGetSomething1 = new ClsGetSomething();
        ClsPermission ClsPermission1 = new ClsPermission();
        ClsGetConnection ClsGetConnection1 = new ClsGetConnection();
        ClsDefaultBranch ClsDefaultBranch1 = new ClsDefaultBranch();
        ClsCompName ClsCompName1 = new ClsCompName();

        string dgvdata = null;
        public static TextBox glblSPO;
        public static TextBox glbltxtTotDisct;
        public static TextBox glbltxtTotNet;
        public static TextBox glbltxtTotCost;
        public static ComboBox glblcboWHCode;
        public static Button glblbtnSave;

        ClsGetSomethingOthers ClsGetSomethingOthers1 = new ClsGetSomethingOthers();
        int varintTableDoor = 0;
        int number = 0;
        private string privarstrVoidIC = null;

        public frmVoucherTS()
        {
            InitializeComponent();
            {
                ClsGetSomethingOthers1.ClsGetVoidRef("TS", "1");
                privarstrVoidIC = ClsGetSomethingOthers1.plsVoidIC;
                if (new ClsValidation().emptytxt(privarstrVoidIC))
                { }
                else
                {
                    ClsGetSomethingOthers1.ClsDeleteErrorTransaction("TS", "1");
                }
            }
        }

        private void buildcboCustCode()
        {
            cboControlNo.DataSource = null;
            ClsBuildComboBox1.ARLCVCN.Clear();
            ClsBuildComboBox1.ClsBuildCVControlno();
            this.cboControlNo.DataSource = (ClsBuildComboBox1.ARLCVCN);
            this.cboControlNo.DisplayMember = "Display";
            this.cboControlNo.ValueMember = "Value";
        }
   
        private void buildcboWHCode()
        {
            cboWHCode.DataSource = null;
            ClsBuildEntryComboBox1.ARWHCode.Clear();
            ClsBuildEntryComboBox1.ClsBuildWHCode();
            this.cboWHCode.DataSource = (ClsBuildEntryComboBox1.ARWHCode);
            this.cboWHCode.DisplayMember = "Display";
            this.cboWHCode.ValueMember = "Value";
            //this.cboWHCode.DropDownWidth = 450;
        }

        private void buildcboDestCode()
        {
            cboDestCode.DataSource = null;
            ClsBuildEntryComboBox1.ARDestWHCode.Clear();
            ClsBuildEntryComboBox1.ClsBuildDestWHCode();
            this.cboDestCode.DataSource = (ClsBuildEntryComboBox1.ARDestWHCode);
            this.cboDestCode.DisplayMember = "Display";
            this.cboDestCode.ValueMember = "Value";
            //this.cboDestCode.DropDownWidth = 450;
        }

        private void buildcboASMCode()
        {
            cboSMCode.DataSource = null;
            ClsBuildEntryComboBox1.ARSMCode.Clear();
            ClsBuildEntryComboBox1.ClsBuildSalesman();
            this.cboSMCode.DataSource = (ClsBuildEntryComboBox1.ARSMCode);
            this.cboSMCode.DisplayMember = "Display";
            this.cboSMCode.ValueMember = "Value";
        }

        private void SaveTransact()
        {
            try
            {
                ClsAutoNumber1.VoucherAutoNum("TS");
                txtDocNum.Text = (ClsAutoNumber1.plsnumber);

                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();

                DateTime DT = DateTime.Now;
                string sqlstatement;
                string sqlstatementdgv2;
                sqlstatement = "INSERT INTO tblmain1 (IC, DocNum, Voucher, UserCode, ControlNo, TDate, Reference, Term, Remarks, CheckNo, CAmount, ASMCode, DE, CNCode)";
                sqlstatement += " Values (@_IC, @_DocNum, @_Voucher, @_UserCode, @_ControlNo, @_TDate, @_Reference, @_Term, @_Remarks, @_CheckNo, @_CAmount, @_ASMCode, @_DE, @_CNCode)";
                sqlstatementdgv2 = "INSERT INTO tblmain2 (IC, StockNumber,  PIn, POut, UP, Cost, ActDisct, PDisct, VAT, RowNum, D1, D2, D3, WHCode)";
                sqlstatementdgv2 += "Values (@_IC, @_StockNumber, @_PIn, @_POut, @_UP, @_Cost, @_ActDisct, @_PDisct, @_VAT, @_RowNum, @_D1, @_D2, @_D3, @_WHCode)";
                mycommand = new SqlCommand(sqlstatement, myconnection);
                mycommand.Parameters.Add("_IC", SqlDbType.VarChar).Value = "TS" + Form1.glbluc.Text + (ClsDefaultBranch1.plsvardb);
                mycommand.Parameters.Add("_DocNum", SqlDbType.VarChar).Value = Form1.glbluc.Text;
                mycommand.Parameters.Add("_Voucher", SqlDbType.VarChar).Value = "TS";
                mycommand.Parameters.Add("_UserCode", SqlDbType.VarChar).Value = Form1.glbluc.Text;
                mycommand.Parameters.Add("_ControlNo", SqlDbType.VarChar).Value = cboControlNo.SelectedValue.ToString();
                mycommand.Parameters.Add("_TDate", SqlDbType.Date).Value = txtTDate.Text;
                mycommand.Parameters.Add("_Reference", SqlDbType.VarChar).Value = txtreference.Text;
                mycommand.Parameters.Add("_Term", SqlDbType.Int).Value = "0";
                mycommand.Parameters.Add("_Remarks", SqlDbType.VarChar).Value = txtRemarks.Text;
                mycommand.Parameters.Add("_CheckNo", SqlDbType.VarChar).Value = 0;
                mycommand.Parameters.Add("_CAmount", SqlDbType.Money).Value = 0;
                mycommand.Parameters.Add("_ASMCode", SqlDbType.VarChar).Value = cboSMCode.SelectedValue.ToString();
                mycommand.Parameters.Add("_DE", SqlDbType.Date).Value = DT;
                mycommand.Parameters.Add("_CNCode", SqlDbType.Char).Value = (ClsDefaultBranch1.plsvardb);
                int n1 = mycommand.ExecuteNonQuery();

                DataGridViewRow row1 = null;
                for (int x = 0; x < dgv2.Rows.Count - 1; x++)
                {
                    row1 = dgv2.Rows[x];
                    mycommanddgv2 = new SqlCommand(sqlstatementdgv2, myconnection);
                    mycommanddgv2.Parameters.Add("_IC", SqlDbType.VarChar).Value = "TS" + Form1.glbluc.Text + (ClsDefaultBranch1.plsvardb);
                    mycommanddgv2.Parameters.Add("_StockNumber", SqlDbType.VarChar).Value = row1.Cells[1].Value;
                    mycommanddgv2.Parameters.Add("_PIn", SqlDbType.Decimal).Value = "0";
                    mycommanddgv2.Parameters.Add("_POut", SqlDbType.Decimal).Value = row1.Cells[3].Value;
                    mycommanddgv2.Parameters.Add("_UP", SqlDbType.Decimal).Value = row1.Cells[4].Value;
                    mycommanddgv2.Parameters.Add("_Cost", SqlDbType.Decimal).Value = Convert.ToDouble(row1.Cells[9].Value) * -1;
                    mycommanddgv2.Parameters.Add("_ActDisct", SqlDbType.Decimal).Value = row1.Cells[5].Value;
                    mycommanddgv2.Parameters.Add("_PDisct", SqlDbType.Decimal).Value = row1.Cells[6].Value;
                    mycommanddgv2.Parameters.Add("_VAT", SqlDbType.Decimal).Value = row1.Cells[7].Value;
                    mycommanddgv2.Parameters.Add("_RowNum", SqlDbType.Int).Value = (Convert.ToInt32(x) + 1).ToString();
                    mycommanddgv2.Parameters.Add("_D1", SqlDbType.Decimal).Value = row1.Cells[0].Value;
                    mycommanddgv2.Parameters.Add("_D2", SqlDbType.Decimal).Value = "0";
                    mycommanddgv2.Parameters.Add("_D3", SqlDbType.Decimal).Value = "0";
                    mycommanddgv2.Parameters.Add("_WHCode", SqlDbType.VarChar).Value = cboWHCode.SelectedValue.ToString();
                    int n3 = mycommanddgv2.ExecuteNonQuery();
                }

                //dgv1.AllowUserToAddRows = true;
                DataGridViewRow row2 = null;
                for (int x = 0; x < dgv2.Rows.Count - 1; x++)
                {
                    row2 = dgv2.Rows[x];
                    ClsGetSomething1.ClsGetProductDetails(row2.Cells[1].Value.ToString());
                    mycommanddgv2 = new SqlCommand(sqlstatementdgv2, myconnection);
                    mycommanddgv2.Parameters.Add("_IC", SqlDbType.VarChar).Value = "TS" + Form1.glbluc.Text + (ClsDefaultBranch1.plsvardb);
                    mycommanddgv2.Parameters.Add("_StockNumber", SqlDbType.VarChar).Value = row2.Cells[1].Value;
                    mycommanddgv2.Parameters.Add("_PIn", SqlDbType.Decimal).Value = row2.Cells[3].Value;
                    mycommanddgv2.Parameters.Add("_POut", SqlDbType.Decimal).Value = "0";
                    mycommanddgv2.Parameters.Add("_UP", SqlDbType.Decimal).Value = row2.Cells[4].Value;
                    mycommanddgv2.Parameters.Add("_Cost", SqlDbType.Decimal).Value = row2.Cells[9].Value;
                    mycommanddgv2.Parameters.Add("_ActDisct", SqlDbType.Decimal).Value = row2.Cells[5].Value;
                    mycommanddgv2.Parameters.Add("_PDisct", SqlDbType.Decimal).Value = row2.Cells[6].Value;
                    mycommanddgv2.Parameters.Add("_VAT", SqlDbType.Decimal).Value = row2.Cells[7].Value;
                    mycommanddgv2.Parameters.Add("_RowNum", SqlDbType.Int).Value = (Convert.ToInt64(x) + 500).ToString();
                    mycommanddgv2.Parameters.Add("_D1", SqlDbType.Decimal).Value = row2.Cells[0].Value;
                    mycommanddgv2.Parameters.Add("_D2", SqlDbType.Decimal).Value = "0";
                    mycommanddgv2.Parameters.Add("_D3", SqlDbType.Decimal).Value = "0";
                    mycommanddgv2.Parameters.Add("_WHCode", SqlDbType.VarChar).Value = cboDestCode.SelectedValue.ToString();
                    int n4 = mycommanddgv2.ExecuteNonQuery();
                }
                myconnection.Close();
                ClsGetSomethingOthers1.ClsFinalize("TS", txtDocNum.Text, "1");

                if (cbSP.Checked)
                {
                    int varnocopy = int.Parse(frmMain.glbltxtNoCopy.Text);
                    for (int i = 1; i <= varnocopy; i++)
                    {
                        printcurvoucher();
                    }
                }

                ClsAutoNumber1.VoucherAutoNum("TS");
                txtDocNum.Text = (ClsAutoNumber1.plsnumber);
                clearscreen();
            }
            catch
            {
                MessageBox.Show("Error, please click OK", "GL");
                this.Close();
            }
            finally
            {
                myconnection.Close();
            }
        }

        private void clearscreen()
        {
            dgv2.Rows.Clear();
            txtreference.Text = "";
            cboControlNo.Text = "";
            //cboPC.Text = "";
            txtRemarks.Text = "Transfer of Products";
            txtTDate.Focus();
            txtTotNet.Text = "0.00";
            txtTotCost.Text = "0.00";
            txtTotDisct.Text = "0.00";
            dgvdata = null;

        }

        private void printcurvoucher()
        {
            string sqlstatement = "SELECT * FROM ViewDetailsBookTS WHERE DocNum ='" + txtDocNum.Text + "' AND CNCode = '" + ClsDefaultBranch1.plsvardb + "' ORDER BY RowNum";

            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();
            mycommand = myconnection.CreateCommand();
            mycommand.CommandText = sqlstatement;
            mycommand.CommandTimeout = 900;
            SqlDataReader1 = mycommand.ExecuteReader();
            DataTable DataTable1 = new DataTable();
            DataTable1.Load(SqlDataReader1);
            myconnection.Close();

            if (DataTable1.Rows.Count == 0)
            {
                MessageBox.Show("No data found", "GL");
                return;
            }

            CRprevTS objRpt = new CRprevTS();
            TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            ClsCompName1.ClsCompNameMain();
            vartxtcompany.Text = ClsCompName1.varcn;

            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            ClsCompName1.ClsCompNamebranchAddress(ClsDefaultBranch1.plsvardb);
            vartxtaddress.Text = (ClsCompName1.plsCRaddress);

            objRpt.SetDataSource(DataTable1);
            System.Drawing.Printing.PrintDocument doctoprint = new System.Drawing.Printing.PrintDocument();
            int rawKind = 0;
            for (int i = 0; i <= doctoprint.PrinterSettings.PaperSizes.Count - 1; i++)
            {
                if (doctoprint.PrinterSettings.PaperSizes[i].PaperName == "C1-HalfShort")
                {
                    rawKind = Convert.ToInt32(doctoprint.PrinterSettings.PaperSizes[i].GetType().GetField("kind",
                    System.Reflection.BindingFlags.Instance |
                    System.Reflection.BindingFlags.NonPublic).GetValue(doctoprint.PrinterSettings.PaperSizes[i]));
                    break; // TODO: might not be correct. Was : Exit For
                }
            }
            objRpt.PrintOptions.PaperSize = (CrystalDecisions.Shared.PaperSize)rawKind;

            objRpt.Refresh();
            objRpt.PrintToPrinter(1, false, 0, 0);
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            ClsValidation1.securedate(DateTime.Parse(txtTDate.Text));
            varoutdate = (ClsValidation1.plsoutdate);
            for (int x = 0; x < dgv2.Rows.Count - 1; x++)
            {
                dgvdata = (dgv2.Rows[x].Cells[0].FormattedValue.ToString());
            }

            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();

            if (new Clsexist().RecordExists(ref myconnection, "SELECT Reference FROM tblmain1 WHERE Reference ='" + txtreference.Text + "'"))
            {
                myconnection.Close();
                MessageBox.Show("Duplicate entry", "GL");
                txtreference.Focus();
            }

            else if ((txtTDate.Text == "  /  /"))
            {
                myconnection.Close();
                MessageBox.Show("Please complete your entry", "GL");
                txtTDate.Focus();
            }
            else if ((new ClsValidation().emptytxt(cboControlNo.Text)) || (new ClsValidation().emptytxt(txtreference.Text)) ||
                (new ClsValidation().emptytxt(txtRemarks.Text)))
            {
                myconnection.Close();
                MessageBox.Show("Please complete your entry", "GL");
                txtTDate.Focus();
            }
            else if (varoutdate == "Yes")
            {
                myconnection.Close();
                MessageBox.Show("Date is out of range", "GL");
                txtTDate.Focus();
            }
            else if (new ClsValidation().emptytxt(dgvdata))
            {
                myconnection.Close();
                MessageBox.Show("Incomplete Record", "IS");
                txtTDate.Focus();
            }
            else
            {
                myconnection.Close();
                privarstrVoidIC = null;
                ClsGetSomethingOthers1.ClsGetTDoor("TS");
                varintTableDoor = int.Parse(ClsGetSomethingOthers1.plsTableDoor);
                number = 0;
                while (varintTableDoor == 1 && number <= 20)
                {
                    number = number + 1;
                    Thread.Sleep(200);
                    varintTableDoor = int.Parse(ClsGetSomethingOthers1.plsTableDoor);
                }

                if (varintTableDoor == 0 && number <= 20)
                {

                    ClsGetSomethingOthers1.ClsGetVoidRef("TS", "1");
                    privarstrVoidIC = ClsGetSomethingOthers1.plsVoidIC;
                    if (new ClsValidation().emptytxt(privarstrVoidIC))
                    {
                        ClsGetSomethingOthers1.ClsOneTheDoor("TS");
                        SaveTransact();
                        ClsGetSomethingOthers1.ClsZeroTheDoor("TS");
                    }
                    else
                    {
                        ClsGetSomethingOthers1.ClsDeleteErrorTransaction("TS", "1");
                        MessageBox.Show("Transaction not saved", "GL");
                    }
                }
                else if (varintTableDoor == 1 && number == 21)
                {
                    MessageBox.Show("Contact your adminnistrator", "GL");
                }

            }
        }


 
 

        private void cboCustCode_Validating(object sender, CancelEventArgs e)
        {
            if (new ClsValidation().emptytxt(cboControlNo.Text))
            {
            }
            else if (cboControlNo.Text != null && cboControlNo.SelectedValue == null)
            {
                MessageBox.Show("Not found", "GL");
                cboControlNo.Focus();
            }
            else
            {
                ClsGetSomething1.ClsGetCustData(cboControlNo.SelectedValue.ToString());
                txtSPO.Text = ClsGetSomething1.plsSPCode;
                cboSMCode.SelectedValue = ClsGetSomething1.plsSMCode;
            }
        }

        private void frmVoucherSales_Load(object sender, EventArgs e)
        {
            ClsPermission1.ClsObjects(this.Text);
            if (new ClsValidation().emptytxt(ClsPermission1.plstxtObject))
            {
                MessageBox.Show("You do not have necessary permission to open this file", "GL");
                this.Close();
            }
            else
            {
                ClsAutoNumber1.VoucherAutoNum("TS");
                txtDocNum.Text = (ClsAutoNumber1.plsnumber);
                ClsGetSomething1.ClsGetDefaultDate();
                txtTDate.Text = ClsGetSomething1.plsdefdate;
                buildcboASMCode();
                buildcboCustCode();
                buildcboWHCode();
                buildcboDestCode();

                glblSPO = txtSPO;
                glbldgv2 = dgv2;
                glbltxtTotCost = txtTotCost;
                glbltxtTotDisct = txtTotDisct;
                glbltxtTotNet = txtTotNet;
                glblcboWHCode = cboWHCode;
                glblbtnSave = btnSave;
                //  cboCustCode.Text = "";

                privarstrVoidIC = null;
                ClsGetSomethingOthers1.ClsGetVoidRef("TS", "1");
                privarstrVoidIC = ClsGetSomethingOthers1.plsVoidIC;
                if (new ClsValidation().emptytxt(privarstrVoidIC))
                { }
                else
                {
                    ClsGetSomethingOthers1.ClsDeleteErrorTransaction("TS", "1");
                    privarstrVoidIC = null;
                }

            }
        }


        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
            frmTransactEntryTS frmTransactEntryTS1 = new frmTransactEntryTS();
            frmTransactEntryTS1.Close();
        }

        private void btnPE_Click(object sender, EventArgs e)
        {
            frmTransactEntryTS frmEntryTS1 = new frmTransactEntryTS();
            frmEntryTS1.Show();
            btnPE.Visible = false;
            label22.Visible = true;
        }

       
        private void frmVoucherSales_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F5)
            {
                frmTransactEntryTS frmEntryTS1 = new frmTransactEntryTS();
                frmEntryTS1.Show();
            }
            else if (e.KeyCode==Keys.F6)
            {
                //SLSave();
            }
            else if (e.KeyCode == Keys.Escape)
            {
                this.Close();
            }
     
        }

        private void txtTDate_Validating(object sender, CancelEventArgs e)
        {
            if (new ClsValidation().errordate(txtTDate.Text) == true)
            {
                MessageBox.Show("Invalid Date", "GL");
                txtTDate.Focus();
            }
        
        }

        private void dgv2_UserDeletedRow(object sender, DataGridViewRowEventArgs e)
        {
            dgv2total();
        }

        private void dgv2total()
        {
            double vartxtTotCost = 0.00;
            double vartxtTotNet = 0.00;
            double vartxtTotDisct = 0.00;

            {
                for (int x = 0; x < frmVoucherTS.glbldgv2.Rows.Count - 1; x++)
                {
                    vartxtTotCost += double.Parse(frmVoucherTS.glbldgv2.Rows[x].Cells[9].FormattedValue.ToString());
                }

                for (int x = 0; x < frmVoucherTS.glbldgv2.Rows.Count - 1; x++)
                {
                    vartxtTotNet += double.Parse(frmVoucherTS.glbldgv2.Rows[x].Cells[8].FormattedValue.ToString());
                }

                for (int x = 0; x < frmVoucherTS.glbldgv2.Rows.Count - 1; x++)
                {
                    string vartxtD1 = frmVoucherTS.glbldgv2.Rows[x].Cells[6].FormattedValue.ToString();
                    string vartxtD2 = frmVoucherTS.glbldgv2.Rows[x].Cells[7].FormattedValue.ToString();
                    vartxtTotDisct += double.Parse(vartxtD1) + double.Parse(vartxtD2);
                }

                frmVoucherTS.glbltxtTotCost.Text = vartxtTotCost.ToString("N2");
                frmVoucherTS.glbltxtTotNet.Text = vartxtTotNet.ToString("N2");
                frmVoucherTS.glbltxtTotDisct.Text = vartxtTotDisct.ToString("N2");
            }

        }

        private void txtreference_Validating(object sender, CancelEventArgs e)
        {
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();

            if (new Clsexist().RecordExists(ref myconnection, "SELECT Reference FROM tblmain1 WHERE Reference ='" + txtreference.Text + "'"))
            {
                myconnection.Close();
                MessageBox.Show("Duplicate entry", "GL");
                txtreference.Focus();
            }
            myconnection.Close();
        }

        private void nextfieldenter1(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.Equals(Keys.Enter))
            {
                SendKeys.Send("{TAB}");
            }
            else if ((e.KeyCode.Equals(Keys.Up)) || (e.KeyCode.Equals(Keys.Left)))
            {
                SendKeys.Send("+{TAB}");
            }
            else if ((e.KeyCode.Equals(Keys.Down)) || (e.KeyCode.Equals(Keys.Right)))
            {
                SendKeys.Send("{TAB}");
            }
        }

        private void nextfieldenter2(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.Equals(Keys.Enter))
            {
                SendKeys.Send("{TAB}");
            }

        }

        private void cboSMCode_Validating(object sender, CancelEventArgs e)
        {
            if (new ClsValidation().emptytxt(cboSMCode.Text))
            {
            }
            else if (cboSMCode.Text != null && cboSMCode.SelectedValue == null)
            {
                MessageBox.Show("Not found", "GL");
                cboSMCode.Focus();
            }

        }

    }
}
