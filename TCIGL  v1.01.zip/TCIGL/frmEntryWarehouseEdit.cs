﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TCIGL
{
    public partial class frmEntryWarehouseEdit : Form
    {
        SqlConnection myconnection;
        SqlCommand mycommand;
        BindingSource dbind = new BindingSource();
        //SqlDataReader dr;
     //   SqlDataAdapter da;
     //   DataSet dset;
        ClsPermission ClsPermission1 = new ClsPermission();
        ClsGetConnection ClsGetConnection1 = new ClsGetConnection();
        ClsBuildEntryComboBox ClsBuildEntryComboBox1 = new ClsBuildEntryComboBox();
        ClsGetSomethingEntry ClsGetSomethingEntry1 = new ClsGetSomethingEntry(); 
        public frmEntryWarehouseEdit()
        {
            InitializeComponent();
        }

 
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buildWHCode()
        {
            cboWHCode.DataSource = null;
            ClsBuildEntryComboBox1.ARWHCode.Clear();
            ClsBuildEntryComboBox1.ClsBuildWHCode();
            this.cboWHCode.DataSource = (ClsBuildEntryComboBox1.ARWHCode);
            this.cboWHCode.DisplayMember = "Display";
            this.cboWHCode.ValueMember = "Value";
            //this.cboWHCode.DropDownWidth = 450;
        }

  
        private void frmWarehouseEdit_Load(object sender, EventArgs e)
        {
           ClsPermission1.ClsObjects(this.Text);
           if (new ClsValidation().emptytxt(ClsPermission1.plstxtObject))
               {
                  MessageBox.Show("You do not have necessary permission to open this file", "GL");
                  this.Close();
               }
           else
               {
                  buildWHCode();
                  cboWHCode.Text = "";
                  txtWHDesc.Text = "";
               }
        }

  
        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {

                if (new ClsValidation().emptytxt (txtWHDesc.Text))
                {
                    MessageBox.Show("Please complete your entry", "POS");
                    txtWHDesc.Focus();
                }
                else
                {
                    ClsGetConnection1.ClsGetConMSSQL();
                    myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                    myconnection.Open();

                    string sqlstatement;
                    sqlstatement = "UPDATE tblWarehouse SET WHDesc=@_WHDesc WHERE WHCode ='" + cboWHCode.SelectedValue.ToString() + "'";

                    mycommand = new SqlCommand(sqlstatement, myconnection);
                    mycommand.Parameters.Add("_WHDesc", SqlDbType.VarChar).Value = txtWHDesc.Text;
                    int n1 = mycommand.ExecuteNonQuery();
                    myconnection.Close();
                    buildWHCode();
                    cboWHCode.Text = "";
                    txtWHDesc.Text = "";
                    cboWHCode.Focus();
                }
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                //dr.Close();
                myconnection.Close();
            }
        }

        private void cboWHCode_Validating(object sender, CancelEventArgs e)
        {
            if (new ClsValidation().emptytxt(cboWHCode.Text))
            {
            }
            else if (cboWHCode.Text != null && cboWHCode.SelectedValue == null)
            {
                MessageBox.Show("Not found", "GL");
                cboWHCode.Focus();
            }
            else
            {
                GetWHDesc();
            }
        }

      private void GetWHDesc()
        {
            ClsGetSomethingEntry1.ClsGetWHDesc(cboWHCode.SelectedValue.ToString());
            txtWHDesc.Text = ClsGetSomethingEntry1.plsvarWHDesc;
        }

      private void nextfieldenter1(object sender, KeyEventArgs e)
      {
          if (e.KeyCode.Equals(Keys.Enter))
          {
              SendKeys.Send("{TAB}");
          }
          else if ((e.KeyCode.Equals(Keys.Up)) || (e.KeyCode.Equals(Keys.Left)))
          {
              SendKeys.Send("+{TAB}");
          }
          else if ((e.KeyCode.Equals(Keys.Down)) || (e.KeyCode.Equals(Keys.Right)))
          {
              SendKeys.Send("{TAB}");
          }
      }

      private void nextfieldenter2(object sender, KeyEventArgs e)
      {
          if (e.KeyCode.Equals(Keys.Enter))
          {
              SendKeys.Send("{TAB}");
          }

      }
  
    }
}
