﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Collections;

namespace TCIGL
{
    class ClsBuildEntryComboBox
    {
        public ArrayList ARWHCode = new ArrayList();
        public ArrayList ARDestWHCode = new ArrayList();
        public ArrayList ARTCode = new ArrayList();
        public ArrayList ARChannelCode = new ArrayList();
        public ArrayList ARGACode = new ArrayList();
        public ArrayList ARSPCode = new ArrayList();
        public ArrayList ARSMCode = new ArrayList();
        public ArrayList ARCatCode = new ArrayList();
        public ArrayList ARSupplierCode = new ArrayList();
        public ArrayList ARCollectCode = new ArrayList();
        public ArrayList ARDriverCode = new ArrayList();
        public ArrayList ARTruckCode = new ArrayList();
        public ArrayList ARLSNCatCode = new ArrayList();
        public ArrayList ARBDCode = new ArrayList();
        SqlConnection myconnection;
        SqlDataReader dr;
        SqlCommand mycommand;
        ClsDefaultBranch ClsDefaultBranch1 = new ClsDefaultBranch();
        ClsGetConnection ClsGetConnection1 = new ClsGetConnection();

        public void ClsBuildWHCode()
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = new SqlCommand("SELECT WHCode, WHDesc FROM tblWarehouse ORDER by WHDesc", myconnection);
                dr = mycommand.ExecuteReader();

                while (dr.Read())
                {
                    ARWHCode.Add(new Clsaddvalue(dr.GetString(1), dr.GetString(0)));
                }
                dr.Close();
                myconnection.Close();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
                myconnection.Close();
            }
        }

        public void ClsBuildDestWHCode()
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = new SqlCommand("SELECT WHCode, WHDesc FROM tblWarehouse ORDER by WHDesc", myconnection);
                dr = mycommand.ExecuteReader();

                while (dr.Read())
                {
                    ARDestWHCode.Add(new Clsaddvalue(dr.GetString(1), dr.GetString(0)));
                }
                dr.Close();
                myconnection.Close();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
                myconnection.Close();
            }
        }

        public void ClsBuildSalesman()
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = new SqlCommand("SELECT SMCode, SMDesc FROM tblSalesman ORDER by SMDesc ", myconnection);
                dr = mycommand.ExecuteReader();

                while (dr.Read())
                {
                    ARSMCode.Add(new Clsaddvalue(dr.GetString(1), dr.GetString(0)));
                }
                dr.Close();
                myconnection.Close();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
                myconnection.Close();
            }
        }
        public void ClsBuildTCode()
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = new SqlCommand("SELECT TCode, TDesc FROM tblTerritory ORDER by TDesc", myconnection);
                dr = mycommand.ExecuteReader();

                while (dr.Read())
                {
                    ARTCode.Add(new Clsaddvalue(dr.GetString(1), dr.GetString(0)));
                }
                dr.Close();
                myconnection.Close();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
                myconnection.Close();
            }
        }

        public void ClsBuildChannelCode()
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = new SqlCommand("SELECT ChannelCode, ChannelDesc FROM tblChannel ORDER by ChannelDesc", myconnection);
                dr = mycommand.ExecuteReader();

                while (dr.Read())
                {
                    ARChannelCode.Add(new Clsaddvalue(dr.GetString(1), dr.GetString(0)));
                }
                dr.Close();
                myconnection.Close();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
                myconnection.Close();
            }
        }

        public void ClsBuildGACode()
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = new SqlCommand("SELECT GACode, GADesc FROM tblGeogArea ORDER by GADesc", myconnection);
                dr = mycommand.ExecuteReader();

                while (dr.Read())
                {
                    ARGACode.Add(new Clsaddvalue(dr.GetString(1), dr.GetString(0)));
                }
                dr.Close();
                myconnection.Close();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
                myconnection.Close();
            }
        }
        public void ClsBuildSPCode()
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = new SqlCommand("SELECT SPCode, SPDesc FROM tblSPOption ORDER by SPDesc", myconnection);
                dr = mycommand.ExecuteReader();

                while (dr.Read())
                {
                    ARSPCode.Add(new Clsaddvalue(dr.GetString(1), dr.GetString(0)));
                }
                dr.Close();
                myconnection.Close();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
                myconnection.Close();
            }
        }

        public void ClsBuildCatCode()
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = new SqlCommand("SELECT CatCode, CatDesc FROM tblCategory ORDER by CatDesc", myconnection);
                dr = mycommand.ExecuteReader();

                while (dr.Read())
                {
                    ARCatCode.Add(new Clsaddvalue(dr.GetString(1), dr.GetString(0)));
                }
                dr.Close();
                myconnection.Close();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
                myconnection.Close();
            }
        }

        public void ClsBuildSupplierCode()
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = new SqlCommand("SELECT ControlNo, CustName FROM tblCustomer WHERE NType='S' ORDER BY CustName", myconnection);
                dr = mycommand.ExecuteReader();

                while (dr.Read())
                {
                    ARSupplierCode.Add(new Clsaddvalue(dr.GetString(1), dr.GetString(0)));
                }
                dr.Close();
                myconnection.Close();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
                myconnection.Close();
            }
        }

        public void ClsBuildCollectorCode()
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = new SqlCommand("SELECT CollectCode, CollectName FROM tblCollector WHERE Active=1 ORDER BY CollectName", myconnection);
                dr = mycommand.ExecuteReader();

                while (dr.Read())
                {
                    ARCollectCode.Add(new Clsaddvalue(dr.GetString(1), dr.GetString(0)));
                }
                dr.Close();
                myconnection.Close();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
                myconnection.Close();
            }
        }

        public void ClsBuildDriverCode()
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = new SqlCommand("SELECT DriverCode, Drivername FROM tblDriver ORDER by DriverName", myconnection);
                dr = mycommand.ExecuteReader();

                while (dr.Read())
                {
                    ARDriverCode.Add(new Clsaddvalue(dr.GetString(1), dr.GetString(0)));
                }
                dr.Close();
                myconnection.Close();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
                myconnection.Close();
            }
        }

        public void ClsBuildTruckCode()
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = new SqlCommand("SELECT TruckCode, TruckNumber FROM tblTruck ORDER by TruckNumber", myconnection);
                dr = mycommand.ExecuteReader();

                while (dr.Read())
                {
                    ARTruckCode.Add(new Clsaddvalue(dr.GetString(1), dr.GetString(0)));
                }
                dr.Close();
                myconnection.Close();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
                myconnection.Close();
            }
        }

        public void ClsBuildStocksCategory(string strCatCode)
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = new SqlCommand("SELECT StockNumber, StockDesc FROM tblStocks  WHERE Active = 1 AND CatCode = '"+strCatCode+"' ORDER by StockDesc ", myconnection);
                dr = mycommand.ExecuteReader();

                while (dr.Read())
                {
                    ARLSNCatCode.Add(new Clsaddvalue(dr.GetString(1), dr.GetString(0)));
                }
                dr.Close();
                myconnection.Close();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
                myconnection.Close();
            }
        }

        public void ClsBuildBDCode()
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = new SqlCommand("SELECT BankCode, BankName FROM tblBankDetail ORDER by BankName", myconnection);
                dr = mycommand.ExecuteReader();

                while (dr.Read())
                {
                    ARBDCode.Add(new Clsaddvalue(dr.GetString(1), dr.GetString(0)));
                }
                dr.Close();
                myconnection.Close();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
                myconnection.Close();
            }
        }

    }
}
