﻿namespace TCIGL
{
    partial class frmTransactEntryRS
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label17 = new System.Windows.Forms.Label();
            this.cboStockNumber = new System.Windows.Forms.ComboBox();
            this.label22 = new System.Windows.Forms.Label();
            this.txtQty = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtD3 = new System.Windows.Forms.TextBox();
            this.txtD2 = new System.Windows.Forms.TextBox();
            this.txtD1 = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.txtPDisct = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.txtBalance = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.txtUPCS = new System.Windows.Forms.TextBox();
            this.txtCost = new System.Windows.Forms.TextBox();
            this.txtActDisct = new System.Windows.Forms.TextBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.cbVAT = new System.Windows.Forms.CheckBox();
            this.cbProductCode = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(9, 19);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(151, 15);
            this.label17.TabIndex = 127;
            this.label17.Text = "PRODUCT DESCRIPTION:";
            // 
            // cboStockNumber
            // 
            this.cboStockNumber.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cboStockNumber.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cboStockNumber.DropDownWidth = 338;
            this.cboStockNumber.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboStockNumber.FormattingEnabled = true;
            this.cboStockNumber.Location = new System.Drawing.Point(12, 40);
            this.cboStockNumber.Name = "cboStockNumber";
            this.cboStockNumber.Size = new System.Drawing.Size(392, 23);
            this.cboStockNumber.TabIndex = 1;
            this.cboStockNumber.KeyDown += new System.Windows.Forms.KeyEventHandler(this.nextfieldenter2);
            this.cboStockNumber.Validating += new System.ComponentModel.CancelEventHandler(this.cboStockNumber_Validating);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(9, 71);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(34, 15);
            this.label22.TabIndex = 136;
            this.label22.Text = "QTY:";
            // 
            // txtQty
            // 
            this.txtQty.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQty.Location = new System.Drawing.Point(12, 89);
            this.txtQty.Name = "txtQty";
            this.txtQty.Size = new System.Drawing.Size(72, 22);
            this.txtQty.TabIndex = 2;
            this.txtQty.Text = "0.00";
            this.txtQty.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtQty.KeyDown += new System.Windows.Forms.KeyEventHandler(this.nextfieldenter1);
            this.txtQty.Validating += new System.ComponentModel.CancelEventHandler(this.txtQty_Validating);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(168, 71);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(60, 15);
            this.label14.TabIndex = 140;
            this.label14.Text = "LESS (%):";
            // 
            // txtD3
            // 
            this.txtD3.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtD3.Location = new System.Drawing.Point(138, 117);
            this.txtD3.Name = "txtD3";
            this.txtD3.Size = new System.Drawing.Size(33, 22);
            this.txtD3.TabIndex = 139;
            this.txtD3.Text = "0.0%";
            this.txtD3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtD3.Visible = false;
            // 
            // txtD2
            // 
            this.txtD2.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtD2.Location = new System.Drawing.Point(177, 118);
            this.txtD2.Name = "txtD2";
            this.txtD2.Size = new System.Drawing.Size(33, 22);
            this.txtD2.TabIndex = 138;
            this.txtD2.Text = "0.0%";
            this.txtD2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtD2.Visible = false;
            // 
            // txtD1
            // 
            this.txtD1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtD1.Location = new System.Drawing.Point(172, 89);
            this.txtD1.Name = "txtD1";
            this.txtD1.Size = new System.Drawing.Size(72, 22);
            this.txtD1.TabIndex = 4;
            this.txtD1.Text = "0.0%";
            this.txtD1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtD1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.nextfieldenter1);
            this.txtD1.Validating += new System.ComponentModel.CancelEventHandler(this.txtD1_Validating);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(246, 71);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(79, 15);
            this.label26.TabIndex = 144;
            this.label26.Text = "LESS (PESO):";
            // 
            // txtPDisct
            // 
            this.txtPDisct.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPDisct.Location = new System.Drawing.Point(250, 89);
            this.txtPDisct.Name = "txtPDisct";
            this.txtPDisct.Size = new System.Drawing.Size(72, 22);
            this.txtPDisct.TabIndex = 5;
            this.txtPDisct.Text = "0.00";
            this.txtPDisct.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtPDisct.KeyDown += new System.Windows.Forms.KeyEventHandler(this.nextfieldenter1);
            this.txtPDisct.Validating += new System.ComponentModel.CancelEventHandler(this.txtPDisct_Validating);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(348, 71);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(49, 15);
            this.label29.TabIndex = 161;
            this.label29.Text = "Balance";
            // 
            // txtBalance
            // 
            this.txtBalance.Enabled = false;
            this.txtBalance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBalance.Location = new System.Drawing.Point(328, 89);
            this.txtBalance.Name = "txtBalance";
            this.txtBalance.Size = new System.Drawing.Size(76, 22);
            this.txtBalance.TabIndex = 6;
            this.txtBalance.Text = "0.00";
            this.txtBalance.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(87, 71);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(75, 15);
            this.label25.TabIndex = 158;
            this.label25.Text = "Selling Price:";
            // 
            // txtUPCS
            // 
            this.txtUPCS.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUPCS.Location = new System.Drawing.Point(90, 89);
            this.txtUPCS.Name = "txtUPCS";
            this.txtUPCS.Size = new System.Drawing.Size(76, 22);
            this.txtUPCS.TabIndex = 3;
            this.txtUPCS.Text = "0.00";
            this.txtUPCS.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtUPCS.KeyDown += new System.Windows.Forms.KeyEventHandler(this.nextfieldenter1);
            this.txtUPCS.Validating += new System.ComponentModel.CancelEventHandler(this.txtUPCS_Validating);
            // 
            // txtCost
            // 
            this.txtCost.Enabled = false;
            this.txtCost.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCost.Location = new System.Drawing.Point(97, 117);
            this.txtCost.Name = "txtCost";
            this.txtCost.Size = new System.Drawing.Size(35, 22);
            this.txtCost.TabIndex = 169;
            this.txtCost.Text = "0.00";
            this.txtCost.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCost.Visible = false;
            // 
            // txtActDisct
            // 
            this.txtActDisct.Enabled = false;
            this.txtActDisct.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtActDisct.Location = new System.Drawing.Point(188, 12);
            this.txtActDisct.Name = "txtActDisct";
            this.txtActDisct.Size = new System.Drawing.Size(40, 22);
            this.txtActDisct.TabIndex = 171;
            this.txtActDisct.Text = "0.00";
            this.txtActDisct.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtActDisct.Visible = false;
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(294, 130);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(52, 23);
            this.btnSave.TabIndex = 7;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(352, 130);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(52, 23);
            this.btnClose.TabIndex = 8;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // cbVAT
            // 
            this.cbVAT.AutoSize = true;
            this.cbVAT.Location = new System.Drawing.Point(15, 123);
            this.cbVAT.Name = "cbVAT";
            this.cbVAT.Size = new System.Drawing.Size(53, 17);
            this.cbVAT.TabIndex = 175;
            this.cbVAT.Text = "VAT?";
            this.cbVAT.UseVisualStyleBackColor = true;
            this.cbVAT.Visible = false;
            // 
            // cbProductCode
            // 
            this.cbProductCode.AutoSize = true;
            this.cbProductCode.Checked = true;
            this.cbProductCode.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbProductCode.Location = new System.Drawing.Point(15, 144);
            this.cbProductCode.Name = "cbProductCode";
            this.cbProductCode.Size = new System.Drawing.Size(91, 17);
            this.cbProductCode.TabIndex = 188;
            this.cbProductCode.Text = "Product Code";
            this.cbProductCode.UseVisualStyleBackColor = true;
            this.cbProductCode.CheckedChanged += new System.EventHandler(this.cbProductCode_CheckedChanged);
            // 
            // frmTransactEntryRS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(424, 173);
            this.ControlBox = false;
            this.Controls.Add(this.cbProductCode);
            this.Controls.Add(this.cbVAT);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.txtActDisct);
            this.Controls.Add(this.txtCost);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.txtBalance);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.txtUPCS);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.txtPDisct);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.txtD3);
            this.Controls.Add(this.txtD2);
            this.Controls.Add(this.txtD1);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.txtQty);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.cboStockNumber);
            this.KeyPreview = true;
            this.Name = "frmTransactEntryRS";
            this.Text = "Entry";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.frmSalesEntry_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frmSalesEntry_KeyDown);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ComboBox cboStockNumber;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtQty;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtD3;
        private System.Windows.Forms.TextBox txtD2;
        private System.Windows.Forms.TextBox txtD1;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox txtPDisct;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox txtBalance;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox txtUPCS;
        private System.Windows.Forms.TextBox txtCost;
        private System.Windows.Forms.TextBox txtActDisct;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.CheckBox cbVAT;
        private System.Windows.Forms.CheckBox cbProductCode;
    }
}