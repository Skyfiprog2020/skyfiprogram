﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using CrystalDecisions.CrystalReports.Engine;
using System.Threading;

namespace TCIGL
{
    public partial class frmVoucherOR : Form
    {
        public static TextBox glbldocnum;
        ClsCompName ClsCompName1 = new ClsCompName();
        
        SqlConnection myconnection;
        SqlCommand mycommand;
        //SqlDataReader dr;
        string varoutdate = "No";
        private SqlDataAdapter da;
        private DataTable dataTable = null;
        private BindingSource bindingSource = null;
        string dgvdata = null;
        ClsAutoNumber ClsAutoNumber1 = new ClsAutoNumber();
        ClsBuildComboBox ClsBuildComboBox1 = new ClsBuildComboBox();
        ClsPermission ClsPermission1 = new ClsPermission();
        ClsValidation ClsValidation1 = new ClsValidation();
        ClsGetSomething ClsGetSomething1 = new ClsGetSomething();
        ClsGetSomethingOthers ClsGetSomethingOthers1 = new ClsGetSomethingOthers(); 
        ClsDefaultBranch ClsDefaultBranch1 = new ClsDefaultBranch();
        ClsGetConnection ClsGetConnection1 = new ClsGetConnection();
        ClsBuildEntryComboBox ClsBuildEntryComboBox1 = new ClsBuildEntryComboBox();
        ClsBuildCOAComboBox ClsBuildCOAComboBox1 = new ClsBuildCOAComboBox();
        int varintTableDoor = 0;
        int number = 0;
        private string privarstrVoidIC = null;

        public frmVoucherOR()
        {
            InitializeComponent();
            {
                ClsGetSomethingOthers1.ClsGetVoidRef("OR", "1");
                privarstrVoidIC = ClsGetSomethingOthers1.plsVoidIC;
                if (new ClsValidation().emptytxt(privarstrVoidIC))
                { }
                else
                {
                    ClsGetSomethingOthers1.ClsDeleteErrorTransaction("OR", "1");
                }
            }
        }

        private void buildcboBank()
        {
            cboBank.DataSource = null;
            ClsBuildCOAComboBox1.ARLRAct.Clear();
            ClsBuildCOAComboBox1.ClsbuildcboReleasingAct();
            this.cboBank.DataSource = (ClsBuildCOAComboBox1.ARLRAct);
            this.cboBank.DisplayMember = "Display";
            this.cboBank.ValueMember = "Value";
        }

        private void frmVoucherOR_Load(object sender, EventArgs e)
        {
            ClsPermission1.ClsObjects(this.Text);
            if (new ClsValidation().emptytxt(ClsPermission1.plstxtObject))
            {
                MessageBox.Show("You do not have necessary permission to open this file", "GL");
                this.Close();
            }
            else
            {
                ClsAutoNumber1.VoucherAutoNum("OR");
                txtDocNum.Text = (ClsAutoNumber1.plsnumber);
                ClsGetSomething1.ClsGetDefaultDate();
                txtTDate.Text = ClsGetSomething1.plsdefdate;
                buildcboControlNo();
                buildcboPA();
                buildcboSMCode();
                buildcboCollectorCode();
                buildcboBank();
                cboBank.SelectedValue = "12000000004";//default Value
                cboControlNo.SelectedValue = ""; cboSMCode.SelectedValue = "";
                cboCollectCode.SelectedValue = "";
                ClsGetSomethingOthers1.ClsGetVoidRef("OR", "1");
                privarstrVoidIC = ClsGetSomethingOthers1.plsVoidIC;
                if (new ClsValidation().emptytxt(privarstrVoidIC))
                { }
                else
                {
                    ClsGetSomethingOthers1.ClsDeleteErrorTransaction("OR", "1");
                    privarstrVoidIC = null;
                }
            }
        }
        private void buildcboControlNo()
        {
            cboControlNo.DataSource = null;
            ClsBuildComboBox1.ARLCVCN.Clear();
            ClsBuildComboBox1.ClsBuildCVControlno();
            this.cboControlNo.DataSource = (ClsBuildComboBox1.ARLCVCN);
            this.cboControlNo.DisplayMember = "Display";
            this.cboControlNo.ValueMember = "Value";
        }

        private void buildcboPA()
        {
            cboPA.DataSource = null;
            ClsBuildCOAComboBox1.ARPA.Clear();
            ClsBuildCOAComboBox1.ClsBuildPA(Convert.ToBoolean (cbAccountNo.CheckState));
            this.cboPA.DataSource = (ClsBuildCOAComboBox1.ARPA);
            this.cboPA.DisplayMember = "Display";
            this.cboPA.ValueMember = "Value";
            this.cboPA.DropDownWidth = 450;
        }
        private void buildcboSMCode()
        {
            cboSMCode.DataSource = null;
            ClsBuildEntryComboBox1.ARSMCode.Clear();
            ClsBuildEntryComboBox1.ClsBuildSalesman();
            this.cboSMCode.DataSource = (ClsBuildEntryComboBox1.ARSMCode);
            this.cboSMCode.DisplayMember = "Display";
            this.cboSMCode.ValueMember = "Value";
        }

        private void buildcboCollectorCode()
        {
            cboCollectCode.DataSource = null;
            ClsBuildEntryComboBox1.ARCollectCode.Clear();
            ClsBuildEntryComboBox1.ClsBuildCollectorCode();
            this.cboCollectCode.DataSource = (ClsBuildEntryComboBox1.ARCollectCode);
            this.cboCollectCode.DisplayMember = "Display";
            this.cboCollectCode.ValueMember = "Value";
        }

        private void buildShowCustBalance()
        {
            dgvListReceive.DataSource = null;
            dgvListReceive.Columns.Clear();

            string sqlstatement;
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            sqlstatement = "SELECT Refer, MinDate, Bal FROM ViewIndAccount WHERE MinDate <= '" + txtTDate.Text + "' AND  ControlNo='" + cboControlNo.SelectedValue.ToString() + "'";
            
            da = new SqlDataAdapter(sqlstatement, myconnection);
            SqlCommandBuilder commandBuilder = new SqlCommandBuilder(da);

            dataTable = new DataTable();
            da.Fill(dataTable);
            bindingSource = new BindingSource();
            bindingSource.DataSource = dataTable;

            //Adding  Reference TextBox
            DataGridViewTextBoxColumn ColumnReference = new DataGridViewTextBoxColumn();
            ColumnReference.HeaderText = "Reference";
            ColumnReference.Width = 150;
            ColumnReference.DataPropertyName = "Refer";
            //ColumnReference.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            //ColumnReference.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            //ColumnReference.Visible = false;
            ColumnReference.ReadOnly = true;
            dgvListReceive.Columns.Add(ColumnReference);

            //Adding  TDate TextBox
            DataGridViewTextBoxColumn ColumnTDate = new DataGridViewTextBoxColumn();
            ColumnTDate.HeaderText = "Date";
            ColumnTDate.Width = 150;
            ColumnTDate.DataPropertyName = "MinDate";
            //ColumnTDate.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            //ColumnTDate.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            //ColumnTDate.Visible = false;
            ColumnTDate.ReadOnly = true;
            dgvListReceive.Columns.Add(ColumnTDate);

            //Adding  Balance TextBox
            DataGridViewTextBoxColumn ColumnBalance = new DataGridViewTextBoxColumn();
            ColumnBalance.HeaderText = "Balance";
            ColumnBalance.Width = 150;
            ColumnBalance.DataPropertyName = "Bal";
            //ColumnBalance.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnBalance.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnBalance.ReadOnly = true;
            dgvListReceive.Columns.Add(ColumnBalance);

            //dgvListReceive.Columns[0].Name = "RVRefer";
            //dgvListReceive.Columns[1].Name = "TDate";
            //dgvListReceive.Columns[2].Name = "Balance";
            //Setting Data Source for DataGridView
            dgvListReceive.DataSource = bindingSource;
            //            dgvListReceive.AutoResizeColumns();
            //            dgvListReceive.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            myconnection.Close();
            //            this.WindowState = FormWindowState.Maximized;
            //dgvListReceive.AllowUserToAddRows = false;
            dgvListReceive.Columns[2].DefaultCellStyle.Format = "N2";
            dgvListReceive.Columns[1].DefaultCellStyle.Format = "MM/dd/yyyy";
        }



        private void cboControlNo_Validating(object sender, CancelEventArgs e)
        {
                if (new ClsValidation().emptytxt(cboControlNo.Text))
                {
                }
                else if (cboControlNo.Text != null && cboControlNo.SelectedValue == null)
                {
                    MessageBox.Show("Not found","GL");
                    cboControlNo.Focus();
                }
                else
                {
                    buildShowCustBalance();
                    ClsGetSomething1.ClsGetCustData(cboControlNo.SelectedValue.ToString());
                    cboSMCode.SelectedValue = ClsGetSomething1.plsSMCode;
                    cboCollectCode.SelectedValue = ClsGetSomething1.plsvarCollectCode;
                    //buildlv();
                }
          }

        private void dgv1total()
        {
            double vartxtdr = 0.00;
            double vartxtcr = 0.00;
            double vartxtdiff = 0.00;
            for (int x = 0; x < dgv1.Rows.Count - 1; x++)
            {
                vartxtdr += double.Parse(dgv1.Rows[x].Cells[3].FormattedValue.ToString());
            }

            for (int x = 0; x < dgv1.Rows.Count - 1; x++)
            {
                vartxtcr += double.Parse(dgv1.Rows[x].Cells[4].FormattedValue.ToString());
            }
            txtdrtot.Text = vartxtdr.ToString("n2");
            txtcrtot.Text = vartxtcr.ToString("n2");
            vartxtdiff = Convert.ToDouble(txtdrtot.Text) - Convert.ToDouble(txtcrtot.Text);
            txtDifference.Text = vartxtdiff.ToString("n2");
            txtCDiff.Text = ((double.Parse(txtDifference.Text)*-1) - double.Parse(txtCAmount.Text)).ToString("N2");

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dgv1_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            // Clear the row error in case the user presses ESC.   
            dgv1.Rows[e.RowIndex].ErrorText = String.Empty;

            if (e.ColumnIndex == dgv1.Columns["cbopa"].Index)
            {
                string[] values = new string[1];
                DataGridViewRow row = dgv1.Rows[e.RowIndex];

                ClsGetSomething1.ClsGetAT(row.Cells[0].Value.ToString());
                row.Cells[1].Value = ClsGetSomething1.plsAT;

                dgv1.CurrentRow.Cells[2].Value = txtreference.Text;
                dgv1.CurrentRow.Cells[3].Value = "0.00";
                dgv1.CurrentRow.Cells[4].Value = "0.00";
                dgv1.CurrentRow.Cells[5].Value = 0;
                dgv1total();
            }
            else if (e.ColumnIndex == dgv1.Columns["txtdr"].Index)
            {
                this.dgv1.Rows[e.RowIndex].Cells[3].Value = double.Parse(dgv1.Rows[e.RowIndex].Cells[3].FormattedValue.ToString().Trim()).ToString("N2");
                dgv1total();
            }

            else if (e.ColumnIndex == dgv1.Columns["txtcr"].Index)
            {
                this.dgv1.Rows[e.RowIndex].Cells[4].Value = double.Parse(dgv1.Rows[e.RowIndex].Cells[4].FormattedValue.ToString().Trim()).ToString("N2");
                dgv1total();
            }


        }

     
        private void dgv1_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            //if (e.Control is DataGridViewComboBoxEditingControl)
            //{
            //    ((ComboBox)e.Control).DropDownStyle = ComboBoxStyle.DropDown;
            //    ((ComboBox)e.Control).AutoCompleteSource = AutoCompleteSource.ListItems;
            //    ((ComboBox)e.Control).AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            //}
  
        }

        private void dgv1_CurrentCellDirtyStateChanged(object sender, EventArgs e)
        {
            if (dgv1.IsCurrentCellDirty)
            {
                dgv1.CommitEdit(DataGridViewDataErrorContexts.Commit);
            }
   
        }

        private void dgv1_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        {
            if (e.ColumnIndex == dgv1.Columns["txtrefer"].Index)  //this is our numeric column
            {
                if (String.IsNullOrEmpty(e.FormattedValue.ToString()))// &&
                //dgv1[e.ColumnIndex, e.RowIndex].IsInEditMode)
                {
                    e.Cancel = true;
                    MessageBox.Show("Empty", "IS");
                }
            }
            else if (e.ColumnIndex == dgv1.Columns["txtDR"].Index)  //this is our numeric column
            {
                if (String.IsNullOrEmpty(e.FormattedValue.ToString()))// &&
                //dgv1[e.ColumnIndex, e.RowIndex].IsInEditMode)
                {
                    e.Cancel = true;
                    MessageBox.Show("Empty", "IS");
                }
                else
                {
                    double i;
                    if (!double.TryParse(Convert.ToString(e.FormattedValue), out i))
                    {
                        e.Cancel = true;
                        MessageBox.Show("Numeric only", "IS");
                    }
                }
            }

            else if (e.ColumnIndex == dgv1.Columns["txtCR"].Index)  //this is our numeric column
            {
                if (String.IsNullOrEmpty(e.FormattedValue.ToString()))// &&
                //dgv1[e.ColumnIndex, e.RowIndex].IsInEditMode)
                {
                    e.Cancel = true;
                    MessageBox.Show("Empty", "IS");
                }
                else
                {
                    double i;
                    if (!double.TryParse(Convert.ToString(e.FormattedValue), out i))
                    {
                        e.Cancel = true;
                        MessageBox.Show("Numeric only", "IS");
                    }
                }
            }
        }


        private void SaveTransact()
        {
            try
            {
                DateTime DT = DateTime.Now;
                ClsAutoNumber1.VoucherAutoNum("OR");
                txtDocNum.Text = (ClsAutoNumber1.plsnumber);

                string sqlstatement = "INSERT INTO tblmain1 (IC, DocNum, Voucher, UserCode, TDate, Reference, ControlNo, Remarks,  Term, CheckNo, CAmount, DE, CNCode) ";
                sqlstatement += "Values (@_IC, @_DocNum, @_Voucher, @_UserCode, @_TDate, @_Reference, @_ControlNo, @_Remarks,  @_Term, @_CheckNo, @_CAmount, @_DE, @_CNCode)";
                string sqlstatementdgv2 = "INSERT INTO tblmain3 (IC, Refer, ActRemarks, Debit, Credit, PA, SIT) Values (@_IC, @_Refer, @_ActRemarks, @_Debit, @_Credit, @_PA, @_SIT)";

                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();

                mycommand = new SqlCommand(sqlstatement, myconnection);
                mycommand.Parameters.Add("_IC", SqlDbType.VarChar).Value = "OR" + Form1.glbluc.Text + (ClsDefaultBranch1.plsvardb);
                mycommand.Parameters.Add("_DocNum", SqlDbType.VarChar).Value = Form1.glbluc.Text;
                mycommand.Parameters.Add("_Voucher", SqlDbType.VarChar).Value = "OR";
                mycommand.Parameters.Add("_UserCode", SqlDbType.VarChar).Value = Form1.glbluc.Text;
                mycommand.Parameters.Add("_TDate", SqlDbType.DateTime).Value = txtTDate.Text;
                mycommand.Parameters.Add("_Reference", SqlDbType.VarChar).Value = txtreference.Text;
                mycommand.Parameters.Add("_ControlNo", SqlDbType.VarChar).Value = cboControlNo.SelectedValue.ToString();
                mycommand.Parameters.Add("_Remarks", SqlDbType.VarChar).Value = txtRemarks.Text;
                mycommand.Parameters.Add("_Term", SqlDbType.Int).Value = 0;
                mycommand.Parameters.Add("_CheckNo", SqlDbType.VarChar).Value = txtCheckNo.Text;
                mycommand.Parameters.Add("_CAmount", SqlDbType.Decimal).Value = txtCAmount.Text;
                mycommand.Parameters.Add("_DE", SqlDbType.DateTime).Value = DT;
                mycommand.Parameters.Add("_CNCode", SqlDbType.Char).Value = (ClsDefaultBranch1.plsvardb);
                int n1 = mycommand.ExecuteNonQuery();


                DataGridViewRow row = null;
                for (int x = 0; x < dgv1.Rows.Count - 1; x++)
                {
                    row = dgv1.Rows[x];
                    mycommand = new SqlCommand(sqlstatementdgv2, myconnection);
                    mycommand.Parameters.Add("_IC", SqlDbType.VarChar).Value = "OR" + Form1.glbluc.Text + (ClsDefaultBranch1.plsvardb);
                    mycommand.Parameters.Add("_Refer", SqlDbType.VarChar).Value = row.Cells[2].Value;
                    mycommand.Parameters.Add("_ActRemarks", SqlDbType.VarChar).Value = "NA";
                    mycommand.Parameters.Add("_Debit", SqlDbType.Decimal).Value = row.Cells[3].Value;
                    mycommand.Parameters.Add("_Credit", SqlDbType.Decimal).Value = row.Cells[4].Value;
                    mycommand.Parameters.Add("_PA", SqlDbType.VarChar).Value = row.Cells[0].Value;
                    mycommand.Parameters.Add("_SIT", SqlDbType.Bit).Value = row.Cells[5].Value;
                    int n2 = mycommand.ExecuteNonQuery();
                }
                myconnection.Close();
                ClsGetSomethingOthers1.ClsFinalize("OR", txtDocNum.Text, "1");

                if (cbSP.Checked)
                {
                    int varnocopy = int.Parse(frmMain.glbltxtNoCopy.Text);
                    for (int i = 1; i <= varnocopy; i++)
                    {
                        printcurvoucher();
                    }
                }

                ClsAutoNumber1.VoucherAutoNum("OR");
                txtDocNum.Text = (ClsAutoNumber1.plsnumber);

                dgv1.Rows.Clear();
                txtreference.Text = "";
                // txtCheckNo.Text = "NA";
                txtCAmount.Text = "0.00";
                cboControlNo.Text = "";
                txtRemarks.Text = "";
                txtTDate.Focus();
                txtdrtot.Text = "0.00";
                txtcrtot.Text = "0.00";
                txtDifference.Text = "0.00";
                dgvdata = null;
                txtTDate.Text = ClsGetSomething1.plsdefdate;
                cboControlNo.SelectedValue = ""; cboSMCode.SelectedValue = "";
                cboCollectCode.SelectedValue = "";

            }
            catch
            {
                MessageBox.Show("Error, please click OK", "GL");
                this.Close();
            }
            finally
            {
                //               dr.Close();
                myconnection.Close();
            }
        }


        private void getSLSEntry()
        {
            double varslsCollection = Convert.ToDouble(txtDifference.Text)*-1;
            //Salesman Collection
            //ClsGetSomething1.ClsGetAT("11500000000");
            //dgv1.Rows.Add("11500000000", ClsGetSomething1.plsAT, txtreference.Text, varslsCollection.ToString("N2"), "0.00", 0);
            dgv1.Rows.Add(cboBank.SelectedValue.ToString(), ClsGetSomething1.plsAT, txtreference.Text, varslsCollection.ToString("N2"), "0.00", 0);
            dgv1total();
        }


      
 

        private void ORSave()
        {
            try
            {
                getSLSEntry();
                double vartxtdrtot = double.Parse((txtdrtot.Text).ToString());
                double vartxtcrtot = double.Parse((txtcrtot.Text).ToString());

                ClsAutoNumber1.VoucherAutoNum("OR");
                txtDocNum.Text = (ClsAutoNumber1.plsnumber);

                ClsValidation1.securedate(DateTime.Parse(txtTDate.Text));
                varoutdate = (ClsValidation1.plsoutdate);

                for (int x = 0; x < dgv1.Rows.Count - 1; x++)
                {
                    dgvdata = (dgv1.Rows[x].Cells[0].FormattedValue.ToString());
                }

                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();

                if (new Clsexist().RecordExists(ref myconnection, "SELECT Reference FROM tblmain1 WHERE Reference ='" + txtreference.Text + "' AND CNCode = '" + (ClsDefaultBranch1.plsvardb) + "'"))
                {
                    myconnection.Close();
                    MessageBox.Show("Duplicate entry", "GL");
                    txtTDate.Focus();
                }
                else if (txtTDate.Text == "  /  /")
                {
                    MessageBox.Show("Please complete your entry", "GL");
                    txtTDate.Focus();
                }
                else if (new ClsValidation().emptytxt (txtreference .Text))
                {
                    MessageBox.Show("Please complete your entry", "GL");
                    txtreference.Focus();
                }
                else if (new ClsValidation().emptytxt(txtCheckNo.Text))
                {
                    MessageBox.Show("Please complete your entry", "GL");
                    txtCheckNo.Focus();
                }

                else if (new ClsValidation().emptytxt(txtCAmount.Text))
                {
                    MessageBox.Show("Please complete your entry", "GL");
                    txtCAmount.Focus();
                }

                else if (new ClsValidation().emptytxt(cboControlNo.Text))
                {
                    MessageBox.Show("Please complete your entry", "GL");
                    cboControlNo.Focus();
                }
                else if (new ClsValidation().emptytxt(cboSMCode.Text))
                {
                    MessageBox.Show("Please complete your entry", "GL");
                    cboSMCode.Focus();
                }
                else if (new ClsValidation().emptytxt(txtRemarks.Text))
                {
                    MessageBox.Show("Please complete your entry", "GL");
                    txtRemarks.Focus();
                }
                else if (varoutdate == "Yes")
                {
                    myconnection.Close();
                    MessageBox.Show("Date is out of range", "GL");
                    txtTDate.Focus();
                }

                else if (vartxtdrtot != vartxtcrtot)
                {
                    MessageBox.Show("Not balance", "GL");
                    txtRemarks.Focus();
                }
                else if (new ClsValidation().emptytxt(dgvdata))
                {
                    MessageBox.Show("Incomplete Record", "IS");
                    txtTDate.Focus();
                }

                else
                {
                    string sqlstatement;
                    DateTime DT = DateTime.Now;
                    //  txtTStart.Text = DT.ToString();
                    sqlstatement = "INSERT INTO tblmain1 (IC, DocNum, Voucher, UserCode, TDate, Reference, ControlNo, Remarks,  Term, CheckNo, CAmount, ASMCode, CollectCode, DE, CNCode)";
                    sqlstatement += " Values (@_IC, @_DocNum, @_Voucher, @_UserCode, @_TDate, @_Reference, @_ControlNo, @_Remarks,  @_Term, @_CheckNo, @_CAmount, @_ASMCode, @_CollectCode, @_DE, @_CNCode)";
                    string sqlstatementdgv1 = "INSERT INTO tblmain3 (IC, Refer, Debit, Credit, PA, SIT, STCode) Values (@_IC, @_Refer, @_Debit, @_Credit, @_PA, @_SIT, @_STCode)";

                    mycommand = new SqlCommand(sqlstatement, myconnection);
                    mycommand.Parameters.Add("_IC", SqlDbType.VarChar).Value = "OR" + txtDocNum.Text + (ClsDefaultBranch1.plsvardb);
                    mycommand.Parameters.Add("_DocNum", SqlDbType.VarChar).Value = txtDocNum.Text;
                    mycommand.Parameters.Add("_Voucher", SqlDbType.VarChar).Value = "OR";
                    mycommand.Parameters.Add("_UserCode", SqlDbType.VarChar).Value = Form1.glbluc.Text;
                    mycommand.Parameters.Add("_TDate", SqlDbType.DateTime).Value = txtTDate.Text;
                    mycommand.Parameters.Add("_Reference", SqlDbType.VarChar).Value = txtreference.Text;
                    mycommand.Parameters.Add("_ControlNo", SqlDbType.VarChar).Value = cboControlNo.SelectedValue;
                    mycommand.Parameters.Add("_Remarks", SqlDbType.VarChar).Value = txtRemarks.Text;
                    mycommand.Parameters.Add("_Term", SqlDbType.Int).Value = 0;
                    mycommand.Parameters.Add("_CheckNo", SqlDbType.VarChar).Value = txtCheckNo.Text;
                    mycommand.Parameters.Add("_CAmount", SqlDbType.Decimal).Value = txtCAmount.Text;
                    mycommand.Parameters.Add("_ASMCode", SqlDbType.VarChar).Value = cboSMCode.SelectedValue.ToString();
                    mycommand.Parameters.Add("_CollectCode", SqlDbType.VarChar).Value = cboCollectCode.SelectedValue.ToString();
                    mycommand.Parameters.Add("_DE", SqlDbType.DateTime).Value = DT;
                    mycommand.Parameters.Add("_CNCode", SqlDbType.VarChar).Value = (ClsDefaultBranch1.plsvardb);
                    int n1 = mycommand.ExecuteNonQuery();

                    //       dgv1.AllowUserToAddRows = true;
                    DataGridViewRow row = null;
                    for (int x = 0; x < dgv1.Rows.Count - 1; x++)
                    {
                        row = dgv1.Rows[x];

                        mycommand = new SqlCommand(sqlstatementdgv1, myconnection);
                        mycommand.Parameters.Add("_IC", SqlDbType.VarChar).Value = "OR" + txtDocNum.Text + (ClsDefaultBranch1.plsvardb);
                        mycommand.Parameters.Add("_Refer", SqlDbType.VarChar).Value = row.Cells[2].Value;
                        mycommand.Parameters.Add("_Debit", SqlDbType.Decimal).Value = row.Cells[3].Value;
                        mycommand.Parameters.Add("_Credit", SqlDbType.Decimal).Value = row.Cells[4].Value;
                        mycommand.Parameters.Add("_PA", SqlDbType.VarChar).Value = row.Cells[0].Value;
                        mycommand.Parameters.Add("_SIT", SqlDbType.VarChar).Value = row.Cells[5].Value;
                        mycommand.Parameters.Add("_STCode", SqlDbType.VarChar).Value = row.Cells[2].Value;
                        int n2 = mycommand.ExecuteNonQuery();
                    }

                    myconnection.Close();
                    //dr.Close();

                    if (cbSP.Checked)
                    {
                        int varnocopy = int.Parse(frmMain.glbltxtNoCopy.Text);
                        for (int i = 1; i <= varnocopy; i++)
                        {
                            printcurvoucher();
                        }
                    }
                    ClsAutoNumber1.VoucherAutoNum("OR");
                    txtDocNum.Text = (ClsAutoNumber1.plsnumber);

                    dgv1.Rows.Clear();
                    txtreference.Text = "";
                    txtCheckNo.Text = "";
                    txtCAmount.Text = "0.00";
                    cboControlNo.SelectedValue = "";
                    cboSMCode.SelectedValue = "";
                    cboCollectCode.SelectedValue = "";
                    txtRemarks.Text = "Collection";
                    txtTDate.Focus();
                    txtdrtot.Text = "0.00";
                    txtcrtot.Text = "0.00";
                    txtDifference.Text = "0.00";
                    txtCDiff.Text = "0.00";
                    dgvListReceive.DataSource = null;
                    dgvListReceive.Columns.Clear();
                    createcolumn();
                    dgvdata = null;
                }
            }
            catch
            {
                MessageBox.Show("Busy, please click OK", "GL");
                ORSave();
            }
            finally
            {
                //               dr.Close();
                myconnection.Close();
            }
        }

        private void createcolumn()
        {
            var ColReference = new DataGridViewTextBoxColumn();
            var ColTDate = new DataGridViewTextBoxColumn();
            var ColBal = new DataGridViewTextBoxColumn();
            
            ColReference.HeaderText = "Reference";
            ColReference.Name = "ColumnReference";
            ColReference.Width = 150;

            ColTDate.HeaderText = "Date";
            ColTDate.Name = "ColumnTDate";
            ColTDate.Width = 150;

            ColBal.HeaderText = "Balance";
            ColBal.Name = "ColumnBalance";
            ColBal.Width = 150;

            dgvListReceive.Columns.AddRange(new DataGridViewColumn[] { ColReference, ColTDate, ColBal });

        }
        private void dgv1_UserDeletedRow(object sender, DataGridViewRowEventArgs e)
        {
            dgv1total();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            getSLSEntry();
            double vartxtdrtot = double.Parse((txtdrtot.Text).ToString());
            double vartxtcrtot = double.Parse((txtcrtot.Text).ToString());

            ClsValidation1.securedate(DateTime.Parse(txtTDate.Text));
            varoutdate = (ClsValidation1.plsoutdate);

            for (int x = 0; x < dgv1.Rows.Count - 1; x++)
            {
                dgvdata = (dgv1.Rows[x].Cells[0].FormattedValue.ToString());
            }

            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();
            if (new Clsexist().RecordExists(ref myconnection, "SELECT Reference FROM tblmain1 WHERE Reference ='" + txtreference.Text + "' AND CNCode = '" + (ClsDefaultBranch1.plsvardb) + "'"))
            {
                myconnection.Close();
                MessageBox.Show("Duplicate entry", "GL");
                txtTDate.Focus();
            }
            else if (txtTDate.Text == "  /  /")
            {
                myconnection.Close();
                MessageBox.Show("Please complete your entry", "GL");
                txtTDate.Focus();
            }
            else if (new ClsValidation().emptytxt(txtreference.Text))
            {
                myconnection.Close();
                MessageBox.Show("Please complete your entry", "GL");
                txtreference.Focus();
            }
            else if (new ClsValidation().emptytxt(txtCheckNo.Text))
            {
                myconnection.Close();
                MessageBox.Show("Please complete your entry", "GL");
                txtCheckNo.Focus();
            }
            else if (new ClsValidation().emptytxt(txtCAmount.Text))
            {
                myconnection.Close();
                MessageBox.Show("Please complete your entry", "GL");
                txtCAmount.Focus();
            }
            else if (new ClsValidation().emptytxt(cboControlNo.Text))
            {
                myconnection.Close();
                MessageBox.Show("Please complete your entry", "GL");
                cboControlNo.Focus();
            }
            else if (new ClsValidation().emptytxt(txtRemarks.Text))
            {
                myconnection.Close();
                MessageBox.Show("Please complete your entry", "GL");
                txtRemarks.Focus();
            }
            else if (varoutdate == "Yes")
            {
                myconnection.Close();
                MessageBox.Show("Date is out of range", "GL");
                txtTDate.Focus();
            }

            else if (vartxtdrtot != vartxtcrtot)
            {
                myconnection.Close();
                MessageBox.Show("Not balance", "GL");
                txtRemarks.Focus();
            }
            else if (new ClsValidation().emptytxt(dgvdata))
            {
                myconnection.Close();
                MessageBox.Show("Incomplete Record", "GL");
                txtTDate.Focus();
            }
            else
            {
                myconnection.Close();
                privarstrVoidIC = null;
                ClsGetSomethingOthers1.ClsGetTDoor("OR");
                varintTableDoor = int.Parse(ClsGetSomethingOthers1.plsTableDoor);
                number = 0;
                while (varintTableDoor == 1 && number <= 20)
                {
                    number = number + 1;
                    Thread.Sleep(200);
                    varintTableDoor = int.Parse(ClsGetSomethingOthers1.plsTableDoor);
                }

                if (varintTableDoor == 0 && number <= 20)
                {

                    ClsGetSomethingOthers1.ClsGetVoidRef("OR", "1");
                    privarstrVoidIC = ClsGetSomethingOthers1.plsVoidIC;
                    if (new ClsValidation().emptytxt(privarstrVoidIC))
                    {
                        ClsGetSomethingOthers1.ClsOneTheDoor("OR");
                        SaveTransact();
                        ClsGetSomethingOthers1.ClsZeroTheDoor("OR");
                    }
                    else
                    {
                        ClsGetSomethingOthers1.ClsDeleteErrorTransaction("OR", "1");
                        MessageBox.Show("Transaction not saved", "GL");
                    }
                }
                else if (varintTableDoor == 1 && number == 21)
                {
                    MessageBox.Show("Contact your adminnistrator", "GL");
                }
            }

        }

        private void txtCAmount_Validating(object sender, CancelEventArgs e)
        {
            if (new ClsValidation().isDouble(txtCAmount.Text) == true)
            {
                MessageBox.Show("Invalid Number", "GL");
                txtCAmount.Focus();
            }
            else
            {
                txtCAmount.Text = Convert.ToDouble(txtCAmount.Text).ToString("N2");
                dgv1total();
            }
        }

 

        private void txtTDate_Leave(object sender, EventArgs e)
        {
            if (new ClsValidation().errordate(txtTDate.Text) == true)
            {
                MessageBox.Show("Invalid Date", "GL");
                txtTDate.Focus();
            }
        }
        private void printcurvoucher()
        {
            //string sqlstatement;

            //myconnection = new SqlConnection(Program.mycon);
            //myconnection.Open();

            //sqlstatement = "SELECT DocNum, TDate, CustName, Term, Principal, IntRate, IntAmt, ProcessFee, Insurance, ServiceFee,";
            //sqlstatement += "Rebate, UserName, CheckNo, CAmount FROM ViewBookLOT WHERE DocNum ='" + frmVoucherLRV.glbldocnum.Text + "' AND CNCode = '" + (ClsDefaultBranch1.plsvardb) + "'";


            //SqlDataAdapter dscmd = new SqlDataAdapter(sqlstatement, myconnection);
            //DSBooks dsplot = new DSBooks();
            //dscmd.Fill(dsplot, "viewbooklot");
            //myconnection.Close();

            //CRprevlot objRpt = new CRprevlot();
            //TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            //vartxtcompany.Text = Form1.glblncompany.Text;

            //TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            ////vartxtaddress.Text = Form1.glbladdress.Text;
            //ClsCompName1.ClsCompNamebranch();
            //vartxtaddress.Text = (ClsCompName1.plsaddress);

            //objRpt.SetDataSource(dsplot.Tables[1]);
            //// objRpt.Refresh();
            ////  objRpt.PrintToPrinter(1, true, 0, 0);


            //System.Drawing.Printing.PrintDocument doctoprint = new System.Drawing.Printing.PrintDocument();
            ////doctoprint.PrinterSettings.PrinterName = "EPSON LX-300+ /II";
            //int rawKind = 0;
            //for (int i = 0; i <= doctoprint.PrinterSettings.PaperSizes.Count - 1; i++)
            //{
            //    if (doctoprint.PrinterSettings.PaperSizes[i].PaperName == "C1-HalfShort")
            //    {
            //        rawKind = Convert.ToInt32(doctoprint.PrinterSettings.PaperSizes[i].GetType().GetField("kind",
            //        System.Reflection.BindingFlags.Instance |
            //        System.Reflection.BindingFlags.NonPublic).GetValue(doctoprint.PrinterSettings.PaperSizes[i]));
            //        break; // TODO: might not be correct. Was : Exit For
            //    }
            //}
            //objRpt.PrintOptions.PaperSize = (CrystalDecisions.Shared.PaperSize)rawKind;
            ////CrystalDecisions.Shared.PageMargins pMargin = new CrystalDecisions.Shared.PageMargins(0, 0, 0, 0);
            ////objRpt.PrintOptions.ApplyPageMargins(pMargin);
            //objRpt.Refresh();
            //objRpt.PrintToPrinter(1, false, 0, 0);

        }

    

        private void cboPC_Validating(object sender, CancelEventArgs e)
        {
                if (new ClsValidation().emptytxt(cboSMCode.Text))
                {
                }
                else if (cboSMCode.Text != null && cboSMCode.SelectedValue == null)
                {
                    MessageBox.Show("Not found", "GL");
                    cboSMCode.Focus();
                }
          }

   

        private void btnRecord_Click(object sender, EventArgs e)
        {
            if (new ClsValidation().emptytxt(txtLORRefer.Text))
            {
                MessageBox.Show("Please select list of receivable", "GL");
                dgvListReceive.Focus();

            }
            else
            {
                double varreceiveamt = double.Parse(txtReceiveAmt.Text);
                //Accounts Receivable
                ClsGetSomething1.ClsGetAT("13000000000");
                dgv1.Rows.Add("13000000000", ClsGetSomething1.plsAT, txtLORRefer.Text, "0.00", varreceiveamt.ToString("N2"), 0);

                
                double A = Convert.ToDouble(dgvListReceive.CurrentRow.Cells[2].Value);
                double B = Convert.ToDouble(txtReceiveAmt.Text);
                {
                    dgvListReceive.CurrentRow.Cells[2].Value = (A - B);
                }
                dgvListReceive.Focus();
                txtReceiveAmt.Text = "0.00";
                txtLORRefer.Text = null;
                dgv1total();
                refreshdgvListReceive();
            }

        }

        private void refreshdgvListReceive()
        {
            BindingSource bs = new BindingSource();
            bs.DataSource = dgvListReceive.DataSource;
            dgvListReceive.DataSource = bs;
            bs.Filter = "Bal <> '0.00'";
            dgvListReceive.DataSource = bs;
        }

        private void txtreference_Validating(object sender, CancelEventArgs e)
        {
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();

            if (new Clsexist().RecordExists(ref myconnection, "SELECT Reference FROM tblmain1 WHERE Reference ='" + txtreference.Text + "'"))
            {
                MessageBox.Show("Duplicate entry", "GL");
                txtreference.Focus();
            }
            myconnection.Close();
        }

        private void dgvListReceive_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            txtLORRefer.Text = dgvListReceive .CurrentRow.Cells[0].Value.ToString();
            double varamt = Convert.ToDouble(dgvListReceive.CurrentRow.Cells[2].Value);
            txtReceiveAmt.Text = varamt.ToString("N2");
         
        }

        private void txtReceiveAmt_Validating(object sender, CancelEventArgs e)
        {
            if (new ClsValidation().isDouble(txtReceiveAmt.Text) == true)
            {
                MessageBox.Show("Invalid Number", "GL");
                txtReceiveAmt.Focus();
            }
            else
            {
                txtReceiveAmt.Text = Convert.ToDouble(txtReceiveAmt.Text).ToString("N2");
            }

        }

        private void nextfiledenter1(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.Equals(Keys.Enter))
            {
                SendKeys.Send("{TAB}");
            }
            else if ((e.KeyCode.Equals(Keys.Up)) || (e.KeyCode.Equals(Keys.Left)))
            {
                SendKeys.Send("+{TAB}");
            }
            else if ((e.KeyCode.Equals(Keys.Down)) || (e.KeyCode.Equals(Keys.Right)))
            {
                SendKeys.Send("{TAB}");
            }
        }

        private void nextfiledenter2(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.Equals(Keys.Enter))
            {
                SendKeys.Send("{TAB}");
            }

        }

        private void cbAccountNo_CheckedChanged(object sender, EventArgs e)
        {
            buildcboPA();
        }

        private void cboCollectCode_Validating(object sender, CancelEventArgs e)
        {
            if (new ClsValidation().emptytxt(cboCollectCode.Text))
            {
            }
            else if (cboCollectCode.Text != null && cboCollectCode.SelectedValue == null)
            {
                MessageBox.Show("Not found", "GL");
                cboCollectCode.Focus();
            }
        }
    }
}
