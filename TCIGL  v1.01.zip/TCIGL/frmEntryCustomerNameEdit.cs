﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TCIGL
{
    public partial class frmEntryCustomerNameEdit : Form
    {
        private SqlDataAdapter da;
        private DataTable dataTable = null;
        private SqlConnection myconnection;
        private BindingSource bindingSource = null;
        BindingSource bsource = new BindingSource();
        ClsDefaultBranch ClsDefaultBranch1 = new ClsDefaultBranch(); 
        //   DataSet ds = null;
        string sql;
        ClsGetConnection ClsGetConnection1 = new ClsGetConnection();
        ClsPermission ClsPermission1 = new ClsPermission();

        public frmEntryCustomerNameEdit()
        {
            InitializeComponent();
        }

        private void frmNameEdit_Load(object sender, EventArgs e)
        {
            ClsPermission1.ClsObjects(this.Text);
            if (new ClsValidation().emptytxt(ClsPermission1.plstxtObject))
            {
                MessageBox.Show("You do not have necessary permission to open this file", "GL");
                this.Close();
            }
            else
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);

                sql = "SELECT ControlNo, CustName, ContactNo, Address, ChannelCode, GACode, SMCode, ";
                sql += "Term, CreditLimit, ContactPerson, TIN, SPCode ";
                sql += "FROM tblCustomer WHERE NType ='C' AND CNCode = '" + ClsDefaultBranch1.plsvardb + "'";

                da = new SqlDataAdapter(sql, myconnection);
                SqlCommandBuilder commandBuilder = new SqlCommandBuilder(da);

                dataTable = new DataTable();
                da.Fill(dataTable);
                bindingSource = new BindingSource();
                bindingSource.DataSource = dataTable;


                //Channel Data Source
                string selectQueryStringtblChannel = "SELECT ChannelCode, ChannelDesc FROM tblChannel ORDER BY ChannelDesc";
                SqlDataAdapter sqlDataAdaptertblChannel = new SqlDataAdapter(selectQueryStringtblChannel, myconnection);
                SqlCommandBuilder sqlCommandBuildertblChannel = new SqlCommandBuilder(sqlDataAdaptertblChannel);
                DataTable dataTabletblChannel = new DataTable();
                sqlDataAdaptertblChannel.Fill(dataTabletblChannel);
                BindingSource bindingSourcetblChannel = new BindingSource();
                bindingSourcetblChannel.DataSource = dataTabletblChannel;

                //GeogArea Data Source
                string selectQueryStringtblGeogArea = "SELECT GACode, GADesc FROM tblGeogArea ORDER BY GADesc";
                SqlDataAdapter sqlDataAdaptertblGeogArea = new SqlDataAdapter(selectQueryStringtblGeogArea, myconnection);
                SqlCommandBuilder sqlCommandBuildertblGeogArea = new SqlCommandBuilder(sqlDataAdaptertblGeogArea);
                DataTable dataTabletblGeogArea = new DataTable();
                sqlDataAdaptertblGeogArea.Fill(dataTabletblGeogArea);
                BindingSource bindingSourcetblGeogArea = new BindingSource();
                bindingSourcetblGeogArea.DataSource = dataTabletblGeogArea;

                //Salesman Data Source
                string selectQueryStringtblSalesman = "SELECT SMCode, SMDesc FROM tblSalesman ORDER BY SMDesc";
                SqlDataAdapter sqlDataAdaptertblSalesman = new SqlDataAdapter(selectQueryStringtblSalesman, myconnection);
                SqlCommandBuilder sqlCommandBuildertblSalesman = new SqlCommandBuilder(sqlDataAdaptertblSalesman);
                DataTable dataTabletblSalesman = new DataTable();
                sqlDataAdaptertblSalesman.Fill(dataTabletblSalesman);
                BindingSource bindingSourcetblSalesman = new BindingSource();
                bindingSourcetblSalesman.DataSource = dataTabletblSalesman;

                //SPOption Data Source
                string selectQueryStringtblSPOption = "SELECT SPCode, SPDesc FROM tblSPOption ORDER BY SPDesc";
                SqlDataAdapter sqlDataAdaptertblSPOption = new SqlDataAdapter(selectQueryStringtblSPOption, myconnection);
                SqlCommandBuilder sqlCommandBuildertblSPOption = new SqlCommandBuilder(sqlDataAdaptertblSPOption);
                DataTable dataTabletblSPOption = new DataTable();
                sqlDataAdaptertblSPOption.Fill(dataTabletblSPOption);
                BindingSource bindingSourcetblSPOption = new BindingSource();
                bindingSourcetblSPOption.DataSource = dataTabletblSPOption;

                //Adding  ControlNo TextBox
                DataGridViewTextBoxColumn ColumnControlNo = new DataGridViewTextBoxColumn();
                ColumnControlNo.HeaderText = "Code";
                ColumnControlNo.Width = 50;
                ColumnControlNo.DataPropertyName = "ControlNo";
                ColumnControlNo.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                ColumnControlNo.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
                ColumnControlNo.Visible = false;
                dgv1.Columns.Add(ColumnControlNo);

                //Adding  CustName TextBox
                DataGridViewTextBoxColumn ColumnCustName = new DataGridViewTextBoxColumn();
                ColumnCustName.HeaderText = "Name";
                ColumnCustName.Width = 200;
                ColumnCustName.DataPropertyName = "CustName";
                ColumnCustName.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                ColumnCustName.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
                dgv1.Columns.Add(ColumnCustName);

                //Adding  ContactNo TextBox
                DataGridViewTextBoxColumn ColumnContactNo = new DataGridViewTextBoxColumn();
                ColumnContactNo.HeaderText = "Contact Number";
                ColumnContactNo.Width = 150;
                ColumnContactNo.DataPropertyName = "ContactNo";
                ColumnContactNo.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                ColumnContactNo.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
                dgv1.Columns.Add(ColumnContactNo);
                //sql = "SELECT ControlNo, CustCode, CustName, ContactNo, Address, ChannelCode, GACode, SMCode, ";
                //sql += "Term, CreditLimit, ContactPerson, TIN, SPOption ";
                //sql += "FROM tblCustomer WHERE NType ='C' AND CNCode = '" + ClsDefaultBranch1.plsvardb + "'";

                //Adding  Address TextBox
                DataGridViewTextBoxColumn ColumnAddress = new DataGridViewTextBoxColumn();
                ColumnAddress.HeaderText = "Address";
                ColumnAddress.Width = 250;
                ColumnAddress.DataPropertyName = "Address";
                ColumnAddress.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                ColumnAddress.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
                dgv1.Columns.Add(ColumnAddress);

                //Adding  ChannelCode Combo
                DataGridViewComboBoxColumn ColumnChannelCode = new DataGridViewComboBoxColumn();
                ColumnChannelCode.DataPropertyName = "ChannelCode";
                ColumnChannelCode.HeaderText = "Channel";
                ColumnChannelCode.Width = 120;
                ColumnChannelCode.DataSource = bindingSourcetblChannel;
                ColumnChannelCode.ValueMember = "ChannelCode";
                ColumnChannelCode.DisplayMember = "ChannelDesc";
                dgv1.Columns.Add(ColumnChannelCode);

                //Adding  ChannelCode Combo
                DataGridViewComboBoxColumn ColumnGACode = new DataGridViewComboBoxColumn();
                ColumnGACode.DataPropertyName = "GACode";
                ColumnGACode.HeaderText = "Area";
                ColumnGACode.Width = 120;
                ColumnGACode.DataSource = bindingSourcetblGeogArea;
                ColumnGACode.ValueMember = "GACode";
                ColumnGACode.DisplayMember = "GADesc";
                dgv1.Columns.Add(ColumnGACode);

                //Adding  SMCode Combo
                DataGridViewComboBoxColumn ColumnSMCode = new DataGridViewComboBoxColumn();
                ColumnSMCode.DataPropertyName = "SMCode";
                ColumnSMCode.HeaderText = "Salesman";
                ColumnSMCode.Width = 120;
                ColumnSMCode.DataSource = bindingSourcetblSalesman;
                ColumnSMCode.ValueMember = "SMCode";
                ColumnSMCode.DisplayMember = "SMDesc";
                dgv1.Columns.Add(ColumnSMCode);

                //Adding  Term TextBox
                DataGridViewTextBoxColumn ColumnTerm = new DataGridViewTextBoxColumn();
                ColumnTerm.HeaderText = "Term";
                ColumnTerm.Width = 80;
                ColumnTerm.DataPropertyName = "Term";
                ColumnTerm.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                ColumnTerm.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgv1.Columns.Add(ColumnTerm);

                //Adding  CreditLimit TextBox
                DataGridViewTextBoxColumn ColumnCreditLimit = new DataGridViewTextBoxColumn();
                ColumnCreditLimit.HeaderText = "Credit Limit";
                ColumnCreditLimit.Width = 80;
                ColumnCreditLimit.DataPropertyName = "CreditLimit";
                ColumnCreditLimit.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                ColumnCreditLimit.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgv1.Columns.Add(ColumnCreditLimit);

                //Adding  ContactPerson TextBox
                DataGridViewTextBoxColumn ColumnContactPerson = new DataGridViewTextBoxColumn();
                ColumnContactPerson.HeaderText = "Contact Person";
                ColumnContactPerson.Width = 120;
                ColumnContactPerson.DataPropertyName = "ContactPerson";
                ColumnContactPerson.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                ColumnContactPerson.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
                dgv1.Columns.Add(ColumnContactPerson);

                //Adding  TIN TextBox
                DataGridViewTextBoxColumn ColumnTIN = new DataGridViewTextBoxColumn();
                ColumnTIN.HeaderText = "TIN";
                ColumnTIN.Width = 120;
                ColumnTIN.DataPropertyName = "TIN";
                ColumnTIN.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                ColumnTIN.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
                dgv1.Columns.Add(ColumnTIN);

                //Adding  SPCode Combo
                DataGridViewComboBoxColumn ColumnSPCode = new DataGridViewComboBoxColumn();
                ColumnSPCode.DataPropertyName = "SPCode";
                ColumnSPCode.HeaderText = "SP Option";
                ColumnSPCode.Width = 120;
                ColumnSPCode.DataSource = bindingSourcetblSPOption;
                ColumnSPCode.ValueMember = "SPCode";
                ColumnSPCode.DisplayMember = "SPDesc";
                dgv1.Columns.Add(ColumnSPCode);


                //Setting Data Source for DataGridView
                dgv1.DataSource = bindingSource;
                //dgv1.AutoResizeColumns();
                //dgv1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
                myconnection.Close();
                this.WindowState = FormWindowState.Maximized;
                dgv1.AllowUserToAddRows = false;

                dgv1.Columns[8].DefaultCellStyle.Format = "N2";
            }
        }

        private void btnclose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                da.Update(dataTable);
                MessageBox.Show("Saved", "GL");
                this.Close();

            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }

        }
    }
}
