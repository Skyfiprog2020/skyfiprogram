﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TCIGL
{
    class ClsBuildComboBox
    {
        public ArrayList ARAN = new ArrayList();
        public ArrayList ARANIncome = new ArrayList();
        public ArrayList ARD1 = new ArrayList();
        public ArrayList ARD2 = new ArrayList();
        public ArrayList ARBranch = new ArrayList();
        public ArrayList ARPCN = new ArrayList();
        public ArrayList ARPDCN = new ArrayList();
        public ArrayList ARLCVCN = new ArrayList();
        public ArrayList ARCABN = new ArrayList();
        public ArrayList ARPCNStatement = new ArrayList();
        public ArrayList ARLDocNumFrom = new ArrayList();
        public ArrayList ARLDocNumTo = new ArrayList();
        public ArrayList ARLSN = new ArrayList();
        public ArrayList ARLUM = new ArrayList();
        public ArrayList ARLBankCode = new ArrayList();
        public ArrayList ARPA = new ArrayList();
        public ArrayList ARPASUB = new ArrayList();
        public ArrayList ARLSubtitle = new ArrayList();
        public ArrayList PALJONumber = new ArrayList();
        public ArrayList PIBNCode = new ArrayList();
        public ArrayList PIBN = new ArrayList();
        public ArrayList InvClassCode = new ArrayList();
        public ArrayList ARLSNCode = new ArrayList();
        SqlConnection myconnection;
        SqlDataReader dr;
        SqlCommand mycommand;
        ClsDefaultBranch ClsDefaultBranch1 = new ClsDefaultBranch();
        ClsGetConnection ClsGetConnection1 = new ClsGetConnection(); 

        public void ClsBuildCustControlno()
        {
            try
            {

                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = new SqlCommand("SELECT ControlNo, CustName FROM tblCustomer WHERE NType = 'C' OR NType = 'O' AND CNCode = '" + (ClsDefaultBranch1.plsvardb) + "' ORDER by CustName ", myconnection);
                dr = mycommand.ExecuteReader();

                while (dr.Read())
                {
                    ARPCN.Add(new Clsaddvalue(dr.GetString(1), dr.GetString(0)));
                }
                dr.Close();
                myconnection.Close();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
                myconnection.Close();
            }

        }
        public void ClsBuildCustControlno1()
        {
            try
            {

                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = new SqlCommand("SELECT ControlNo, CustName FROM tblCustomer WHERE NType = 'C' OR NType = 'O' OR NType ='S' AND CNCode = '" + (ClsDefaultBranch1.plsvardb) + "' ORDER by CustName ", myconnection);
                dr = mycommand.ExecuteReader();

                while (dr.Read())
                {
                    ARPCN.Add(new Clsaddvalue(dr.GetString(1), dr.GetString(0)));
                }
                dr.Close();
                myconnection.Close();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
                myconnection.Close();
            }

        }
        public void ClsBuildJONo()
        {
            try
            {

                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = new SqlCommand("SELECT Reference As JONumber1, Reference As JONumber2 FROM tblPI1", myconnection);
                dr = mycommand.ExecuteReader();

                while (dr.Read())
                {
                    PALJONumber.Add(new Clsaddvalue(dr.GetString(1), dr.GetString(0)));
                }
                dr.Close();
                myconnection.Close();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
                myconnection.Close();
            }

        }

        public void ClsBuildPDControlNo()
        {
            try
            {

                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = new SqlCommand("SELECT ControlNo, CustName FROM tblCustomer WHERE NType = 'S' AND CNCode = '" + (ClsDefaultBranch1.plsvardb) + "' ORDER by CustName ", myconnection);
                dr = mycommand.ExecuteReader();

                while (dr.Read())
                {
                    ARPDCN.Add(new Clsaddvalue(dr.GetString(1), dr.GetString(0)));
                }
                dr.Close();
                myconnection.Close();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
                myconnection.Close();
            }

        }

        public void ClsBuildCVControlno()
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = new SqlCommand("SELECT ControlNo, CustName FROM tblCustomer WHERE CNCode = '" + (ClsDefaultBranch1.plsvardb) + "' ORDER by CustName ", myconnection);
                dr = mycommand.ExecuteReader();

                while (dr.Read())
                {
                    ARLCVCN.Add(new Clsaddvalue(dr.GetString(1), dr.GetString(0)));
                }
                dr.Close();
                myconnection.Close();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
                myconnection.Close();
            }

        }

        public void ClsBuildCustControlnoStatement(string strCNCode)
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                //mycommand = new SqlCommand("SELECT ControlNo, CustName FROM tblCustomer WHERE NType = 'C' AND CNCode = '" + strCNCode + "' ORDER by CustName ", myconnection);
                mycommand = new SqlCommand("SELECT ControlNo, CustName FROM tblCustomer WHERE  CNCode = '" + strCNCode + "' ORDER by CustName ", myconnection);
                dr = mycommand.ExecuteReader();

                while (dr.Read())
                {
                    ARPCNStatement.Add(new Clsaddvalue(dr.GetString(1), dr.GetString(0)));
                }
                dr.Close();
                myconnection.Close();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
                myconnection.Close();
            }
        }

      
           
        
        public void ClsBuildAcctNo()
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = new SqlCommand("SELECT AcctNo, TitleAcct FROM tbltitleacct ORDER by TitleAcct", myconnection);
                dr = mycommand.ExecuteReader();

                while (dr.Read())
                {
                    ARAN.Add(new Clsaddvalue(dr.GetString(1), dr.GetString(0)));

                }
                dr.Close();
                myconnection.Close();


            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
                myconnection.Close();
            }
        }

        public void ClsBuildIncomeAcctNo()
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = new SqlCommand("SELECT tblPA.PA, tblTitleAcct.TitleAcct FROM tblPA INNER JOIN tblTitleAcct ON tblPA.AcctNo = tblTitleAcct.AcctNo WHERE (tblTitleAcct.FCCode = 'R') ORDER BY tblTitleAcct.TitleAcct", myconnection);
                dr = mycommand.ExecuteReader();

                while (dr.Read())
                {
                    ARANIncome.Add(new Clsaddvalue(dr.GetString(1), dr.GetString(0)));
                }
                dr.Close();
                myconnection.Close();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
                myconnection.Close();
            }
        }

        public void ClsBuildD1Code()
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = new SqlCommand("SELECT D1Code, D1Desc FROM tbldept1 ORDER by D1Desc", myconnection);
                dr = mycommand.ExecuteReader();

                while (dr.Read())
                {
                    ARD1.Add(new Clsaddvalue(dr.GetString(1), dr.GetString(0)));
                }
                dr.Close();
                myconnection.Close();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
                myconnection.Close();
            }
        }

        public void ClsBuildD2Code()
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = new SqlCommand("SELECT D2Code, D2Desc FROM tbldept2 ORDER by D2Desc", myconnection);
                dr = mycommand.ExecuteReader();

                while (dr.Read())
                {
                    ARD2.Add(new Clsaddvalue(dr.GetString(1), dr.GetString(0)));
                }
                dr.Close();
                myconnection.Close();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
                myconnection.Close();
            }
        }
       
        public void ClsBuildBranch()
        {
          try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = new SqlCommand("SELECT CNCode, CName FROM tblCompanyName ORDER by CName ", myconnection);
                dr = mycommand.ExecuteReader();

                while (dr.Read())
                {
                    ARBranch.Add(new Clsaddvalue(dr.GetString(1), dr.GetString(0)));
                }
                dr.Close();
                myconnection.Close();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
                myconnection.Close();
            }
        }



        public void ClsBuildCABN()
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = new SqlCommand("SELECT PA, D2Desc FROM ViewBankList ORDER by D2Desc", myconnection);
                dr = mycommand.ExecuteReader();

                while (dr.Read())
                {
                    ARCABN.Add(new Clsaddvalue(dr.GetString(1), dr.GetString(0)));
                }
                dr.Close();
                myconnection.Close();


            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
                myconnection.Close();
            }
        }

        public void ClsBuildDocNumFrom(string strVoucher, string strCNCode)
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = new SqlCommand("SELECT CAST(D1 As VarChar), CAST(D2 As VarChar) FROM ViewConvertedDocNum WHERE CNCode = '" + (strCNCode) + "'  AND Voucher = '" + strVoucher + "' ORDER BY D1 DESC", myconnection);
                dr = mycommand.ExecuteReader();

                while (dr.Read())
                {
                    ARLDocNumFrom.Add(new Clsaddvalue(dr.GetString(1), dr.GetString(0)));
                }
                dr.Close();
                myconnection.Close();


            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
                myconnection.Close();
            }
        }

        public void ClsBuildDocNumTo(string strVoucher, string strCNCode)
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = new SqlCommand("SELECT CAST(D1 As VarChar), CAST(D2 As VarChar) FROM ViewConvertedDocNum WHERE CNCode = '" + (strCNCode) + "'  AND Voucher = '" + strVoucher + "' ORDER BY D1 DESC", myconnection);
                dr = mycommand.ExecuteReader();

                while (dr.Read())
                {
                    ARLDocNumTo.Add(new Clsaddvalue(dr.GetString(1), dr.GetString(0)));
                }
                dr.Close();
                myconnection.Close();


            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
                myconnection.Close();
            }
        }

        public void ClsBuildStocks(string strShow, bool boolProductCode)
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();

                if (boolProductCode == true)
                {
                    if (strShow == "1")//All
                    {
                        mycommand = new SqlCommand("SELECT StockNumber, StockCode+' - '+StockDesc FROM tblStocks  WHERE Active = 1 ORDER by StockDesc ", myconnection);
                    }
                    else if (strShow == "2")//Raw Material-
                    {
                        mycommand = new SqlCommand("SELECT StockNumber, StockCode+' - '+StockDesc FROM tblStocks  WHERE InvClassCode = 01 OR InvClassCode = 02 AND Active = 1 ORDER by StockDesc ", myconnection);
                    }
                    else if (strShow == "3")//Finished Product
                    {
                        mycommand = new SqlCommand("SELECT StockNumber, StockCode+' - '+StockDesc FROM tblStocks  WHERE InvClassCode = 03 AND Active = 1 ORDER by StockDesc ", myconnection);
                    }
                    else if (strShow == "4")//Office Supplies Product
                    {
                        mycommand = new SqlCommand("SELECT StockNumber, StockCode+' - '+StockDesc FROM tblStocks  WHERE InvClassCode = 04 AND Active = 1 ORDER by StockDesc ", myconnection);
                    }
                }
                else
                {
                    if (strShow == "1")//All
                    {
                        mycommand = new SqlCommand("SELECT StockNumber, StockDesc FROM tblStocks  WHERE Active = 1 ORDER by StockDesc ", myconnection);
                    }
                    else if (strShow == "2")//Raw Material
                    {
                        mycommand = new SqlCommand("SELECT StockNumber, StockDesc FROM tblStocks  WHERE InvClassCode = 01 OR InvClassCode = 02 AND Active = 1 ORDER by StockDesc ", myconnection);
                    }
                    else if (strShow == "3")//Finished Product
                    {
                        mycommand = new SqlCommand("SELECT StockNumber, StockDesc FROM tblStocks  WHERE InvClassCode = 03 AND Active = 1 ORDER by StockDesc ", myconnection);
                    }
                    else if (strShow == "4")//Office Supplies Product
                    {
                        mycommand = new SqlCommand("SELECT StockNumber, StockDesc FROM tblStocks  WHERE InvClassCode = 04 AND Active = 1 ORDER by StockDesc ", myconnection);
                    }
                }

                dr = mycommand.ExecuteReader();

                while (dr.Read())
                {
                    ARLSN.Add(new Clsaddvalue(dr.GetString(1), dr.GetString(0)));
                }
                dr.Close();
                myconnection.Close();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
                myconnection.Close();
            }
        }

        public void ClsBuildStocksCode(string strShow)
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                if (strShow == "1")//All
                {
                    mycommand = new SqlCommand("SELECT StockNumber, StockDesc FROM tblStocks  WHERE Active = 1 ORDER by StockDesc ", myconnection);
                }
                else if (strShow == "2")//Raw Material
                {
                    mycommand = new SqlCommand("SELECT StockNumber, StockDesc FROM tblStocks  WHERE FinishedProduct = 0 AND Active = 1 ORDER by StockDesc ", myconnection);
                }
                else if (strShow == "3")//Finished Product
                {
                    mycommand = new SqlCommand("SELECT StockNumber, StockDesc FROM tblStocks  WHERE FinishedProduct = 1 AND Active = 1 ORDER by StockDesc ", myconnection);
                }

                dr = mycommand.ExecuteReader();

                while (dr.Read())
                {
                    ARLSNCode.Add(new Clsaddvalue(dr.GetString(1), dr.GetString(0)));
                }
                dr.Close();
                myconnection.Close();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
                myconnection.Close();
            }
        }
        public void ClsBuildBankCode()
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL(); myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = new SqlCommand("SELECT BankCode, BankName FROM tblCheckWriterSetup ORDER by BankName ", myconnection);
                dr = mycommand.ExecuteReader();

                while (dr.Read())
                {
                    ARLBankCode.Add(new Clsaddvalue(dr.GetString(1), dr.GetString(0)));
                }
                dr.Close();
                myconnection.Close();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
                myconnection.Close();
            }
        }



 

        public void ClsBuildPA()
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                //if (bactnumber == true)
                //{
                //    mycommand = new SqlCommand("SELECT PA, PA  +' - '+ AT FROM viewpa ORDER by PA ", myconnection);
                //}
                //else
                //{
                    mycommand = new SqlCommand("SELECT PA, AT FROM viewpa ORDER by AT ", myconnection);
                //}
                dr = mycommand.ExecuteReader();

                while (dr.Read())
                {
                    ARPA.Add(new Clsaddvalue(dr.GetString(1), dr.GetString(0)));

                }
                dr.Close();
                myconnection.Close();


            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
                myconnection.Close();
            }
        }

        public void ClsBuildSubTitle()
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = new SqlCommand("SELECT STCode, STDesc FROM tblSubTitle ORDER by STDesc", myconnection);
                dr = mycommand.ExecuteReader();

                while (dr.Read())
                {
                    ARLSubtitle.Add(new Clsaddvalue(dr.GetString(1), dr.GetString(0)));
                }
                dr.Close();
                myconnection.Close();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
                myconnection.Close();
            }
        }

        public void ClsBuildBankNameCode()
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = new SqlCommand("SELECT BankCode, BankName FROM tblBankDetail ORDER by BankName", myconnection);
                dr = mycommand.ExecuteReader();

                while (dr.Read())
                {
                    PIBNCode.Add(new Clsaddvalue(dr.GetString(1), dr.GetString(0)));
                }
                dr.Close();
                myconnection.Close();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
                myconnection.Close();
            }
        }

        public void ClsBuildBankNameNo()
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = new SqlCommand("SELECT BankCode, BankName FROM tblBankDetail ORDER by BankName", myconnection);
                dr = mycommand.ExecuteReader();

                while (dr.Read())
                {
                    PIBN.Add(new Clsaddvalue(dr.GetString(1), dr.GetString(0)));
                }
                dr.Close();
                myconnection.Close();


            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
                myconnection.Close();
            }
        }

        public void ClsBuildInviClassCode()
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = new SqlCommand("SELECT InvClassCode, InvClassDesc FROM tblInvClass ORDER by InvClassDesc", myconnection);
                dr = mycommand.ExecuteReader();

                while (dr.Read())
                {
                    InvClassCode.Add(new Clsaddvalue(dr.GetString(1), dr.GetString(0)));

                }
                dr.Close();
                myconnection.Close();


            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
                myconnection.Close();
            }
        }
    }
}
