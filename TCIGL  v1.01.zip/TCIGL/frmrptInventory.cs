﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using CrystalDecisions.CrystalReports.Engine;
using System.Data.SqlClient;

namespace TCIGL
{

    public partial class frmrptInventory : Form
    {
        SqlConnection myconnection;
        BindingSource dbind = new BindingSource();
        ClsBuildComboBox ClsBuildComboBox1 = new ClsBuildComboBox();
        ClsGetSomething ClsGetSomething1 = new ClsGetSomething(); 
        //SqlCommand mycommand;
        ClsPermission ClsPermission1 = new ClsPermission();
        ClsBuildEntryComboBox ClsBuildEntryComboBox1 = new ClsBuildEntryComboBox();
        ClsGetConnection ClsGetConnection1 = new ClsGetConnection();
        ClsCompName ClsCompName1 = new ClsCompName();
        SqlCommand mycommand;
        string sqlstatement;
        SqlDataReader SqlDataReader1;
        //string pristrNOM;
        public frmrptInventory()
        {
            InitializeComponent();
            cbortprint.DisplayMember = "Text";
            cbortprint.ValueMember = "Value";
            cbortprint.Text = "Inventory Summary";
            var items = new[]
            { 
             new { Text = "Inventory Summary", Value = "01" },
             new { Text = "Inventory Summary - Category", Value = "02" },
             new { Text = "Stock Card", Value = "03" },
             new { Text = "Stock Card - Type", Value = "04" },
             new { Text = "Inventory - Type", Value = "05" },
             new { Text = "Inventory - Type - Category", Value = "06" },
             new { Text = "Inventory Summary From-To", Value = "07" },
             new { Text = "Inventory Summary From-To PD Only", Value = "08" },
            };
            cbortprint.DataSource = items;

        }
        private void buildcboStocks()
        {
            cboStockNumber.DataSource = null;
            ClsBuildEntryComboBox1.ARLSNCatCode.Clear();
            ClsBuildEntryComboBox1.ClsBuildStocksCategory(cboCatCode.SelectedValue.ToString());
            this.cboStockNumber.DataSource = (ClsBuildEntryComboBox1.ARLSNCatCode);
            this.cboStockNumber.DisplayMember = "Display";
            this.cboStockNumber.ValueMember = "Value";
         }
 
        private void buildcboWHCode()
        {
            cboWHCode.DataSource = null;
            ClsBuildEntryComboBox1.ARWHCode.Clear();
            ClsBuildEntryComboBox1.ClsBuildWHCode();
            this.cboWHCode.DataSource = (ClsBuildEntryComboBox1.ARWHCode);
            this.cboWHCode.DisplayMember = "Display";
            this.cboWHCode.ValueMember = "Value";
            //this.cboWHCode.DropDownWidth = 450;
        }

        private void buildcboCatCode()
        {
            cboCatCode.DataSource = null;
            ClsBuildEntryComboBox1.ARCatCode.Clear();
            ClsBuildEntryComboBox1.ClsBuildCatCode();
            this.cboCatCode.DataSource = (ClsBuildEntryComboBox1.ARCatCode);
            this.cboCatCode.DisplayMember = "Display";
            this.cboCatCode.ValueMember = "Value";
        }
        private void buildcboCNCode()
        {
            cboCNCode.DataSource = null;
            ClsBuildComboBox1.ARBranch.Clear();
            ClsBuildComboBox1.ClsBuildBranch();
            this.cboCNCode.DataSource = (ClsBuildComboBox1.ARBranch);
            this.cboCNCode.DisplayMember = "Display";
            this.cboCNCode.ValueMember = "Value";
        }


        private void btnPreview_Click(object sender, EventArgs e)
        {
            if (cbortprint.SelectedValue.ToString() == "01")//Inventory Summary
            {
                if ((new ClsValidation().emptytxt(cbortprint.Text)) || (txtEnterDate.Text == "  /  /") ||
                    (new ClsValidation().emptytxt (cboWHCode.Text)) || (new ClsValidation().emptytxt (cboCNCode.Text)))
                {
                    MessageBox.Show("Please complete your entry", "GL");
                    cbortprint.Focus();
                }
                else
                {
                    InventorySum();
                }
            }

            else if (cbortprint.SelectedValue.ToString()=="02")// Inventory Summary -Category
            {
                if ((new ClsValidation().emptytxt(cbortprint.Text)) || (txtEnterDate.Text == "  /  /") ||
                    (new ClsValidation().emptytxt(cboWHCode.Text)) || (new ClsValidation().emptytxt(cboCNCode.Text)) ||
                    (new ClsValidation().emptytxt (cboCatCode.Text)))
                {
                    MessageBox.Show("Please complete your entry", "GL");
                    cbortprint.Focus();
                }
                else
                {
                    InventorySum();
                }

            }
            else if (cbortprint.SelectedValue.ToString() == "03")//Stock Card
            {
                if ((new ClsValidation().emptytxt(cbortprint.Text)) || (new ClsValidation().emptytxt(cboStockNumber.Text))
                    || (txtBeginDate.Text == "  /  /") || (txtEndDate.Text == "  /  /") || (new ClsValidation().emptytxt(cboWHCode.Text))
                    || (new ClsValidation().emptytxt(cboCNCode.Text)))
                {
                    MessageBox.Show("Please complete your entry", "GL");
                    cbortprint.Focus();
                }
                else if (Convert.ToDateTime(txtBeginDate.Text) > Convert.ToDateTime(txtEndDate.Text))
                {
                    MessageBox.Show("Beginning date is greater than ending date");
                    txtBeginDate.Focus();
                }
                else
                {
                    StockCard();
                }
            }
            else if (cbortprint.SelectedValue.ToString() == "04")//Stock Card
            {
                if ((new ClsValidation().emptytxt(cbortprint.Text)) || (new ClsValidation().emptytxt(cboStockNumber.Text))
                    || (txtBeginDate.Text == "  /  /") || (txtEndDate.Text == "  /  /") || (new ClsValidation().emptytxt(cboWHCode.Text))
                    || (new ClsValidation().emptytxt(cboCNCode.Text)) || (new ClsValidation().emptytxt(cboVoucher.Text)))
                {
                    MessageBox.Show("Please complete your entry", "GL");
                    cbortprint.Focus();
                }
                else if (Convert.ToDateTime(txtBeginDate.Text) > Convert.ToDateTime(txtEndDate.Text))
                {
                    MessageBox.Show("Beginning date is greater than ending date");
                    txtBeginDate.Focus();
                }
                else
                {
                    StockCardType();
                }
            }

            else if (cbortprint.SelectedValue.ToString() == "05")// Inventory Summary - Type
            {
                if ((new ClsValidation().emptytxt(cbortprint.Text))
                    || (txtBeginDate.Text == "  /  /") || (txtEndDate.Text == "  /  /") || (new ClsValidation().emptytxt(cboWHCode.Text))
                    || (new ClsValidation().emptytxt(cboCNCode.Text)) || (new ClsValidation().emptytxt (cboVoucher.Text)))
                {
                    MessageBox.Show("Please complete your entry", "GL");
                    cbortprint.Focus();
                }
                else if (Convert.ToDateTime(txtBeginDate.Text) > Convert.ToDateTime(txtEndDate.Text))
                {
                    MessageBox.Show("Beginning date is greater than ending date");
                    txtBeginDate.Focus();
                }
                else
                {
                    InventorySum();
                }
            }
            else if (cbortprint.SelectedValue.ToString() == "06")// Inventory Summary - Type - Category
            {
                if ((new ClsValidation().emptytxt(cbortprint.Text))
                    || (txtBeginDate.Text == "  /  /") || (txtEndDate.Text == "  /  /") || (new ClsValidation().emptytxt(cboWHCode.Text))
                    || (new ClsValidation().emptytxt(cboCNCode.Text)) || (new ClsValidation().emptytxt(cboVoucher.Text)) || (new ClsValidation().emptytxt(cboCatCode.Text)))
                {
                    MessageBox.Show("Please complete your entry", "GL");
                    cbortprint.Focus();
                }
                else if (Convert.ToDateTime(txtBeginDate.Text) > Convert.ToDateTime(txtEndDate.Text))
                {
                    MessageBox.Show("Beginning date is greater than ending date");
                    txtBeginDate.Focus();
                }
                else
                {
                    InventorySum();
                }

            }

            else if (cbortprint.SelectedValue.ToString() == "07")// Inventory Summary From-To
            {
                if ((new ClsValidation().emptytxt(cbortprint.Text)) || 
                    (txtBeginDate.Text == "  /  /") || (txtEndDate.Text == "  /  /") || (new ClsValidation().emptytxt(cboWHCode.Text))
                    || (new ClsValidation().emptytxt(cboCNCode.Text)))
                {
                    MessageBox.Show("Please complete your entry", "GL");
                    cbortprint.Focus();
                }
                else if (Convert.ToDateTime(txtBeginDate.Text) > Convert.ToDateTime(txtEndDate.Text))
                {
                    MessageBox.Show("Beginning date is greater than ending date");
                    txtBeginDate.Focus();
                }
                else
                {
                    InventorySumFromTo();
                }
            }
            else if (cbortprint.SelectedValue.ToString() == "08")// Inventory Summary From-To PD Only
            {
                if ((new ClsValidation().emptytxt(cbortprint.Text)) ||
                    (txtBeginDate.Text == "  /  /") || (txtEndDate.Text == "  /  /") || (new ClsValidation().emptytxt(cboWHCode.Text))
                    || (new ClsValidation().emptytxt(cboCNCode.Text)))
                {
                    MessageBox.Show("Please complete your entry", "GL");
                    cbortprint.Focus();
                }
                else if (Convert.ToDateTime(txtBeginDate.Text) > Convert.ToDateTime(txtEndDate.Text))
                {
                    MessageBox.Show("Beginning date is greater than ending date");
                    txtBeginDate.Focus();
                }
                else
                {
                    InventorySumFromToPDOnly();
                }

            }


        }

        private void InventorySum()
        {

            //sqlstatement = "SELECT Piece, IB, Item, ClassDesc, PClassDesc, StockNumber, Sum(Vol) As SVol, Sum(AmtIn)-Sum(AmtOut) As AveCost, ";
            //sqlstatement += "CAST(SUM(ConvertedQty) AS int) % Piece AS QtyPC, (SELECT CASE WHEN IB <> 0 THEN CAST(((SUM(ConvertedQty) - (CAST(SUM(ConvertedQty) AS int) % Piece)) / Piece) AS int) % IB ELSE 0 END) AS QtyIB,";
            //sqlstatement += "(SELECT  CASE WHEN IB = 0 THEN ((Sum(ConvertedQty))-CAST(SUM(ConvertedQty)  AS int) % Piece) /Piece ";
            //sqlstatement += "ELSE (((Sum(ConvertedQty)-CAST(SUM(ConvertedQty) AS int) % Piece)/Piece)-(CAST(((SUM(ConvertedQty) - (CAST(SUM(ConvertedQty) AS int) % Piece)) / Piece) AS int) % IB))/IB END) AS QtyCS ";
            //sqlstatement += "FROM ViewInvBalance GROUP By Piece, IB, Item, ClassDesc, PClassDesc, StockNumber, TDate, WHCode ";
            //sqlstatement += "HAVING WHCode = '" + cboWHCode.SelectedValue.ToString() + "' AND TDate<='" + txtEndDate.Text + "' AND SUM(ConvertedQty)<>0";
            //, AVG(UP) As UP
            
            if (cbortprint.SelectedValue.ToString() == "01")
            {
                sqlstatement = "SELECT  CatDesc, StockDesc, StockNumber,  SUM(TotalCost) As SumCost, SUM(ConvertedQty) As SumConvertedQty, UCost, UM, SellingPrice ";
                sqlstatement += "FROM ViewInventory  WHERE  TDate <= '" + txtEnterDate.Text + "' AND WHCode = '" + cboWHCode.SelectedValue.ToString() + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "'";
                sqlstatement += "GROUP By CatDesc, StockDesc, StockNumber, UCost, UM, SellingPrice";
            }
            else if (cbortprint.SelectedValue.ToString()=="02")
            {
                sqlstatement = "SELECT  CatDesc, StockDesc, StockNumber,  SUM(TotalCost) As SumCost, SUM(ConvertedQty) As SumConvertedQty, UCost, UM, SellingPrice ";
                sqlstatement += "FROM ViewInventory  WHERE  TDate <= '" + txtEnterDate.Text + "' AND WHCode = '" + cboWHCode.SelectedValue.ToString() + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "' AND CatCode='" + cboCatCode.SelectedValue.ToString() + "'";
                sqlstatement += "GROUP By CatDesc, StockDesc, StockNumber, UCost, UM, SellingPrice";
            }
            else if (cbortprint.SelectedValue.ToString()=="05")
            {
                sqlstatement = "SELECT  CatDesc, StockDesc, StockNumber,  SUM(TotalCost) As SumCost, SUM(ConvertedQty) As SumConvertedQty, UCost, UM, SellingPrice ";
                sqlstatement += "FROM ViewInventory  WHERE  TDate BETWEEN '" + txtBeginDate.Text + "' And  '" + txtEndDate.Text + "' AND WHCode = '" + cboWHCode.SelectedValue.ToString() + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "' AND Voucher='" + cboVoucher.Text + "'";
                sqlstatement += "GROUP By CatDesc, StockDesc, StockNumber, UCost, UM, SellingPrice";
            }
            else if (cbortprint.SelectedValue.ToString() == "06")
            {
                sqlstatement = "SELECT  CatDesc, StockDesc, StockNumber,  SUM(TotalCost) As SumCost, SUM(ConvertedQty) As SumConvertedQty, UCost, UM, SellingPrice ";
                sqlstatement += "FROM ViewInventory  WHERE  TDate BETWEEN '" + txtBeginDate.Text + "' And  '" + txtEndDate.Text + "' AND WHCode = '" + cboWHCode.SelectedValue.ToString() + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "' AND Voucher='" + cboVoucher.Text + "' AND CatCode='"+cboCatCode.SelectedValue.ToString()+"'";
                sqlstatement += "GROUP By CatDesc, StockDesc, StockNumber, UCost, UM, SellingPrice";
            }

            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();
            mycommand = myconnection.CreateCommand();
            mycommand.CommandText = sqlstatement;
            mycommand.CommandTimeout = 900;
            SqlDataReader1 = mycommand.ExecuteReader();
            DataTable DataTable1 = new DataTable();
            DataTable1.Load(SqlDataReader1);
            myconnection.Close();

            if (DataTable1.Rows.Count == 0)
            {
                MessageBox.Show("No data found", "GL");
                return;
            }

            CRInvSumIndWarehouse objRpt = new CRInvSumIndWarehouse();
            TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            ClsCompName1.ClsCompNameMain();
            vartxtcompany.Text = ClsCompName1.varcn;

            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            ClsCompName1.ClsCompNamebranchAddress(cboCNCode.SelectedValue.ToString()); 
            vartxtaddress.Text = (ClsCompName1.plsCRaddress);

            TextObject varrpttoenterdate = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttoenterdate"];
            varrpttoenterdate.Text = "As of " + txtEnterDate.Text;

            TextObject varrpttoWarehouse = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttoWarehouse"];
            varrpttoWarehouse.Text = cboWHCode.Text;

            if (cbortprint.SelectedValue.ToString()=="05")
            {
                TextObject varTextVoucher = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["TextVoucher"];
                varTextVoucher.Text = cboVoucher.Text;
            }

            objRpt.SetDataSource(DataTable1);
            crystalReportViewer1.ReportSource = objRpt;
            crystalReportViewer1.Refresh();
        }

       
        private void StockCard()
        {
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();

            mycommand = new SqlCommand("usp_stockcard2", myconnection);
            mycommand.CommandType = CommandType.StoredProcedure;
            mycommand.Parameters.Add("@Parambegindate2", SqlDbType.DateTime).Value = txtBeginDate.Text;
            mycommand.Parameters.Add("@Paramenddate2", SqlDbType.DateTime).Value = txtEndDate.Text;
            mycommand.Parameters.Add("@ParamStockNumber2", SqlDbType.VarChar).Value = cboStockNumber.SelectedValue.ToString();
            mycommand.Parameters.Add("@ParamWHCode2", SqlDbType.VarChar).Value = cboWHCode.SelectedValue.ToString();
            mycommand.Parameters.Add("@ParamCNCode2", SqlDbType.VarChar).Value = cboCNCode.SelectedValue.ToString();

            mycommand.CommandTimeout = 900;
            SqlDataReader1 = mycommand.ExecuteReader();
            DataTable DataTable1 = new DataTable();
            DataTable1.Load(SqlDataReader1);
            myconnection.Close();

            if (DataTable1.Rows.Count == 0)
            {
                MessageBox.Show("No data found", "GL");
                return;
            }

            CRInvSumStockCard objRpt = new CRInvSumStockCard();
            TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            ClsCompName1.ClsCompNameMain();
            vartxtcompany.Text = ClsCompName1.varcn;

            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            ClsCompName1.ClsCompNamebranchAddress(cboCNCode.SelectedValue.ToString());
            vartxtaddress.Text = (ClsCompName1.plsCRaddress);

            TextObject varTextRangeDate = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["TextRangeDate"];
            varTextRangeDate.Text = "As of " + txtEnterDate.Text;

            TextObject varTextStockNumber = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["TextStockNumber"];
            varTextStockNumber.Text = cboStockNumber.Text;

            TextObject varrpttoWarehouse = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttoWarehouse"];
            varrpttoWarehouse.Text = cboWHCode.Text;

            objRpt.SetDataSource(DataTable1);
            crystalReportViewer1.ReportSource = objRpt;
            crystalReportViewer1.Refresh();
        }

        private void StockCardType()
        {
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();

            mycommand = new SqlCommand("usp_stockcard4", myconnection);
            mycommand.CommandType = CommandType.StoredProcedure;
            mycommand.Parameters.Add("@Parambegindate2", SqlDbType.DateTime).Value = txtBeginDate.Text;
            mycommand.Parameters.Add("@Paramenddate2", SqlDbType.DateTime).Value = txtEndDate.Text;
            mycommand.Parameters.Add("@ParamStockNumber2", SqlDbType.VarChar).Value = cboStockNumber.SelectedValue.ToString();
            mycommand.Parameters.Add("@ParamWHCode2", SqlDbType.VarChar).Value = cboWHCode.SelectedValue.ToString();
            mycommand.Parameters.Add("@ParamCNCode2", SqlDbType.VarChar).Value = cboCNCode.SelectedValue.ToString();
            mycommand.Parameters.Add("@ParamVoucher2", SqlDbType.VarChar).Value = cboVoucher.Text.ToString();

            mycommand.CommandTimeout = 900;
            SqlDataReader1 = mycommand.ExecuteReader();
            DataTable DataTable1 = new DataTable();
            DataTable1.Load(SqlDataReader1);
            myconnection.Close();

            if (DataTable1.Rows.Count == 0)
            {
                MessageBox.Show("No data found", "GL");
                return;
            }

            CRInvSumStockCard objRpt = new CRInvSumStockCard();
            TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            ClsCompName1.ClsCompNameMain();
            vartxtcompany.Text = ClsCompName1.varcn;

            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            ClsCompName1.ClsCompNamebranchAddress(cboCNCode.SelectedValue.ToString());
            vartxtaddress.Text = (ClsCompName1.plsCRaddress);

            TextObject varTextRangeDate = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["TextRangeDate"];
            varTextRangeDate.Text = "As of " + txtEnterDate.Text;

            TextObject varTextStockNumber = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["TextStockNumber"];
            varTextStockNumber.Text = cboStockNumber.Text;

            TextObject varrpttoWarehouse = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttoWarehouse"];
            varrpttoWarehouse.Text = cboWHCode.Text;

            objRpt.SetDataSource(DataTable1);
            crystalReportViewer1.ReportSource = objRpt;
            crystalReportViewer1.Refresh();
        }

        private void InventorySumFromTo()
        {
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();

            mycommand = new SqlCommand("usp_InventorySumm2", myconnection);
            mycommand.CommandType = CommandType.StoredProcedure;
            mycommand.Parameters.Add("@Parambegindate2", SqlDbType.DateTime).Value = txtBeginDate.Text;
            mycommand.Parameters.Add("@Paramenddate2", SqlDbType.DateTime).Value = txtEndDate.Text;
            mycommand.Parameters.Add("@ParamWHCode2", SqlDbType.VarChar).Value = cboWHCode.SelectedValue.ToString();
            mycommand.Parameters.Add("@ParamCNCode2", SqlDbType.VarChar).Value = cboCNCode.SelectedValue.ToString();

            mycommand.CommandTimeout = 900;
            SqlDataReader1 = mycommand.ExecuteReader();
            DataTable DataTable1 = new DataTable();
            DataTable1.Load(SqlDataReader1);
            myconnection.Close();

            if (DataTable1.Rows.Count == 0)
            {
                MessageBox.Show("No data found", "GL");
                return;
            }
            CRInvSumIndWarehouseFromTo objRpt = new CRInvSumIndWarehouseFromTo();
            TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            ClsCompName1.ClsCompNameMain();
            vartxtcompany.Text = ClsCompName1.varcn;

            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            ClsCompName1.ClsCompNamebranchAddress(cboCNCode.SelectedValue.ToString());
            vartxtaddress.Text = (ClsCompName1.plsCRaddress);

            TextObject varTextRangeDate = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["TextRangeDate"];
            varTextRangeDate.Text = "From " + txtBeginDate.Text + " To " + txtEndDate.Text;

            TextObject varrpttoWarehouse = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttoWarehouse"];
            varrpttoWarehouse.Text = cboWHCode.Text;

            objRpt.SetDataSource(DataTable1);
            crystalReportViewer1.ReportSource = objRpt;
            crystalReportViewer1.Refresh();
        }

        private void InventorySumFromToPDOnly()
        {
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();

            mycommand = new SqlCommand("usp_InventorySummPDOnly2", myconnection);
            mycommand.CommandType = CommandType.StoredProcedure;
            mycommand.Parameters.Add("@Parambegindate2", SqlDbType.DateTime).Value = txtBeginDate.Text;
            mycommand.Parameters.Add("@Paramenddate2", SqlDbType.DateTime).Value = txtEndDate.Text;
            mycommand.Parameters.Add("@ParamWHCode2", SqlDbType.VarChar).Value = cboWHCode.SelectedValue.ToString();
            mycommand.Parameters.Add("@ParamCNCode2", SqlDbType.VarChar).Value = cboCNCode.SelectedValue.ToString();

            mycommand.CommandTimeout = 900;
            SqlDataReader1 = mycommand.ExecuteReader();
            DataTable DataTable1 = new DataTable();
            DataTable1.Load(SqlDataReader1);
            myconnection.Close();

            if (DataTable1.Rows.Count == 0)
            {
                MessageBox.Show("No data found", "GL");
                return;
            }
            CRInvSumIndWarehouseFromTo objRpt = new CRInvSumIndWarehouseFromTo();
            TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            ClsCompName1.ClsCompNameMain();
            vartxtcompany.Text = ClsCompName1.varcn;

            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            ClsCompName1.ClsCompNamebranchAddress(cboCNCode.SelectedValue.ToString());
            vartxtaddress.Text = (ClsCompName1.plsCRaddress);

            TextObject varTextRangeDate = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["TextRangeDate"];
            varTextRangeDate.Text = "From " + txtBeginDate.Text + " To " + txtEndDate.Text;

            TextObject varrpttoWarehouse = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttoWarehouse"];
            varrpttoWarehouse.Text = cboWHCode.Text;

            objRpt.SetDataSource(DataTable1);
            crystalReportViewer1.ReportSource = objRpt;
            crystalReportViewer1.Refresh();
        }

        private void cboStockNumber_Validating(object sender, CancelEventArgs e)
        {
            if (new ClsValidation().emptytxt(cboStockNumber.Text))
            {
            }
            else if (cboStockNumber.Text != null && cboStockNumber.SelectedValue == null)
            {
                MessageBox.Show("Not found", "GL");
                cboStockNumber.Focus();
            }
        }


        private void frmrptInventory_Load(object sender, EventArgs e)
        {
            ClsPermission1.ClsObjects(this.Text);
            if (new ClsValidation().emptytxt(ClsPermission1.plstxtObject))
            {
                MessageBox.Show("You do not have necessary permission to open this file", "GL");
                this.Close();
            }
            else
            {
                this.WindowState = FormWindowState.Maximized;
                ClsGetSomething1.ClsGetDefaultDate();
                txtEnterDate.Text = ClsGetSomething1.plsdefdate;
                txtBeginDate.Text = ClsGetSomething1.plsdefdate;
                txtEndDate.Text = ClsGetSomething1.plsdefdate;
                
                buildcboWHCode();
                buildcboCNCode();
                buildcboCatCode();
                cboWHCode.SelectedValue = "";
                cboCatCode.SelectedValue = "";
                cboStockNumber.SelectedValue = "";
                cboVoucher.Text = "PD";
            }
        }

        private void txtEnterDate_Validating(object sender, CancelEventArgs e)
        {
            if (new ClsValidation().errordate(txtEnterDate.Text) == true)
            {
                MessageBox.Show("Invalid Date", "GL");
                txtEnterDate.Focus();
            }
        }

        private void nextfieldenter2(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.Equals(Keys.Enter))
            {
                SendKeys.Send("{TAB}");
            }
        }

        private void cbortprint_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbortprint.SelectedValue.ToString() == "01")//Inventory Summary
            {
                cboStockNumber.Enabled = false;
                cboCatCode.Enabled = false;
                cboVoucher.Enabled = false;
                lblEnterDate.Enabled = true;
                txtEnterDate.Enabled = true;
                lblBeginDate.Enabled = false;
                lblEndDate.Enabled = false;
                txtBeginDate.Enabled = false;
                txtEndDate.Enabled = false;
                cboWHCode.Enabled = true;

            }
            else if (cbortprint.SelectedValue.ToString()=="02")//Inventory Summary - Category
            {
                lblEnterDate.Enabled = true;
                txtEnterDate.Enabled = true;
                lblBeginDate.Enabled = false;
                lblEndDate.Enabled = false;
                txtBeginDate.Enabled = false;
                txtEndDate.Enabled = false;
                cboWHCode.Enabled = true;
                cboStockNumber.Enabled = false;
                cboVoucher.Enabled = false;
                cboCatCode.Enabled = true;
            }
            else if (cbortprint.SelectedValue.ToString() == "03")//Stock Card
            {
                cboStockNumber.Enabled = true;
                lblEnterDate.Enabled = false;
                txtEnterDate.Enabled = false;
                lblBeginDate.Enabled = true;
                lblEndDate.Enabled = true;
                txtBeginDate.Enabled = true;
                txtEndDate.Enabled = true;
                cboWHCode.Enabled = true;
                cboCatCode.Enabled = true;
                cboVoucher.Enabled = false;
            }
            else if (cbortprint.SelectedValue.ToString() == "04")//Stock Card - type
            {
                cboStockNumber.Enabled = true;
                lblEnterDate.Enabled = false;
                txtEnterDate.Enabled = false;
                lblBeginDate.Enabled = true;
                lblEndDate.Enabled = true;
                txtBeginDate.Enabled = true;
                txtEndDate.Enabled = true;
                cboWHCode.Enabled = true;
                cboCatCode.Enabled = true;
                cboVoucher.Enabled = true;
            }

            else if (cbortprint.SelectedValue.ToString() == "05")//Inventory Summary - type
            {
                cboStockNumber.Enabled = false;
                lblEnterDate.Enabled = false;
                txtEnterDate.Enabled = false;
                lblBeginDate.Enabled = true;
                lblEndDate.Enabled = true;
                txtBeginDate.Enabled = true;
                txtEndDate.Enabled = true;
                cboWHCode.Enabled = true;
                cboCatCode.Enabled = false;
                cboVoucher.Enabled = true;
            }
            else if (cbortprint.SelectedValue.ToString() == "06")//Inventory Summary - type - Category
            {
                cboStockNumber.Enabled = false;
                lblEnterDate.Enabled = false;
                txtEnterDate.Enabled = false;
                lblBeginDate.Enabled = true;
                lblEndDate.Enabled = true;
                txtBeginDate.Enabled = true;
                txtEndDate.Enabled = true;
                cboWHCode.Enabled = true;
                cboCatCode.Enabled = true;
                cboVoucher.Enabled = true;
            }
            else if (cbortprint.SelectedValue.ToString() == "07")//Inventory Summary From-To
            {
                cboStockNumber.Enabled = false;
                lblEnterDate.Enabled = false;
                txtEnterDate.Enabled = false;
                lblBeginDate.Enabled = true;
                lblEndDate.Enabled = true;
                txtBeginDate.Enabled = true;
                txtEndDate.Enabled = true;
                cboWHCode.Enabled = true;
                cboCatCode.Enabled = false;
                cboVoucher.Enabled = false;
            }
            else if (cbortprint.SelectedValue.ToString() == "08")//Inventory Summary From-To PD Only
            {
                cboStockNumber.Enabled = false;
                lblEnterDate.Enabled = false;
                txtEnterDate.Enabled = false;
                lblBeginDate.Enabled = true;
                lblEndDate.Enabled = true;
                txtBeginDate.Enabled = true;
                txtEndDate.Enabled = true;
                cboWHCode.Enabled = true;
                cboCatCode.Enabled = false;
                cboVoucher.Enabled = false;
            }

        }

        private void cboCatCode_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void cboCatCode_Validating(object sender, CancelEventArgs e)
        {
            buildcboStocks();

        }
    }
}
