﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Threading;

namespace TCIGL
{
    public partial class frmVoucherRTS : Form
    {
        string varoutdate = "No";
        
        public static DataGridView glbldgv2;
        SqlConnection myconnection;
        SqlCommand mycommand;
        SqlCommand mycommanddgv2;
        ClsAutoNumber ClsAutoNumber1 = new ClsAutoNumber();
        ClsBuildComboBox ClsBuildComboBox1 = new ClsBuildComboBox();
        ClsValidation ClsValidation1 = new ClsValidation();
        ClsGetSomething ClsGetSomething1 = new ClsGetSomething();
        ClsPermission ClsPermission1 = new ClsPermission();
        ClsBuildEntryComboBox ClsBuildEntryComboBox1 = new ClsBuildEntryComboBox();
        ClsGetConnection ClsGetConnection1 = new ClsGetConnection();
        ClsDefaultBranch ClsDefaultBranch1 = new ClsDefaultBranch();
        ClsGetSomethingEntry ClsGetSomethingEntry1 = new ClsGetSomethingEntry();
        string dgvdata = null;
        public static TextBox glblSPO;
        public static TextBox glbltxtTotDisct, glbltxtTotalVAT, glbltxtTotCost, glbltxtTotPayables;
        public static ComboBox glblcboWHCode;
        public static MaskedTextBox glbltxtTDate;
        public static ComboBox glblcboControlNo, glblProjectCode;
        public static TextBox glbltxtreference, glbltxtTerm, glbltxtRemarks, glbltxtOrigDoc;
        public static Button glblbtnSave;
        private string pristrRMInvTotal = "0";
        private string pristrFSInvTotal="0";

        ClsGetSomethingOthers ClsGetSomethingOthers1 = new ClsGetSomethingOthers();
        int varintTableDoor = 0;
        int number = 0;
        private string privarstrVoidIC = null;
        public frmVoucherRTS()
        {
            InitializeComponent();
            {
                ClsGetSomethingOthers1.ClsGetVoidRef("RTS", "1");
                privarstrVoidIC = ClsGetSomethingOthers1.plsVoidIC;
                if (new ClsValidation().emptytxt(privarstrVoidIC))
                { }
                else
                {
                    ClsGetSomethingOthers1.ClsDeleteErrorTransaction("RTS", "1");
                }
            }
        }

        private void buildcboCustCode()
        {
            cboControlNo.DataSource = null;
            ClsBuildComboBox1.ARPDCN.Clear();
            ClsBuildComboBox1.ClsBuildPDControlNo();
            this.cboControlNo.DataSource = (ClsBuildComboBox1.ARPDCN);
            this.cboControlNo.DisplayMember = "Display";
            this.cboControlNo.ValueMember = "Value";
        }
        private void buildcboWHCode()
        {
            cboWHCode.DataSource = null;
            ClsBuildEntryComboBox1.ARWHCode.Clear();
            ClsBuildEntryComboBox1.ClsBuildWHCode();
            this.cboWHCode.DataSource = (ClsBuildEntryComboBox1.ARWHCode);
            this.cboWHCode.DisplayMember = "Display";
            this.cboWHCode.ValueMember = "Value";
            //this.cboWHCode.DropDownWidth = 450;
        }

        private void getAcctEntry()
        {
            string vartotalPayables = (double.Parse(txtTotalVAT.Text) + double.Parse(txtTotCost.Text)).ToString("N2");
            string vartotalRMInv = double.Parse(pristrRMInvTotal).ToString("N2");
            string vartotalFSInv = double.Parse(pristrFSInvTotal).ToString("N2");
            string vartotalVAT = double.Parse(txtTotalVAT.Text).ToString("N2");

            //Payables
            dgv1.Rows.Add("30000000000", txtOrigDoc.Text, vartotalPayables, "0.00", 0);

            if (double.Parse(vartotalVAT) != 0)
            {
                dgv1.Rows.Add("25000000000", txtOrigDoc.Text, "0.00", vartotalVAT, 0);
            }

            //Raw Material Inventory
            if (double.Parse(pristrRMInvTotal) != 0)
            {
                dgv1.Rows.Add("14000000000", txtOrigDoc.Text, "0.00", vartotalRMInv, 0);
            }

            //Factory Supply Inventory
            if (double.Parse(pristrFSInvTotal) != 0)
            {
                dgv1.Rows.Add("14500000000", txtOrigDoc.Text, "0.00", vartotalFSInv, 0);
            }
          dgv1total();
        }

        private void SaveTransact()
        {
            try
            {
                DateTime DT = DateTime.Now;
                string sqlstatement;
                string sqlstatementdgv2;

                sqlstatement = "INSERT INTO tblmain1 (IC, DocNum, Voucher, UserCode, ControlNo, TDate, Reference, Term, Remarks, CheckNo, CAmount, ASMCode, DE, CNCode)";
                sqlstatement += " Values (@_IC, @_DocNum, @_Voucher, @_UserCode, @_ControlNo, @_TDate, @_Reference, @_Term, @_Remarks, @_CheckNo, @_CAmount, @_ASMCode, @_DE, @_CNCode)";
                sqlstatementdgv2 = "INSERT INTO tblmain2 (IC, StockNumber,  PIn, POut, UP, Cost, ActDisct, PDisct, VAT, RowNum, D1, D2, D3, WHCode)";
                sqlstatementdgv2 += "Values (@_IC, @_StockNumber, @_PIn, @_POut, @_UP, @_Cost, @_ActDisct, @_PDisct, @_VAT, @_RowNum, @_D1, @_D2, @_D3, @_WHCode)";
                string sqlstatementdgv3 = "INSERT INTO tblmain3 (IC, Refer, Debit, Credit, PA, SIT) Values (@_IC, @_Refer, @_Debit, @_Credit, @_PA, @_SIT)";

                ClsAutoNumber1.VoucherAutoNum("RTS");
                txtDocNum.Text = (ClsAutoNumber1.plsnumber);

                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();

                mycommand = new SqlCommand(sqlstatement, myconnection);
                mycommand.Parameters.Add("_IC", SqlDbType.VarChar).Value = "RTS" + Form1.glbluc.Text + (ClsDefaultBranch1.plsvardb);
                mycommand.Parameters.Add("_DocNum", SqlDbType.VarChar).Value = Form1.glbluc.Text;
                mycommand.Parameters.Add("_Voucher", SqlDbType.VarChar).Value = "RTS";
                mycommand.Parameters.Add("_UserCode", SqlDbType.VarChar).Value = Form1.glbluc.Text;
                mycommand.Parameters.Add("_ControlNo", SqlDbType.VarChar).Value = cboControlNo.SelectedValue;
                mycommand.Parameters.Add("_TDate", SqlDbType.Date).Value = txtTDate.Text;
                mycommand.Parameters.Add("_Reference", SqlDbType.VarChar).Value = txtreference.Text;
                mycommand.Parameters.Add("_Term", SqlDbType.Int).Value = "0";
                mycommand.Parameters.Add("_Remarks", SqlDbType.VarChar).Value = txtRemarks.Text;
                mycommand.Parameters.Add("_CheckNo", SqlDbType.VarChar).Value = "NA";
                mycommand.Parameters.Add("_CAmount", SqlDbType.Money).Value = 0;
                mycommand.Parameters.Add("_ASMCode", SqlDbType.VarChar).Value = "001";
                mycommand.Parameters.Add("_DE", SqlDbType.Date).Value = DT;
                mycommand.Parameters.Add("_CNCode", SqlDbType.Char).Value = (ClsDefaultBranch1.plsvardb);
                int n1 = mycommand.ExecuteNonQuery();

                DataGridViewRow row1 = null;
                for (int x = 0; x < dgv2.Rows.Count; x++)
                {
                    row1 = dgv2.Rows[x];
                    mycommanddgv2 = new SqlCommand(sqlstatementdgv2, myconnection);
                    mycommanddgv2.Parameters.Add("_IC", SqlDbType.VarChar).Value = "RTS" + Form1.glbluc.Text + (ClsDefaultBranch1.plsvardb);
                    mycommanddgv2.Parameters.Add("_StockNumber", SqlDbType.VarChar).Value = row1.Cells[1].Value;
                    mycommanddgv2.Parameters.Add("_PIn", SqlDbType.Decimal).Value = "0";
                    mycommanddgv2.Parameters.Add("_POut", SqlDbType.Decimal).Value = row1.Cells[3].Value;
                    mycommanddgv2.Parameters.Add("_UP", SqlDbType.Decimal).Value = row1.Cells[4].Value;
                    mycommanddgv2.Parameters.Add("_Cost", SqlDbType.Decimal).Value = row1.Cells[9].Value;
                    mycommanddgv2.Parameters.Add("_ActDisct", SqlDbType.Decimal).Value = row1.Cells[5].Value;
                    mycommanddgv2.Parameters.Add("_PDisct", SqlDbType.Decimal).Value = row1.Cells[6].Value;
                    mycommanddgv2.Parameters.Add("_VAT", SqlDbType.Decimal).Value = row1.Cells[7].Value;
                    mycommanddgv2.Parameters.Add("_RowNum", SqlDbType.Int).Value = (Convert.ToInt32(x) + 1).ToString();
                    mycommanddgv2.Parameters.Add("_D1", SqlDbType.Decimal).Value = row1.Cells[0].Value;
                    mycommanddgv2.Parameters.Add("_D2", SqlDbType.Decimal).Value = "0";
                    mycommanddgv2.Parameters.Add("_D3", SqlDbType.Decimal).Value = "0";
                    mycommanddgv2.Parameters.Add("_WHCode", SqlDbType.VarChar).Value = cboWHCode.SelectedValue.ToString();
                    int n2 = mycommanddgv2.ExecuteNonQuery();
                }

                DataGridViewRow row = null;
                for (int x = 0; x < dgv1.Rows.Count; x++)
                {
                    row = dgv1.Rows[x];
                    mycommand = new SqlCommand(sqlstatementdgv3, myconnection);
                    mycommand.Parameters.Add("_IC", SqlDbType.VarChar).Value = "RTS" + Form1.glbluc.Text + (ClsDefaultBranch1.plsvardb);
                    mycommand.Parameters.Add("_PA", SqlDbType.VarChar).Value = row.Cells[0].Value;
                    mycommand.Parameters.Add("_Refer", SqlDbType.VarChar).Value = row.Cells[1].Value;
                    mycommand.Parameters.Add("_Debit", SqlDbType.Decimal).Value = row.Cells[2].Value;
                    mycommand.Parameters.Add("_Credit", SqlDbType.Decimal).Value = row.Cells[3].Value;
                    mycommand.Parameters.Add("_SIT", SqlDbType.VarChar).Value = row.Cells[4].Value;
                    int n3 = mycommand.ExecuteNonQuery();
                }

                myconnection.Close();
                ClsGetSomethingOthers1.ClsFinalize("RTS", txtDocNum.Text, "1");

                ClsAutoNumber1.VoucherAutoNum("RTS");
                txtDocNum.Text = (ClsAutoNumber1.plsnumber);
                clearscreen();
            }
            catch
            {
                MessageBox.Show("Error, please click OK", "GL");
                this.Close();
            }
            finally
            {
                myconnection.Close();
            }
        }

        private void clearscreen()
        {
            dgv2.Rows.Clear();
            txtreference.Text = "";
            cboControlNo.SelectedValue = "";
            // txtCheckNo.Text = "NA";
            //  txtCAmount.Text = "0.00";
            //cboPC.Text = "";
            txtRemarks.Text = "Return to Supplier";
            txtTDate.Focus();
            txtTotalVAT.Text = "0.00";
            txtTotCost.Text = "0.00";
            txtTotDisct.Text = "0.00";
            txtTerm.Text = "0";
            txtOrigDoc.Text = null;
            dgvdata = null;
            pristrFSInvTotal = "0";
            pristrRMInvTotal = "0";
        }

        private void dgv2totalActualEntry()
        {
            pristrRMInvTotal = (dgv2.Rows.Cast<DataGridViewRow>().Where(r => (r.Cells[10].Value).Equals("1")).Sum(t => Convert.ToDouble(t.Cells[9].Value))).ToString("N2");
            pristrFSInvTotal = (dgv2.Rows.Cast<DataGridViewRow>().Where(r => (r.Cells[10].Value).Equals("2")).Sum(t => Convert.ToDouble(t.Cells[9].Value))).ToString("N2");
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            
            ClsValidation1.securedate(DateTime.Parse(txtTDate.Text));
            varoutdate = (ClsValidation1.plsoutdate);
            for (int x = 0; x < dgv2.Rows.Count; x++)
            {
                dgvdata = (dgv2.Rows[x].Cells[0].FormattedValue.ToString());
            }

            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();

            dgv1.Rows.Clear();
            DataGridViewRow row1 = null;
            for (int x = 0; x < dgv2.Rows.Count; x++)
            {
                row1 = dgv2.Rows[x];
                ClsGetSomethingEntry1.ClsGetInvClassCode(row1.Cells[1].Value.ToString());
                string strInvClassCode = ClsGetSomethingEntry1.plsvarInvClassCode;
                row1.Cells[10].Value = ClsGetSomethingEntry1.plsvarInvClassCode;
            }
            dgv2totalActualEntry();

            getAcctEntry();

            if (new Clsexist().RecordExists(ref myconnection, "SELECT Reference FROM tblmain1 WHERE Reference ='" + txtreference.Text + "'"))
            {
                myconnection.Close();
                MessageBox.Show("Duplicate entry", "GL");
                txtreference.Focus();
            }
            else if ((txtTDate.Text == "  /  /"))
            {
                myconnection.Close();
                MessageBox.Show("Please complete your entry", "GL");
                txtTDate.Focus();
            }
            else if ((new ClsValidation().emptytxt(cboControlNo.Text)) || (new ClsValidation().emptytxt(txtreference.Text)) ||
                (new ClsValidation().emptytxt(txtRemarks.Text)) || (new ClsValidation().emptytxt (txtOrigDoc.Text)))
            {
                myconnection.Close();
                MessageBox.Show("Please complete your entry", "GL");
                txtTDate.Focus();
            }
            else if (varoutdate == "Yes")
            {
                myconnection.Close();
                MessageBox.Show("Date is out of range", "GL");
                txtTDate.Focus();
            }
            else if (new ClsValidation().emptytxt(dgvdata))
            {
                myconnection.Close();
                MessageBox.Show("Incomplete Record", "IS");
                txtTDate.Focus();
            }
            else if (Convert.ToDouble(txtDifference.Text) != 0)
            {
                myconnection.Close();
                dgv1.Rows.Clear();
                MessageBox.Show("Not balance", "GL");
                txtRemarks.Focus();
            }
            else
            {
                myconnection.Close();
                privarstrVoidIC = null;
                ClsGetSomethingOthers1.ClsGetTDoor("RTS");
                varintTableDoor = int.Parse(ClsGetSomethingOthers1.plsTableDoor);
                number = 0;
                while (varintTableDoor == 1 && number <= 20)
                {
                    number = number + 1;
                    Thread.Sleep(200);
                    varintTableDoor = int.Parse(ClsGetSomethingOthers1.plsTableDoor);
                }

                if (varintTableDoor == 0 && number <= 20)
                {

                    ClsGetSomethingOthers1.ClsGetVoidRef("RTS", "1");
                    privarstrVoidIC = ClsGetSomethingOthers1.plsVoidIC;
                    if (new ClsValidation().emptytxt(privarstrVoidIC))
                    {
                        ClsGetSomethingOthers1.ClsOneTheDoor("RTS");
                        SaveTransact();
                        ClsGetSomethingOthers1.ClsZeroTheDoor("RTS");
                    }
                    else
                    {
                        ClsGetSomethingOthers1.ClsDeleteErrorTransaction("RTS", "1");
                        MessageBox.Show("Transaction not saved", "GL");
                    }
                }
                else if (varintTableDoor == 1 && number == 21)
                {
                    MessageBox.Show("Contact your adminnistrator", "GL");
                }
            }
        }



        private void cboCustCode_Validating(object sender, CancelEventArgs e)
        {
            if (new ClsValidation().emptytxt(cboControlNo.Text))
            {
            }
            else if (cboControlNo.Text != null && cboControlNo.SelectedValue == null)
            {
                MessageBox.Show("Not found", "GL");
                cboControlNo.Focus();
            }
            else
            {
                ClsGetSomething1.ClsGetCustData(cboControlNo.SelectedValue.ToString());
                txtTerm.Text = ClsGetSomething1.plsTerm;
            }
        }

        private void frmVoucherRTS_Load(object sender, EventArgs e)
        {
            ClsPermission1.ClsObjects(this.Text);
            if (new ClsValidation().emptytxt(ClsPermission1.plstxtObject))
            {
                MessageBox.Show("You do not have necessary permission to open this file", "GL");
                this.Close();
            }
            else
            {
                ClsAutoNumber1.VoucherAutoNum("RTS");
                txtDocNum.Text = (ClsAutoNumber1.plsnumber);
                ClsGetSomething1.ClsGetDefaultDate();
                txtTDate.Text = ClsGetSomething1.plsdefdate;
                buildcboWHCode();
                buildcboCustCode();
                
                glbldgv2 = dgv2;
                glbltxtTotDisct=txtTotDisct;
                glbltxtTotalVAT=txtTotalVAT;
                glbltxtTotCost=txtTotCost;
                glblcboWHCode = cboWHCode;
                glbltxtTotDisct = txtTotDisct;
                glbltxtTotalVAT = txtTotalVAT;
                glbltxtTotCost = txtTotCost;
                glblcboWHCode = cboWHCode;
                glbltxtTDate = txtTDate;
                glblcboControlNo = cboControlNo;
                glbltxtreference = txtreference;
                glbltxtTerm = txtTerm;
                glbltxtRemarks = txtRemarks;
                glbltxtOrigDoc = txtOrigDoc;
                glblbtnSave = btnSave;
    
                cboControlNo.SelectedValue = "";
                privarstrVoidIC = null;
                ClsGetSomethingOthers1.ClsGetVoidRef("RTS", "1");
                privarstrVoidIC = ClsGetSomethingOthers1.plsVoidIC;
                if (new ClsValidation().emptytxt(privarstrVoidIC))
                { }
                else
                {
                    ClsGetSomethingOthers1.ClsDeleteErrorTransaction("RTS", "1");
                    privarstrVoidIC = null;
                }
            }
        }


        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
            frmTransactEntryPD frmTransactEntryPD1 = new frmTransactEntryPD();
            frmTransactEntryPD1.Close();
        }

        private void btnPE_Click(object sender, EventArgs e)
        {
            frmTransactEntryPD frmEntryPD1 = new frmTransactEntryPD();
            frmEntryPD1.Show();
            frmTransactEntryPD.glbltxtVoucher.Text = "RTS";
            btnPE.Visible = false;
            label22.Visible = true;
        }

       
        private void frmVoucherRTS_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F5)
            {
                if ((txtTDate.Text == "  /  /"))
                {
                    MessageBox.Show("Please complete your entry", "GL");
                    txtTDate.Focus();
                }
                else if ((new ClsValidation().emptytxt(cboControlNo.Text)) || (new ClsValidation().emptytxt(txtreference.Text)) ||
                    (new ClsValidation().emptytxt(txtRemarks.Text)))
                {
                    MessageBox.Show("Please complete your entry", "GL");
                    txtTDate.Focus();
                }
                else
                {
                    //frmTransactEntryCI.glbltxtD1.Enabled = false;
                    //frmTransactEntryCI.glbltxtD2.Enabled = false;
                    //frmTransactEntryCI.glbltxtD3.Enabled = false;
                    Form NonPoultry = Application.OpenForms["frmTransactEntryPD"];
                    if (NonPoultry != null)
                    {
                        //Application.OpenForms["frmTransactEntryCI"].BringToFront();
                        Application.OpenForms["frmTransactEntryPD"].Show();
                    }
                    else
                    {
                        MessageBox.Show("Not applicable at this moment", "GL");
                    }
                }
            }
        }

        private void txtTDate_Validating(object sender, CancelEventArgs e)
        {
            if (new ClsValidation().errordate(txtTDate.Text) == true)
            {
                MessageBox.Show("Invalid Date", "GL");
                txtTDate.Focus();
            }
        }

        private void dgv2_UserDeletedRow(object sender, DataGridViewRowEventArgs e)
        {
            dgv2total();
        }

        private void dgv1total()
        {
            double vartxtdr = 0.00;
            double vartxtcr = 0.00;
            double vartxtdiff = 0.00;

            for (int x = 0; x < dgv1.Rows.Count; x++)
            {
                vartxtdr += double.Parse(dgv1.Rows[x].Cells[2].FormattedValue.ToString());
            }

            for (int x = 0; x < dgv1.Rows.Count; x++)
            {
                vartxtcr += double.Parse(dgv1.Rows[x].Cells[3].FormattedValue.ToString());
            }
            txtdrtot.Text = vartxtdr.ToString("N2");
            txtcrtot.Text = vartxtcr.ToString("N2");
            vartxtdiff = Convert.ToDouble(txtdrtot.Text) - Convert.ToDouble(txtcrtot.Text);
            txtDifference.Text = vartxtdiff.ToString("N2");
        }
        private void dgv2total()
        {
            double dbltxtTotDisct = 0;
            double dbltxtTotalVAT = 0;
            double dbltxtTotCost = 0;
            {
                for (int x = 0; x < frmVoucherRTS.glbldgv2.Rows.Count; x++)
                {
                    string vartxtD1 = frmVoucherRTS.glbldgv2.Rows[x].Cells[6].FormattedValue.ToString();
                    string vartxtD2 = frmVoucherRTS.glbldgv2.Rows[x].Cells[7].FormattedValue.ToString();
                    dbltxtTotDisct += double.Parse(vartxtD1) + double.Parse(vartxtD2);
                }
                for (int x = 0; x < frmVoucherRTS.glbldgv2.Rows.Count; x++)
                {
                    dbltxtTotalVAT += double.Parse(frmVoucherRTS.glbldgv2.Rows[x].Cells[8].FormattedValue.ToString());
                }

                for (int x = 0; x < frmVoucherRTS.glbldgv2.Rows.Count; x++)
                {
                    dbltxtTotCost += double.Parse(frmVoucherRTS.glbldgv2.Rows[x].Cells[10].FormattedValue.ToString());
                }

                frmVoucherRTS.glbltxtTotDisct.Text = dbltxtTotDisct.ToString("N2");
                frmVoucherRTS.glbltxtTotalVAT.Text = dbltxtTotalVAT.ToString("N2");
                frmVoucherRTS.glbltxtTotCost.Text = dbltxtTotCost.ToString("N2");

            }
        }

        private void txtreference_Validating(object sender, CancelEventArgs e)
        {
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();

            if (new Clsexist().RecordExists(ref myconnection, "SELECT Reference FROM tblmain1 WHERE Reference ='" + txtreference.Text + "'"))
            {
                myconnection.Close();
                MessageBox.Show("Duplicate entry", "GL");
                txtreference.Focus();
            }
            myconnection.Close();
        }

        private void cboWHCode_Validating(object sender, CancelEventArgs e)
        {
            if (new ClsValidation().emptytxt(cboWHCode.Text))
            {
            }
            else if (cboWHCode.Text != null && cboWHCode.SelectedValue == null)
            {
                MessageBox.Show("Not found", "GL");
                cboWHCode.Focus();
            }
        }

        private void txtTerm_Validating(object sender, CancelEventArgs e)
        {
            if (new ClsValidation().isInt(txtTerm.Text) == true)
            {
                MessageBox.Show("Invalid Number", "GL");
                txtTerm.Focus();
            }

        }

        private void nextfieldenter1(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.Equals(Keys.Enter))
            {
                SendKeys.Send("{TAB}");
            }
            else if ((e.KeyCode.Equals(Keys.Up)) || (e.KeyCode.Equals(Keys.Left)))
            {
                SendKeys.Send("+{TAB}");
            }
            else if ((e.KeyCode.Equals(Keys.Down)) || (e.KeyCode.Equals(Keys.Right)))
            {
                SendKeys.Send("{TAB}");
            }
        }

        private void nextfieldenter2(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.Equals(Keys.Enter))
            {
                SendKeys.Send("{TAB}");
            }
        }

  

        private void LaunchPayableList()
        {
            txtOrigDoc.Text = "";
            if (new Clsexist().RecordExists(ref myconnection, "SELECT Reference FROM tblmain1 WHERE Reference ='" + txtreference.Text + "' AND CNCode = '" + (ClsDefaultBranch1.plsvardb) + "'"))
            {
                myconnection.Close();
                MessageBox.Show("Duplicate entry", "GL");
                txtTDate.Focus();
            }
            else if (txtTDate.Text == "  /  /")
            {
                MessageBox.Show("Please complete your entry", "GL");
                txtTDate.Focus();
            }
            else if (new ClsValidation().emptytxt(txtreference.Text))
            {
                MessageBox.Show("Please complete your entry", "GL");
                txtreference.Focus();
            }
            else if (new ClsValidation().emptytxt(cboControlNo.Text))
            {
                MessageBox.Show("Please complete your entry", "GL");
                cboControlNo.Focus();
            }
            else if (new ClsValidation().emptytxt(txtRemarks.Text))
            {
                MessageBox.Show("Please complete your entry", "GL");
                txtRemarks.Focus();
            }
            else
            {
                frmIndPayables frmIndPayables1 = new frmIndPayables();
                frmIndPayables1.Show();
            }
        }

        private void btnListOfPayables_Click(object sender, EventArgs e)
        {
            LaunchPayableList();
            frmIndPayables.glbltxtVoucher.Text = "RTS";
        }

        private void frmVoucherRTS_FormClosing(object sender, FormClosingEventArgs e)
        {
            Form NonPoultry = Application.OpenForms["frmTransactEntryPD"];
            if (NonPoultry != null)
            {
                frmTransactEntryPD CloseNonPoultry = (frmTransactEntryPD)Application.OpenForms["frmTransactEntryPD"];
                CloseNonPoultry.Close();
            }
        }
    }
}
