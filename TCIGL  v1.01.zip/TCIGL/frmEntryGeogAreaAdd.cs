﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TCIGL
{
    public partial class frmEntryGeogAreaAdd : Form
    {
        SqlConnection myconnection;
        SqlCommand mycommand;
        BindingSource dbind = new BindingSource();
        ClsAutoNumber ClsAutoNumber1 = new ClsAutoNumber();
        ClsPermission ClsPermission1 = new ClsPermission();
        ClsGetConnection ClsGetConnection1 = new ClsGetConnection();
        ClsBuildEntryComboBox ClsBuildEntryComboBox1 = new ClsBuildEntryComboBox(); 
        public frmEntryGeogAreaAdd()
        {
            InitializeComponent();
            buildcboTCode();
        }
   
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            Save();
        }

        private void Save()
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                if (new ClsValidation().emptytxt(txtGADesc.Text))
                {
                    myconnection.Close();
                    MessageBox.Show("Please complete your entry", "GL");
                    txtGADesc.Focus();
                }
                else if (new ClsValidation().emptytxt (cboTCode.Text))
                {
                    myconnection.Close();
                    MessageBox.Show("Please complete your entry", "GL");
                    cboTCode.Focus();
                }
                else if (new Clsexist().RecordExists(ref myconnection, "SELECT GADesc FROM tblGeogArea WHERE GADesc ='" + txtGADesc.Text + "'"))
                {
                    myconnection.Close();
                    MessageBox.Show("Duplicate entry", "GL");
                    txtGADesc.Focus();
                }
                else
                {
                    ClsAutoNumber1.GAAutoNum();
                    txtGACode.Text = (ClsAutoNumber1.plsnumber);
                    string sqlstatement;
                    sqlstatement = "INSERT INTO tblGeogArea (GACode, GADesc, TCode) Values (@_GACode, @_GADesc, @_TCode)";
                    mycommand = new SqlCommand(sqlstatement, myconnection);
                    mycommand.Parameters.Add("_GACode", SqlDbType.VarChar).Value = txtGACode.Text;
                    mycommand.Parameters.Add("_GADesc", SqlDbType.VarChar).Value = txtGADesc.Text;
                    mycommand.Parameters.Add("_TCode", SqlDbType.VarChar).Value = cboTCode.SelectedValue.ToString();
                    int n2 = mycommand.ExecuteNonQuery();

                    myconnection.Close();
                    txtGADesc.Text = "";
                    cboTCode.Text = "";
                    txtGADesc.Focus();

                    ClsAutoNumber1.GAAutoNum();
                    txtGACode.Text = (ClsAutoNumber1.plsnumber);
                }
            }
            catch
            {
                MessageBox.Show("Busy, please click OK", "GL");
                Save();
            }
            finally
            {
                //               dr.Close();
                myconnection.Close();
            }

        }
        private void frmGAAdd_Load(object sender, EventArgs e)
        {
            ClsPermission1.ClsObjects(this.Text);
            if (new ClsValidation().emptytxt(ClsPermission1.plstxtObject))
            {
                MessageBox.Show("You do not have necessary permission to open this file", "GL");
                this.Close();
            }
            else
            {
                ClsAutoNumber1.GAAutoNum();
                txtGACode.Text = (ClsAutoNumber1.plsnumber);
            }
        }

       

        private void buildcboTCode()
        {
            cboTCode.DataSource = null;
            ClsBuildEntryComboBox1.ARTCode.Clear();
            ClsBuildEntryComboBox1.ClsBuildTCode();
            this.cboTCode.DataSource = (ClsBuildEntryComboBox1.ARTCode);
            this.cboTCode.DisplayMember = "Display";
            this.cboTCode.ValueMember = "Value";
            this.cboTCode.DropDownWidth = 450;
        }

        private void nextfieldenter1(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.Equals(Keys.Enter))
            {
                SendKeys.Send("{TAB}");
            }
            else if ((e.KeyCode.Equals(Keys.Up)) || (e.KeyCode.Equals(Keys.Left)))
            {
                SendKeys.Send("+{TAB}");
            }
            else if ((e.KeyCode.Equals(Keys.Down)) || (e.KeyCode.Equals(Keys.Right)))
            {
                SendKeys.Send("{TAB}");
            }
        }

        private void nextfieldenter2(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.Equals(Keys.Enter))
            {
                SendKeys.Send("{TAB}");
            }

        } 

    
    }
}
