﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TCIGL
{
    class ClsBuildCOAComboBox
    {
        public ArrayList ARCOAG1 = new ArrayList();
        public ArrayList ARCOAG2 = new ArrayList();
        public ArrayList ARFCCode = new ArrayList();
        public ArrayList ARSCCode = new ArrayList();
        public ArrayList ARUsage = new ArrayList();
        public ArrayList ARcboactcode = new ArrayList();
        public ArrayList ARcboD1Code = new ArrayList();
        public ArrayList ARcboD2Code = new ArrayList();
        public ArrayList ARcboSearchPA = new ArrayList();
        public ArrayList ARcboSearchAN = new ArrayList();
        public ArrayList ARPA = new ArrayList();
        public ArrayList ARLRAct = new ArrayList();
        SqlConnection myconnection;
        SqlDataReader dr;
        SqlCommand mycommand;
        ClsGetConnection ClsGetConnection1 = new ClsGetConnection(); 

        public void ClsbuildCOAG1()
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = new SqlCommand("SELECT Code, Description FROM tblCOAGrouping WHERE GroupCode='01'", myconnection);
                dr = mycommand.ExecuteReader();

                while (dr.Read())
                {
                    ARCOAG1.Add(new Clsaddvalue(dr.GetString(1), dr.GetString(0)));
                }
                dr.Close();
                myconnection.Close();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
                myconnection.Close();
            }
        }

        public void ClsbuildcboReleasingAct()
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL(); myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = new SqlCommand("SELECT PA, AT FROM ViewPA WHERE SCCode='CA' ORDER by PA ", myconnection);
                dr = mycommand.ExecuteReader();

                while (dr.Read())
                {
                    ARLRAct.Add(new Clsaddvalue(dr.GetString(1), dr.GetString(0)));
                }
                dr.Close();
                myconnection.Close();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
                myconnection.Close();
            }
        }

        public void ClsbuildCOAG2()
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = new SqlCommand("SELECT Code, Description FROM tblCOAGrouping WHERE GroupCode='02'", myconnection);
                dr = mycommand.ExecuteReader();

                while (dr.Read())
                {
                    ARCOAG2.Add(new Clsaddvalue(dr.GetString(1), dr.GetString(0)));
                }
                dr.Close();
                myconnection.Close();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
                myconnection.Close();
            }
        }

        public void ClsbuildFirstCaption()
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = new SqlCommand("SELECT FCCode, FCDesc FROM tblFSFirstCaption", myconnection);
                dr = mycommand.ExecuteReader();

                while (dr.Read())
                {
                    ARFCCode.Add(new Clsaddvalue(dr.GetString(1), dr.GetString(0)));
                }
                dr.Close();
                myconnection.Close();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
                myconnection.Close();
            }
        }

        public void ClsbuildSecondCaption()
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = new SqlCommand("SELECT SCCode, Description FROM tblFSSecondCaption", myconnection);
                dr = mycommand.ExecuteReader();

                while (dr.Read())
                {
                    ARSCCode.Add(new Clsaddvalue(dr.GetString(1), dr.GetString(0)));
                }
                dr.Close();
                myconnection.Close();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
                myconnection.Close();
            }
        }

        public void ClsbuildUsage()
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = new SqlCommand("SELECT UsageCode, UsageDesc FROM tblClassificationUsage", myconnection);
                dr = mycommand.ExecuteReader();

                while (dr.Read())
                {
                    ARUsage.Add(new Clsaddvalue(dr.GetString(1), dr.GetString(0)));
                }
                dr.Close();
                myconnection.Close();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
                myconnection.Close();
            }
        }

        public void ClsbuildCboActCode()
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = new SqlCommand("SELECT AcctNo, TitleAcct FROM tbltitleacct ORDER by TitleAcct ", myconnection);
                dr = mycommand.ExecuteReader();

                while (dr.Read())
                {
                    ARcboactcode.Add(new Clsaddvalue(dr.GetString(1), dr.GetString(0)));
                }
                dr.Close();
                myconnection.Close();

            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
                myconnection.Close();
            }
        }

        public void ClsbuildCboD1Code()
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = new SqlCommand("SELECT D1Code, D1Desc FROM tbldept1 ORDER by D1Desc ", myconnection);
                dr = mycommand.ExecuteReader();

                while (dr.Read())
                {
                    ARcboD1Code.Add(new Clsaddvalue(dr.GetString(1), dr.GetString(0)));
                }
                dr.Close();
                myconnection.Close();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
                myconnection.Close();
            }
        }

        public void ClsbuildCboD2Code()
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = new SqlCommand("SELECT D2Code, D2Desc FROM tbldept2 ORDER by D2Desc ", myconnection);
                dr = mycommand.ExecuteReader();

                while (dr.Read())
                {
                    ARcboD2Code.Add(new Clsaddvalue(dr.GetString(1), dr.GetString(0)));
                }
                dr.Close();
                myconnection.Close();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
                myconnection.Close();
            }
        }

        public void ClsbuildCboSearchPA()
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = new SqlCommand("SELECT PA As PA1, AT FROM ViewPA ORDER by AT ", myconnection);
                dr = mycommand.ExecuteReader();

                while (dr.Read())
                {
                    ARcboSearchPA.Add(new Clsaddvalue(dr.GetString(1), dr.GetString(0)));
                }
                dr.Close();
                myconnection.Close();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
                myconnection.Close();
            }
        }

        public void ClsbuildCboSearchAN()
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = new SqlCommand("SELECT AcctNo As AcctNo1, AcctNo As AcctNo2 FROM tblTitleAcct ORDER by AcctNo ", myconnection);
                dr = mycommand.ExecuteReader();

                while (dr.Read())
                {
                    ARcboSearchAN.Add(new Clsaddvalue(dr.GetString(1), dr.GetString(0)));
                }
                dr.Close();
                myconnection.Close();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
                myconnection.Close();
            }
        }

        public void ClsBuildPA(bool bactnumber)
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                if (bactnumber == true)
                {
                    mycommand = new SqlCommand("SELECT PA, PA  +' - '+ AT FROM viewpa ORDER by PA ", myconnection);
                }
                else
                {
                    mycommand = new SqlCommand("SELECT PA, AT FROM viewpa ORDER by AT ", myconnection);
                }
                dr = mycommand.ExecuteReader();

                while (dr.Read())
                {
                    ARPA.Add(new Clsaddvalue(dr.GetString(1), dr.GetString(0)));
                }
                dr.Close();
                myconnection.Close();


            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
                myconnection.Close();
            }
        }

    }
}
