﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using CrystalDecisions.CrystalReports.Engine;
using System.Data.SqlClient;

namespace TCIGL
{
    public partial class frmrptIndLedger : Form
    {
        SqlConnection myconnection;
        SqlDataReader SqlDataReader1;
        SqlCommand mycommand;
        BindingSource dbind = new BindingSource();
        ClsBuildComboBox ClsBuildComboBox1 = new ClsBuildComboBox();
        ClsCompName ClsCompName1 = new ClsCompName();
        ClsPermission ClsPermission1 = new ClsPermission();
        ClsDefaultBranch ClsDefaultBranch1 = new ClsDefaultBranch();
        ClsGetSomething ClsGetSomething1 = new ClsGetSomething();
        ClsGetConnection ClsGetConnection1 = new ClsGetConnection(); 

        public frmrptIndLedger()
        {
            InitializeComponent();
            cbortprint.DisplayMember = "Text";
            cbortprint.ValueMember = "Value";
            cbortprint.SelectedValue= "02";
            var items = new[]
            { 
             new { Text = "Accounts Receivable - Ledger", Value = "01" },
             new { Text = "Accounts Receivable - Group Ledger", Value = "02" },
             new { Text = "Accounts Payable - Ledger", Value = "03" },
             new { Text = "Accounts Payable - Group Ledger", Value = "04" },
            };
            cbortprint.DataSource = items;
        }

    

        private void txtBeginDate_Leave(object sender, EventArgs e)
        {
            if (new ClsValidation().errordate(txtBeginDate.Text) == true)
            {
                MessageBox.Show("Invalid Date", "GL");
                txtBeginDate.Focus();
            }

        }

        private void txtEndDate_Leave(object sender, EventArgs e)
        {
            if (new ClsValidation().errordate(txtEndDate.Text) == true)
            {
                MessageBox.Show("Invalid Date", "GL");
                txtEndDate.Focus();
            }
        }

        private void btnPreview_Click(object sender, EventArgs e)
        {
            if (new ClsValidation().emptytxt (cbortprint.Text))
            {
                MessageBox.Show("Please complete your entry", "GL");
                cbortprint.Focus();
            }
            else if (txtBeginDate.Text=="  /  /")
            {
                MessageBox.Show("Please complete your entry", "GL");
                txtBeginDate.Focus();
            }
            else if (txtEndDate.Text == "  /  /")
            {
                MessageBox.Show("Please complete your entry", "GL");
                txtEndDate.Focus();
            }
            else if (Convert.ToDateTime(txtBeginDate.Text) > Convert.ToDateTime(txtEndDate.Text))
            {
                MessageBox.Show("Beginning date is greater than ending date");
                txtBeginDate.Focus();
            }
            else
            {
                if (cbortprint.SelectedValue.ToString() == "01")//Accounts Receivable - Ledger
                {
                    ARLedger();
                }
                else if (cbortprint.SelectedValue.ToString() == "02")//Accounts Receivable - Group Ledger
                {
                    ARLedgerGroup();
                }
                else if (cbortprint.SelectedValue.ToString() == "03")//Accounts Payable - Ledger
                {
                    APLedger();
                }
                else if (cbortprint.SelectedValue.ToString() == "04")//Accounts Payable - Group Ledger
                {
                    APLedgerGroup();
                }
            }
        }
                private void ARLedger()
                {

                    ClsGetConnection1.ClsGetConMSSQL();
                    myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                    myconnection.Open();
                    mycommand = new SqlCommand("usp_IndLedCust2", myconnection);
                    mycommand.CommandType = CommandType.StoredProcedure;

                    mycommand.Parameters.Add("@ParamControlNo1", SqlDbType.VarChar).Value = cboControlNo.SelectedValue.ToString();
                    mycommand.Parameters.Add("@Parambegindate1", SqlDbType.DateTime).Value = txtBeginDate.Text;
                    mycommand.Parameters.Add("@Paramenddate1", SqlDbType.DateTime).Value = txtEndDate.Text;
                    mycommand.Parameters.Add("@ParamUsageCode1", SqlDbType.VarChar).Value = "02";
                    mycommand.Parameters.Add("@ParamCNCode1", SqlDbType.VarChar).Value = cboCNCode.SelectedValue.ToString();

                    mycommand.CommandTimeout = 900;
                    SqlDataReader1 = mycommand.ExecuteReader();
                    DataTable DataTable1 = new DataTable();
                    DataTable1.Load(SqlDataReader1);
                    myconnection.Close();

                    if (DataTable1.Rows.Count == 0)
                    {
                        MessageBox.Show("No data found", "GL");
                        return;
                    }

                    CRIndLedgerCust objRpt = new CRIndLedgerCust();
                    TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
                    ClsCompName1.ClsCompNameMain();
                    vartxtcompany.Text = ClsCompName1.varcn;

                    ClsCompName1.ClsCompNamebranchAddress(cboCNCode.SelectedValue.ToString());
                    TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
                    vartxtaddress.Text = ClsCompName1.plsCRaddress;

                    TextObject varTextReportTitle = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["TextReportTitle"];
                    varTextReportTitle.Text = cbortprint.Text;

                    TextObject varrptAcctTitle = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rptAcctTitle"];
                    varrptAcctTitle.Text = cboControlNo.Text;

                    TextObject varrpttoenterdate = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rptrangedate"];
                    varrpttoenterdate.Text = "From " + txtBeginDate.Text + " To " + txtEndDate.Text;

                    objRpt.SetDataSource(DataTable1);
                    crystalReportViewer1.ReportSource = objRpt;
                    crystalReportViewer1.Refresh();
                }

                private void ARLedgerGroup()
                {

                    ClsGetConnection1.ClsGetConMSSQL();
                    myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                    myconnection.Open();
                    mycommand = new SqlCommand("usp_IndLedCust2", myconnection);
                    mycommand.CommandType = CommandType.StoredProcedure;

                    mycommand.Parameters.Add("@ParamControlNo1", SqlDbType.VarChar).Value = cboControlNo.SelectedValue;
                    mycommand.Parameters.Add("@Parambegindate1", SqlDbType.DateTime).Value = txtBeginDate.Text;
                    mycommand.Parameters.Add("@Paramenddate1", SqlDbType.DateTime).Value = txtEndDate.Text;
                    mycommand.Parameters.Add("@ParamUsageCode1", SqlDbType.VarChar).Value = "02";
                    mycommand.Parameters.Add("@ParamCNCode1", SqlDbType.VarChar).Value = cboCNCode.SelectedValue.ToString();

                    mycommand.CommandTimeout = 900;
                    SqlDataReader1 = mycommand.ExecuteReader();
                    DataTable DataTable1 = new DataTable();
                    DataTable1.Load(SqlDataReader1);
                    myconnection.Close();

                    if (DataTable1.Rows.Count == 0)
                    {
                        MessageBox.Show("No data found", "GL");
                        return;
                    }

                    CRIndLedgerCustGroup objRpt = new CRIndLedgerCustGroup();
                    TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
                    ClsCompName1.ClsCompNameMain();
                    vartxtcompany.Text = ClsCompName1.varcn;

                    ClsCompName1.ClsCompNamebranchAddress(cboCNCode.SelectedValue.ToString());
                    TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
                    vartxtaddress.Text = ClsCompName1.plsCRaddress;

                    TextObject varTextReportTitle = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["TextReportTitle"];
                    varTextReportTitle.Text = cbortprint.Text;

                    TextObject varrptAcctTitle = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rptAcctTitle"];
                    varrptAcctTitle.Text = cboControlNo.Text;

                    TextObject varrpttoenterdate = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rptrangedate"];
                    varrpttoenterdate.Text = "From " + txtBeginDate.Text + " To " + txtEndDate.Text;

                    objRpt.SetDataSource(DataTable1);
                    crystalReportViewer1.ReportSource = objRpt;
                    crystalReportViewer1.Refresh();
                }

                private void APLedger()
                {
                    ClsGetConnection1.ClsGetConMSSQL();
                    myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                    myconnection.Open();
                    mycommand = new SqlCommand("usp_IndLedCust2", myconnection);
                    mycommand.CommandType = CommandType.StoredProcedure;

                    mycommand.Parameters.Add("@ParamControlNo1", SqlDbType.VarChar).Value = cboControlNo.SelectedValue.ToString();
                    mycommand.Parameters.Add("@Parambegindate1", SqlDbType.DateTime).Value = txtBeginDate.Text;
                    mycommand.Parameters.Add("@Paramenddate1", SqlDbType.DateTime).Value = txtEndDate.Text;
                    mycommand.Parameters.Add("@ParamUsageCode1", SqlDbType.VarChar).Value = "03";
                    mycommand.Parameters.Add("@ParamCNCode1", SqlDbType.VarChar).Value = cboCNCode.SelectedValue.ToString();

                    mycommand.CommandTimeout = 900;
                    SqlDataReader1 = mycommand.ExecuteReader();
                    DataTable DataTable1 = new DataTable();
                    DataTable1.Load(SqlDataReader1);
                    myconnection.Close();

                    if (DataTable1.Rows.Count == 0)
                    {
                        MessageBox.Show("No data found", "GL");
                        return;
                    }

                    CRIndLedgerCust objRpt = new CRIndLedgerCust();
                    TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
                    ClsCompName1.ClsCompNameMain();
                    vartxtcompany.Text = ClsCompName1.varcn;

                    ClsCompName1.ClsCompNamebranchAddress(cboCNCode.SelectedValue.ToString());
                    TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
                    vartxtaddress.Text = ClsCompName1.plsCRaddress;

                    TextObject varTextReportTitle = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["TextReportTitle"];
                    varTextReportTitle.Text = cbortprint.Text;

                    TextObject varrptAcctTitle = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rptAcctTitle"];
                    varrptAcctTitle.Text = cboControlNo.Text;

                    TextObject varrpttoenterdate = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rptrangedate"];
                    varrpttoenterdate.Text = "From " + txtBeginDate.Text + " To " + txtEndDate.Text;

                    objRpt.SetDataSource(DataTable1);
                    crystalReportViewer1.ReportSource = objRpt;
                    crystalReportViewer1.Refresh();
                }

                private void APLedgerGroup()
                {

                    ClsGetConnection1.ClsGetConMSSQL();
                    myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                    myconnection.Open();
                    mycommand = new SqlCommand("usp_IndLedCust2", myconnection);
                    mycommand.CommandType = CommandType.StoredProcedure;

                    mycommand.Parameters.Add("@ParamControlNo1", SqlDbType.VarChar).Value = cboControlNo.SelectedValue;
                    mycommand.Parameters.Add("@Parambegindate1", SqlDbType.DateTime).Value = txtBeginDate.Text;
                    mycommand.Parameters.Add("@Paramenddate1", SqlDbType.DateTime).Value = txtEndDate.Text;
                    mycommand.Parameters.Add("@ParamUsageCode1", SqlDbType.VarChar).Value = "03";
                    mycommand.Parameters.Add("@ParamCNCode1", SqlDbType.VarChar).Value = cboCNCode.SelectedValue.ToString();

                    mycommand.CommandTimeout = 900;
                    SqlDataReader1 = mycommand.ExecuteReader();
                    DataTable DataTable1 = new DataTable();
                    DataTable1.Load(SqlDataReader1);
                    myconnection.Close();

                    if (DataTable1.Rows.Count == 0)
                    {
                        MessageBox.Show("No data found", "GL");
                        return;
                    }

                    CRIndLedgerCustGroup objRpt = new CRIndLedgerCustGroup();
                    TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
                    ClsCompName1.ClsCompNameMain();
                    vartxtcompany.Text = ClsCompName1.varcn;

                    ClsCompName1.ClsCompNamebranchAddress(cboCNCode.SelectedValue.ToString());
                    TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
                    vartxtaddress.Text = ClsCompName1.plsCRaddress;

                    TextObject varTextReportTitle = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["TextReportTitle"];
                    varTextReportTitle.Text = cbortprint.Text;

                    TextObject varrptAcctTitle = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rptAcctTitle"];
                    varrptAcctTitle.Text = cboControlNo.Text;

                    TextObject varrpttoenterdate = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rptrangedate"];
                    varrpttoenterdate.Text = "From " + txtBeginDate.Text + " To " + txtEndDate.Text;

                    objRpt.SetDataSource(DataTable1);
                    crystalReportViewer1.ReportSource = objRpt;
                    crystalReportViewer1.Refresh();
                }

                private void frmrptIndLedger_Load(object sender, EventArgs e)
                {
                    ClsPermission1.ClsObjects(this.Text);
                    if (new ClsValidation().emptytxt(ClsPermission1.plstxtObject))
                    {
                        MessageBox.Show("You do not have necessary permission to open this file", "GL");
                        this.Close();
                    }
                    else
                    {
                        buildcboCNCode();
                        cboCNCode.SelectedValue = (ClsDefaultBranch1.plsvardb);
                        ClsGetSomething1.ClsGetDefaultDate();
                        txtBeginDate.Text = ClsGetSomething1.plsdefdate;
                        txtEndDate.Text = ClsGetSomething1.plsdefdate;
                        this.WindowState = FormWindowState.Maximized;
                        buildcboControlNo();
                    }
                }
       private void buildcboControlNo()

                {
                    cboControlNo.DataSource = null;
                    ClsBuildComboBox1.ARPCNStatement.Clear();
                    ClsBuildComboBox1.ClsBuildCustControlnoStatement(cboCNCode.SelectedValue.ToString());
                    this.cboControlNo.DataSource = (ClsBuildComboBox1.ARPCNStatement);
                    this.cboControlNo.DisplayMember = "Display";
                    this.cboControlNo.ValueMember = "Value";
               }

        private void buildcboCNCode()
        {
            cboCNCode.DataSource = null;
            ClsBuildComboBox1.ARBranch.Clear();
            ClsBuildComboBox1.ClsBuildBranch();
            this.cboCNCode.DataSource = (ClsBuildComboBox1.ARBranch);
            this.cboCNCode.DisplayMember = "Display";
            this.cboCNCode.ValueMember = "Value";
        }
    

        private void cboControlNo_Validating(object sender, CancelEventArgs e)
        {
                if (new ClsValidation().emptytxt(cboControlNo.Text))
                {
                }
                else if (cboControlNo.Text != null && cboControlNo.SelectedValue == null)
                {
                    MessageBox.Show("Not found");
                    cboControlNo.Focus();
                }
        }

        private void cboCNCode_Validating(object sender, CancelEventArgs e)
        {
            if (new ClsValidation().emptytxt(cboCNCode.Text))
            {
            }
            else if (cboCNCode.Text != null && cboCNCode.SelectedValue == null)
            {
                MessageBox.Show("Not found", "GL");
                cboCNCode.Focus();
            }
           
        }

        private void cboCNCode_SelectionChangeCommitted(object sender, EventArgs e)
        {
            buildcboControlNo();
        }

        private void nextfieldenter1(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.Equals(Keys.Enter))
            {
                SendKeys.Send("{TAB}");
            }
            else if ((e.KeyCode.Equals(Keys.Up)) || (e.KeyCode.Equals(Keys.Left)))
            {
                SendKeys.Send("+{TAB}");
            }
            else if ((e.KeyCode.Equals(Keys.Down)) || (e.KeyCode.Equals(Keys.Right)))
            {
                SendKeys.Send("{TAB}");
            }

        }

        private void nextfieldenter2(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.Equals(Keys.Enter))
            {
                SendKeys.Send("{TAB}");
            }

        }
    }
}
