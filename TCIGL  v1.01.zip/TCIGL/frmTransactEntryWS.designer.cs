﻿namespace TCIGL
{
    partial class frmTransactEntryWS
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label17 = new System.Windows.Forms.Label();
            this.cboStockNumber = new System.Windows.Forms.ComboBox();
            this.label22 = new System.Windows.Forms.Label();
            this.txtQty = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.txtBalance = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.txtUPCS = new System.Windows.Forms.TextBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.cbIn = new System.Windows.Forms.CheckBox();
            this.cbProductCode = new System.Windows.Forms.CheckBox();
            this.txtNum = new System.Windows.Forms.TextBox();
            this.txtVoucher = new System.Windows.Forms.TextBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(9, 22);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(151, 15);
            this.label17.TabIndex = 127;
            this.label17.Text = "PRODUCT DESCRIPTION:";
            // 
            // cboStockNumber
            // 
            this.cboStockNumber.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cboStockNumber.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cboStockNumber.DropDownWidth = 338;
            this.cboStockNumber.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboStockNumber.FormattingEnabled = true;
            this.cboStockNumber.Location = new System.Drawing.Point(12, 40);
            this.cboStockNumber.Name = "cboStockNumber";
            this.cboStockNumber.Size = new System.Drawing.Size(310, 23);
            this.cboStockNumber.TabIndex = 0;
            this.cboStockNumber.KeyDown += new System.Windows.Forms.KeyEventHandler(this.nextfieldenter2);
            this.cboStockNumber.Validating += new System.ComponentModel.CancelEventHandler(this.cboStockNumber_Validating);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(12, 71);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(34, 15);
            this.label22.TabIndex = 136;
            this.label22.Text = "QTY:";
            // 
            // txtQty
            // 
            this.txtQty.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQty.Location = new System.Drawing.Point(12, 89);
            this.txtQty.Name = "txtQty";
            this.txtQty.Size = new System.Drawing.Size(72, 22);
            this.txtQty.TabIndex = 1;
            this.txtQty.Text = "0.00";
            this.txtQty.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtQty.KeyDown += new System.Windows.Forms.KeyEventHandler(this.nextfieldenter1);
            this.txtQty.Validating += new System.ComponentModel.CancelEventHandler(this.txtQty_Validating);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(247, 71);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(49, 15);
            this.label29.TabIndex = 161;
            this.label29.Text = "Balance";
            // 
            // txtBalance
            // 
            this.txtBalance.Enabled = false;
            this.txtBalance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBalance.Location = new System.Drawing.Point(250, 89);
            this.txtBalance.Name = "txtBalance";
            this.txtBalance.Size = new System.Drawing.Size(72, 22);
            this.txtBalance.TabIndex = 154;
            this.txtBalance.Text = "0.00";
            this.txtBalance.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(128, 71);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(61, 15);
            this.label25.TabIndex = 158;
            this.label25.Text = "Unit Cost:";
            // 
            // txtUPCS
            // 
            this.txtUPCS.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUPCS.Location = new System.Drawing.Point(131, 89);
            this.txtUPCS.Name = "txtUPCS";
            this.txtUPCS.Size = new System.Drawing.Size(72, 22);
            this.txtUPCS.TabIndex = 151;
            this.txtUPCS.Text = "0.00";
            this.txtUPCS.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtUPCS.KeyDown += new System.Windows.Forms.KeyEventHandler(this.nextfieldenter1);
            this.txtUPCS.Validating += new System.ComponentModel.CancelEventHandler(this.txtUPCS_Validating);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(210, 130);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(52, 23);
            this.btnSave.TabIndex = 172;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(270, 130);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(52, 23);
            this.btnClose.TabIndex = 173;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // cbIn
            // 
            this.cbIn.AutoSize = true;
            this.cbIn.Enabled = false;
            this.cbIn.Location = new System.Drawing.Point(12, 123);
            this.cbIn.Name = "cbIn";
            this.cbIn.Size = new System.Drawing.Size(77, 17);
            this.cbIn.TabIndex = 181;
            this.cbIn.Text = "Quantity In";
            this.cbIn.UseVisualStyleBackColor = true;
            // 
            // cbProductCode
            // 
            this.cbProductCode.AutoSize = true;
            this.cbProductCode.Checked = true;
            this.cbProductCode.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbProductCode.Location = new System.Drawing.Point(12, 144);
            this.cbProductCode.Name = "cbProductCode";
            this.cbProductCode.Size = new System.Drawing.Size(91, 17);
            this.cbProductCode.TabIndex = 190;
            this.cbProductCode.Text = "Product Code";
            this.cbProductCode.UseVisualStyleBackColor = true;
            this.cbProductCode.CheckedChanged += new System.EventHandler(this.cbProductCode_CheckedChanged);
            // 
            // txtNum
            // 
            this.txtNum.Location = new System.Drawing.Point(279, 12);
            this.txtNum.Name = "txtNum";
            this.txtNum.Size = new System.Drawing.Size(48, 20);
            this.txtNum.TabIndex = 191;
            this.txtNum.Visible = false;
            // 
            // txtVoucher
            // 
            this.txtVoucher.Location = new System.Drawing.Point(191, 12);
            this.txtVoucher.Name = "txtVoucher";
            this.txtVoucher.Size = new System.Drawing.Size(48, 20);
            this.txtVoucher.TabIndex = 192;
            this.txtVoucher.Visible = false;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 2000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // frmTransactEntryWS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(339, 173);
            this.ControlBox = false;
            this.Controls.Add(this.txtVoucher);
            this.Controls.Add(this.txtNum);
            this.Controls.Add(this.cbProductCode);
            this.Controls.Add(this.cbIn);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.txtBalance);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.txtUPCS);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.txtQty);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.cboStockNumber);
            this.KeyPreview = true;
            this.Name = "frmTransactEntryWS";
            this.Text = "Entry";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.frmSalesEntry_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frmSalesEntry_KeyDown);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ComboBox cboStockNumber;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtQty;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox txtBalance;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox txtUPCS;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.CheckBox cbIn;
        private System.Windows.Forms.CheckBox cbProductCode;
        private System.Windows.Forms.TextBox txtNum;
        private System.Windows.Forms.TextBox txtVoucher;
        private System.Windows.Forms.Timer timer1;
    }
}