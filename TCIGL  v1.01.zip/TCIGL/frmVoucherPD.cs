﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Threading;
using CrystalDecisions.CrystalReports.Engine;

namespace TCIGL
{
    public partial class frmVoucherPD : Form
    {
        string varoutdate = "No";
        public static DataGridView glbldgv2;
        SqlConnection myconnection;
        SqlCommand mycommand;
        SqlCommand mycommanddgv2;
        SqlCommand mycommanddgv3;
        SqlDataReader SqlDataReader1; 
        ClsAutoNumber ClsAutoNumber1 = new ClsAutoNumber();
        ClsBuildComboBox ClsBuildComboBox1 = new ClsBuildComboBox();
        ClsValidation ClsValidation1 = new ClsValidation();
        ClsGetSomething ClsGetSomething1 = new ClsGetSomething();
        ClsPermission ClsPermission1 = new ClsPermission();
        ClsBuildEntryComboBox ClsBuildEntryComboBox1 = new ClsBuildEntryComboBox();
        ClsGetConnection ClsGetConnection1 = new ClsGetConnection();
        ClsDefaultBranch ClsDefaultBranch1 = new ClsDefaultBranch();
        ClsCompName ClsCompName1 = new ClsCompName();
        ClsGetSomethingEntry ClsGetSomethingEntry1 = new ClsGetSomethingEntry();

        //string dgvdata = null;
        public static TextBox glblSPO;
        public static TextBox glbltxtTotDisct, glbltxtTotalVAT, glbltxtTotCost, glbltxtTotPayables;
        public static ComboBox glblcboWHCode;
        public static MaskedTextBox glbltxtTDate;
        public static ComboBox glblcboControlNo, glblProjectCode;
        public static TextBox glbltxtreference, glbltxtTerm, glbltxtRemarks, glbltxtPONumber;
        public static Button glblbtnSave;
        string pristrIC, pristrRowNum;
        private string pristrRMInvTotal = "0";
        private string pristrFSInvTotal = "0";
        private string pristrOSInvTotal = "0";
        ClsGetSomethingOthers ClsGetSomethingOthers1 = new ClsGetSomethingOthers();
        int varintTableDoor = 0;
        int number = 0;
        private string privarstrVoidIC = null;
        public frmVoucherPD()
        {
            InitializeComponent();
            {
                ClsGetSomethingOthers1.ClsGetVoidRef("PD", "1");
                privarstrVoidIC = ClsGetSomethingOthers1.plsVoidIC;
                if (new ClsValidation().emptytxt(privarstrVoidIC))
                { }
                else
                {
                    ClsGetSomethingOthers1.ClsDeleteErrorTransaction("PD", "1");
                }
            }
        }


        private void buildcboCustCode()
        {
            cboControlNo.DataSource = null;
            ClsBuildComboBox1.ARPDCN.Clear();
            ClsBuildComboBox1.ClsBuildPDControlNo();
            this.cboControlNo.DataSource = (ClsBuildComboBox1.ARPDCN);
            this.cboControlNo.DisplayMember = "Display";
            this.cboControlNo.ValueMember = "Value";
        }

        private void buildcboAcctTile()
        {
            cboAcctTitle.DataSource = null;
            ClsBuildComboBox1.ARPA.Clear();
            ClsBuildComboBox1.ClsBuildPA();
            this.cboAcctTitle.DataSource = (ClsBuildComboBox1.ARPA);
            this.cboAcctTitle.DisplayMember = "Display";
            this.cboAcctTitle.ValueMember = "Value";
        }

        private void buildcboWHCode()
        {
            cboWHCode.DataSource = null;
            ClsBuildEntryComboBox1.ARWHCode.Clear();
            ClsBuildEntryComboBox1.ClsBuildWHCode();
            this.cboWHCode.DataSource = (ClsBuildEntryComboBox1.ARWHCode);
            this.cboWHCode.DisplayMember = "Display";
            this.cboWHCode.ValueMember = "Value";
            //this.cboWHCode.DropDownWidth = 450;
        }


        private void getAcctEntry()
        {
            string vartotalPayables = (double.Parse(txtTotalVAT.Text) + double.Parse(txtTotCost.Text)).ToString("N2");
            string vartotalRMInv = double.Parse(pristrRMInvTotal).ToString("N2");
            string vartotalFSInv = double.Parse(pristrFSInvTotal).ToString("N2");
            string vartotalOSInv = double.Parse(pristrOSInvTotal).ToString("N2");

            string vartotalVAT = double.Parse(txtTotalVAT.Text).ToString("N2");

           

            //Raw Material Inventory
            if (double.Parse(pristrRMInvTotal) != 0)
            {
                ClsGetSomething1.ClsGetAT("14000000000");
                dgv1.Rows.Add("14000000000", ClsGetSomething1.plsAT, txtreference.Text, vartotalRMInv, "0.00", 0);
            }

            //Factory Supply Inventory
            if (double.Parse(pristrFSInvTotal) != 0)
            {
                ClsGetSomething1.ClsGetAT("14500000000");
                dgv1.Rows.Add("14500000000", ClsGetSomething1.plsAT, txtreference.Text, vartotalFSInv, "0.00", 0);
            }

            //Office Supplies Inventory
            if (double.Parse(pristrOSInvTotal) != 0)
            {
                ClsGetSomething1.ClsGetAT("14800000000");
                dgv1.Rows.Add("14800000000", ClsGetSomething1.plsAT, txtreference.Text, vartotalOSInv, "0.00", 0);
            }

            //VAT - Input
            if (double.Parse(vartotalVAT) != 0)
            {
                ClsGetSomething1.ClsGetAT("25000000000");
                dgv1.Rows.Add("25000000000", ClsGetSomething1.plsAT, txtreference.Text, vartotalVAT, "0.00", 0);
            }
            //Payables
            ClsGetSomething1.ClsGetAT("30000000000");
            dgv1.Rows.Add("30000000000", ClsGetSomething1.plsAT, txtreference.Text, "0.00", vartotalPayables, 0);
            dgv1total();
        }

        private void SaveTransact()
        {
            try
            {
                DateTime DT = DateTime.Now;
                string sqlstatement;
                string sqlstatementdgv2;

                sqlstatement = "INSERT INTO tblmain1 (IC, DocNum, Voucher, UserCode, ControlNo, TDate, Reference, Term, Remarks, CheckNo, CAmount, ASMCode, DE, CNCode, PONumber)";
                sqlstatement += " Values (@_IC, @_DocNum, @_Voucher, @_UserCode, @_ControlNo, @_TDate, @_Reference, @_Term, @_Remarks, @_CheckNo, @_CAmount, @_ASMCode, @_DE, @_CNCode, @_PONumber)";
                sqlstatementdgv2 = "INSERT INTO tblmain2 (IC, StockNumber,  PIn, POut, UP, Cost, ActDisct, PDisct, VAT, RowNum, D1, D2, D3, WHCode)";
                sqlstatementdgv2 += "Values (@_IC, @_StockNumber, @_PIn, @_POut, @_UP, @_Cost, @_ActDisct, @_PDisct, @_VAT, @_RowNum, @_D1, @_D2, @_D3, @_WHCode)";
                string sqlstatementdgv3 = "INSERT INTO tblmain3 (IC, Refer, Debit, Credit, PA, SIT) Values (@_IC, @_Refer, @_Debit, @_Credit, @_PA, @_SIT)";

                ClsAutoNumber1.VoucherAutoNum("PD");
                txtDocNum.Text = (ClsAutoNumber1.plsnumber);

                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();

                mycommand = new SqlCommand(sqlstatement, myconnection);
                mycommand.Parameters.Add("_IC", SqlDbType.VarChar).Value = "PD" + Form1.glbluc.Text + (ClsDefaultBranch1.plsvardb);
                mycommand.Parameters.Add("_DocNum", SqlDbType.VarChar).Value = Form1.glbluc.Text;
                mycommand.Parameters.Add("_Voucher", SqlDbType.VarChar).Value = "PD";
                mycommand.Parameters.Add("_UserCode", SqlDbType.VarChar).Value = Form1.glbluc.Text;
                mycommand.Parameters.Add("_ControlNo", SqlDbType.VarChar).Value = cboControlNo.SelectedValue;
                mycommand.Parameters.Add("_TDate", SqlDbType.Date).Value = txtTDate.Text;
                mycommand.Parameters.Add("_Reference", SqlDbType.VarChar).Value = txtreference.Text;
                mycommand.Parameters.Add("_Term", SqlDbType.Int).Value = txtTerm.Text;
                mycommand.Parameters.Add("_Remarks", SqlDbType.VarChar).Value = txtRemarks.Text;
                mycommand.Parameters.Add("_CheckNo", SqlDbType.VarChar).Value = "NA";
                mycommand.Parameters.Add("_CAmount", SqlDbType.Money).Value = 0;
                mycommand.Parameters.Add("_ASMCode", SqlDbType.VarChar).Value = "001";
                mycommand.Parameters.Add("_DE", SqlDbType.Date).Value = DT;
                mycommand.Parameters.Add("_CNCode", SqlDbType.Char).Value = (ClsDefaultBranch1.plsvardb);
                mycommand.Parameters.Add("_PONumber", SqlDbType.VarChar).Value = txtPONumber.Text;
                int n1 = mycommand.ExecuteNonQuery();

                DataGridViewRow row1 = null;
                for (int x = 0; x < dgv2.Rows.Count; x++)
                {
                    row1 = dgv2.Rows[x];
                    mycommanddgv2 = new SqlCommand(sqlstatementdgv2, myconnection);
                    mycommanddgv2.Parameters.Add("_IC", SqlDbType.VarChar).Value = "PD" + Form1.glbluc.Text + (ClsDefaultBranch1.plsvardb);
                    mycommanddgv2.Parameters.Add("_StockNumber", SqlDbType.VarChar).Value = row1.Cells[1].Value;
                    mycommanddgv2.Parameters.Add("_PIn", SqlDbType.Decimal).Value = row1.Cells[3].Value;
                    mycommanddgv2.Parameters.Add("_POut", SqlDbType.Decimal).Value = "0";
                    mycommanddgv2.Parameters.Add("_UP", SqlDbType.Decimal).Value = row1.Cells[4].Value;
                    mycommanddgv2.Parameters.Add("_Cost", SqlDbType.Decimal).Value = row1.Cells[9].Value;
                    mycommanddgv2.Parameters.Add("_ActDisct", SqlDbType.Decimal).Value = row1.Cells[5].Value;
                    mycommanddgv2.Parameters.Add("_PDisct", SqlDbType.Decimal).Value = row1.Cells[6].Value;
                    mycommanddgv2.Parameters.Add("_VAT", SqlDbType.Decimal).Value = row1.Cells[7].Value;
                    mycommanddgv2.Parameters.Add("_RowNum", SqlDbType.Int).Value = (Convert.ToInt32(x) + 1).ToString();
                    mycommanddgv2.Parameters.Add("_D1", SqlDbType.Decimal).Value = row1.Cells[0].Value;
                    mycommanddgv2.Parameters.Add("_D2", SqlDbType.Decimal).Value = "0";
                    mycommanddgv2.Parameters.Add("_D3", SqlDbType.Decimal).Value = "0";
                    mycommanddgv2.Parameters.Add("_WHCode", SqlDbType.VarChar).Value = cboWHCode.SelectedValue.ToString();
                    int n2 = mycommanddgv2.ExecuteNonQuery();
                }

                DataGridViewRow row = null;
                for (int x = 0; x < dgv1.Rows.Count; x++)
                {
                    row = dgv1.Rows[x];
                    mycommand = new SqlCommand(sqlstatementdgv3, myconnection);
                    mycommand.Parameters.Add("_IC", SqlDbType.VarChar).Value = "PD" + Form1.glbluc.Text + (ClsDefaultBranch1.plsvardb);
                    mycommand.Parameters.Add("_PA", SqlDbType.VarChar).Value = row.Cells[0].Value;
                    mycommand.Parameters.Add("_Refer", SqlDbType.VarChar).Value = row.Cells[2].Value;
                    mycommand.Parameters.Add("_Debit", SqlDbType.Decimal).Value = row.Cells[3].Value;
                    mycommand.Parameters.Add("_Credit", SqlDbType.Decimal).Value = row.Cells[4].Value;
                    mycommand.Parameters.Add("_SIT", SqlDbType.VarChar).Value = row.Cells[5].Value;
                    int n3 = mycommand.ExecuteNonQuery();
                }

                DataGridViewRow row2 = null;
                for (int x = 0; x < dgv2.Rows.Count; x++)
                {
                    row2 = dgv2.Rows[x];
                    double varin = double.Parse(dgv2.Rows[x].Cells[3].Value.ToString());
                    double varTCost = double.Parse(dgv2.Rows[x].Cells[9].Value.ToString());
                    double varTVAT = double.Parse(dgv2.Rows[x].Cells[7].Value.ToString());
                    ClsGetSomething1.ClsGetProductDetails(dgv2.Rows[x].Cells[1].Value.ToString());
                    ClsGetSomething1.ClsPDUCost(varTCost, varTVAT, varin);
                    string varlc = ClsGetSomething1.plsUCost;
                    string varvc = ClsGetSomething1.plsUVAT;
                    string sqlstatementupdate = "UPDATE tblStocks set UCost=@_UCost, VC=@_VC  WHERE StockNumber ='" + row2.Cells[1].FormattedValue.ToString() + "'";
                    mycommanddgv3 = new SqlCommand(sqlstatementupdate, myconnection);
                    mycommanddgv3.Parameters.Add("_UCost", SqlDbType.Money).Value = varlc;
                    mycommanddgv3.Parameters.Add("_VC", SqlDbType.Money).Value = varvc;
                    int n4 = mycommanddgv3.ExecuteNonQuery();
                }

                if (new ClsValidation().NotEmptytxt(txtPONumber.Text))
                {
                    DataGridViewRow row3 = null;
                    for (int x = 0; x < dgv2.Rows.Count; x++)
                    {
                        row3 = dgv2.Rows[x];
                        string strRemainQty = row3.Cells[14].Value.ToString();
                        pristrIC = row3.Cells[15].FormattedValue.ToString();
                        pristrRowNum = row3.Cells[17].FormattedValue.ToString();
                        string sqlstatementupdate2 = "UPDATE tblPO2 SET Rqty=@_Rqty WHERE IC ='" + pristrIC + "' AND RowNum = '" + pristrRowNum + "'";
                        mycommand = new SqlCommand(sqlstatementupdate2, myconnection);
                        mycommand.Parameters.Add("_Rqty", SqlDbType.Money).Value = strRemainQty;
                        int n5 = mycommand.ExecuteNonQuery();
                    }
                }
                myconnection.Close();
                ClsGetSomethingOthers1.ClsFinalize("PD", txtDocNum.Text, "1");

                if (cbSP.Checked)
                {
                    int varnocopy = int.Parse(frmMain.glbltxtNoCopy.Text);
                    for (int i = 1; i <= varnocopy; i++)
                    {
                        printcurvoucher();
                    }
                }


                ClsAutoNumber1.VoucherAutoNum("PD");
                txtDocNum.Text = (ClsAutoNumber1.plsnumber);
                clearscreen();
                dgv1.Rows.Clear();
            }
            catch
            {
                MessageBox.Show("Error, please click OK", "GL");
                this.Close();
            }
            finally
            {
                myconnection.Close();
            }
        }

        private void clearscreen()
        {
            dgv2.Rows.Clear();
            txtreference.Text = "";
            cboControlNo.Text = "";
            // txtCheckNo.Text = "NA";
            //  txtCAmount.Text = "0.00";
            //cboPC.Text = "";
            txtRemarks.Text = "Purchases";
            txtTDate.Focus();
            txtTotalVAT.Text = "0.00";
            txtTotCost.Text = "0.00";
            txtTotDisct.Text = "0.00";
            txtTotPayables.Text = "0.00";
            txtTerm.Text = "0";
            pristrRMInvTotal = "0";
            pristrFSInvTotal = "0";
            pristrOSInvTotal = "0";
            //dgvdata = null;
            txtPONumber.Clear();
        }

        private void printcurvoucher()
        {
            string sqlstatement = "SELECT * FROM ViewDetailsBookPD WHERE DocNum ='" + txtDocNum.Text + "' AND CNCode = '" + ClsDefaultBranch1.plsvardb + "' ORDER BY RowNum";

            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();
            mycommand = myconnection.CreateCommand();
            mycommand.CommandText = sqlstatement;
            mycommand.CommandTimeout = 900;
            SqlDataReader1 = mycommand.ExecuteReader();
            DataTable DataTable1 = new DataTable();
            DataTable1.Load(SqlDataReader1);
            myconnection.Close();

            if (DataTable1.Rows.Count == 0)
            {
                MessageBox.Show("No data found", "GL");
                return;
            }

            CRprevPD objRpt = new CRprevPD();
            TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            ClsCompName1.ClsCompNameMain();
            vartxtcompany.Text = ClsCompName1.varcn;

            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            ClsCompName1.ClsCompNamebranchAddress(ClsDefaultBranch1.plsvardb);
            vartxtaddress.Text = (ClsCompName1.plsCRaddress);

            objRpt.SetDataSource(DataTable1);
            System.Drawing.Printing.PrintDocument doctoprint = new System.Drawing.Printing.PrintDocument();
            int rawKind = 0;
            for (int i = 0; i <= doctoprint.PrinterSettings.PaperSizes.Count - 1; i++)
            {
                if (doctoprint.PrinterSettings.PaperSizes[i].PaperName == "C1-HalfShort")
                {
                    rawKind = Convert.ToInt32(doctoprint.PrinterSettings.PaperSizes[i].GetType().GetField("kind",
                    System.Reflection.BindingFlags.Instance |
                    System.Reflection.BindingFlags.NonPublic).GetValue(doctoprint.PrinterSettings.PaperSizes[i]));
                    break; // TODO: might not be correct. Was : Exit For
                }
            }
            objRpt.PrintOptions.PaperSize = (CrystalDecisions.Shared.PaperSize)rawKind;

            objRpt.Refresh();
            objRpt.PrintToPrinter(1, false, 0, 0);
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            dgv1.Rows.Clear();

            DataGridViewRow row1 = null;
            for (int x = 0; x < dgv2.Rows.Count; x++)
            {
                row1 = dgv2.Rows[x];
                ClsGetSomethingEntry1.ClsGetInvClassCode(row1.Cells[1].Value.ToString());
                string strInvClassCode = ClsGetSomethingEntry1.plsvarInvClassCode;
                row1.Cells[16].Value = ClsGetSomethingEntry1.plsvarInvClassCode;
            }
            dgv2totalActualEntry();
            getAcctEntry();

            if (new ClsValidation().DataExist("tblMain1", "Reference", txtreference.Text))

            {
                MessageBox.Show("Duplicate entry", "GL");
                txtreference.Focus();
            }

            else if ((txtTDate.Text == "  /  /"))
            {
                MessageBox.Show("Please complete your entry", "GL");
                txtTDate.Focus();
            }
            else if ((new ClsValidation().emptytxt(cboControlNo.Text)) || (new ClsValidation().emptytxt(txtreference.Text)) ||
                (new ClsValidation().emptytxt(txtRemarks.Text)))
            {
                MessageBox.Show("Please complete your entry", "GL");
                txtTDate.Focus();
            }
            else if (varoutdate == "Yes")
            {
                MessageBox.Show("Date is out of range", "GL");
                txtTDate.Focus();
            }
            else if (dgv2.Rows.Count == 0)

            {
                MessageBox.Show("Incomplete Record", "IS");
                txtTDate.Focus();
            }
            else if (Convert.ToDouble(txtDifference.Text) != 0)
            {
                dgv1.Rows.Clear();
                MessageBox.Show("Not balance", "GL");
                txtRemarks.Focus();
            }
            else
            {
                privarstrVoidIC = null;
                ClsGetSomethingOthers1.ClsGetTDoor("PD");
                varintTableDoor = int.Parse(ClsGetSomethingOthers1.plsTableDoor);
                number = 0;
                while (varintTableDoor == 1 && number <= 20)
                {
                    number = number + 1;
                    Thread.Sleep(200);
                    varintTableDoor = int.Parse(ClsGetSomethingOthers1.plsTableDoor);
                }

                if (varintTableDoor == 0 && number <= 20)
                {

                    ClsGetSomethingOthers1.ClsGetVoidRef("PD", "1");
                    privarstrVoidIC = ClsGetSomethingOthers1.plsVoidIC;
                    if (new ClsValidation().emptytxt(privarstrVoidIC))
                    {
                        ClsGetSomethingOthers1.ClsOneTheDoor("PD");
                        SaveTransact();
                        ClsGetSomethingOthers1.ClsZeroTheDoor("PD");
                    }
                    else
                    {
                        ClsGetSomethingOthers1.ClsDeleteErrorTransaction("PD", "1");
                        MessageBox.Show("Transaction not saved", "GL");
                    }
                }
                else if (varintTableDoor == 1 && number == 21)
                {
                    MessageBox.Show("Contact your adminnistrator", "GL");
                }
            }
        }

  

        private void cboCustCode_Validating(object sender, CancelEventArgs e)
        {
                if (new ClsValidation().emptytxt(cboControlNo.Text))
                {
                }
                else if (cboControlNo.Text != null && cboControlNo.SelectedValue == null)
                {
                    MessageBox.Show("Not found", "GL");
                    cboControlNo.Focus();
                }
                else
                {
                    ClsGetSomething1.ClsGetCustData(cboControlNo.SelectedValue.ToString());
                    txtTerm.Text = ClsGetSomething1.plsTerm;
                }
        }

        private void frmVoucherPD_Load(object sender, EventArgs e)
        {
            ClsPermission1.ClsObjects(this.Text);
            if (new ClsValidation().emptytxt(ClsPermission1.plstxtObject))
            {
                MessageBox.Show("You do not have necessary permission to open this file", "GL");
                this.Close();
            }
            else
            {
                ClsAutoNumber1.VoucherAutoNum("PD");
                txtDocNum.Text = (ClsAutoNumber1.plsnumber);
                ClsGetSomething1.ClsGetDefaultDate();
                txtTDate.Text = ClsGetSomething1.plsdefdate;
                buildcboWHCode();
                buildcboCustCode();
                buildcboAcctTile();
                cboAcctTitle.SelectedValue = "30000000000";

                glbldgv2 = dgv2;
                glbltxtTotDisct=txtTotDisct;
                glbltxtTotalVAT=txtTotalVAT;
                glbltxtTotCost=txtTotCost;
                glblcboWHCode = cboWHCode;
                glbltxtTotDisct = txtTotDisct;
                glbltxtTotalVAT = txtTotalVAT;
                glbltxtTotCost = txtTotCost;
                glblcboWHCode = cboWHCode;
                glbltxtTDate = txtTDate;
                glblcboControlNo = cboControlNo;
                glbltxtreference = txtreference;
                glbltxtTerm = txtTerm;
                glbltxtRemarks = txtRemarks;
                glbltxtPONumber = txtPONumber;
                glbltxtTotPayables = txtTotPayables;
                glblbtnSave = btnSave;
    
                //  cboCustCode.Text = "";
                privarstrVoidIC = null;
                ClsGetSomethingOthers1.ClsGetVoidRef("PD", "1");
                privarstrVoidIC = ClsGetSomethingOthers1.plsVoidIC;
                if (new ClsValidation().emptytxt(privarstrVoidIC))
                { }
                else
                {
                    ClsGetSomethingOthers1.ClsDeleteErrorTransaction("PD", "1");
                    privarstrVoidIC = null;
                }
            }
        }

       

       

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
            frmTransactEntryPD frmTransactEntryPD1 = new frmTransactEntryPD();
            frmTransactEntryPD1.Close();
        }

        private void btnPE_Click(object sender, EventArgs e)
        {
            frmTransactEntryPD frmEntryPD1 = new frmTransactEntryPD();
            frmEntryPD1.Show();
            frmTransactEntryPD.glbltxtVoucher.Text = "PD";
            btnPE.Visible = false;
            label22.Visible = true;
        }

       
        private void frmVoucherPD_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F5)
            {
                if ((txtTDate.Text == "  /  /"))
                {
                    MessageBox.Show("Please complete your entry", "GL");
                    txtTDate.Focus();
                }
                else if ((new ClsValidation().emptytxt(cboControlNo.Text)) || (new ClsValidation().emptytxt(txtreference.Text)) ||
                    (new ClsValidation().emptytxt(txtRemarks.Text)))
                {
                    MessageBox.Show("Please complete your entry", "GL");
                    txtTDate.Focus();
                }
                else
                {
                    //frmTransactEntryCI.glbltxtD1.Enabled = false;
                    //frmTransactEntryCI.glbltxtD2.Enabled = false;
                    //frmTransactEntryCI.glbltxtD3.Enabled = false;
                    Form NonPoultry = Application.OpenForms["frmTransactEntryPD"];
                    if (NonPoultry != null)
                    {
                        //Application.OpenForms["frmTransactEntryCI"].BringToFront();
                        Application.OpenForms["frmTransactEntryPD"].Show();
                    }
                    else
                    {
                        MessageBox.Show("Not applicable at this moment", "GL");
                    }
                }
            }
     
        }

        private void txtTDate_Validating(object sender, CancelEventArgs e)
        {
            if (new ClsValidation().errordate(txtTDate.Text) == true)
            {
                MessageBox.Show("Invalid Date", "GL");
                txtTDate.Focus();
            }
        }

        private void dgv2_UserDeletedRow(object sender, DataGridViewRowEventArgs e)
        {
            dgv2total();
        }

        private void dgv1total()
        {
            double vartxtdr = 0.00;
            double vartxtcr = 0.00;
            double vartxtdiff = 0.00;

            for (int x = 0; x < dgv1.Rows.Count; x++)
            {
                vartxtdr += double.Parse(dgv1.Rows[x].Cells[3].FormattedValue.ToString());
            }

            for (int x = 0; x < dgv1.Rows.Count; x++)
            {
                vartxtcr += double.Parse(dgv1.Rows[x].Cells[4].FormattedValue.ToString());
            }
            txtdrtot.Text = vartxtdr.ToString("N2");
            txtcrtot.Text = vartxtcr.ToString("N2");
            vartxtdiff = Convert.ToDouble(txtdrtot.Text) - Convert.ToDouble(txtcrtot.Text);
            txtDifference.Text = vartxtdiff.ToString("N2");
        }
        private void dgv2total()
        {
            double dbltxtTotDisct = 0;
            double dbltxtTotalVAT = 0;
            double dbltxtTotCost = 0;
            {
                for (int x = 0; x < frmVoucherPD.glbldgv2.Rows.Count; x++)
                {
                    string vartxtD1 = frmVoucherPD.glbldgv2.Rows[x].Cells[6].FormattedValue.ToString();
                    string vartxtD2 = frmVoucherPD.glbldgv2.Rows[x].Cells[7].FormattedValue.ToString();
                    dbltxtTotDisct += double.Parse(vartxtD1) + double.Parse(vartxtD2);
                }
                for (int x = 0; x < frmVoucherPD.glbldgv2.Rows.Count; x++)
                {
                    dbltxtTotalVAT += double.Parse(frmVoucherPD.glbldgv2.Rows[x].Cells[7].FormattedValue.ToString());
                }

                for (int x = 0; x < frmVoucherPD.glbldgv2.Rows.Count; x++)
                {
                    dbltxtTotCost += double.Parse(frmVoucherPD.glbldgv2.Rows[x].Cells[9].FormattedValue.ToString());
                }

                frmVoucherPD.glbltxtTotDisct.Text = dbltxtTotDisct.ToString("N2");
                frmVoucherPD.glbltxtTotalVAT.Text = dbltxtTotalVAT.ToString("N2");
                frmVoucherPD.glbltxtTotCost.Text = dbltxtTotCost.ToString("N2");
                frmVoucherPD.glbltxtTotPayables.Text = (dbltxtTotalVAT+dbltxtTotCost).ToString("N2");


            }

        }


        private void dgv2totalActualEntry()
        {
            pristrRMInvTotal = (dgv2.Rows.Cast<DataGridViewRow>().Where(r => (r.Cells[16].Value).Equals("01")).Sum(t => Convert.ToDouble(t.Cells[9].Value))).ToString("N2");
            pristrFSInvTotal = (dgv2.Rows.Cast<DataGridViewRow>().Where(r => (r.Cells[16].Value).Equals("02")).Sum(t => Convert.ToDouble(t.Cells[9].Value))).ToString("N2");
            pristrOSInvTotal = (dgv2.Rows.Cast<DataGridViewRow>().Where(r => (r.Cells[16].Value).Equals("04")).Sum(t => Convert.ToDouble(t.Cells[9].Value))).ToString("N2");
        }


        private void txtreference_Validating(object sender, CancelEventArgs e)
        {
            if (new ClsValidation().DataExist("tblMain1", "Reference", txtreference.Text))
            {
                MessageBox.Show("Duplicate entry", "GL");
                txtreference.Focus();
            }
        }

        private void cboWHCode_Validating(object sender, CancelEventArgs e)
        {
            if (new ClsValidation().emptytxt(cboWHCode.Text))
            {
            }
            else if (cboWHCode.Text != null && cboWHCode.SelectedValue == null)
            {
                MessageBox.Show("Not found", "GL");
                cboWHCode.Focus();
            }
 
        }

        private void txtTerm_Validating(object sender, CancelEventArgs e)
        {
            if (new ClsValidation().isInt(txtTerm.Text) == true)
            {
                MessageBox.Show("Invalid Number", "GL");
                txtTerm.Focus();
            }

        }

        private void nextfieldenter1(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.Equals(Keys.Enter))
            {
                SendKeys.Send("{TAB}");
            }
            else if ((e.KeyCode.Equals(Keys.Up)) || (e.KeyCode.Equals(Keys.Left)))
            {
                SendKeys.Send("+{TAB}");
            }
            else if ((e.KeyCode.Equals(Keys.Down)) || (e.KeyCode.Equals(Keys.Right)))
            {
                SendKeys.Send("{TAB}");
            }

        }

        private void nextfieldenter2(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.Equals(Keys.Enter))
            {
                SendKeys.Send("{TAB}");
            }

        }

        private void btnListPendingPO_Click(object sender, EventArgs e)
        {
            if (new ClsValidation().emptytxt(cboControlNo.Text))
            {
                MessageBox.Show("Please complete your entry", "GL");
            }
            else
            {
                dgv2.Rows.Clear();
                frmListOfPendingPO frmListOfPendingPO1 = new frmListOfPendingPO();
                frmListOfPendingPO1.Show();
            }
        }

        private void frmVoucherPD_FormClosing(object sender, FormClosingEventArgs e)
        {
            Form NonPoultry = Application.OpenForms["frmTransactEntryPD"];
            if (NonPoultry != null)
            {
                frmTransactEntryPD CloseNonPoultry = (frmTransactEntryPD)Application.OpenForms["frmTransactEntryPD"];
                CloseNonPoultry.Close();
            }
        }

        private void btnAcctEntry_Click(object sender, EventArgs e)
        {
            DataGridViewRow row1 = null;
            for (int x = 0; x < dgv2.Rows.Count; x++)
            {
                row1 = dgv2.Rows[x];
                ClsGetSomethingEntry1.ClsGetInvClassCode(row1.Cells[1].Value.ToString());
                string strInvClassCode = ClsGetSomethingEntry1.plsvarInvClassCode;
                row1.Cells[16].Value = ClsGetSomethingEntry1.plsvarInvClassCode;
            }
            dgv2totalActualEntry();
            getAcctEntry();
        }
    }
}
