﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Threading;
using CrystalDecisions.CrystalReports.Engine;

namespace TCIGL
{
    public partial class frmrptInvProcess : Form
    {
        SqlConnection myconnection;
        SqlCommand mycommand;
        SqlDataReader SqlDataReader1; 
        ClsBuildComboBox ClsBuildComboBox1 = new ClsBuildComboBox();
        ClsValidation ClsValidation1 = new ClsValidation();
        ClsGetSomething ClsGetSomething1 = new ClsGetSomething();
        ClsPermission ClsPermission1 = new ClsPermission();
        ClsBuildEntryComboBox ClsBuildEntryComboBox1 = new ClsBuildEntryComboBox();
        ClsGetConnection ClsGetConnection1 = new ClsGetConnection();
        ClsBuildCOAComboBox ClsBuildCOAComboBox1 = new ClsBuildCOAComboBox();
        ClsDefaultBranch ClsDefaultBranch1 = new ClsDefaultBranch();
        ClsCompName ClsCompName1 = new ClsCompName();
        public frmrptInvProcess()
        {
            InitializeComponent();
            cbortprint.DisplayMember = "Text";
            cbortprint.ValueMember = "Value";

            var items = new[]
            { 
             new { Text = "Inventory Count Sheet", Value = "01" }, 
             new { Text = "Descripancy Report", Value = "02" }, 
            };
            cbortprint.DataSource = items;
            cbortprint.SelectedValue = "01";
        }

        private void frmInvCountSheet_Load(object sender, EventArgs e)
        {
          ClsPermission1.ClsObjects(this.Text);
          if (new ClsValidation().emptytxt(ClsPermission1.plstxtObject))
          {
              MessageBox.Show("You do not have necessary permission to open this file", "GL");
              this.Close();
          }
          else
          {
              ClsGetSomething1.ClsGetDefaultDate();
              txtTDate.Text = ClsGetSomething1.plsdefdate;
              buildcboWHCode();
              cboWHCode.SelectedValue = "";
          }
        }
        private void buildcboWHCode()
        {
            cboWHCode.DataSource = null;
            ClsBuildEntryComboBox1.ARWHCode.Clear();
            ClsBuildEntryComboBox1.ClsBuildWHCode();
            this.cboWHCode.DataSource = (ClsBuildEntryComboBox1.ARWHCode);
            this.cboWHCode.DisplayMember = "Display";
            this.cboWHCode.ValueMember = "Value";
            //this.cboWHCode.DropDownWidth = 450;
        }
      
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            if ((new ClsValidation().emptytxt(cboWHCode.Text)) || (txtTDate.Text == "  /  /"))
            {
                MessageBox.Show("Please complete your entry", "GL");
                cboWHCode.Focus();
            }
            else
            {
                if (cbortprint.SelectedValue.ToString()=="01")
                {
                    InvCountSheet();
                }
                else if (cbortprint.SelectedValue.ToString()=="02")
                {
                    InvDescripancy();
                }
            }
        }

        private void InvCountSheet()
        {
            string sqlstatement = "SELECT StockNumber, StockDesc, UM, SellingPrice FROM tblStocks WHERE TBS = '1'  ORDER BY StockNumber ASC";

            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();
            mycommand = myconnection.CreateCommand();
            mycommand.CommandText = sqlstatement;
            mycommand.CommandTimeout = 900;
            SqlDataReader1 = mycommand.ExecuteReader();
            DataTable DataTable1 = new DataTable();
            DataTable1.Load(SqlDataReader1);
            myconnection.Close();

            if (DataTable1.Rows.Count == 0)
            {
                MessageBox.Show("No data found", "GL");
                return;
            }

            CRProcessInvCountSheet objRpt = new CRProcessInvCountSheet();
            TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            ClsCompName1.ClsCompNameMain();
            vartxtcompany.Text = ClsCompName1.varcn;

            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            ClsCompName1.ClsCompNamebranchAddress(ClsDefaultBranch1.plsvardb);
            vartxtaddress.Text = (ClsCompName1.plsCRaddress);

            TextObject varrpttoWarehouse = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["TextWarehouse"];
            varrpttoWarehouse.Text = "Warehouse : " + cboWHCode.Text;

            TextObject varrpttoTDate = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["TextTDate"];
            varrpttoTDate.Text = "Date : " + txtTDate.Text;

            objRpt.SetDataSource(DataTable1);
            crystalReportViewer1.ReportSource = objRpt;
            crystalReportViewer1.Refresh();
        }

        private void InvDescripancy()
        {
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();

            mycommand = new SqlCommand("usp_AVRPost", myconnection);
            mycommand.CommandType = CommandType.StoredProcedure;
            mycommand.CommandTimeout = 900;
            mycommand.Parameters.Add("@Paramenddate2", SqlDbType.DateTime).Value = txtTDate.Text;
            mycommand.Parameters.Add("@ParamWHCode2", SqlDbType.VarChar).Value = cboWHCode.SelectedValue.ToString();

            SqlDataReader1 = mycommand.ExecuteReader();
            DataTable DataTable1 = new DataTable();
            DataTable1.Load(SqlDataReader1);
            myconnection.Close();

            if (DataTable1.Rows.Count == 0)
            {
                MessageBox.Show("No data found", "GL");
                return;
            }

            CRProcessDescripancy objRpt = new CRProcessDescripancy();
            TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            ClsCompName1.ClsCompNameMain();
            vartxtcompany.Text = ClsCompName1.varcn;

            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            ClsCompName1.ClsCompNamebranchAddress(ClsDefaultBranch1.plsvardb);
            vartxtaddress.Text = (ClsCompName1.plsCRaddress);

            TextObject varrpttoWarehouse = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["TextWarehouse"];
            varrpttoWarehouse.Text = "Warehouse : " + cboWHCode.Text;

            TextObject varrpttoTDate = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["TextTDate"];
            varrpttoTDate.Text = "Date : " + txtTDate.Text;

            objRpt.SetDataSource(DataTable1);
            crystalReportViewer1.ReportSource = objRpt;
            crystalReportViewer1.Refresh();
        }

    }
}
