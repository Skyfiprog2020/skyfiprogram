﻿namespace TCIGL
{
    partial class frmIndReceivable
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dgvList = new System.Windows.Forms.DataGridView();
            this.ColumnReference = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnTDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnBalance = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label8 = new System.Windows.Forms.Label();
            this.txtReceiveAmt = new System.Windows.Forms.TextBox();
            this.btnRecord = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.txtLORRefer = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvList)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvList
            // 
            this.dgvList.AllowUserToAddRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColumnReference,
            this.ColumnTDate,
            this.ColumnBalance});
            this.dgvList.Location = new System.Drawing.Point(12, 12);
            this.dgvList.Name = "dgvList";
            this.dgvList.Size = new System.Drawing.Size(460, 214);
            this.dgvList.TabIndex = 0;
            this.dgvList.CellEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvList_CellEnter);
            // 
            // ColumnReference
            // 
            this.ColumnReference.HeaderText = "Reference";
            this.ColumnReference.Name = "ColumnReference";
            this.ColumnReference.Width = 150;
            // 
            // ColumnTDate
            // 
            this.ColumnTDate.HeaderText = "Date";
            this.ColumnTDate.Name = "ColumnTDate";
            this.ColumnTDate.Width = 120;
            // 
            // ColumnBalance
            // 
            this.ColumnBalance.HeaderText = "Balance";
            this.ColumnBalance.Name = "ColumnBalance";
            this.ColumnBalance.Width = 120;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(8, 249);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(60, 19);
            this.label8.TabIndex = 130;
            this.label8.Text = "Amount:";
            // 
            // txtReceiveAmt
            // 
            this.txtReceiveAmt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtReceiveAmt.Location = new System.Drawing.Point(74, 246);
            this.txtReceiveAmt.Name = "txtReceiveAmt";
            this.txtReceiveAmt.Size = new System.Drawing.Size(111, 26);
            this.txtReceiveAmt.TabIndex = 129;
            this.txtReceiveAmt.Text = "0.00";
            this.txtReceiveAmt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtReceiveAmt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.nextfieldenter1);
            this.txtReceiveAmt.Validating += new System.ComponentModel.CancelEventHandler(this.txtReceiveAmt_Validating);
            // 
            // btnRecord
            // 
            this.btnRecord.Location = new System.Drawing.Point(316, 249);
            this.btnRecord.Name = "btnRecord";
            this.btnRecord.Size = new System.Drawing.Size(75, 23);
            this.btnRecord.TabIndex = 131;
            this.btnRecord.Text = "Record";
            this.btnRecord.UseVisualStyleBackColor = true;
            this.btnRecord.Click += new System.EventHandler(this.btnRecord_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(397, 248);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 132;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // txtLORRefer
            // 
            this.txtLORRefer.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLORRefer.Location = new System.Drawing.Point(224, 242);
            this.txtLORRefer.Name = "txtLORRefer";
            this.txtLORRefer.Size = new System.Drawing.Size(57, 26);
            this.txtLORRefer.TabIndex = 133;
            this.txtLORRefer.Visible = false;
            // 
            // frmIndReceivable
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(486, 284);
            this.Controls.Add(this.txtLORRefer);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnRecord);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtReceiveAmt);
            this.Controls.Add(this.dgvList);
            this.KeyPreview = true;
            this.Name = "frmIndReceivable";
            this.Text = "List of Receivable";
            this.Load += new System.EventHandler(this.frmIndReceivable_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frmIndReceivable_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.dgvList)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvList;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnReference;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnTDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnBalance;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtReceiveAmt;
        private System.Windows.Forms.Button btnRecord;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.TextBox txtLORRefer;
    }
}