﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TCIGL
{
    public partial class frmSetNoCopiesToPrint : Form
    {
        public frmSetNoCopiesToPrint()
        {
            InitializeComponent();
            txtNoCopies.Text = frmMain.glbltxtNoCopy.Text;

        }

        private void txtNoCopies_Validating(object sender, CancelEventArgs e)
        {
            if (new ClsValidation().isInt(txtNoCopies.Text) == true)
            {
                MessageBox.Show("Invalid Number", "GL");
                txtNoCopies.Focus();
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (new ClsValidation().emptytxt(txtNoCopies.Text))
            {
                MessageBox.Show("Please complete your entry", "GL");
                txtNoCopies.Focus();
            }
            else if (int.Parse(txtNoCopies.Text) <= 0)
            {
                MessageBox.Show("No. of copy should be more than zero", "GL");
                txtNoCopies.Focus();
            }
            else
            {
                frmMain.glbltxtNoCopy.Text = txtNoCopies.Text;
                this.Close();
            }

        }

      
    }
}
