﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TCIGL
{
    public partial class frmTransactEntryPS : Form
    {
        ClsBuildComboBox ClsBuildComboBox1 = new ClsBuildComboBox();
        ClsGetSomething ClsGetSomething1 = new ClsGetSomething();
        ClsVariousFormula ClsVariousFormula1 = new ClsVariousFormula();
        ClsDefaultBranch ClsDefaultBranch1 = new ClsDefaultBranch();
        ClsGetRate ClsGetRate1 = new ClsGetRate();
        public frmTransactEntryPS()
        {
            InitializeComponent();
        }

        private void buildcboStocks()
        {
            cboStockNumber.DataSource = null;
            ClsBuildComboBox1.ARLSN.Clear();
            ClsBuildComboBox1.ClsBuildStocks("3", (Convert.ToBoolean(cbProductCode.CheckState)));
            this.cboStockNumber.DataSource = (ClsBuildComboBox1.ARLSN);
            this.cboStockNumber.DisplayMember = "Display";
            this.cboStockNumber.ValueMember = "Value";
        }

      
        private void frmSalesEntry_Load(object sender, EventArgs e)
        {
            buildcboStocks();
        }

        private void cboStockNumber_Validating(object sender, CancelEventArgs e)
        {
            try
            {
                if (new ClsValidation().emptytxt(cboStockNumber.Text))
                {
                }
                else if (cboStockNumber.Text != null && cboStockNumber.SelectedValue == null)
                {
                    MessageBox.Show("Not found", "GL");
                    cboStockNumber.Focus();
                }
                else
                {
                    getproductdetails();
                    getproductBalance();
                }

            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {

            }
        }


        private void getproductdetails()
        {
            ClsGetSomething1.ClsGetProductDetails(cboStockNumber.SelectedValue.ToString());
            txtUPCS.Text = Convert.ToDouble(ClsGetSomething1.plvarUCost).ToString("N2");

            //ClsGetRate1.ClsGetAveCost(cboStockNumber.SelectedValue.ToString());
            //txtUPCS.Text = Convert.ToDouble(ClsGetRate1.plsAveCostCase).ToString("N2");

            //ClsGetSomething1.ClsGetProductDetails(cboStockNumber.SelectedValue.ToString());
            //txtUPCS.Text = Convert.ToDouble(ClsGetSomething1.plvarUCost).ToString("N2");
        }

        private void getproductBalance()
        {
            ClsGetSomething1.ClsGetAvailSaleBal(cboStockNumber.SelectedValue.ToString(), frmVoucherPS.glblcboWHCode.SelectedValue.ToString(), ClsDefaultBranch1.plsvardb);
            txtBalance.Text = double.Parse(ClsGetSomething1.plsavailbal).ToString("N2");
        }

        private void txtQty_Validating(object sender, CancelEventArgs e)
        {
            if (new ClsValidation().isDouble(txtQty.Text) == true)
            {
                MessageBox.Show("Invalid Number", "GL");
                txtQty.Focus();
            }
            else
            {
                txtQty.Text = Convert.ToDouble(txtQty.Text).ToString("N2");
            }
        }


       
        private void savetodgvIn()
        {
            if (new ClsValidation().emptytxt(cboStockNumber.Text))
            {
                MessageBox.Show("Product Description is empty", "GL");
                cboStockNumber.Focus();
            }
            else if (double.Parse(txtQty.Text) == 0)
            {
                MessageBox.Show("Quantity  is zero", "GL");
                txtQty.Focus();
            }
            //else if (double.Parse(txtTotPCBal.Text) < double.Parse(txtTotalPCOrdered.Text))
            //{
            //    MessageBox.Show("Quantity ordered is greater than inventory balance", "GL");
            //    cboStockNumber.Focus();
            //}
            //else if (double.Parse(txtCost.Text) == 0)
            //{
            //    MessageBox.Show("Cost is zero", "GL");
            //    cboStockNumber.Focus();
            //}
            //else if ((double.Parse(txtUPCS.Text) == 0))
            //{
            //    MessageBox.Show("Please check selling price", "GL");
            //    cboStockNumber.Focus();
            //}
            else 
            {
                double vargrosssales = (Convert.ToDouble(txtQty.Text) * Convert.ToDouble(txtUPCS.Text));
                frmVoucherPS.glbldgv2.Rows.Add(cboStockNumber.SelectedValue, cboStockNumber.Text, txtQty.Text, 0.00,  txtUPCS.Text, vargrosssales.ToString("N2"));
            }
                 clearscreen();
        }

        private void savetodgvOut()
        {
            if (new ClsValidation().emptytxt(cboStockNumber.Text))
            {
                MessageBox.Show("Product Description is empty", "GL");
                cboStockNumber.Focus();
            }
            else if (double.Parse(txtQty.Text) == 0)
            {
                MessageBox.Show("Quantity  is zero", "GL");
                txtQty.Focus();
            }
            //else if (double.Parse(txtTotPCBal.Text) < double.Parse(txtTotalPCOrdered.Text))
            //{
            //    MessageBox.Show("Quantity ordered is greater than inventory balance", "GL");
            //    cboStockNumber.Focus();
            //}
            //else if (double.Parse(txtCost.Text) == 0)
            //{
            //    MessageBox.Show("Cost is zero", "GL");
            //    cboStockNumber.Focus();
            //}
            else if (((double.Parse(txtUPCS.Text) == 0)))
            {
                MessageBox.Show("Please check selling price", "GL");
                cboStockNumber.Focus();
            }
            else 
            {
                double vargrosssales = Convert.ToDouble(txtQty.Text) * Convert.ToDouble(txtUPCS.Text);
                frmVoucherPS.glbldgv2.Rows.Add(cboStockNumber.SelectedValue, cboStockNumber.Text, 0.00, txtQty.Text, txtUPCS.Text, vargrosssales.ToString("N2"));
            }
                clearscreen();
        }

        private void clearscreen()
        {
            txtQty.Text = "0.00";
            cboStockNumber.Text = "";
            cboStockNumber.Focus();
            txtUPCS.Text = "0.00";
            txtBalance.Text = "0.00";
            dgv2total();
        }
       

        private void dgv2total()
        {
            double vartxtTotCost = 0.00;

            {
                for (int x = 0; x < frmVoucherPS.glbldgv2.Rows.Count - 1; x++)
                {
                    vartxtTotCost += double.Parse(frmVoucherPS.glbldgv2.Rows[x].Cells[5].FormattedValue.ToString());
                }

     
                frmVoucherPS.glbltxtTotCost.Text = vartxtTotCost.ToString("N2");
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            SendtoBackEntry();
        }
        private void SendtoBackEntry()
        {
            this.Hide();
            //this.SendToBack();
            cboStockNumber.Focus();
            frmVoucherPS.glblbtnSave.Focus();
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
                   
            if (cbIn.Checked)
            {
                savetodgvIn();
            }
            else
            {
                savetodgvOut();
            }

        }

        private void frmSalesEntry_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                SendtoBackEntry();
            }

        }

        private void nextfieldenter1(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.Equals(Keys.Enter))
            {
                SendKeys.Send("{TAB}");
            }
            else if ((e.KeyCode.Equals(Keys.Up)) || (e.KeyCode.Equals(Keys.Left)))
            {
                SendKeys.Send("+{TAB}");
            }
            else if ((e.KeyCode.Equals(Keys.Down)) || (e.KeyCode.Equals(Keys.Right)))
            {
                SendKeys.Send("{TAB}");
            }

        }

        private void nextfieldenter2(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.Equals(Keys.Enter))
            {
                SendKeys.Send("{TAB}");
            }

        }

        private void txtUPCS_Validating(object sender, CancelEventArgs e)
        {
            if (new ClsValidation().isDouble(txtUPCS.Text) == true)
            {
                MessageBox.Show("Invalid Number", "GL");
                txtUPCS.Focus();
            }
            else
            {
                txtUPCS.Text = Double.Parse(txtUPCS.Text).ToString("N2");
            }

        }

        private void cbProductCode_CheckedChanged(object sender, EventArgs e)
        {
            buildcboStocks();
        }

    }
}
