﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TCIGL
{
    public partial class frmEntryCollectorAdd : Form
    {
        SqlConnection myconnection;
        //SqlDataReader dr;
        SqlCommand mycommand;
        BindingSource dbind = new BindingSource();
        ClsAutoNumber ClsAutoNumber1 = new ClsAutoNumber();
        ClsGetConnection ClsGetConnection1 = new ClsGetConnection();
        ClsPermission ClsPermission1 = new ClsPermission();

        public frmEntryCollectorAdd()
        {
            InitializeComponent();
        }
   
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {

            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();

            //if (myconnection.State == ConnectionState.Closed)
            //{
            //    ClsGetConnection1.ClsGetConMSSQL();
            //    MSSQLConnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            //    MSSQLConnection.Open();
            //}

            if (string.IsNullOrEmpty(txtCollectorName.Text))
            {
                myconnection.Close();
                MessageBox.Show("Please complete your entry", "GL");
                txtCollectorName.Focus();
            }
            else if (new Clsexist().RecordExists(ref myconnection, "SELECT SMDesc FROM tblSalesman WHERE SMDesc ='" + txtCollectorName.Text + "'"))
            {
                myconnection.Close();
                MessageBox.Show("Duplicate entry", "GL");
                txtCollectorName.Focus();
            }

            else
            {
                ClsAutoNumber1.CollectorAutoNum();
                txtCollectorCode.Text = (ClsAutoNumber1.plsnumber);
                string sqlstatement;
                sqlstatement = "INSERT INTO tblCollector (CollectCode, CollectName) Values (@_CollectCode, @_CollectName)";
                mycommand = new SqlCommand(sqlstatement, myconnection);
                mycommand.Parameters.Add("_CollectCode", SqlDbType.VarChar).Value = txtCollectorCode.Text;
                mycommand.Parameters.Add("_CollectName", SqlDbType.VarChar).Value = txtCollectorName.Text;
                int n2 = mycommand.ExecuteNonQuery();
            
                txtCollectorName.Text = "";
                txtCollectorName.Focus();
                //mycommand = new SqlCommand("SELECT BankCode FROM tblBank ORDER BY BankCode ASC", myconnection);
                //dr = mycommand.ExecuteReader();
                myconnection.Close();
               // dr.Close();
                ClsAutoNumber1.CollectorAutoNum();
                txtCollectorCode.Text = (ClsAutoNumber1.plsnumber);
            }
        }

        private void frmSalesmanAdd_Load(object sender, EventArgs e)
        {
              ClsPermission1.ClsObjects(this.Text);
              if (new ClsValidation().emptytxt(ClsPermission1.plstxtObject))
              {
                  MessageBox.Show("You do not have necessary permission to open this file", "GL");
                  this.Close();
              }
              else
              {
                  ClsAutoNumber1.CollectorAutoNum();
                  txtCollectorCode.Text = (ClsAutoNumber1.plsnumber);
              }
        }

      

        private void nextfieldenter1(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.Equals(Keys.Enter))
            {
                SendKeys.Send("{TAB}");
            }
            else if ((e.KeyCode.Equals(Keys.Up)) || (e.KeyCode.Equals(Keys.Left)))
            {
                SendKeys.Send("+{TAB}");
            }
            else if ((e.KeyCode.Equals(Keys.Down)) || (e.KeyCode.Equals(Keys.Right)))
            {
                SendKeys.Send("{TAB}");
            }
        }
  
    }
}
