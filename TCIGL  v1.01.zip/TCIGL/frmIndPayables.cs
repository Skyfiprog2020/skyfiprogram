﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TCIGL
{

    public partial class frmIndPayables : Form
    {
        SqlConnection myconnection;
        //SqlCommand mycommand;
        //string varoutdate = "No";
        private SqlDataAdapter da;
        private DataTable dataTable = null;
        private BindingSource bindingSource = null;
        ClsGetConnection ClsGetConnection1 = new ClsGetConnection();
        ClsGetSomething ClsGetSomething1 = new ClsGetSomething();
        ClsDefaultBranch ClsDefaultBranch1 = new ClsDefaultBranch();
        string varstrOrigDoc;
        public static TextBox glbltxtVoucher;
        string sqlstatement;
        public frmIndPayables()
        {
            InitializeComponent();
        }

        private void frmIndPayables_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                this.Close();
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void buildShowPayList()
        {
            dgvList.DataSource = null;
            dgvList.Columns.Clear();

            
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();

            if (txtVoucher.Text == "CV")
            {
                sqlstatement = "SELECT Refer, MinTDate, Balance FROM ViewAP1Aging WHERE   ControlNo='" + frmVoucherCV.glblcboControlNo.SelectedValue.ToString() + "' AND CNCode='" + ClsDefaultBranch1.plsvardb + "'";
            }
            else if (txtVoucher.Text == "RTS")
            {
                sqlstatement = "SELECT Refer, MinTDate, Balance FROM ViewAP1Aging WHERE   ControlNo='" + frmVoucherRTS.glblcboControlNo.SelectedValue.ToString() + "' AND CNCode='" + ClsDefaultBranch1.plsvardb + "'";
            }

            da = new SqlDataAdapter(sqlstatement, myconnection);
            SqlCommandBuilder commandBuilder = new SqlCommandBuilder(da);

            dataTable = new DataTable();
            da.Fill(dataTable);
            bindingSource = new BindingSource();
            bindingSource.DataSource = dataTable;

            //Adding  Reference TextBox
            DataGridViewTextBoxColumn ColumnReference = new DataGridViewTextBoxColumn();
            ColumnReference.HeaderText = "Reference";
            ColumnReference.Width = 150;
            ColumnReference.DataPropertyName = "Refer";
            //ColumnReference.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            //ColumnReference.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnReference.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            //ColumnReference.Visible = false;
            ColumnReference.ReadOnly = true;
            dgvList.Columns.Add(ColumnReference);

            //Adding  TDate TextBox
            DataGridViewTextBoxColumn ColumnTDate = new DataGridViewTextBoxColumn();
            ColumnTDate.HeaderText = "Date";
            ColumnTDate.Width = 120;
            ColumnTDate.DataPropertyName = "MinTDate";
            //ColumnTDate.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            //ColumnTDate.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            //ColumnTDate.Visible = false;
            ColumnTDate.ReadOnly = true;
            dgvList.Columns.Add(ColumnTDate);

            //Adding  Balance TextBox
            DataGridViewTextBoxColumn ColumnBalance = new DataGridViewTextBoxColumn();
            ColumnBalance.HeaderText = "Balance";
            ColumnBalance.Width = 120;
            ColumnBalance.DataPropertyName = "Balance";
            //ColumnBalance.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnBalance.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnBalance.ReadOnly = true;
            dgvList.Columns.Add(ColumnBalance);

            //dgvListReceive.Columns[0].Name = "RVRefer";
            //dgvListReceive.Columns[1].Name = "TDate";
            //dgvListReceive.Columns[2].Name = "Balance";
            //Setting Data Source for DataGridView
            dgvList.DataSource = bindingSource;
            //            dgvListReceive.AutoResizeColumns();
            //            dgvListReceive.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            myconnection.Close();
            //            this.WindowState = FormWindowState.Maximized;
            //dgvListReceive.AllowUserToAddRows = false;
            dgvList.Columns[2].DefaultCellStyle.Format = "N2";
            dgvList.Columns[1].DefaultCellStyle.Format = "MM/dd/yyyy";
        }

        private void frmIndPayables_Load(object sender, EventArgs e)
        {
            glbltxtVoucher = txtVoucher;
           
        }

        private void dgvList_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            varstrOrigDoc = dgvList.CurrentRow.Cells[0].Value.ToString();
            double varamt = Convert.ToDouble(dgvList.CurrentRow.Cells[2].Value);
            txtReceiveAmt.Text = varamt.ToString("N2");
        }

        private void txtReceiveAmt_Validating(object sender, CancelEventArgs e)
        {
            if (new ClsValidation().isDouble(txtReceiveAmt.Text) == true)
            {
                MessageBox.Show("Invalid Number", "GL");
                txtReceiveAmt.Focus();
            }
            else
            {
                txtReceiveAmt.Text = Convert.ToDouble(txtReceiveAmt.Text).ToString("N2");
            }
        }

        private void btnRecord_Click(object sender, EventArgs e)
        {
            if (txtVoucher.Text == "CV")
            {
                if (new ClsValidation().emptytxt(varstrOrigDoc))
                {
                    MessageBox.Show("Please select list of receivable", "GL");
                    dgvList.Focus();
                }
                else
                {
                    ClsGetSomething1.ClsGetChartData("03");
                    double varreceiveamt = double.Parse(txtReceiveAmt.Text);
                    frmVoucherCV.glbldgv1.Rows.Add(ClsGetSomething1.plsPA, ClsGetSomething1.plsAT, "000", "NA", varstrOrigDoc, varreceiveamt.ToString("N2"), "0.00", 0);
                    double A = Convert.ToDouble(dgvList.CurrentRow.Cells[2].Value);
                    double B = Convert.ToDouble(txtReceiveAmt.Text);
                    {
                        dgvList.CurrentRow.Cells[2].Value = (A - B);
                    }
                    dgvList.Focus();
                    txtReceiveAmt.Text = "0.00";
                    varstrOrigDoc = null;
                    glbldgv1total();
                    refreshdgvList();
                }
            }

            else if (txtVoucher.Text=="RTS")
            {
                frmVoucherRTS.glbltxtOrigDoc.Text = varstrOrigDoc;
                this.Close();
            }
        }

        private void glbldgv1total()
        {
            double vartxtdr = 0.00;
            double vartxtcr = 0.00;
            double vartxtdiff = 0.00;

            for (int x = 0; x < frmVoucherCV.glbldgv1.Rows.Count - 1; x++)
            {
                vartxtdr += double.Parse(frmVoucherCV.glbldgv1.Rows[x].Cells[5].FormattedValue.ToString());
            }

            for (int x = 0; x < frmVoucherCV.glbldgv1.Rows.Count - 1; x++)
            {
                vartxtcr += double.Parse(frmVoucherCV.glbldgv1.Rows[x].Cells[6].FormattedValue.ToString());
            }
            frmVoucherCV.glbltxtdrtot.Text = vartxtdr.ToString("n2");
            frmVoucherCV.glbltxtcrtot.Text = vartxtcr.ToString("n2");
            vartxtdiff = Convert.ToDouble(frmVoucherCV.glbltxtdrtot.Text) - Convert.ToDouble(frmVoucherCV.glbltxtcrtot.Text);
            frmVoucherCV.glbltxtDifference.Text = vartxtdiff.ToString("n2");
        }

        private void refreshdgvList()
        {
            BindingSource bs = new BindingSource();
            bs.DataSource = dgvList.DataSource;
            dgvList.DataSource = bs;
            bs.Filter = "Balance <> '0.00'";
            dgvList.DataSource = bs;
        }

        private void nextfieldenter1(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.Equals(Keys.Enter))
            {
                SendKeys.Send("{TAB}");
            }
            else if ((e.KeyCode.Equals(Keys.Up)) || (e.KeyCode.Equals(Keys.Left)))
            {
                SendKeys.Send("+{TAB}");
            }
            else if ((e.KeyCode.Equals(Keys.Down)) || (e.KeyCode.Equals(Keys.Right)))
            {
                SendKeys.Send("{TAB}");
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            buildShowPayList();
            timer1.Enabled = false;
        }

     
    }
}
