﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TCIGL
{
    public partial class frmEntryCategoryEdit : Form
    {
        private SqlDataAdapter da;
        private DataTable dataTable = null;
        private SqlConnection myconnection;
        private BindingSource bindingSource = null;
        BindingSource bsource = new BindingSource();
        //   DataSet ds = null;
        string sql;
        ClsPermission ClsPermission1 = new ClsPermission();
        ClsGetConnection ClsGetConnection1 = new ClsGetConnection(); 

        public frmEntryCategoryEdit()
        {
            InitializeComponent();
        }

        private void frmEntryCategoryEdit_Load(object sender, EventArgs e)
        {

            ClsPermission1.ClsObjects(this.Text);
            if (new ClsValidation().emptytxt(ClsPermission1.plstxtObject))
            {
                MessageBox.Show("You do not have necessary permission to open this file", "GL");
                this.Close();
            }
            else
            {
                LoadData();
            }
 
        }

        private void LoadData()
        {
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            sql = "SELECT CatCode, CatDesc FROM tblCategory ORDER BY CatCode";

            da = new SqlDataAdapter(sql, myconnection);
            SqlCommandBuilder commandBuilder = new SqlCommandBuilder(da);

            dataTable = new DataTable();
            da.Fill(dataTable);
            bindingSource = new BindingSource();
            bindingSource.DataSource = dataTable;

            //Adding  CatCode TextBox
            DataGridViewTextBoxColumn ColumnCatCode = new DataGridViewTextBoxColumn();
            ColumnCatCode.HeaderText = "Code";
            //ColumnCatCode.Width = 80;
            ColumnCatCode.DataPropertyName = "CatCode";
            ColumnCatCode.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnCatCode.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            //ColumnCatCode.Visible = false;
            ColumnCatCode.ReadOnly = true;
            dgv1.Columns.Add(ColumnCatCode);

            //Adding  CatDesc TextBox
            DataGridViewTextBoxColumn ColumnCatDesc = new DataGridViewTextBoxColumn();
            ColumnCatDesc.HeaderText = "Description";
            //ColumnItem.Width = 80;
            ColumnCatDesc.DataPropertyName = "CatDesc";
            ColumnCatDesc.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnCatDesc.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            //ColumnCatDesc.ReadOnly = true;
            dgv1.Columns.Add(ColumnCatDesc);

            //Setting Data Source for DataGridView
            dgv1.DataSource = bindingSource;
            dgv1.AutoResizeColumns();
            dgv1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            myconnection.Close();
            this.WindowState = FormWindowState.Maximized;
            dgv1.AllowUserToAddRows = false;
        }
        private void btnclose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                da.Update(dataTable);
                MessageBox.Show("Saved", "GL");
                this.Close();

            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }

        }
    }
}
