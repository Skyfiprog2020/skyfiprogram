﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using CrystalDecisions.CrystalReports.Engine;
using System.Data.SqlClient;

namespace TCIGL
{
    public partial class frmrptLedgerSummary : Form
    {
        SqlConnection myconnection;
       // SqlDataReader dr;
       // SqlCommand mycommand;
        BindingSource dbind = new BindingSource();
        ClsBuildComboBox ClsBuildComboBox1 = new ClsBuildComboBox();
        ClsBuildCOAComboBox ClsBuildCOAComboBox1 = new ClsBuildCOAComboBox(); 
        ClsDefaultBranch ClsDefaultBranch1 = new ClsDefaultBranch();
        ClsCompName ClsCompName1 = new ClsCompName();
        ClsGetSomething ClsGetSomething1 = new ClsGetSomething();
        ClsGetConnection ClsGetConnection1 = new ClsGetConnection(); 

        public frmrptLedgerSummary()
        {
            InitializeComponent();
        }

        private void txtBeginDate_Leave(object sender, EventArgs e)
        {
            if (new ClsValidation().errordate(txtBeginDate.Text) == true)
            {
                MessageBox.Show("Invalid Date", "GL");
                txtBeginDate.Focus();
            }
        }

        private void txtEndDate_Leave(object sender, EventArgs e)
        {
            if (new ClsValidation().errordate(txtEndDate.Text) == true)
            {
                MessageBox.Show("Invalid Date", "GL");
                txtEndDate.Focus();
            }
        }

        private void btnPreview_Click(object sender, EventArgs e)
        {
            if (cbortprint.Text == "Ledger Summary - 1")
            {
                if ((new ClsValidation().emptytxt(cboActCode.Text)) || (new ClsValidation().emptytxt(cboCNCode.Text)))
                {
                    MessageBox.Show("Please complete your entry", "GL");
                    cboActCode.Focus();
                }
                else if (txtEndDate.Text == "  /  /")
                {
                    MessageBox.Show("Please complete your entry", "GL");
                    txtEndDate.Focus();
                }

                else
                {
                    LedgerSum1();
                }

            }
            else if (cbortprint.Text == "Ledger Summary - 2")
            {
                if ((new ClsValidation().emptytxt(cboActCode.Text))  || (new ClsValidation().emptytxt(cboCNCode.Text)))
                {
                    MessageBox.Show("Please complete your entry", "GL");
                    cboActCode.Focus();
                }
                else if (txtBeginDate.Text == "  /  /")
                {
                    MessageBox.Show("Please complete your entry", "GL");
                    txtBeginDate.Focus();
                }
                else if (txtEndDate.Text == "  /  /")
                {
                    MessageBox.Show("Please complete your entry", "GL");
                    txtEndDate.Focus();
                }
                else if (Convert.ToDateTime(txtBeginDate.Text) > Convert.ToDateTime(txtEndDate.Text))
                {
                    MessageBox.Show("Beginning date is greater than ending date");
                    txtBeginDate.Focus();
                }
                else
                {
                    LedgerSum2();
                }

            }

        }
                private void LedgerSum1()
                {
                    string sqlstatement;
                    ClsGetConnection1.ClsGetConMSSQL();
                    myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                    myconnection.Open();
                    sqlstatement = "SELECT	CustName, SUM(Bal) AS SumBal FROM ViewLedgerSummary  WHERE TDate <= '" + txtEndDate.Text + "'AND CNCode = '" + cboCNCode.SelectedValue + "' AND AcctNo='"+cboActCode.SelectedValue+"'  GROUP BY CustName HAVING (SUM(Bal) <> 0)";

                    SqlDataAdapter dscmd = new SqlDataAdapter(sqlstatement, myconnection);
                    DSLedgerSummary DSLedgerSummary1 = new DSLedgerSummary();
                    dscmd.Fill(DSLedgerSummary1, "ViewLedgerSummary");
                    myconnection.Close();

                    CRLedgerSummary objRpt = new CRLedgerSummary();
                    TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
                    ClsCompName1.ClsCompNameMain();
                    vartxtcompany.Text = ClsCompName1.varcn;

                    ClsCompName1.ClsCompNamebranchAddress(cboCNCode.SelectedValue.ToString());
                    TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
                    vartxtaddress.Text = ClsCompName1.plsCRaddress;


                    TextObject varTextActTitle = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["TextActTitle"];
                    varTextActTitle.Text = cboActCode.Text;

                    TextObject varrpttoenterdate = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttoenterdate"];
                    varrpttoenterdate.Text = "As of " + txtEndDate.Text;

                    objRpt.SetDataSource(DSLedgerSummary1.Tables[1]);
                    crystalReportViewer1.ReportSource = objRpt;
                    crystalReportViewer1.Refresh();
                }

                private void LedgerSum2()
                {
                    string sqlstatement;
                    ClsGetConnection1.ClsGetConMSSQL();
                    myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                    myconnection.Open();
                    sqlstatement = "SELECT	CustName, SUM(Bal) AS SumBal FROM ViewLedgerSummary  WHERE TDate Between '"+txtBeginDate.Text+"' AND '" + txtEndDate.Text + "'AND CNCode = '" + cboCNCode.SelectedValue + "' AND AcctNo='" + cboActCode.SelectedValue + "'  GROUP BY CustName HAVING (SUM(Bal) <> 0)";

                    SqlDataAdapter dscmd = new SqlDataAdapter(sqlstatement, myconnection);
                    DSLedgerSummary DSLedgerSummary1 = new DSLedgerSummary();
                    dscmd.Fill(DSLedgerSummary1, "ViewLedgerSummary");
                    myconnection.Close();

                    CRLedgerSummary objRpt = new CRLedgerSummary();
                    TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
                    ClsCompName1.ClsCompNameMain();
                    vartxtcompany.Text = ClsCompName1.varcn;

                    ClsCompName1.ClsCompNamebranchAddress(cboCNCode.SelectedValue.ToString());
                    TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
                    vartxtaddress.Text = ClsCompName1.plsCRaddress;


                    TextObject varTextActTitle = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["TextActTitle"];
                    varTextActTitle.Text = cboActCode.Text;

                    TextObject varrpttoenterdate = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttoenterdate"];
                    varrpttoenterdate.Text = "From " +txtBeginDate.Text +" To "+ txtEndDate.Text;

                    objRpt.SetDataSource(DSLedgerSummary1.Tables[1]);
                    crystalReportViewer1.ReportSource = objRpt;
                    crystalReportViewer1.Refresh();
                }

        private void frmrptLedgerSummary_Load(object sender, EventArgs e)
        {
            buildcboActCode();
            buildcboCName();
            cboCNCode.SelectedValue = (ClsDefaultBranch1.plsvardb);
            ClsGetSomething1.ClsGetDefaultDate();
            txtBeginDate.Text = ClsGetSomething1.plsdefdate;
            txtEndDate.Text = ClsGetSomething1.plsdefdate;
            this.WindowState = FormWindowState.Maximized;
        }

        private void buildcboCName()
        {
            cboCNCode.DataSource = null;
            ClsBuildComboBox1.ARBranch.Clear();
            ClsBuildComboBox1.ClsBuildBranch();
            this.cboCNCode.DataSource = (ClsBuildComboBox1.ARBranch);
            this.cboCNCode.DisplayMember = "Display";
            this.cboCNCode.ValueMember = "Value";
        }
        private void buildcboActCode()
        {
            cboActCode.DataSource = null;
            ClsBuildCOAComboBox1.ARcboactcode.Clear();
            ClsBuildCOAComboBox1.ClsbuildCboActCode();
            this.cboActCode.DataSource = ClsBuildCOAComboBox1.ARcboactcode;
            this.cboActCode.DisplayMember = "Display";
            this.cboActCode.ValueMember = "Value";
        }

  
        private void cboActCode_Validating(object sender, CancelEventArgs e)
        {
            if (new ClsValidation().emptytxt(cboActCode.Text))
            {
            }
            else if (cboActCode.Text != null && cboActCode.SelectedValue == null)
            {
                MessageBox.Show("Not found", "GL");
                cboActCode.Focus();
            }

        }

        private void cboCNCode_Validating(object sender, CancelEventArgs e)
        {
            if (new ClsValidation().emptytxt(cboCNCode.Text))
            {
            }
            else if (cboCNCode.Text != null && cboCNCode.SelectedValue == null)
            {
                MessageBox.Show("Not found", "GL");
                cboCNCode.Focus();
            }
        }

    
        private void cbortprint_Validating(object sender, CancelEventArgs e)
        {
            if (cbortprint.Text == "Ledger Summary - 1")
            {
                label5.Visible = false;
                txtBeginDate.Visible = false;
                label1.Text = "As of";
            }
            else if (cbortprint.Text == "Ledger Summary - 2")
            {
                label5.Visible = true;
                txtBeginDate.Visible = true;
                label1.Text = "Ending Date";
            }

        }

        private void nextfieldenter1(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.Equals(Keys.Enter))
            {
                SendKeys.Send("{TAB}");
            }
            else if ((e.KeyCode.Equals(Keys.Up)) || (e.KeyCode.Equals(Keys.Left)))
            {
                SendKeys.Send("+{TAB}");
            }
            else if ((e.KeyCode.Equals(Keys.Down)) || (e.KeyCode.Equals(Keys.Right)))
            {
                SendKeys.Send("{TAB}");
            }

        }

        private void nextfieldenter2(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.Equals(Keys.Enter))
            {
                SendKeys.Send("{TAB}");
            }

        }

       
    
   }
}
