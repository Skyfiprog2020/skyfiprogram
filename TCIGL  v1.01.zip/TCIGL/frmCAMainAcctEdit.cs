﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace TCIGL
{
    public partial class frmCAMainAcctEdit : Form
    {
        SqlConnection myconnection;
        SqlDataReader dr;
        SqlCommand mycommand;
        BindingSource dbind = new BindingSource();
        ClsBuildCOAComboBox ClsBuildCOAComboBox1 = new ClsBuildCOAComboBox();
        ClsGetConnection ClsGetConnection1 = new ClsGetConnection();
        ClsPermission ClsPermission1 = new ClsPermission(); 

        public frmCAMainAcctEdit()
        {
            InitializeComponent();
        }

        private void btnclose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buildcboFSClass()
        {
            ClsBuildCOAComboBox1.ClsbuildCOAG1();
            this.cboFSClass.DataSource = (ClsBuildCOAComboBox1.ARCOAG1);
            this.cboFSClass.DisplayMember = "Display";
            this.cboFSClass.ValueMember = "Value";
        }

        private void buildcboNormalBal()
        {
            ClsBuildCOAComboBox1.ClsbuildCOAG2();
            this.cboNormalBal.DataSource = (ClsBuildCOAComboBox1.ARCOAG2);
            this.cboNormalBal.DisplayMember = "Display";
            this.cboNormalBal.ValueMember = "Value";
        }

        private void buildcboFCCode()
        {
            ClsBuildCOAComboBox1.ClsbuildFirstCaption();
            this.cboFCCode.DataSource = (ClsBuildCOAComboBox1.ARFCCode);
            this.cboFCCode.DisplayMember = "Display";
            this.cboFCCode.ValueMember = "Value";
        }
        private void buildcboSCCode()
        {
            ClsBuildCOAComboBox1.ClsbuildSecondCaption();
            this.cboSCCode.DataSource = (ClsBuildCOAComboBox1.ARSCCode);
            this.cboSCCode.DisplayMember = "Display";
            this.cboSCCode.ValueMember = "Value";
        }

        private void buildcboUsageCode()
        {
            this.cboUsageCode.DataSource = null;
            ClsBuildCOAComboBox1.ARUsage.Clear();
            ClsBuildCOAComboBox1.ClsbuildUsage();
            this.cboUsageCode.DataSource = (ClsBuildCOAComboBox1.ARUsage);
            this.cboUsageCode.DisplayMember = "Display";
            this.cboUsageCode.ValueMember = "Value";
        }

        private void buildcboSearchActNo()
        {
            this.cboSearchActNo.DataSource = null;
            ClsBuildCOAComboBox1.ARcboactcode.Clear();
            ClsBuildCOAComboBox1.ClsbuildCboActCode();
            this.cboSearchActNo.DataSource = (ClsBuildCOAComboBox1.ARcboactcode);
            this.cboSearchActNo.DisplayMember = "Display";
            this.cboSearchActNo.ValueMember = "Value";
        }

        private void getCOADetails()
        {
            try
            {
                string sql;
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                sql = "SELECT AcctNo, TitleAcct, FSClass, FCCode, SCCode, NormalBal, UsageCode From tblTitleAcct WHERE AcctNo = '" + cboSearchActNo.SelectedValue + "'";
                mycommand = new SqlCommand(sql, myconnection);
                dr = mycommand.ExecuteReader();

                while (dr.Read())
                {
                    txtAcctNo.Text = dr["AcctNo"].ToString();
                    txtTitleAcct.Text = dr["TitleAcct"].ToString();
                    cboFSClass.SelectedValue = dr["FSClass"].ToString();
                    cboFCCode.SelectedValue = dr["FCCode"].ToString();
                    cboSCCode.SelectedValue = dr["SCCode"].ToString();
                    cboNormalBal.SelectedValue = dr["NormalBal"].ToString();
                    cboUsageCode.SelectedValue = dr["UsageCode"].ToString();
                }
                dr.Close();
                myconnection.Close();

            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
                myconnection.Close();
            }

        }
        private void frmCAPAAdd_Load(object sender, EventArgs e)
        {
            ClsPermission1.ClsObjects(this.Text);
            if (new ClsValidation().emptytxt(ClsPermission1.plstxtObject))
            {
                MessageBox.Show("You do not have necessary permission to open this file", "GL");
                this.Close();
            }
            else
            {
                buildcboSearchActNo();
                buildcboFSClass();
                buildcboNormalBal();
                buildcboFCCode();
                buildcboSCCode();
                buildcboUsageCode();
                cboFSClass.SelectedValue = "";
                cboFCCode.SelectedValue = "";
                cboSCCode.SelectedValue = "";
                cboNormalBal.SelectedValue = "";
                cboUsageCode.SelectedValue = "";
                cboSearchActNo.SelectedValue = "";
            }
        }

 

        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {

                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();

                //if (new Clsexist().RecordExists(ref myconnection, "SELECT AcctNo FROM tblTitleAcct WHERE AcctNo ='" + txtAcctNo.Text + "'"))
                //{
                //    myconnection.Close();
                //    MessageBox.Show("Duplicate entry", "GL");
                //    txtAcctNo.Focus();
                //}

                //else if (new Clsexist().RecordExists(ref myconnection, "SELECT TitleAcct FROM tblTitleAcct WHERE TitleAcct ='" + txtTitleAcct.Text + "'"))
                //{
                //    myconnection.Close();
                //    MessageBox.Show("Duplicate entry", "GL");
                //    txtTitleAcct.Focus();
                //}

                if (new ClsValidation().emptytxt(cboSearchActNo.Text))
                {
                    myconnection.Close();
                    MessageBox.Show("Please complete your entry", "GL");
                    cboSearchActNo.Focus();
                }

                else if (new ClsValidation().emptytxt(txtAcctNo.Text))
                {
                    myconnection.Close();
                    MessageBox.Show("Please complete your entry", "GL");
                    txtAcctNo.Focus();
                }
                else if (new ClsValidation().emptytxt(txtTitleAcct.Text))
                {
                    myconnection.Close();
                    MessageBox.Show("Please complete your entry", "GL");
                    txtTitleAcct.Focus();
                }
                else if (new ClsValidation().emptytxt(cboFSClass.Text))
                {
                    myconnection.Close();
                    MessageBox.Show("Please complete your entry", "GL");
                    cboFSClass.Focus();
                }
                else if (new ClsValidation().emptytxt(cboFCCode.Text))
                {
                    myconnection.Close();
                    MessageBox.Show("Please complete your entry", "GL");
                    cboFCCode.Focus();
                }
                else if (new ClsValidation().emptytxt(cboSCCode.Text))
                {
                    myconnection.Close();
                    MessageBox.Show("Please complete your entry", "GL");
                    cboSCCode.Focus();
                }
                else if (new ClsValidation().emptytxt(cboNormalBal.Text))
                {
                    myconnection.Close();
                    MessageBox.Show("Please complete your entry", "GL");
                    cboNormalBal.Focus();
                }
                else if (new ClsValidation().emptytxt(cboUsageCode.Text))
                {
                    myconnection.Close();
                    MessageBox.Show("Please complete your entry", "GL");
                    cboUsageCode.Focus();
                }
                else
                {
                    string sqlstatement;
                    sqlstatement = "UPDATE tblTitleAcct set AcctNo=@_AcctNo, TitleAcct=@_TitleAcct, FSClass=@_FSClass, FCCode=@_FCCode, SCCode=@_SCCode, NormalBal=@_NormalBal, UsageCode=@_UsageCode WHERE AcctNo= '" + cboSearchActNo.SelectedValue + "'";
                    mycommand = new SqlCommand(sqlstatement, myconnection);
                    mycommand.Parameters.Add("_AcctNo", SqlDbType.VarChar).Value = txtAcctNo.Text;
                    mycommand.Parameters.Add("_TitleAcct", SqlDbType.VarChar).Value = txtTitleAcct.Text;
                    mycommand.Parameters.Add("_FSClass", SqlDbType.VarChar).Value = cboFSClass.SelectedValue;
                    mycommand.Parameters.Add("_FCCode", SqlDbType.VarChar).Value = cboFCCode.SelectedValue;
                    mycommand.Parameters.Add("_SCCode", SqlDbType.VarChar).Value = cboSCCode.SelectedValue;
                    mycommand.Parameters.Add("_NormalBal", SqlDbType.VarChar).Value = cboNormalBal.SelectedValue;
                    mycommand.Parameters.Add("_UsageCode", SqlDbType.VarChar).Value = cboUsageCode.SelectedValue;
                    int n1 = mycommand.ExecuteNonQuery();
                    myconnection.Close();
                    //dr.Close();
                    buildcboSearchActNo();
                    cboFSClass.SelectedValue = "";
                    cboFCCode.SelectedValue = "";
                    cboSCCode.SelectedValue = "";
                    cboNormalBal.SelectedValue = "";
                    cboUsageCode.SelectedValue = "";
                    cboSearchActNo.SelectedValue = "";
                    txtAcctNo.Clear();
                    txtTitleAcct.Clear();
                    cboSearchActNo.Focus();
                }
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
                myconnection.Close();
            }
        
        }

        private void cboFSClass_Validating(object sender, CancelEventArgs e)
            {
                if (new ClsValidation().emptytxt(cboFSClass.Text))
                {
                }
                else if (cboFSClass.Text != null && cboFSClass.SelectedValue == null)
                {
                    MessageBox.Show("Not found", "GL");
                    cboFSClass.Focus();
                }
            }
      
        private void cboFCCode_Validating(object sender, CancelEventArgs e)
            {
                if (new ClsValidation().emptytxt(cboFCCode.Text))
                {
                }
                else if (cboFCCode.Text != null && cboFCCode.SelectedValue == null)
                {
                    MessageBox.Show("Not found", "GL");
                    cboFCCode.Focus();
                }
        }

        private void cboSCCode_Validating(object sender, CancelEventArgs e)
            {
                if (new ClsValidation().emptytxt(cboSCCode.Text))
                {
                }
                else if (cboSCCode.Text != null && cboSCCode.SelectedValue == null)
                {
                    MessageBox.Show("Not found", "GL");
                    cboSCCode.Focus();
                }
            }
      
        private void cboNormalBal_Validating(object sender, CancelEventArgs e)
            {
                if (new ClsValidation().emptytxt(cboNormalBal.Text))
                {
                }
                else if (cboNormalBal.Text != null && cboNormalBal.SelectedValue == null)
                {
                    MessageBox.Show("Not found", "GL");
                    cboNormalBal.Focus();
                }
            }
      
        private void cboUsageCode_Validating(object sender, CancelEventArgs e)
            {
                if (new ClsValidation().emptytxt(cboUsageCode.Text))
                {
                }
                else if (cboUsageCode.Text != null && cboUsageCode.SelectedValue == null)
                {
                    MessageBox.Show("Not found", "GL");
                    cboUsageCode.Focus();
                }
            }
    
     
  
     

        private void cboSearchActNo_Validating(object sender, CancelEventArgs e)
        {
                if (new ClsValidation().emptytxt(cboSearchActNo.Text))
                {
                }
                else if (cboSearchActNo.Text != null && cboSearchActNo.SelectedValue == null)
                {
                    MessageBox.Show("Not found", "GL");
                    cboSearchActNo.Focus();
                }
     
        }

        private void cboSearchActNo_SelectedIndexChanged(object sender, EventArgs e)
        {
            getCOADetails();
        }

        private void nextfieldenter1(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.Equals(Keys.Enter))
            {
                SendKeys.Send("{TAB}");
            }
            else if ((e.KeyCode.Equals(Keys.Up)) || (e.KeyCode.Equals(Keys.Left)))
            {
                SendKeys.Send("+{TAB}");
            }
            else if ((e.KeyCode.Equals(Keys.Down)) || (e.KeyCode.Equals(Keys.Right)))
            {
                SendKeys.Send("{TAB}");
            }

        }

        private void nextfieldenter2(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.Equals(Keys.Enter))
            {
                SendKeys.Send("{TAB}");
            }
        }
            
    }
}
