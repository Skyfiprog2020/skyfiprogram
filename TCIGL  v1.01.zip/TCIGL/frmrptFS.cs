﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using CrystalDecisions.CrystalReports.Engine;
using System.Data.SqlClient;

namespace TCIGL
{
    public partial class frmrptFS : Form
    {
        SqlConnection myconnection;
        SqlDataReader dr;
        SqlCommand mycommand;
        BindingSource dbind = new BindingSource();
        ClsDefaultBranch ClsDefaultBranch1 = new ClsDefaultBranch();
        ClsBuildComboBox ClsBuildComboBox1 = new ClsBuildComboBox();
        ClsCompName ClsCompName1 = new ClsCompName();
        ClsGetConnection ClsGetConnection1 = new ClsGetConnection(); 

        public frmrptFS()
        {
            InitializeComponent();
        }
   
        private void btnPreview_Click(object sender, EventArgs e)
        {

            if (cbortprint.Text == "Trial Balance")
            {
                if (new ClsValidation().emptytxt(cbortprint.Text))
                {
                    MessageBox.Show("Please complete your entry", "GL");
                    cbortprint.Focus();
                }
                else if (txtBeginDate.Text == "  /  /")
                {
                    MessageBox.Show("Please complete your entry", "GL");
                    txtBeginDate.Focus();
                }
                else if (txtEndDate.Text == "  /  /")
                {
                    MessageBox.Show("Please complete your entry", "GL");
                    txtEndDate.Focus();
                }
                else if (Convert.ToDateTime(txtBeginDate.Text) > Convert.ToDateTime(txtEndDate.Text))
                {
                    MessageBox.Show("Beginning date is greater than ending date");
                    txtBeginDate.Focus();
                }
                else
                {
                    openTB();         
                }
            }

           
            else if (cbortprint.Text == "Balance Sheet")
            {
                if (new ClsValidation().emptytxt(cbortprint.Text))
                {
                    MessageBox.Show("Please complete your entry", "GL");
                    cbortprint.Focus();
                }
                else if (txtEnterDate.Text == "  /  /")
                {
                    MessageBox.Show("Please complete your entry", "GL");
                    txtEnterDate.Focus();
                }
                else
                {
                    deletetRE();
                    getNetIncome();
                    openBS();
                }
            }

      
            else if (cbortprint.Text == "Income Statement")
            {
                if (new ClsValidation().emptytxt(cbortprint.Text))
                {
                    MessageBox.Show("Please complete your entry", "GL");
                    cbortprint.Focus();
                }
                else if (txtBeginDate.Text == "  /  /")
                {
                    MessageBox.Show("Please complete your entry", "GL");
                    txtBeginDate.Focus();
                }
                else if (txtEndDate.Text == "  /  /")
                {
                    MessageBox.Show("Please complete your entry", "GL");
                    txtEndDate.Focus();
                }
                else if (Convert.ToDateTime(txtBeginDate.Text) > Convert.ToDateTime(txtEndDate.Text))
                {
                    MessageBox.Show("Beginning date is greater than ending date");
                    txtBeginDate.Focus();
                }
                else
                {
                    openIS();
                }
            }
        }
        private void openTB()
        {
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();
            mycommand = new SqlCommand("usp_TrialBalance2", myconnection);
            mycommand.CommandType = CommandType.StoredProcedure;
            mycommand.Parameters.Add("@ParamCNCode2", SqlDbType.VarChar).Value = cboCNCode.SelectedValue.ToString();
            mycommand.Parameters.Add("@ParamBeginDate2", SqlDbType.DateTime).Value = txtBeginDate.Text;
            mycommand.Parameters.Add("@ParamEndDate2", SqlDbType.DateTime).Value = txtEndDate.Text;

            SqlDataAdapter dscmd = new SqlDataAdapter();
            dscmd.SelectCommand = mycommand;
            DSTB DSTB1 = new DSTB();
            dscmd.Fill(DSTB1, "viewtb");
            myconnection.Close();

            CRFSTrialBalance objRpt = new CRFSTrialBalance();
            TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            ClsCompName1.ClsCompNameMain();
            vartxtcompany.Text = ClsCompName1.varcn;

            ClsCompName1.ClsCompNamebranchAddress(cboCNCode.SelectedValue.ToString());
            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            vartxtaddress.Text = ClsCompName1.plsCRaddress;

            TextObject varrpttoenterdate = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttoenterdate"];
            varrpttoenterdate.Text = "From " + txtBeginDate.Text + " To " + txtEndDate.Text;

            objRpt.SetDataSource(DSTB1.Tables[1]);
            crystalReportViewer1.ReportSource = objRpt;
            crystalReportViewer1.Refresh();
        }

        private void openIS()
        {
            string sqlstatement;

            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();
            sqlstatement = "SELECT	FCDesc, FCSort, TitleAcct, SUM(TotAmt) AS  SumTotAmt, SUM(TotNetAmt) AS  SumTotNetAmt FROM ViewIncomeStatement  WHERE TDate BETWEEN '" + txtBeginDate.Text + "' And  '" + txtEndDate.Text + "'AND CNCode = '" + cboCNCode.SelectedValue + "' GROUP BY FCDesc, FCSort, TitleAcct";

            SqlDataAdapter dscmd = new SqlDataAdapter(sqlstatement, myconnection);
            DSIncomeStatement dsis = new DSIncomeStatement();
            dscmd.Fill(dsis, "ViewIncomeStatement");
            myconnection.Close();

            CRFSIncomeStatement objRpt = new CRFSIncomeStatement();
            TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            ClsCompName1.ClsCompNameMain();
            vartxtcompany.Text = ClsCompName1.varcn;

            ClsCompName1.ClsCompNamebranchAddress(cboCNCode.SelectedValue.ToString());
            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            vartxtaddress.Text = ClsCompName1.plsCRaddress;

            TextObject varrpttoenterdate = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttoenterdate"];
            varrpttoenterdate.Text = "From " + txtBeginDate.Text + " To " + txtEndDate.Text;

            objRpt.SetDataSource(dsis.Tables[1]);
            crystalReportViewer1.ReportSource = objRpt;
            crystalReportViewer1.Refresh();

        }

        private void openBS()
        {
            string sqlstatement;
            string sqlstatement1 = "INSERT INTO tblmain1 (IC, DocNum, Voucher, UserCode, TDate, Reference, ControlNo, Remarks, CheckNo, ASMCode, DE, CNCode, void) Values (@_IC, @_DocNum, @_Voucher, @_UserCode, @_TDate, @_Reference, @_ControlNo, @_Remarks, @_CheckNo, @_ASMCode, @_DE, @_CNCode, @_void)";
            string sqlstatement2 = "INSERT INTO tblmain3 (IC, Refer, Debit, Credit, PA) Values (@_IC, @_Refer, @_Debit, @_Credit, @_PA)";

            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();
            mycommand = new SqlCommand(sqlstatement1, myconnection);
            mycommand.Parameters.Add("_IC", SqlDbType.VarChar).Value = "RET";
            mycommand.Parameters.Add("_DocNum", SqlDbType.VarChar).Value = "RET";
            mycommand.Parameters.Add("_Voucher", SqlDbType.VarChar).Value = "RET";
            mycommand.Parameters.Add("_UserCode", SqlDbType.VarChar).Value = Form1.glbluc.Text;
            mycommand.Parameters.Add("_TDate", SqlDbType.DateTime).Value = txtEnterDate.Text;
            mycommand.Parameters.Add("_Reference", SqlDbType.VarChar).Value = "A@*,^)5[K";
            mycommand.Parameters.Add("_ControlNo", SqlDbType.VarChar).Value = txtControNo.Text;
            mycommand.Parameters.Add("_Remarks", SqlDbType.VarChar).Value = "NA";
            mycommand.Parameters.Add("_CheckNo", SqlDbType.VarChar).Value = "NA";
            mycommand.Parameters.Add("_ASMCode", SqlDbType.VarChar).Value = "001";
            mycommand.Parameters.Add("_DE", SqlDbType.DateTime).Value = txtEndDate.Text;
            mycommand.Parameters.Add("_CNCode", SqlDbType.Char).Value = cboCNCode.SelectedValue;
            mycommand.Parameters.Add("_Void", SqlDbType.Bit).Value = 0;
            int n1 = mycommand.ExecuteNonQuery();

            mycommand = new SqlCommand(sqlstatement2, myconnection);
            mycommand.Parameters.Add("_IC", SqlDbType.VarChar).Value = "RET";
            mycommand.Parameters.Add("_PA", SqlDbType.VarChar).Value = "41000000000";
            mycommand.Parameters.Add("_Refer", SqlDbType.VarChar).Value = "RET";
            mycommand.Parameters.Add("_Debit", SqlDbType.Decimal).Value = 0;
            mycommand.Parameters.Add("_Credit", SqlDbType.Decimal).Value = txtNetIncome.Text;
            int n2 = mycommand.ExecuteNonQuery();

            sqlstatement = "SELECT	FCDesc, FCSort, TitleAcct, Description, Number, SUM(TotAmt) AS  SumTotAmt, SUM(TotLOAmt) AS SumTotLOAmt FROM ViewBS  WHERE TDate <= '" + txtEnterDate.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "' GROUP BY FCDesc, FCSort, TitleAcct, Description, Number";

            SqlDataAdapter dscmd = new SqlDataAdapter(sqlstatement, myconnection);
            DSBalanceSheet dsbs = new DSBalanceSheet();
            dscmd.Fill(dsbs, "ViewBS");
            myconnection.Close();    

            CRFSBalanceSheet objRpt = new CRFSBalanceSheet();
            TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            ClsCompName1.ClsCompNameMain();
            vartxtcompany.Text = ClsCompName1.varcn;

            ClsCompName1.ClsCompNamebranchAddress(cboCNCode.SelectedValue.ToString());
            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            vartxtaddress.Text = ClsCompName1.plsCRaddress;

            TextObject varrpttoenterdate = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttoenterdate"];
            varrpttoenterdate.Text = "As of " + txtEnterDate.Text;

            objRpt.SetDataSource(dsbs.Tables[1]);
            crystalReportViewer1.ReportSource = objRpt;
            crystalReportViewer1.Refresh();

            deletetRE();
            
        }

        private void deletetRE()
        {
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();
            string sqldelete1 = "DELETE FROM tblMain3 WHERE IC='RET'";
            string sqldelete2 = "DELETE FROM tblMain1 WHERE IC='RET'";

            mycommand = new SqlCommand(sqldelete1, myconnection);
            int n1 = mycommand.ExecuteNonQuery();
            mycommand = new SqlCommand(sqldelete2, myconnection);
            int n2 = mycommand.ExecuteNonQuery();
            myconnection.Close();

        }
       private void getControlNo()
        {
            try
            {
                string sql;
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                sql = "SELECT ControlNo From tblCustomer";
                mycommand = new SqlCommand(sql, myconnection);
                dr = mycommand.ExecuteReader();

                while (dr.Read())
                {
                    txtControNo.Text = dr["ControlNo"].ToString();
                }
                dr.Close();
                myconnection.Close();

            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
                myconnection.Close();
            }

        }

       private void getNetIncome()
       {
           try
           {
               string sql;
               ClsGetConnection1.ClsGetConMSSQL();
               myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
               myconnection.Open();
               sql = "SELECT SUM(TotNetAmt) AS  SumTotNetAmt FROM ViewIncomeStatement  WHERE TDate <= '" + txtEnterDate.Text + "' AND CNCode = '" + cboCNCode.SelectedValue + "'";

               mycommand = new SqlCommand(sql, myconnection);
               dr = mycommand.ExecuteReader();

               while (dr.Read())
               {
                   string varnetincome1 = dr["SumTotNetAmt"].ToString();
                   if (new ClsValidation().emptytxt(varnetincome1))
                   {
                       txtNetIncome.Text = "0";
                   }
                   else
                   {
                       double varnetincome2 = Convert.ToDouble (varnetincome1.ToString());
                       txtNetIncome.Text = varnetincome2.ToString("N2");
                   }

                  // double varnetincome = Convert.ToDouble (dr["SumTotNetAmt"].ToString());
                  // txtNetIncome.Text = varnetincome.ToString("N2");
                  

               }
               dr.Close();
               myconnection.Close();

           }
           catch (Exception ex)
           {
               System.Windows.Forms.MessageBox.Show(ex.Message);
           }
           finally
           {
               dr.Close();
               myconnection.Close();
           }

       }

        private void frmrptFS_Load(object sender, EventArgs e)
        {
            cbortprint.Items.Add("Trial Balance");
            cbortprint.Items.Add("Balance Sheet");
            cbortprint.Items.Add("Income Statement");
            buildcboCName();
            cboCNCode.SelectedValue = (ClsDefaultBranch1.plsvardb);
            getControlNo();
            DateTime VarToday = DateTime.Today;
            txtBeginDate.Text = String.Format("{0:MM/dd/yyyy}", VarToday);
            txtEndDate.Text = String.Format("{0:MM/dd/yyyy}", VarToday);
            txtEnterDate.Text = String.Format("{0:MM/dd/yyyy}", VarToday);
            this.WindowState = FormWindowState.Maximized;
        }
 
        private void buildcboCName()
        {
            cboCNCode.DataSource = null;
            ClsBuildComboBox1.ARBranch.Clear();
            ClsBuildComboBox1.ClsBuildBranch();
            this.cboCNCode.DataSource = (ClsBuildComboBox1.ARBranch);
            this.cboCNCode.DisplayMember = "Display";
            this.cboCNCode.ValueMember = "Value";
        }

        private void txtBeginDate_Leave(object sender, EventArgs e)
        {
            if (new ClsValidation().errordate(txtBeginDate.Text) == true)
            {
                MessageBox.Show("Invalid Date", "GL");
                txtBeginDate.Focus();
            }
        }

        private void txtEndDate_Leave(object sender, EventArgs e)
        {
            if (new ClsValidation().errordate(txtEndDate.Text) == true)
            {
                MessageBox.Show("Invalid Date", "GL");
                txtEndDate.Focus();
            }
        }

    

        private void cboCNCode_Validating(object sender, CancelEventArgs e)
        {
                if (new ClsValidation().emptytxt(cboCNCode.Text))
                {
                }
                else if (cboCNCode.Text != null && cboCNCode.SelectedValue == null)
                {
                    MessageBox.Show("Not found", "GL");
                    cboCNCode.Focus();
                }

        }

        private void txtEnterDate_Leave(object sender, EventArgs e)
        {
            if (new ClsValidation().errordate(txtEnterDate.Text) == true)
            {
                MessageBox.Show("Invalid Date", "GL");
                txtEnterDate.Focus();
            }

        }

        private void cbortprint_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbortprint.Text == "Trial Balance")
            {
                txtBeginDate.Visible = true;
                txtEndDate.Visible = true;
                txtEnterDate.Visible = false;

                lblBeginDate.Visible = true;
                lblEndDate.Visible = true;
                lblEnterDate.Visible = false;
            }
            else if (cbortprint.Text == "Balance Sheet")
            {
                txtBeginDate.Visible = false;
                txtEndDate.Visible = false;
                txtEnterDate.Visible = true;

                lblBeginDate.Visible = false;
                lblEndDate.Visible = false;
                lblEnterDate.Visible = true;
 
            }
            else if (cbortprint.Text == "Income Statement")
            {
                txtBeginDate.Visible = true;
                txtEndDate.Visible = true;
                txtEnterDate.Visible = false;

                lblBeginDate.Visible = true;
                lblEndDate.Visible = true;
                lblEnterDate.Visible = false;
 
            }

        }

        private void nextfieldenter1(object sender, KeyEventArgs e)
        {

        }

        private void nextfieldenter2(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.Equals(Keys.Enter))
            {
                SendKeys.Send("{TAB}");
            }

        }
    }
}
