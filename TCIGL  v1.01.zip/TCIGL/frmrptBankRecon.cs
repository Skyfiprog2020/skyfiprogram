﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using CrystalDecisions.CrystalReports.Engine;
using System.Data.SqlClient;

namespace TCIGL
{
    public partial class frmrptBankRecon : Form
    {
        SqlConnection myconnection;
        BindingSource dbind = new BindingSource();
        ClsDefaultBranch ClsDefaultBranch1 = new ClsDefaultBranch();
        ClsCompName ClsCompName1 = new ClsCompName();
        ClsBuildComboBox ClsBuildComboBox1 = new ClsBuildComboBox();
        ClsGetConnection ClsGetConnection1 = new ClsGetConnection(); 

        public frmrptBankRecon()
        {
            InitializeComponent();
        }

        private void frmrptBankRecon_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            
            if (frmBankRecon.glblTxtReport.Text == "1")
            {
                BankRecon();
            }
            else
            {
                BankReconSum();
            }
        }
    
        private void BankRecon()
        {
                    CRBankRecon objRpt = new CRBankRecon();
                    TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
                    ClsCompName1.ClsCompNamebranch();
                    vartxtcompany.Text = ClsCompName1.plsbn;

                    TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
                    vartxtaddress.Text = ClsCompName1.plsaddress;

                    TextObject varTextReportDate = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["TextReportDate"];
                    varTextReportDate.Text = "As of " + frmBankRecon.glbltxtTDate.Text;

                    TextObject varTextbookbalance = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["Textbookbalance"];
                    varTextbookbalance.Text = frmBankRecon.glbltxtBookBalance.Text;

                    TextObject varTextAdjustBookBal = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["TextAdjustBookBal"];
                    varTextAdjustBookBal.Text = frmBankRecon.glbltxtBookBalance.Text;

                    TextObject varTextbankbalance = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["Textbankbalance"];
                    varTextbankbalance.Text = frmBankRecon.glbltxtBankBalance.Text;

                    TextObject varTextOutstandingChecks = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["TextOutstandingChecks"];
                    varTextOutstandingChecks.Text = frmBankRecon.glbltxtSumCR.Text;

                    TextObject varTextDepostTransit = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["TextDepostTransit"];
                    varTextDepostTransit.Text = frmBankRecon.glbltxtSumDR.Text;

                    string stradjbal;
                    stradjbal = (double.Parse(frmBankRecon.glbltxtBankBalance.Text) + double.Parse(frmBankRecon.glbltxtSumCR.Text) + double.Parse(frmBankRecon.glbltxtSumDR.Text)).ToString("N2");
                    TextObject varTextAdjustBankBal = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["TextAdjustBankBal"];
                    varTextAdjustBankBal.Text = stradjbal;
                    
                    crystalReportViewer1.ReportSource = objRpt;
                    crystalReportViewer1.Refresh();
                }

        private void BankReconSum()
        {
            string sqlstatement;
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();
            sqlstatement = "SELECT DITOC, TDate, CustName, CheckNo, Amt FROM ViewBankReconTransact WHERE  TDate<='" + frmBankRecon.glbltxtTDate.Text + "' AND PA = '" + frmBankRecon.glblcboBank .SelectedValue.ToString() + "' AND CNCode = '" + (ClsDefaultBranch1.plsvardb) + "'";

            SqlDataAdapter dscmd = new SqlDataAdapter(sqlstatement, myconnection);
            DSBankReconSum DSBankReconSum1 = new DSBankReconSum();
            dscmd.Fill(DSBankReconSum1, "BankRecon");
            myconnection.Close();

            CRBankReconDetailed objRpt = new CRBankReconDetailed();
            TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            ClsCompName1.ClsCompNamebranch();
            vartxtcompany.Text = ClsCompName1.plsbn;

            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            vartxtaddress.Text = ClsCompName1.plsaddress;

            TextObject varTextReportDate = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["TextReportDate"];
            varTextReportDate.Text = "As of " + frmBankRecon.glbltxtTDate.Text;

            
            objRpt.SetDataSource(DSBankReconSum1.Tables[1]);
            crystalReportViewer1.ReportSource = objRpt;
            crystalReportViewer1.Refresh();
        }
    }
}
