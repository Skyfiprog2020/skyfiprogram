﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TCIGL
{
    public partial class frmEntryGeogAreaEdit : Form
    {
        private SqlDataAdapter da;
        private DataTable dataTable = null;
        private SqlConnection myconnection;
        private BindingSource bindingSource = null;
        BindingSource bsource = new BindingSource();
        //   DataSet ds = null;
        string sql;
        ClsPermission ClsPermission1 = new ClsPermission();
        ClsGetConnection ClsGetConnection1 = new ClsGetConnection(); 

        public frmEntryGeogAreaEdit()
        {
            InitializeComponent();
        }

        private void frmGAEdit_Load(object sender, EventArgs e)
        {

            ClsPermission1.ClsObjects(this.Text);
            if (new ClsValidation().emptytxt(ClsPermission1.plstxtObject))
            {
                MessageBox.Show("You do not have necessary permission to open this file", "GL");
                this.Close();
            }
            else
            {
                LoadData();
            }
 
        }

        private void LoadData()
        {
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            sql = "SELECT GACode, GADesc, TCode FROM tblGeogArea";

            da = new SqlDataAdapter(sql, myconnection);
            SqlCommandBuilder commandBuilder = new SqlCommandBuilder(da);

            dataTable = new DataTable();
            da.Fill(dataTable);
            bindingSource = new BindingSource();
            bindingSource.DataSource = dataTable;

            //tblTerritory Data Source
            string selectQueryStringtblTerritory = "SELECT TCode, TDesc FROM tblTerritory ORDER BY TDesc";
            SqlDataAdapter sqlDataAdaptertblTerritory = new SqlDataAdapter(selectQueryStringtblTerritory, myconnection);
            SqlCommandBuilder sqlCommandBuildertblTerritory = new SqlCommandBuilder(sqlDataAdaptertblTerritory);
            DataTable dataTabletblTerritory = new DataTable();
            sqlDataAdaptertblTerritory.Fill(dataTabletblTerritory);
            BindingSource bindingSourcetblTerritory = new BindingSource();
            bindingSourcetblTerritory.DataSource = dataTabletblTerritory;

            //Adding  GACode TextBox
            DataGridViewTextBoxColumn ColumnGACode = new DataGridViewTextBoxColumn();
            ColumnGACode.HeaderText = "Code";
            //ColumnGACode.Width = 80;
            ColumnGACode.DataPropertyName = "GACode";
            ColumnGACode.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnGACode.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            //ColumnGACode.Visible = false;
            ColumnGACode.ReadOnly = true;
            dgv1.Columns.Add(ColumnGACode);

            //Adding  GADesc TextBox
            DataGridViewTextBoxColumn ColumnGADesc = new DataGridViewTextBoxColumn();
            ColumnGADesc.HeaderText = "Description";
            //ColumnItem.Width = 80;
            ColumnGADesc.DataPropertyName = "GADesc";
            ColumnGADesc.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnGADesc.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            //ColumnGADesc.ReadOnly = true;
            dgv1.Columns.Add(ColumnGADesc);

            //Adding  TCode Combo
            DataGridViewComboBoxColumn ColumnTCode = new DataGridViewComboBoxColumn();
            ColumnTCode.DataPropertyName = "TCode";
            ColumnTCode.HeaderText = "Territory";
            //ColumnTCode.Width = 120;
            ColumnTCode.DataSource = bindingSourcetblTerritory;
            ColumnTCode.ValueMember = "TCode";
            ColumnTCode.DisplayMember = "TDesc";
            dgv1.Columns.Add(ColumnTCode);

            //Setting Data Source for DataGridView
            dgv1.DataSource = bindingSource;
            dgv1.AutoResizeColumns();
            dgv1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            myconnection.Close();
            this.WindowState = FormWindowState.Maximized;
            dgv1.AllowUserToAddRows = false;
        }
        private void btnclose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                da.Update(dataTable);
                MessageBox.Show("Saved", "GL");
                this.Close();

            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }

        }
    }
}
