﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace TCIGL
{
    public partial class frmEditVouchers : Form
    {
        SqlConnection myconnection;
        private SqlDataAdapter da;
        private DataTable dataTable = null;
        SqlDataReader dr;
        SqlCommand mycommand;
        BindingSource dbind = new BindingSource();
        private BindingSource bindingSource = null;
        ClsBuildComboBox ClsBuildComboBox1 = new ClsBuildComboBox();
        ClsPermission ClsPermission1 = new ClsPermission();
        ClsGetConnection ClsGetConnection1 = new ClsGetConnection();
        ClsBuildCOAComboBox ClsBuildCOAComboBox1 = new ClsBuildCOAComboBox();
        string sql;
        string selectSQL;
        public frmEditVouchers()
        {
            InitializeComponent();
        }

        private void buildcboCustCode()
        {
            cboControlNo.DataSource = null;
            ClsBuildComboBox1.ARPCN.Clear();
            ClsBuildComboBox1.ClsBuildCustControlno1();
            this.cboControlNo.DataSource = (ClsBuildComboBox1.ARPCN);
            this.cboControlNo.DisplayMember = "Display";
            this.cboControlNo.ValueMember = "Value";
        }
      
        private void buildcboPA()
        {
            //cboPA.DataSource = null;
            //ClsBuildComboBox1.ARPA.Clear();
            //ClsBuildComboBox1.ClsBuildPA();
            //this.cboPA.DataSource = (ClsBuildComboBox1.ARPA);
            //this.cboPA.DisplayMember = "Display";
            //this.cboPA.ValueMember = "Value";
            //this.cboPA.DropDownWidth = 450;
            cboPA.DataSource = null;
            ClsBuildCOAComboBox1.ARPA.Clear();
            ClsBuildCOAComboBox1.ClsBuildPA(Convert.ToBoolean(cbAccountNo.CheckState));
            this.cboPA.DataSource = (ClsBuildCOAComboBox1.ARPA);
            this.cboPA.DisplayMember = "Display";
            this.cboPA.ValueMember = "Value";
        }

     

        private void buildcboCNCode()
        {
            cboCNCode.DataSource = null;
            ClsBuildComboBox1.ARBranch.Clear();
            ClsBuildComboBox1.ClsBuildBranch();
            this.cboCNCode.DataSource = (ClsBuildComboBox1.ARBranch);
            this.cboCNCode.DisplayMember = "Display";
            this.cboCNCode.ValueMember = "Value";
        }

       

        private void frmVoucherJV_Load(object sender, EventArgs e)
        {
            ClsPermission1.ClsObjects(this.Text);
            if (new ClsValidation().emptytxt(ClsPermission1.plstxtObject))
            {
                MessageBox.Show("You do not have necessary permission to open this file", "GL");
                this.Close();
            }
            else
            {
                buildcboCNCode();
                buildcboCustCode();
                buildcboPA();
            }
        }

       
        private void cboControlNo_Validating(object sender, CancelEventArgs e)
        {
            try
            {
                if (new ClsValidation().emptytxt(cboControlNo.Text))
                {
                }
                else if (cboControlNo.Text != null && cboControlNo.SelectedValue == null)
                {
                    MessageBox.Show("Not found");
                    cboControlNo.Focus();
                }
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {

            }

        }

        private void dgv1total()
        {
            double vartxtdr = 0.00;
            double vartxtcr = 0.00;

            for (int x = 0; x < dgv1.Rows.Count ; x++)
            {
                vartxtdr += double.Parse(dgv1.Rows[x].Cells[4].FormattedValue.ToString());
            }

            for (int x = 0; x < dgv1.Rows.Count ; x++)
            {
                vartxtcr += double.Parse(dgv1.Rows[x].Cells[5].FormattedValue.ToString());
            }
            txtdrtot.Text = vartxtdr.ToString("n2");
            txtcrtot.Text = vartxtcr.ToString("n2");

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //private void trimValues(int rowIndex)
        //{
        //    DataGridViewRow row = dgv1.Rows[rowIndex];

        //    row.Cells[3].Value = double.Parse(row.Cells[3].FormattedValue.ToString().Trim()).ToString("n2");
        //    row.Cells[4].Value = double.Parse(row.Cells[4].FormattedValue.ToString().Trim()).ToString("n2");
        //}

        private void dgv1_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            if (e.Control is DataGridViewComboBoxEditingControl)
            {
                ((ComboBox)e.Control).DropDownStyle = ComboBoxStyle.DropDown;
                ((ComboBox)e.Control).AutoCompleteSource = AutoCompleteSource.ListItems;
                ((ComboBox)e.Control).AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            }
  
        }

        private void dgv1_CurrentCellDirtyStateChanged(object sender, EventArgs e)
        {
            if (dgv1.IsCurrentCellDirty)
            {
                dgv1.CommitEdit(DataGridViewDataErrorContexts.Commit);
            }
   
        }

        private void dgv1_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        {
            if (e.ColumnIndex == dgv1.Columns["txtDR"].Index)  //this is our numeric column
            {
                if (String.IsNullOrEmpty(e.FormattedValue.ToString()))// &&
                //dgv1[e.ColumnIndex, e.RowIndex].IsInEditMode)
                {
                    e.Cancel = false;

                }

                else
                {
                    double i;
                    if (!double.TryParse(Convert.ToString(e.FormattedValue), out i))
                    {
                        e.Cancel = true;
                        MessageBox.Show("Numeric only");
                    }
                }
            }


            else if (e.ColumnIndex == dgv1.Columns["txtCR"].Index)  //this is our numeric column
            {
                if (String.IsNullOrEmpty(e.FormattedValue.ToString()))// &&
                //dgv1[e.ColumnIndex, e.RowIndex].IsInEditMode)
                {
                    e.Cancel = false;

                }

                else
                {
                    double i;
                    if (!double.TryParse(Convert.ToString(e.FormattedValue), out i))
                    {
                        e.Cancel = true;
                        MessageBox.Show("Numeric only");
                    }
                }
            }


        }

        private void txtDate_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.Equals(Keys.Enter))
            {
                SendKeys.Send("{TAB}");
            }
        }

        private void txtreference_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.Equals(Keys.Enter))
            {
                SendKeys.Send("{TAB}");
            }
        }

        private void cboControlNo_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.Equals(Keys.Enter))
            {
                SendKeys.Send("{TAB}");
            }
        }

        private void txtRemarks_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.Equals(Keys.Enter))
            {
                SendKeys.Send("{TAB}");
            }
        }

 
        private void dgv1_UserDeletedRow(object sender, DataGridViewRowEventArgs e)
        {
            dgv1total();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                string Sqlstatement;
                double vartxtdrtot = double.Parse((txtdrtot.Text).ToString());
                double vartxtcrtot = double.Parse((txtcrtot.Text).ToString());

                if (new ClsValidation().emptytxt(txtTDate.Text) || new ClsValidation().emptytxt(cboControlNo.Text) || new ClsValidation().emptytxt(txtRemarks.Text))
                {
                    MessageBox.Show("Please complete your entry", "POS");
                    txtTDate.Focus();
                }
                else if (vartxtdrtot != vartxtcrtot)
                {
                    MessageBox.Show("Not balance", "GL");
                    txtRemarks.Focus();
                }

                else
                {
                    ClsGetConnection1.ClsGetConMSSQL();
                    myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                    myconnection.Open();
                    if (cboVoucher.Text=="PO")
                    {
                       
                        Sqlstatement = "UPDATE tblPO1 SET  Void=@_Void WHERE IC ='" + txtIC.Text + "'";
                        mycommand = new SqlCommand(Sqlstatement, myconnection);
                 
                        mycommand.Parameters.Add("_Void", SqlDbType.Bit).Value = cbVoid.CheckState;

                        int n2 = mycommand.ExecuteNonQuery();
                        //myconnection.Close();
                    }
                    else if (cboVoucher.Text=="PI")
                    {
                        Sqlstatement = "UPDATE tblPI1 SET  Void=@_Void WHERE IC ='" + txtIC.Text + "'";
                        mycommand = new SqlCommand(Sqlstatement, myconnection);

                        mycommand.Parameters.Add("_Void", SqlDbType.Bit).Value = cbVoid.CheckState;

                        int n3 = mycommand.ExecuteNonQuery();
                    }
                   else
                    {
                        Sqlstatement = "UPDATE tblMain1 SET  Void=@_Void WHERE IC ='" + txtIC.Text + "'";
                    }
                   
                    mycommand = new SqlCommand(Sqlstatement, myconnection);
                    //mycommand.Parameters.Add("_ControlNo", SqlDbType.VarChar).Value = cboControlNo.SelectedValue.ToString();
                    //mycommand.Parameters.Add("_TDate", SqlDbType.SmallDateTime).Value = txtTDate.Text;
                    //mycommand.Parameters.Add("_Remarks", SqlDbType.VarChar).Value = txtRemarks.Text;
                    //mycommand.Parameters.Add("_SMCode", SqlDbType.VarChar).Value = cboSMCode.SelectedValue.ToString();
                    //mycommand.Parameters.Add("_Reference", SqlDbType.VarChar).Value = txtreference.Text;
                    //mycommand.Parameters.Add("_CAmount", SqlDbType.VarChar).Value = txtCAmount.Text;
                    mycommand.Parameters.Add("_Void", SqlDbType.Bit).Value = cbVoid.CheckState;

                    int n1 = mycommand.ExecuteNonQuery();

                    //DataGridViewRow row1 = null;
                    //for (int x = 0; x < dgv1.Rows.Count; x++)
                    //{
                    //    row1 = dgv1.Rows[x];
                    //    string sqlstatementupdate = "UPDATE tblMain3 set PA=@_PA, Refer=@_Refer, Debit=@_Debit, Credit=@_Credit WHERE Num ='" + row1.Cells[4].FormattedValue.ToString() + "' AND IC =  '"+ txtIC.Text + "'";
                    //    mycommand = new SqlCommand(sqlstatementupdate, myconnection);
                    //    mycommand.Parameters.Add("_PA", SqlDbType.VarChar).Value = dgv1.Rows[x].Cells[0].Value.ToString();
                    //    mycommand.Parameters.Add("_Refer", SqlDbType.VarChar).Value = dgv1.Rows[x].Cells[1].Value.ToString();
                    //    mycommand.Parameters.Add("_Debit", SqlDbType.Money).Value = dgv1.Rows[x].Cells[2].Value.ToString();
                    //    mycommand.Parameters.Add("_Credit", SqlDbType.Money).Value = dgv1.Rows[x].Cells[3].Value.ToString();
                    //    int n4 = mycommand.ExecuteNonQuery();
                    //}
                    myconnection.Close();
                    //dr.Close();
                     MessageBox.Show("Saved", "GL");
                    //   this.Close();
                }
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
                myconnection.Close();
            }
        }

       

        private void txtTDate_Leave(object sender, EventArgs e)
        {
            if (new ClsValidation().errordate(txtTDate.Text) == true)
            {
                MessageBox.Show("Invalid Date", "GL");
                txtTDate.Focus();
            }
        }

        private void cboAccountCode_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.Equals(Keys.Enter))
            {
                SendKeys.Send("{TAB}");
            }

        }

        private void txtSearch_Validating(object sender, CancelEventArgs e)
        {
            //if (new ClsValidation().emptytxt(txtSearch.Text))
            //{
            //    //    MessageBox.Show("Search is empty", "GL");
            //}
            //else
            //{
            //    dgv1.DataSource = null;
            //    dgv1.Columns.Clear();
            //    showdata();
            //    showsearchdata();
            //    dgv1total();
            //}
            if (cboVoucher.Text == "PO")
            {
                showreferencePO();
            }
            else if (cboVoucher.Text=="PI")
            {
                showreferencePI();
            }
            else
            {
                showreference();
            }
        }

        private void showdata()
        {
            // Define ADO.NET objects.

            if (cboVoucher.Text == "APV")
            {
                selectSQL = "SELECT * FROM ViewBookAPV ";
                selectSQL += "WHERE Reference='" + txtSearch.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "'";
            }
            else if (cboVoucher.Text == "ARV")
            {
                selectSQL = "SELECT * FROM ViewBookARV ";
                selectSQL += "WHERE Reference='" + txtSearch.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "'";
            }
            else if (cboVoucher.Text == "CI")
            {
                selectSQL = "SELECT * FROM ViewBookCI ";
                selectSQL += "WHERE Reference='" + txtSearch.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "'";
            }
            else if (cboVoucher.Text == "AS")
            {
                selectSQL = "SELECT * FROM ViewBookAS ";
                selectSQL += "WHERE Reference='" + txtSearch.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "'";
            }
            else if (cboVoucher.Text == "CS")
            {
                selectSQL = "SELECT * FROM ViewBookCS ";
                selectSQL += "WHERE Reference='" + txtSearch.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "'";
            }
            else if (cboVoucher.Text == "OR")
            {
                selectSQL = "SELECT * FROM ViewBookOR ";
                selectSQL += "WHERE Reference='" + txtSearch.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "'";
            }
            else if (cboVoucher.Text == "PD")
            {
                selectSQL = "SELECT * FROM ViewBookPD ";
                selectSQL += "WHERE Reference='" + txtSearch.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "'";
            }
            else if (cboVoucher.Text == "RTS")
            {
                selectSQL = "SELECT * FROM ViewBookRTS ";
                selectSQL += "WHERE Reference='" + txtSearch.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "'";
            }
            else if (cboVoucher.Text == "JV")
            {
                selectSQL = "SELECT * FROM ViewBookJV ";
                selectSQL += "WHERE Reference='" + txtSearch.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "'";
            }
            else if (cboVoucher.Text == "CV")
            {
                selectSQL = "SELECT * FROM ViewBookCV ";
                selectSQL += "WHERE Reference='" + txtSearch.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "'";
            }
            else if (cboVoucher.Text == "CRV")
            {
                selectSQL = "SELECT * FROM ViewBookCRV ";
                selectSQL += "WHERE Reference='" + txtSearch.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "'";
            }
            else if (cboVoucher.Text == "RV")
            {
                selectSQL = "SELECT * FROM ViewBookRV ";
                selectSQL += "WHERE Reference='" + txtSearch.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "'";
            }
            else if (cboVoucher.Text == "RS")
            {
                selectSQL = "SELECT * FROM ViewBookRS ";
                selectSQL += "WHERE Reference='" + txtSearch.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "'";
            }
            else if (cboVoucher.Text == "WS")
            {
                selectSQL = "SELECT * FROM ViewBookWS ";
                selectSQL += "WHERE Reference='" + txtSearch.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "'";
            }
            else if (cboVoucher.Text == "PS")
            {
                selectSQL = "SELECT * FROM ViewBookPS ";
                selectSQL += "WHERE Reference='" + txtSearch.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "'";
            }

            // Try to open database and read information.
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = new SqlCommand(selectSQL, myconnection);
                dr = mycommand.ExecuteReader();
                dr.Read();

                
                //// Fill the controls.
                DateTime dtTD = Convert.ToDateTime(dr["TDate"].ToString());
                txtTDate.Text = String.Format("{0:MM/dd/yyyy}", dtTD);
                txtDocNum.Text = dr["DocNum"].ToString();
                txtreference.Text = dr["Reference"].ToString();
                cboControlNo.SelectedValue = dr["ControlNo"].ToString();
                txtRemarks.Text = dr["Remarks"].ToString();
                txtIC.Text = dr["IC"].ToString();
                //chkContract.Checked = (bool)reader["contract"];

                myconnection.Close();
                dr.Close();

            }
            catch (Exception)
            {
                MessageBox.Show("Number cannot be found", "GL");
                cboVoucher.Focus();
            }
            finally
            {
                myconnection.Close();
            }

        }
        

        private void showdataPO()
        {
            // Define ADO.NET objects.

            if (cboVoucher.Text == "PO")
            {
                selectSQL = "SELECT * FROM ViewDetailsBookPO ";
                selectSQL += "WHERE Reference='" + txtSearch.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "'";
            }
          
            // Try to open database and read information.
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = new SqlCommand(selectSQL, myconnection);
                dr = mycommand.ExecuteReader();
                dr.Read();

                //// Fill the controls.
                DateTime dtTD = Convert.ToDateTime(dr["TDate"].ToString());
                txtTDate.Text = String.Format("{0:MM/dd/yyyy}", dtTD);
                //txtDocNum.Text = dr["DocNum"].ToString();
                txtreference.Text = dr["Reference"].ToString();
                cboControlNo.SelectedValue = dr["ControlNo"].ToString();
                txtRemarks.Text = dr["Remarks"].ToString();
                txtIC.Text = dr["IC"].ToString();
                //chkContract.Checked = (bool)reader["contract"];

                myconnection.Close();
                dr.Close();

            }
            catch (Exception)
            {
                MessageBox.Show("Number cannot be found", "GL");
                cboVoucher.Focus();
            }
            finally
            {
                myconnection.Close();
            }

        }
        private void showdataPI()
        {
            // Define ADO.NET objects.

            if (cboVoucher.Text == "PI")
            {
                selectSQL = "SELECT * FROM ViewBookPI ";
                selectSQL += "WHERE Reference ='" + txtSearch.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "'";
            }

            // Try to open database and read information.
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = new SqlCommand(selectSQL, myconnection);
                dr = mycommand.ExecuteReader();
                dr.Read();

                //// Fill the controls.
                DateTime dtTD = Convert.ToDateTime(dr["TDate"].ToString());
                txtTDate.Text = String.Format("{0:MM/dd/yyyy}", dtTD);
                txtDocNum.Text = dr["DocNum"].ToString();
                txtreference.Text = dr["Reference"].ToString();
                cboControlNo.SelectedValue = dr["ControlNo"].ToString();
                txtRemarks.Text = dr["Remarks"].ToString();
                txtIC.Text = dr["IC"].ToString();
                //chkContract.Checked = (bool)reader["contract"];

                myconnection.Close();
                dr.Close();

            }
            catch (Exception)
            {
                MessageBox.Show("Number cannot be found", "GL");
                cboVoucher.Focus();
            }
            finally
            {
                myconnection.Close();
            }

        }
        private void showsearchdata()
        {
           
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            if (cboVoucher.Text == "APV")
            {
                sql = "SELECT PA, AT, ActRemarks, Refer, Debit, Credit, SIT FROM ViewBookAPV WHERE Reference = '" + txtSearch.Text + "' AND CNCode= '" + cboCNCode.SelectedValue.ToString() + "'";
            }
            else if (cboVoucher.Text == "ARV")
            {
                sql = "SELECT PA, AT, ActRemarks, Refer, Debit, Credit, SIT FROM ViewBookARV WHERE Reference = '" + txtSearch.Text + "' AND CNCode= '" + cboCNCode.SelectedValue.ToString() + "'";
            }
            else if (cboVoucher.Text == "CI")
            {
                sql = "SELECT PA, AT, ActRemarks, Refer, Debit, Credit, SIT FROM ViewBookCI WHERE Reference = '" + txtSearch.Text + "' AND CNCode= '" + cboCNCode.SelectedValue.ToString() + "'";
            }
            else if (cboVoucher.Text == "AS")
            {
                sql = "SELECT PA, AT, ActRemarks, Refer, Debit, Credit, SIT FROM ViewBookAS WHERE Reference = '" + txtSearch.Text + "' AND CNCode= '" + cboCNCode.SelectedValue.ToString() + "'";
            }
            else if (cboVoucher.Text == "CRV")
            {
                sql = "SELECT PA, AT, ActRemarks, Refer, Debit, Credit, SIT FROM ViewBookCRV WHERE Reference = '" + txtSearch.Text + "' AND CNCode= '" + cboCNCode.SelectedValue.ToString() + "'";
            }
            else if (cboVoucher.Text == "CS")
            {
                sql = "SELECT PA, AT, ActRemarks, Refer, Debit, Credit, SIT FROM ViewBookCS WHERE Reference = '" + txtSearch.Text + "' AND CNCode= '" + cboCNCode.SelectedValue.ToString() + "'";
            }
            else if (cboVoucher.Text == "OR")
            {
                sql = "SELECT PA, AT, ActRemarks, Refer, Debit, Credit, SIT FROM ViewBookOR WHERE Reference = '" + txtSearch.Text + "' AND CNCode= '" + cboCNCode.SelectedValue.ToString() + "'";
            }
            else if (cboVoucher.Text == "PD")
            {
                sql = "SELECT PA, AT, ActRemarks, Refer, Debit, Credit, SIT FROM ViewBookPD WHERE Reference = '" + txtSearch.Text + "' AND CNCode= '" + cboCNCode.SelectedValue.ToString() + "'";
            }
            else if (cboVoucher.Text == "RS")
            {
                sql = "SELECT PA, AT, ActRemarks, Refer, Debit, Credit, SIT FROM ViewBookRS WHERE Reference = '" + txtSearch.Text + "' AND CNCode= '" + cboCNCode.SelectedValue.ToString() + "'";
            }
            else if (cboVoucher.Text == "RTS")
            {
                sql = "SELECT PA, AT, ActRemarks, Refer, Debit, Credit, SIT FROM ViewBookRTS WHERE Reference = '" + txtSearch.Text + "' AND CNCode= '" + cboCNCode.SelectedValue.ToString() + "'";
            }
            else if (cboVoucher.Text == "JV")
            {
                sql = "SELECT PA, AT, ActRemarks, Refer, Debit, Credit, SIT FROM ViewBookJV WHERE Reference = '" + txtSearch.Text + "' AND CNCode= '" + cboCNCode.SelectedValue.ToString() + "'";
            }
            else if (cboVoucher.Text == "CV")
            {
                sql = "SELECT PA, AT, ActRemarks, Refer, Debit, Credit, SIT FROM ViewBookCV WHERE Reference = '" + txtSearch.Text + "' AND CNCode= '" + cboCNCode.SelectedValue.ToString() + "'";
            }
            else if (cboVoucher.Text == "RV")
            {
                sql = "SELECT PA, AT, ActRemarks, Refer, Debit, Credit, SIT FROM ViewBookRV WHERE Reference = '" + txtSearch.Text + "' AND CNCode= '" + cboCNCode.SelectedValue.ToString() + "'";
            }
            else if (cboVoucher.Text == "WS")
            {
                sql = "SELECT PA, AT, ActRemarks, Refer, Debit, Credit, SIT FROM ViewBookWS WHERE Reference = '" + txtSearch.Text + "' AND CNCode= '" + cboCNCode.SelectedValue.ToString() + "'";
            }
            else if (cboVoucher.Text == "PS")
            {
                sql = "SELECT PA, AT, ActRemarks, Refer, Debit, Credit, SIT FROM ViewBookPS WHERE Reference = '" + txtSearch.Text + "' AND CNCode= '" + cboCNCode.SelectedValue.ToString() + "'";
            }

            da = new SqlDataAdapter(sql, myconnection);
            SqlCommandBuilder commandBuilder = new SqlCommandBuilder(da);

            dataTable = new DataTable();
            da.Fill(dataTable);
            bindingSource = new BindingSource();
            bindingSource.DataSource = dataTable;


            //PA Data Source
            string selectQueryStringPA = "SELECT PA, PA AS PA1 FROM viewpa";
            SqlDataAdapter sqlDataAdapterPA = new SqlDataAdapter(selectQueryStringPA, myconnection);
            SqlCommandBuilder sqlCommandBuildergroup = new SqlCommandBuilder(sqlDataAdapterPA);
            DataTable dataTableItem = new DataTable();
            sqlDataAdapterPA.Fill(dataTableItem);
            BindingSource bindingSourcegroup = new BindingSource();
            bindingSourcegroup.DataSource = dataTableItem;

            //Adding  PA Combo
            DataGridViewComboBoxColumn ColumnPA = new DataGridViewComboBoxColumn();
            ColumnPA.DataPropertyName = "PA";
            ColumnPA.HeaderText = "Account Number";
            ColumnPA.Width = 120;

            ColumnPA.DataSource = bindingSourcegroup;
            ColumnPA.ValueMember = "PA";
            ColumnPA.DisplayMember = "PA1";
            ColumnPA.ReadOnly = false;
            dgv1.Columns.Add(ColumnPA);

            //Adding  AT TextBox
            DataGridViewTextBoxColumn ColumnAT = new DataGridViewTextBoxColumn();
            ColumnAT.HeaderText = "Account Title";
            ColumnAT.Width = 490;
            ColumnAT.DataPropertyName = "AT";
            ColumnAT.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            ColumnAT.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnAT.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            //ColumnAT.Visible = false;
            ColumnAT.ReadOnly = false;
            dgv1.Columns.Add(ColumnAT);

            //Adding  ActRemarks TextBox
            DataGridViewTextBoxColumn ColumnActRemarks = new DataGridViewTextBoxColumn();
            ColumnActRemarks.HeaderText = "ActRemarks";
            ColumnActRemarks.Width = 160;
            ColumnActRemarks.DataPropertyName = "ActRemarks";
            ColumnActRemarks.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnActRemarks.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            //ColumnActRemarks.Visible = false;
            ColumnActRemarks.ReadOnly = false;
            dgv1.Columns.Add(ColumnActRemarks);

            //Adding  Refer TextBox
            DataGridViewTextBoxColumn ColumnRefer = new DataGridViewTextBoxColumn();
            ColumnRefer.HeaderText = "Reference";
            ColumnRefer.Width = 100;
            ColumnRefer.DataPropertyName = "Refer";
            ColumnRefer.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnRefer.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            //ColumnRefer.Visible = false;
            ColumnRefer.ReadOnly = false;
            dgv1.Columns.Add(ColumnRefer);

            //Adding  Debit TextBox
            DataGridViewTextBoxColumn ColumnDR = new DataGridViewTextBoxColumn();
            ColumnDR.HeaderText = "Debit";
            ColumnDR.Width = 80;
            ColumnDR.DataPropertyName = "Debit";
            ColumnDR.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnDR.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnDR.ReadOnly = false;
            dgv1.Columns.Add(ColumnDR);

            //Adding  Credit TextBox
            DataGridViewTextBoxColumn ColumnCR = new DataGridViewTextBoxColumn();
            ColumnCR.HeaderText = "Credit";
            ColumnCR.Width = 80;
            ColumnCR.DataPropertyName = "Credit";
            ColumnCR.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnCR.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnCR.ReadOnly = false;
            dgv1.Columns.Add(ColumnCR);

            //Adding  SIT checkbox
            DataGridViewCheckBoxColumn ColumnSIT = new DataGridViewCheckBoxColumn();
            ColumnSIT.HeaderText = "SIT";
            ColumnSIT.Width = 50;
            ColumnSIT.DataPropertyName = "SIT";
            ColumnSIT.FalseValue = 0;
            ColumnSIT.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            ColumnSIT.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgv1.Columns.Add(ColumnSIT);

            //dgv1.Columns[0].Name = "cboPA";
            //dgv1.Columns[1].Name = "txtrefer";
            //dgv1.Columns[2].Name = "txtDR";
            //dgv1.Columns[3].Name = "txtCR";
           
            //Setting Data Source for DataGridView
            dgv1.DataSource = bindingSource;
            //            dgv1.AutoResizeColumns();
            //            dgv1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            myconnection.Close();
            //            this.WindowState = FormWindowState.Maximized;
            dgv1.AllowUserToAddRows = false;
            dgv1.Columns[4].DefaultCellStyle.Format = "N2";
            dgv1.Columns[5].DefaultCellStyle.Format = "N2";

        }

        private void showreference()
        {
            dgvSearch.DataSource = null;
            dgvSearch.Columns.Clear();
            string sql;
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            sql = "SELECT Reference, DocNum FROM tblMain1 WHERE Voucher = '" + cboVoucher.Text + "' AND Reference like '%' + '" + txtSearch.Text + "' + '%' AND CNCode='" + cboCNCode.SelectedValue.ToString() + "' AND Void=0";
            da = new SqlDataAdapter(sql, myconnection);
            SqlCommandBuilder commandBuilder = new SqlCommandBuilder(da);            
            dataTable = new DataTable();
            da.Fill(dataTable);
            bindingSource = new BindingSource();
            bindingSource.DataSource = dataTable;

            //Adding  Reference TextBox
            DataGridViewTextBoxColumn ColumnReference = new DataGridViewTextBoxColumn();
            ColumnReference.HeaderText = "Reference";
            ColumnReference.Width = 150;
            ColumnReference.DataPropertyName = "Reference";
            ColumnReference.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnReference.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            //ColumnReference.Visible = false;
            ColumnReference.ReadOnly = true;
            dgvSearch.Columns.Add(ColumnReference);

            DataGridViewTextBoxColumn ColumnDocNum = new DataGridViewTextBoxColumn();
            ColumnDocNum.HeaderText = "DocNum";
            ColumnDocNum.Width = 150;
            ColumnDocNum.DataPropertyName = "DocNum";
            ColumnDocNum.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnDocNum.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            //ColumnReference.Visible = false;
            ColumnDocNum.ReadOnly = true;
            ColumnDocNum.Visible = false;
            dgvSearch.Columns.Add(ColumnDocNum);
     
            //Setting Data Source for DataGridView
            dgvSearch.DataSource = bindingSource;
            //            dgv1.AutoResizeColumns();
            //            dgv1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
  
            myconnection.Close();

        }

        private void showreferencePO()
        {
            dgvSearch.DataSource = null;
            dgvSearch.Columns.Clear();
            string sql;
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            sql = "SELECT Reference, DocNum FROM tblPO1 WHERE Voucher = '" + cboVoucher.Text + "' AND Reference like '%' + '" + txtSearch.Text + "' + '%' AND CNCode='" + cboCNCode.SelectedValue.ToString() + "' AND Void=0";
            da = new SqlDataAdapter(sql, myconnection);
            SqlCommandBuilder commandBuilder = new SqlCommandBuilder(da);
            dataTable = new DataTable();
            da.Fill(dataTable);
            bindingSource = new BindingSource();
            bindingSource.DataSource = dataTable;

            //Adding  Reference TextBox
            DataGridViewTextBoxColumn ColumnReference = new DataGridViewTextBoxColumn();
            ColumnReference.HeaderText = "Reference";
            ColumnReference.Width = 150;
            ColumnReference.DataPropertyName = "Reference";
            ColumnReference.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnReference.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            //ColumnReference.Visible = false;
            ColumnReference.ReadOnly = true;
            dgvSearch.Columns.Add(ColumnReference);

            DataGridViewTextBoxColumn ColumnDocNum = new DataGridViewTextBoxColumn();
            ColumnDocNum.HeaderText = "DocNum";
            ColumnDocNum.Width = 150;
            ColumnDocNum.DataPropertyName = "DocNum";
            ColumnDocNum.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnDocNum.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            //ColumnReference.Visible = false;
            ColumnDocNum.ReadOnly = true;
            ColumnDocNum.Visible = false;
            dgvSearch.Columns.Add(ColumnDocNum);

            //Setting Data Source for DataGridView
            dgvSearch.DataSource = bindingSource;
            //            dgv1.AutoResizeColumns();
            //            dgv1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;

            myconnection.Close();

        }
        private void showreferencePI()
        {
            dgvSearch.DataSource = null;
            dgvSearch.Columns.Clear();
            string sql;
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            sql = "SELECT Reference, DocNum FROM tblPI1 WHERE Voucher = '" + cboVoucher.Text + "' AND Reference like '%' + '" + txtSearch.Text + "' + '%' AND CNCode='" + cboCNCode.SelectedValue.ToString() + "' AND Void=0";
            da = new SqlDataAdapter(sql, myconnection);
            SqlCommandBuilder commandBuilder = new SqlCommandBuilder(da);
            dataTable = new DataTable();
            da.Fill(dataTable);
            bindingSource = new BindingSource();
            bindingSource.DataSource = dataTable;

            //Adding  Reference TextBox
            DataGridViewTextBoxColumn ColumnReference = new DataGridViewTextBoxColumn();
            ColumnReference.HeaderText = "Reference";
            ColumnReference.Width = 150;
            ColumnReference.DataPropertyName = "Reference";
            ColumnReference.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnReference.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            //ColumnReference.Visible = false;
            ColumnReference.ReadOnly = true;
            dgvSearch.Columns.Add(ColumnReference);

            DataGridViewTextBoxColumn ColumnDocNum = new DataGridViewTextBoxColumn();
            ColumnDocNum.HeaderText = "DocNum";
            ColumnDocNum.Width = 150;
            ColumnDocNum.DataPropertyName = "DocNum";
            ColumnDocNum.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnDocNum.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            //ColumnReference.Visible = false;
            ColumnDocNum.ReadOnly = true;
            ColumnDocNum.Visible = false;
            dgvSearch.Columns.Add(ColumnDocNum);

            //Setting Data Source for DataGridView
            dgvSearch.DataSource = bindingSource;
            //            dgv1.AutoResizeColumns();
            //            dgv1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;

            myconnection.Close();

        }

        private void LoadPO()
        {
            string sql;
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            sql = "SELECT StockNumber, StockDesc, PIn, UM, UP, Cost FROM ViewDetailsBookPO WHERE DocNum = '" + dgvSearch.CurrentRow.Cells[1].Value.ToString() + "'";

            da = new SqlDataAdapter(sql, myconnection);
            SqlCommandBuilder commandBuilder = new SqlCommandBuilder(da);

            dataTable = new DataTable();
            da.Fill(dataTable);
            bindingSource = new BindingSource();
            bindingSource.DataSource = dataTable;


            //Adding  Product Code TextBox
            DataGridViewTextBoxColumn ColumnSN = new DataGridViewTextBoxColumn();
            ColumnSN.HeaderText = "Product Code";
            ColumnSN.Width = 140;
            ColumnSN.DataPropertyName = "StockNumber";
            ColumnSN.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnSN.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnSN.ReadOnly = true;
            dgvStocks.Columns.Add(ColumnSN);


            //Adding  Product Description TextBox
            DataGridViewTextBoxColumn ColumnItem = new DataGridViewTextBoxColumn();
            ColumnItem.HeaderText = "Description";
            ColumnItem.Width = 270;
            ColumnItem.DataPropertyName = "StockDesc";
            ColumnItem.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            ColumnItem.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnItem.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnItem.ReadOnly = true;
            dgvStocks.Columns.Add(ColumnItem);

            //Adding  Quantity TextBox
            DataGridViewTextBoxColumn ColumnPIn = new DataGridViewTextBoxColumn();
            ColumnPIn.HeaderText = "Quantity";
            ColumnPIn.Width = 120;
            ColumnPIn.DataPropertyName = "PIn";
            ColumnPIn.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnPIn.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnPIn.ReadOnly = true;
            dgvStocks.Columns.Add(ColumnPIn);

            DataGridViewTextBoxColumn ColumnUM = new DataGridViewTextBoxColumn();
            ColumnUM.HeaderText = "UM";
            ColumnUM.Width = 60;
            ColumnUM.DataPropertyName = "UM";
            ColumnUM.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnUM.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnUM.ReadOnly = true;
            dgvStocks.Columns.Add(ColumnUM);

            //Adding  UP TextBox
            DataGridViewTextBoxColumn ColumnUP = new DataGridViewTextBoxColumn();
            ColumnUP.HeaderText = "Unit Price";
            ColumnUP.Width = 120;
            ColumnUP.DataPropertyName = "UP";
            ColumnUP.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnUP.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnUP.ReadOnly = true;
            dgvStocks.Columns.Add(ColumnUP);

            //Adding  Discount TextBox
            DataGridViewTextBoxColumn ColumnCost = new DataGridViewTextBoxColumn();
            ColumnCost.HeaderText = "Total Cost";
            ColumnCost.Width = 120;
            ColumnCost.DataPropertyName = "Cost";
            ColumnCost.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnCost.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnCost.ReadOnly = true;
            dgvStocks.Columns.Add(ColumnCost);


            dgvStocks.Columns[0].Name = "StockNumber";
            dgvStocks.Columns[1].Name = "Item";
            dgvStocks.Columns[2].Name = "PIn";
            dgvStocks.Columns[3].Name = "UM";
            dgvStocks.Columns[4].Name = "Unit Price";
            dgvStocks.Columns[5].Name = "Total Cost";



            dgvStocks.Columns[2].DefaultCellStyle.Format = "N2";
            dgvStocks.Columns[4].DefaultCellStyle.Format = "N4";
            dgvStocks.Columns[5].DefaultCellStyle.Format = "N4";
            //dgvStocks.Columns[6].DefaultCellStyle.Format = "N2";
            //Setting Data Source for DataGridView
            dgvStocks.DataSource = bindingSource;
            myconnection.Close();
            dgvStocks.AllowUserToAddRows = false;
            //dgv1total();
        }
        private void LoadPI()
        {
            string sql;
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            sql = "SELECT StockNumber, StockDesc, POut, UM, UP FROM ViewBookPI WHERE DocNum = '" + dgvSearch.CurrentRow.Cells[1].Value.ToString() + "'";

            da = new SqlDataAdapter(sql, myconnection);
            SqlCommandBuilder commandBuilder = new SqlCommandBuilder(da);

            dataTable = new DataTable();
            da.Fill(dataTable);
            bindingSource = new BindingSource();
            bindingSource.DataSource = dataTable;


            //Adding  Product Code TextBox
            DataGridViewTextBoxColumn ColumnSN = new DataGridViewTextBoxColumn();
            ColumnSN.HeaderText = "Product Code";
            ColumnSN.Width = 140;
            ColumnSN.DataPropertyName = "StockNumber";
            ColumnSN.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnSN.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnSN.ReadOnly = true;
            dgvStocks.Columns.Add(ColumnSN);


            //Adding  Product Description TextBox
            DataGridViewTextBoxColumn ColumnItem = new DataGridViewTextBoxColumn();
            ColumnItem.HeaderText = "Description";
            ColumnItem.Width = 270;
            ColumnItem.DataPropertyName = "StockDesc";
            ColumnItem.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            ColumnItem.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnItem.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnItem.ReadOnly = true;
            dgvStocks.Columns.Add(ColumnItem);

            //Adding  Quantity TextBox
            DataGridViewTextBoxColumn ColumnPOut = new DataGridViewTextBoxColumn();
            ColumnPOut.HeaderText = "Quantity";
            ColumnPOut.Width = 120;
            ColumnPOut.DataPropertyName = "POut";
            ColumnPOut.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnPOut.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnPOut.ReadOnly = true;
            dgvStocks.Columns.Add(ColumnPOut);

            DataGridViewTextBoxColumn ColumnUM = new DataGridViewTextBoxColumn();
            ColumnUM.HeaderText = "UM";
            ColumnUM.Width = 60;
            ColumnUM.DataPropertyName = "UM";
            ColumnUM.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnUM.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnUM.ReadOnly = true;
            dgvStocks.Columns.Add(ColumnUM);

            //Adding  UP TextBox
            DataGridViewTextBoxColumn ColumnUP = new DataGridViewTextBoxColumn();
            ColumnUP.HeaderText = "Unit Price";
            ColumnUP.Width = 120;
            ColumnUP.DataPropertyName = "UP";
            ColumnUP.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnUP.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnUP.ReadOnly = true;
            dgvStocks.Columns.Add(ColumnUP);

            //Adding  Discount TextBox
            //DataGridViewTextBoxColumn ColumnCost = new DataGridViewTextBoxColumn();
            //ColumnCost.HeaderText = "Total Cost";
            //ColumnCost.Width = 120;
            //ColumnCost.DataPropertyName = "Cost";
            //ColumnCost.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
            //ColumnCost.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            //ColumnCost.ReadOnly = true;
            //dgvStocks.Columns.Add(ColumnCost);


            dgvStocks.Columns[0].Name = "StockNumber";
            dgvStocks.Columns[1].Name = "Item";
            dgvStocks.Columns[2].Name = "PIn";
            dgvStocks.Columns[3].Name = "UM";
            dgvStocks.Columns[4].Name = "Unit Price";
            //dgvStocks.Columns[5].Name = "Total Cost";



            dgvStocks.Columns[2].DefaultCellStyle.Format = "N2";
            dgvStocks.Columns[4].DefaultCellStyle.Format = "N4";
            //dgvStocks.Columns[5].DefaultCellStyle.Format = "N4";
            //dgvStocks.Columns[6].DefaultCellStyle.Format = "N2";
            //Setting Data Source for DataGridView
            dgvStocks.DataSource = bindingSource;
            myconnection.Close();
            dgvStocks.AllowUserToAddRows = false;
            //dgv1total();
        }
        private void LoadPD()
        {
            string sql;
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            sql = "SELECT StockNumber, StockDesc, PIn, UM, UP, Cost FROM ViewDetailsBookPD WHERE DocNum = '" + dgvSearch.CurrentRow.Cells[1].FormattedValue.ToString() + "'";

            da = new SqlDataAdapter(sql, myconnection);
            SqlCommandBuilder commandBuilder = new SqlCommandBuilder(da);

            dataTable = new DataTable();
            da.Fill(dataTable);
            bindingSource = new BindingSource();
            bindingSource.DataSource = dataTable;


            //Adding  Product Code TextBox
            DataGridViewTextBoxColumn ColumnSN = new DataGridViewTextBoxColumn();
            ColumnSN.HeaderText = "Product Code";
            ColumnSN.Width = 140;
            ColumnSN.DataPropertyName = "StockNumber";
            ColumnSN.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnSN.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnSN.ReadOnly = true;
            dgvStocks.Columns.Add(ColumnSN);


            //Adding  Product Description TextBox
            DataGridViewTextBoxColumn ColumnItem = new DataGridViewTextBoxColumn();
            ColumnItem.HeaderText = "Description";
            ColumnItem.Width = 270;
            ColumnItem.DataPropertyName = "StockDesc";
            ColumnItem.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            ColumnItem.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnItem.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnItem.ReadOnly = true;
            dgvStocks.Columns.Add(ColumnItem);

            //Adding  Quantity TextBox
            DataGridViewTextBoxColumn ColumnPIn = new DataGridViewTextBoxColumn();
            ColumnPIn.HeaderText = "Quantity";
            ColumnPIn.Width = 120;
            ColumnPIn.DataPropertyName = "PIn";
            ColumnPIn.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnPIn.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnPIn.ReadOnly = true;
            dgvStocks.Columns.Add(ColumnPIn);

            DataGridViewTextBoxColumn ColumnUM = new DataGridViewTextBoxColumn();
            ColumnUM.HeaderText = "UM";
            ColumnUM.Width = 60;
            ColumnUM.DataPropertyName = "UM";
            ColumnUM.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnUM.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnUM.ReadOnly = true;
            dgvStocks.Columns.Add(ColumnUM);

            //Adding  UP TextBox
            DataGridViewTextBoxColumn ColumnUP = new DataGridViewTextBoxColumn();
            ColumnUP.HeaderText = "Unit Price";
            ColumnUP.Width = 120;
            ColumnUP.DataPropertyName = "UP";
            ColumnUP.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnUP.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnUP.ReadOnly = true;
            dgvStocks.Columns.Add(ColumnUP);

            //Adding  Discount TextBox
            DataGridViewTextBoxColumn ColumnCost = new DataGridViewTextBoxColumn();
            ColumnCost.HeaderText = "Total Cost";
            ColumnCost.Width = 120;
            ColumnCost.DataPropertyName = "Cost";
            ColumnCost.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnCost.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnCost.ReadOnly = true;
            dgvStocks.Columns.Add(ColumnCost);


            dgvStocks.Columns[0].Name = "StockNumber";
            dgvStocks.Columns[1].Name = "Item";
            dgvStocks.Columns[2].Name = "PIn";
            dgvStocks.Columns[3].Name = "UM";
            dgvStocks.Columns[4].Name = "Unit Price";
            dgvStocks.Columns[5].Name = "Total Cost";



            dgvStocks.Columns[2].DefaultCellStyle.Format = "N2";
            dgvStocks.Columns[4].DefaultCellStyle.Format = "N4";
            dgvStocks.Columns[5].DefaultCellStyle.Format = "N4";
            //dgvStocks.Columns[6].DefaultCellStyle.Format = "N2";
            //Setting Data Source for DataGridView
            dgvStocks.DataSource = bindingSource;
            myconnection.Close();
            dgvStocks.AllowUserToAddRows = false;
            //dgv1total();
        }
        private void LoadCI()
        {
            string sql;
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            sql = "SELECT StockNumber, StockDesc, POut, UnitM, UP, Cost FROM ViewDetailsBookCI WHERE DocNum = '" + dgvSearch.CurrentRow.Cells[1].FormattedValue.ToString() + "'";

            da = new SqlDataAdapter(sql, myconnection);
            SqlCommandBuilder commandBuilder = new SqlCommandBuilder(da);

            dataTable = new DataTable();
            da.Fill(dataTable);
            bindingSource = new BindingSource();
            bindingSource.DataSource = dataTable;


            //Adding  Product Code TextBox
            DataGridViewTextBoxColumn ColumnSN = new DataGridViewTextBoxColumn();
            ColumnSN.HeaderText = "Product Code";
            ColumnSN.Width = 140;
            ColumnSN.DataPropertyName = "StockNumber";
            ColumnSN.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnSN.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnSN.ReadOnly = true;
            dgvStocks.Columns.Add(ColumnSN);


            //Adding  Product Description TextBox
            DataGridViewTextBoxColumn ColumnItem = new DataGridViewTextBoxColumn();
            ColumnItem.HeaderText = "Description";
            ColumnItem.Width = 270;
            ColumnItem.DataPropertyName = "StockDesc";
            ColumnItem.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            ColumnItem.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnItem.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnItem.ReadOnly = true;
            dgvStocks.Columns.Add(ColumnItem);

            //Adding  Quantity TextBox
            DataGridViewTextBoxColumn ColumnPIn = new DataGridViewTextBoxColumn();
            ColumnPIn.HeaderText = "Quantity";
            ColumnPIn.Width = 120;
            ColumnPIn.DataPropertyName = "POut";
            ColumnPIn.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnPIn.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnPIn.ReadOnly = true;
            dgvStocks.Columns.Add(ColumnPIn);

            DataGridViewTextBoxColumn ColumnUnitM = new DataGridViewTextBoxColumn();
            ColumnUnitM.HeaderText = "UM";
            ColumnUnitM.Width = 60;
            ColumnUnitM.DataPropertyName = "UnitM";
            ColumnUnitM.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnUnitM.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnUnitM.ReadOnly = true;
            dgvStocks.Columns.Add(ColumnUnitM);

            //Adding  UP TextBox
            DataGridViewTextBoxColumn ColumnUP = new DataGridViewTextBoxColumn();
            ColumnUP.HeaderText = "Unit Price";
            ColumnUP.Width = 120;
            ColumnUP.DataPropertyName = "UP";
            ColumnUP.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnUP.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnUP.ReadOnly = true;
            dgvStocks.Columns.Add(ColumnUP);

            //Adding  Discount TextBox
            DataGridViewTextBoxColumn ColumnCost = new DataGridViewTextBoxColumn();
            ColumnCost.HeaderText = "Total Cost";
            ColumnCost.Width = 120;
            ColumnCost.DataPropertyName = "Cost";
            ColumnCost.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnCost.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnCost.ReadOnly = true;
            dgvStocks.Columns.Add(ColumnCost);


            dgvStocks.Columns[0].Name = "StockNumber";
            dgvStocks.Columns[1].Name = "Item";
            dgvStocks.Columns[2].Name = "POut";
            dgvStocks.Columns[3].Name = "UM";
            dgvStocks.Columns[4].Name = "Unit Price";
            dgvStocks.Columns[5].Name = "Total Cost";



            dgvStocks.Columns[2].DefaultCellStyle.Format = "N2";
            dgvStocks.Columns[4].DefaultCellStyle.Format = "N4";
            dgvStocks.Columns[5].DefaultCellStyle.Format = "N4";
            //dgvStocks.Columns[6].DefaultCellStyle.Format = "N2";
            //Setting Data Source for DataGridView
            dgvStocks.DataSource = bindingSource;
            myconnection.Close();
            dgvStocks.AllowUserToAddRows = false;
            //dgv1total();
        }
        private void LoadAS()
        {
            string sql;
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            sql = "SELECT StockNumber, StockDesc, PIn, UnitM, UP, Cost FROM ViewDetailsBookAS WHERE DocNum = '" + dgvSearch.CurrentRow.Cells[1].FormattedValue.ToString() + "'";

            da = new SqlDataAdapter(sql, myconnection);
            SqlCommandBuilder commandBuilder = new SqlCommandBuilder(da);

            dataTable = new DataTable();
            da.Fill(dataTable);
            bindingSource = new BindingSource();
            bindingSource.DataSource = dataTable;


            //Adding  Product Code TextBox
            DataGridViewTextBoxColumn ColumnSN = new DataGridViewTextBoxColumn();
            ColumnSN.HeaderText = "Product Code";
            ColumnSN.Width = 140;
            ColumnSN.DataPropertyName = "StockNumber";
            ColumnSN.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnSN.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnSN.ReadOnly = true;
            dgvStocks.Columns.Add(ColumnSN);


            //Adding  Product Description TextBox
            DataGridViewTextBoxColumn ColumnItem = new DataGridViewTextBoxColumn();
            ColumnItem.HeaderText = "Description";
            ColumnItem.Width = 270;
            ColumnItem.DataPropertyName = "StockDesc";
            ColumnItem.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            ColumnItem.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnItem.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnItem.ReadOnly = true;
            dgvStocks.Columns.Add(ColumnItem);

            //Adding  Quantity TextBox
            DataGridViewTextBoxColumn ColumnPIn = new DataGridViewTextBoxColumn();
            ColumnPIn.HeaderText = "Quantity";
            ColumnPIn.Width = 120;
            ColumnPIn.DataPropertyName = "PIn";
            ColumnPIn.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnPIn.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnPIn.ReadOnly = true;
            dgvStocks.Columns.Add(ColumnPIn);

            DataGridViewTextBoxColumn ColumnUnitM = new DataGridViewTextBoxColumn();
            ColumnUnitM.HeaderText = "UM";
            ColumnUnitM.Width = 60;
            ColumnUnitM.DataPropertyName = "UnitM";
            ColumnUnitM.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnUnitM.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnUnitM.ReadOnly = true;
            dgvStocks.Columns.Add(ColumnUnitM);

            //Adding  UP TextBox
            DataGridViewTextBoxColumn ColumnUP = new DataGridViewTextBoxColumn();
            ColumnUP.HeaderText = "Unit Price";
            ColumnUP.Width = 120;
            ColumnUP.DataPropertyName = "UP";
            ColumnUP.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnUP.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnUP.ReadOnly = true;
            dgvStocks.Columns.Add(ColumnUP);

            //Adding  Discount TextBox
            DataGridViewTextBoxColumn ColumnCost = new DataGridViewTextBoxColumn();
            ColumnCost.HeaderText = "Total Cost";
            ColumnCost.Width = 120;
            ColumnCost.DataPropertyName = "Cost";
            ColumnCost.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnCost.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnCost.ReadOnly = true;
            dgvStocks.Columns.Add(ColumnCost);


            dgvStocks.Columns[0].Name = "StockNumber";
            dgvStocks.Columns[1].Name = "Item";
            dgvStocks.Columns[2].Name = "PIn";
            dgvStocks.Columns[3].Name = "UM";
            dgvStocks.Columns[4].Name = "Unit Price";
            dgvStocks.Columns[5].Name = "Total Cost";



            dgvStocks.Columns[2].DefaultCellStyle.Format = "N2";
            dgvStocks.Columns[4].DefaultCellStyle.Format = "N4";
            dgvStocks.Columns[5].DefaultCellStyle.Format = "N4";
            //dgvStocks.Columns[6].DefaultCellStyle.Format = "N2";
            //Setting Data Source for DataGridView
            dgvStocks.DataSource = bindingSource;
            myconnection.Close();
            dgvStocks.AllowUserToAddRows = false;
            //dgv1total();
        }
        private void LoadCS()
        {
            string sql;
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            sql = "SELECT StockNumber, StockDesc, POut, UnitM, UP, Cost FROM ViewDetailsBookCS WHERE DocNum = '" + dgvSearch.CurrentRow.Cells[1].FormattedValue.ToString() + "'";

            da = new SqlDataAdapter(sql, myconnection);
            SqlCommandBuilder commandBuilder = new SqlCommandBuilder(da);

            dataTable = new DataTable();
            da.Fill(dataTable);
            bindingSource = new BindingSource();
            bindingSource.DataSource = dataTable;


            //Adding  Product Code TextBox
            DataGridViewTextBoxColumn ColumnSN = new DataGridViewTextBoxColumn();
            ColumnSN.HeaderText = "Product Code";
            ColumnSN.Width = 140;
            ColumnSN.DataPropertyName = "StockNumber";
            ColumnSN.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnSN.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnSN.ReadOnly = true;
            dgvStocks.Columns.Add(ColumnSN);


            //Adding  Product Description TextBox
            DataGridViewTextBoxColumn ColumnItem = new DataGridViewTextBoxColumn();
            ColumnItem.HeaderText = "Description";
            ColumnItem.Width = 270;
            ColumnItem.DataPropertyName = "StockDesc";
            ColumnItem.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            ColumnItem.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnItem.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnItem.ReadOnly = true;
            dgvStocks.Columns.Add(ColumnItem);

            //Adding  Quantity TextBox
            DataGridViewTextBoxColumn ColumnPIn = new DataGridViewTextBoxColumn();
            ColumnPIn.HeaderText = "Quantity";
            ColumnPIn.Width = 120;
            ColumnPIn.DataPropertyName = "POut";
            ColumnPIn.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnPIn.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnPIn.ReadOnly = true;
            dgvStocks.Columns.Add(ColumnPIn);

            DataGridViewTextBoxColumn ColumnUnitM = new DataGridViewTextBoxColumn();
            ColumnUnitM.HeaderText = "UM";
            ColumnUnitM.Width = 60;
            ColumnUnitM.DataPropertyName = "UnitM";
            ColumnUnitM.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnUnitM.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnUnitM.ReadOnly = true;
            dgvStocks.Columns.Add(ColumnUnitM);

            //Adding  UP TextBox
            DataGridViewTextBoxColumn ColumnUP = new DataGridViewTextBoxColumn();
            ColumnUP.HeaderText = "Unit Price";
            ColumnUP.Width = 120;
            ColumnUP.DataPropertyName = "UP";
            ColumnUP.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnUP.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnUP.ReadOnly = true;
            dgvStocks.Columns.Add(ColumnUP);

            //Adding  Discount TextBox
            DataGridViewTextBoxColumn ColumnCost = new DataGridViewTextBoxColumn();
            ColumnCost.HeaderText = "Total Cost";
            ColumnCost.Width = 120;
            ColumnCost.DataPropertyName = "Cost";
            ColumnCost.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnCost.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnCost.ReadOnly = true;
            dgvStocks.Columns.Add(ColumnCost);


            dgvStocks.Columns[0].Name = "StockNumber";
            dgvStocks.Columns[1].Name = "Item";
            dgvStocks.Columns[2].Name = "POut";
            dgvStocks.Columns[3].Name = "UM";
            dgvStocks.Columns[4].Name = "Unit Price";
            dgvStocks.Columns[5].Name = "Total Cost";



            dgvStocks.Columns[2].DefaultCellStyle.Format = "N2";
            dgvStocks.Columns[4].DefaultCellStyle.Format = "N4";
            dgvStocks.Columns[5].DefaultCellStyle.Format = "N4";
            //dgvStocks.Columns[6].DefaultCellStyle.Format = "N2";
            //Setting Data Source for DataGridView
            dgvStocks.DataSource = bindingSource;
            myconnection.Close();
            dgvStocks.AllowUserToAddRows = false;
            //dgv1total();
        }
        private void LoadRS()
        {
            string sql;
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            sql = "SELECT StockNumber, StockDesc, PIn, UnitM, UP, Cost FROM ViewDetailsBookRS WHERE DocNum = '" + dgvSearch.CurrentRow.Cells[1].FormattedValue.ToString() + "'";

            da = new SqlDataAdapter(sql, myconnection);
            SqlCommandBuilder commandBuilder = new SqlCommandBuilder(da);

            dataTable = new DataTable();
            da.Fill(dataTable);
            bindingSource = new BindingSource();
            bindingSource.DataSource = dataTable;


            //Adding  Product Code TextBox
            DataGridViewTextBoxColumn ColumnSN = new DataGridViewTextBoxColumn();
            ColumnSN.HeaderText = "Product Code";
            ColumnSN.Width = 140;
            ColumnSN.DataPropertyName = "StockNumber";
            ColumnSN.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnSN.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnSN.ReadOnly = true;
            dgvStocks.Columns.Add(ColumnSN);


            //Adding  Product Description TextBox
            DataGridViewTextBoxColumn ColumnItem = new DataGridViewTextBoxColumn();
            ColumnItem.HeaderText = "Description";
            ColumnItem.Width = 270;
            ColumnItem.DataPropertyName = "StockDesc";
            ColumnItem.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            ColumnItem.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnItem.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnItem.ReadOnly = true;
            dgvStocks.Columns.Add(ColumnItem);

            //Adding  Quantity TextBox
            DataGridViewTextBoxColumn ColumnPIn = new DataGridViewTextBoxColumn();
            ColumnPIn.HeaderText = "Quantity";
            ColumnPIn.Width = 120;
            ColumnPIn.DataPropertyName = "PIn";
            ColumnPIn.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnPIn.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnPIn.ReadOnly = true;
            dgvStocks.Columns.Add(ColumnPIn);

            DataGridViewTextBoxColumn ColumnUnitM = new DataGridViewTextBoxColumn();
            ColumnUnitM.HeaderText = "UM";
            ColumnUnitM.Width = 60;
            ColumnUnitM.DataPropertyName = "UnitM";
            ColumnUnitM.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnUnitM.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnUnitM.ReadOnly = true;
            dgvStocks.Columns.Add(ColumnUnitM);

            //Adding  UP TextBox
            DataGridViewTextBoxColumn ColumnUP = new DataGridViewTextBoxColumn();
            ColumnUP.HeaderText = "Unit Price";
            ColumnUP.Width = 120;
            ColumnUP.DataPropertyName = "UP";
            ColumnUP.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnUP.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnUP.ReadOnly = true;
            dgvStocks.Columns.Add(ColumnUP);

            //Adding  Discount TextBox
            DataGridViewTextBoxColumn ColumnCost = new DataGridViewTextBoxColumn();
            ColumnCost.HeaderText = "Total Cost";
            ColumnCost.Width = 120;
            ColumnCost.DataPropertyName = "Cost";
            ColumnCost.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnCost.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnCost.ReadOnly = true;
            dgvStocks.Columns.Add(ColumnCost);


            dgvStocks.Columns[0].Name = "StockNumber";
            dgvStocks.Columns[1].Name = "Item";
            dgvStocks.Columns[2].Name = "PIn";
            dgvStocks.Columns[3].Name = "UM";
            dgvStocks.Columns[4].Name = "Unit Price";
            dgvStocks.Columns[5].Name = "Total Cost";



            dgvStocks.Columns[2].DefaultCellStyle.Format = "N2";
            dgvStocks.Columns[4].DefaultCellStyle.Format = "N4";
            dgvStocks.Columns[5].DefaultCellStyle.Format = "N4";
            //dgvStocks.Columns[6].DefaultCellStyle.Format = "N2";
            //Setting Data Source for DataGridView
            dgvStocks.DataSource = bindingSource;
            myconnection.Close();
            dgvStocks.AllowUserToAddRows = false;
            //dgv1total();
        }
        private void LoadRTS()
        {
            string sql;
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            sql = "SELECT StockNumber, StockDesc, POut, UM, UP, Cost FROM ViewDetailsBookRTS WHERE DocNum = '" + dgvSearch.CurrentRow.Cells[1].FormattedValue.ToString() + "'";

            da = new SqlDataAdapter(sql, myconnection);
            SqlCommandBuilder commandBuilder = new SqlCommandBuilder(da);

            dataTable = new DataTable();
            da.Fill(dataTable);
            bindingSource = new BindingSource();
            bindingSource.DataSource = dataTable;


            //Adding  Product Code TextBox
            DataGridViewTextBoxColumn ColumnSN = new DataGridViewTextBoxColumn();
            ColumnSN.HeaderText = "Product Code";
            ColumnSN.Width = 140;
            ColumnSN.DataPropertyName = "StockNumber";
            ColumnSN.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnSN.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnSN.ReadOnly = true;
            dgvStocks.Columns.Add(ColumnSN);


            //Adding  Product Description TextBox
            DataGridViewTextBoxColumn ColumnItem = new DataGridViewTextBoxColumn();
            ColumnItem.HeaderText = "Description";
            ColumnItem.Width = 270;
            ColumnItem.DataPropertyName = "StockDesc";
            ColumnItem.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            ColumnItem.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnItem.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnItem.ReadOnly = true;
            dgvStocks.Columns.Add(ColumnItem);

            //Adding  Quantity TextBox
            DataGridViewTextBoxColumn ColumnPIn = new DataGridViewTextBoxColumn();
            ColumnPIn.HeaderText = "Quantity";
            ColumnPIn.Width = 120;
            ColumnPIn.DataPropertyName = "POut";
            ColumnPIn.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnPIn.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnPIn.ReadOnly = true;
            dgvStocks.Columns.Add(ColumnPIn);

            DataGridViewTextBoxColumn ColumnUM = new DataGridViewTextBoxColumn();
            ColumnUM.HeaderText = "UM";
            ColumnUM.Width = 60;
            ColumnUM.DataPropertyName = "UM";
            ColumnUM.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnUM.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnUM.ReadOnly = true;
            dgvStocks.Columns.Add(ColumnUM);

            //Adding  UP TextBox
            DataGridViewTextBoxColumn ColumnUP = new DataGridViewTextBoxColumn();
            ColumnUP.HeaderText = "Unit Price";
            ColumnUP.Width = 120;
            ColumnUP.DataPropertyName = "UP";
            ColumnUP.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnUP.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnUP.ReadOnly = true;
            dgvStocks.Columns.Add(ColumnUP);

            //Adding  Discount TextBox
            DataGridViewTextBoxColumn ColumnCost = new DataGridViewTextBoxColumn();
            ColumnCost.HeaderText = "Total Cost";
            ColumnCost.Width = 120;
            ColumnCost.DataPropertyName = "Cost";
            ColumnCost.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnCost.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnCost.ReadOnly = true;
            dgvStocks.Columns.Add(ColumnCost);


            dgvStocks.Columns[0].Name = "StockNumber";
            dgvStocks.Columns[1].Name = "Item";
            dgvStocks.Columns[2].Name = "POut";
            dgvStocks.Columns[3].Name = "UM";
            dgvStocks.Columns[4].Name = "Unit Price";
            dgvStocks.Columns[5].Name = "Total Cost";



            dgvStocks.Columns[2].DefaultCellStyle.Format = "N2";
            dgvStocks.Columns[4].DefaultCellStyle.Format = "N4";
            dgvStocks.Columns[5].DefaultCellStyle.Format = "N4";
            //dgvStocks.Columns[6].DefaultCellStyle.Format = "N2";
            //Setting Data Source for DataGridView
            dgvStocks.DataSource = bindingSource;
            myconnection.Close();
            dgvStocks.AllowUserToAddRows = false;
            //dgv1total();
        }
        private void LoadWS()
        {
            string sql;
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            sql = "SELECT StockNumber, StockDesc, POut, UnitM, UP, Cost FROM ViewDetailsBookWS WHERE DocNum = '" + dgvSearch.CurrentRow.Cells[1].FormattedValue.ToString() + "'";

            da = new SqlDataAdapter(sql, myconnection);
            SqlCommandBuilder commandBuilder = new SqlCommandBuilder(da);

            dataTable = new DataTable();
            da.Fill(dataTable);
            bindingSource = new BindingSource();
            bindingSource.DataSource = dataTable;


            //Adding  Product Code TextBox
            DataGridViewTextBoxColumn ColumnSN = new DataGridViewTextBoxColumn();
            ColumnSN.HeaderText = "Product Code";
            ColumnSN.Width = 140;
            ColumnSN.DataPropertyName = "StockNumber";
            ColumnSN.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnSN.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnSN.ReadOnly = true;
            dgvStocks.Columns.Add(ColumnSN);


            //Adding  Product Description TextBox
            DataGridViewTextBoxColumn ColumnItem = new DataGridViewTextBoxColumn();
            ColumnItem.HeaderText = "Description";
            ColumnItem.Width = 270;
            ColumnItem.DataPropertyName = "StockDesc";
            ColumnItem.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            ColumnItem.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnItem.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnItem.ReadOnly = true;
            dgvStocks.Columns.Add(ColumnItem);

            //Adding  Quantity TextBox
            DataGridViewTextBoxColumn ColumnPIn = new DataGridViewTextBoxColumn();
            ColumnPIn.HeaderText = "Quantity";
            ColumnPIn.Width = 120;
            ColumnPIn.DataPropertyName = "POut";
            ColumnPIn.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnPIn.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnPIn.ReadOnly = true;
            dgvStocks.Columns.Add(ColumnPIn);

            DataGridViewTextBoxColumn ColumnUnitM = new DataGridViewTextBoxColumn();
            ColumnUnitM.HeaderText = "UM";
            ColumnUnitM.Width = 60;
            ColumnUnitM.DataPropertyName = "UnitM";
            ColumnUnitM.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnUnitM.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnUnitM.ReadOnly = true;
            dgvStocks.Columns.Add(ColumnUnitM);

            //Adding  UP TextBox
            DataGridViewTextBoxColumn ColumnUP = new DataGridViewTextBoxColumn();
            ColumnUP.HeaderText = "Unit Price";
            ColumnUP.Width = 120;
            ColumnUP.DataPropertyName = "UP";
            ColumnUP.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnUP.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnUP.ReadOnly = true;
            dgvStocks.Columns.Add(ColumnUP);

            //Adding  Discount TextBox
            DataGridViewTextBoxColumn ColumnCost = new DataGridViewTextBoxColumn();
            ColumnCost.HeaderText = "Total Cost";
            ColumnCost.Width = 120;
            ColumnCost.DataPropertyName = "Cost";
            ColumnCost.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnCost.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnCost.ReadOnly = true;
            dgvStocks.Columns.Add(ColumnCost);


            dgvStocks.Columns[0].Name = "StockNumber";
            dgvStocks.Columns[1].Name = "Item";
            dgvStocks.Columns[2].Name = "POut";
            dgvStocks.Columns[3].Name = "UM";
            dgvStocks.Columns[4].Name = "Unit Price";
            dgvStocks.Columns[5].Name = "Total Cost";



            dgvStocks.Columns[2].DefaultCellStyle.Format = "N2";
            dgvStocks.Columns[4].DefaultCellStyle.Format = "N4";
            dgvStocks.Columns[5].DefaultCellStyle.Format = "N4";
            //dgvStocks.Columns[6].DefaultCellStyle.Format = "N2";
            //Setting Data Source for DataGridView
            dgvStocks.DataSource = bindingSource;
            myconnection.Close();
            dgvStocks.AllowUserToAddRows = false;
            //dgv1total();
        }
        private void LoadPS()
        {
            string sql;
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            sql = "SELECT StockNumber, StockDesc, PIn, UnitM, UP, Cost FROM ViewDetailsBookPS WHERE DocNum = '" + dgvSearch.CurrentRow.Cells[1].FormattedValue.ToString() + "'";

            da = new SqlDataAdapter(sql, myconnection);
            SqlCommandBuilder commandBuilder = new SqlCommandBuilder(da);

            dataTable = new DataTable();
            da.Fill(dataTable);
            bindingSource = new BindingSource();
            bindingSource.DataSource = dataTable;


            //Adding  Product Code TextBox
            DataGridViewTextBoxColumn ColumnSN = new DataGridViewTextBoxColumn();
            ColumnSN.HeaderText = "Product Code";
            ColumnSN.Width = 140;
            ColumnSN.DataPropertyName = "StockNumber";
            ColumnSN.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnSN.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnSN.ReadOnly = true;
            dgvStocks.Columns.Add(ColumnSN);


            //Adding  Product Description TextBox
            DataGridViewTextBoxColumn ColumnItem = new DataGridViewTextBoxColumn();
            ColumnItem.HeaderText = "Description";
            ColumnItem.Width = 270;
            ColumnItem.DataPropertyName = "StockDesc";
            ColumnItem.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            ColumnItem.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnItem.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnItem.ReadOnly = true;
            dgvStocks.Columns.Add(ColumnItem);

            //Adding  Quantity TextBox
            DataGridViewTextBoxColumn ColumnPIn = new DataGridViewTextBoxColumn();
            ColumnPIn.HeaderText = "Quantity";
            ColumnPIn.Width = 120;
            ColumnPIn.DataPropertyName = "PIn";
            ColumnPIn.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnPIn.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnPIn.ReadOnly = true;
            dgvStocks.Columns.Add(ColumnPIn);

            DataGridViewTextBoxColumn ColumnUnitM = new DataGridViewTextBoxColumn();
            ColumnUnitM.HeaderText = "UM";
            ColumnUnitM.Width = 60;
            ColumnUnitM.DataPropertyName = "UnitM";
            ColumnUnitM.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnUnitM.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnUnitM.ReadOnly = true;
            dgvStocks.Columns.Add(ColumnUnitM);

            //Adding  UP TextBox
            DataGridViewTextBoxColumn ColumnUP = new DataGridViewTextBoxColumn();
            ColumnUP.HeaderText = "Unit Price";
            ColumnUP.Width = 120;
            ColumnUP.DataPropertyName = "UP";
            ColumnUP.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnUP.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnUP.ReadOnly = true;
            dgvStocks.Columns.Add(ColumnUP);

            //Adding  Discount TextBox
            DataGridViewTextBoxColumn ColumnCost = new DataGridViewTextBoxColumn();
            ColumnCost.HeaderText = "Total Cost";
            ColumnCost.Width = 120;
            ColumnCost.DataPropertyName = "Cost";
            ColumnCost.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnCost.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnCost.ReadOnly = true;
            dgvStocks.Columns.Add(ColumnCost);


            dgvStocks.Columns[0].Name = "StockNumber";
            dgvStocks.Columns[1].Name = "Item";
            dgvStocks.Columns[2].Name = "PIn";
            dgvStocks.Columns[3].Name = "UM";
            dgvStocks.Columns[4].Name = "Unit Price";
            dgvStocks.Columns[5].Name = "Total Cost";



            dgvStocks.Columns[2].DefaultCellStyle.Format = "N2";
            dgvStocks.Columns[4].DefaultCellStyle.Format = "N4";
            dgvStocks.Columns[5].DefaultCellStyle.Format = "N4";
            //dgvStocks.Columns[6].DefaultCellStyle.Format = "N2";
            //Setting Data Source for DataGridView
            dgvStocks.DataSource = bindingSource;
            myconnection.Close();
            dgvStocks.AllowUserToAddRows = false;
            //dgv1total();
        }
        private void txtSearch_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.Equals(Keys.Enter))
            {
                SendKeys.Send("{TAB}");
            }
        }

        private void dgvSearch_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow row = dgvSearch.Rows[e.RowIndex];
            txtSearch.Text = row.Cells[0].FormattedValue.ToString();
        }

        private void dgvSearch_DoubleClick(object sender, EventArgs e)
        {
            dgv1.DataSource = null;
            dgv1.Columns.Clear();
            dgvStocks.DataSource = null;
            dgvStocks.Columns.Clear();
            if (cboVoucher.Text == "PO")
            {
                //buildcboCustCode();
                showdataPO();
                LoadPO();
            }
            else if (cboVoucher.Text=="PI")
            {
                showdataPI();
                LoadPI();
            }
            else if (cboVoucher.Text=="PD")
            {
                showdata();
                LoadPD();
                showsearchdata();
                dgv1total();
            }
            else if (cboVoucher.Text=="CI")
            {
                 showdata();
                 LoadCI();
                 showsearchdata();
                 dgv1total();
            }
            else if (cboVoucher.Text=="AS")
            {
                showdata();
                LoadAS();
                showsearchdata();
                dgv1total();
            }
            else if (cboVoucher.Text=="CS")
            {
                showdata();
                LoadCS();
                showsearchdata();
                dgv1total();
            }
            else if (cboVoucher.Text=="RS")
            {
                showdata();
                LoadRS();
                showsearchdata();
                dgv1total();
            }
            else if (cboVoucher.Text=="RTS")
            {
                showdata();
                LoadRTS();
                showsearchdata();
                dgv1total();
            }
            else if (cboVoucher.Text=="WS")
            {
                showdata();
                LoadWS();
                showsearchdata();
                dgv1total();
            }
            else if (cboVoucher.Text=="PS")
            {
                showdata();
                LoadPS();
                showsearchdata();
                dgv1total();
            }
            else
            {
                showdata();
                showsearchdata();
                dgv1total();
            }
        }

        private void cboVoucher_Validating(object sender, CancelEventArgs e)
        {
            //dgvSearch.DataSource = null;
            //dgvSearch.Columns.Clear();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            
            if (new ClsValidation().emptytxt (cboVoucher.Text) || (new ClsValidation ().emptytxt (txtDocNum.Text)))
            {
                MessageBox.Show("Please complete the process", "GL");
                cboVoucher.Focus();
            }
            else
            {
            DialogResult dialogResult = MessageBox.Show("Are you sure to delete this transaction?", "GL", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {

                string sqldel1="A";

                if (cboVoucher.Text == "APV")
                {
                    sqldel1 = "DELETE FROM tblMain3 WHERE IC='" + txtIC.Text + "'";
                }
                else if (cboVoucher.Text == "ARV")
                {
                    sqldel1 = "DELETE FROM tblMain3 WHERE IC='" + txtIC.Text + "'";
                }
                else if (cboVoucher.Text == "JV")
                {
                    sqldel1 = "DELETE FROM tblMain3 WHERE IC='" + txtIC.Text + "'";
                }
                else if (cboVoucher.Text == "CV")
                {
                    sqldel1 = "DELETE FROM tblMain3 WHERE IC='" + txtIC.Text + "'";
                }
                else if (cboVoucher.Text == "OR")
                {
                    sqldel1 = "DELETE FROM tblMain3 WHERE IC='" + txtIC.Text + "'";
                }
            
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = new SqlCommand(sqldel1, myconnection);
                int nmsg1 = mycommand.ExecuteNonQuery();

                myconnection.Close();
                showsearchdata();
            }
          }
        }

        private void cboCNCode_Validating(object sender, CancelEventArgs e)
        {
            buildcboCustCode();
        }

        private void txtCAmount_Validating(object sender, CancelEventArgs e)
        {
            if (new ClsValidation().isDouble(txtCAmount.Text) == true)
            {
                MessageBox.Show("Invalid Number", "GL");
                txtCAmount.Focus();
            }
            else
            {
                txtCAmount.Text = Convert.ToDouble(txtCAmount.Text).ToString("N2");
            }

        }

    }
}
