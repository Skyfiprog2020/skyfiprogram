﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TCIGL
{
    public partial class frmEntryWarehouseAdd : Form
    {
        SqlConnection myconnection;
         //SqlDataReader dr;
        SqlCommand mycommand;
        BindingSource dbind = new BindingSource();
    //    SqlDataAdapter da;
    //    DataSet dset;
        ClsPermission ClsPermission1 = new ClsPermission();
        ClsGetConnection ClsGetConnection1 = new ClsGetConnection();
        ClsAutoNumber ClsAutoNumber1 = new ClsAutoNumber(); 
        public frmEntryWarehouseAdd()
        {
            InitializeComponent();
        }
 
    
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();
            if (new ClsValidation().emptytxt(txtWHDesc.Text))
            {
                myconnection.Close();
                MessageBox.Show("Please complete your entry", "IF");
                txtWHDesc.Focus();
            }
            else if (new Clsexist().RecordExists(ref myconnection, "SELECT WHDesc FROM tblWarehouse WHERE WHDesc ='" + txtWHDesc.Text + "'"))
            {
                myconnection.Close();
                MessageBox.Show("Duplicate entry", "POS");
                txtWHDesc.Focus();
            }

            else
            {
                ClsAutoNumber1.WarehouseAutoNum();
                txtWHCode.Text = (ClsAutoNumber1.plsnumber);

                string sqlstatement;
                sqlstatement = "INSERT INTO tblWarehouse (WHCode, WHDesc) Values (@_WHCode, @_WHDesc)";
                mycommand = new SqlCommand(sqlstatement, myconnection);
                mycommand.Parameters.Add("_WHCode", SqlDbType.VarChar).Value = txtWHCode.Text;
                mycommand.Parameters.Add("_WHDesc", SqlDbType.VarChar).Value = txtWHDesc.Text;
                int n2 = mycommand.ExecuteNonQuery();
            
                txtWHDesc.Text = "";
                txtWHDesc.Focus();

                ClsAutoNumber1.WarehouseAutoNum();
                txtWHCode.Text = (ClsAutoNumber1.plsnumber);
                myconnection.Close();
            }
        }

 

        private void frmWarehouseAdd_Load(object sender, EventArgs e)
        {
            ClsPermission1.ClsObjects(this.Text);
            if (new ClsValidation().emptytxt(ClsPermission1.plstxtObject))
            {
                MessageBox.Show("You do not have necessary permission to open this file", "GL");
                this.Close();
            }
            else
            {
                ClsAutoNumber1.WarehouseAutoNum();
                txtWHCode.Text = (ClsAutoNumber1.plsnumber);
            }

        }

        private void nextfieldenter1(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.Equals(Keys.Enter))
            {
                SendKeys.Send("{TAB}");
            }
            else if ((e.KeyCode.Equals(Keys.Up)) || (e.KeyCode.Equals(Keys.Left)))
            {
                SendKeys.Send("+{TAB}");
            }
            else if ((e.KeyCode.Equals(Keys.Down)) || (e.KeyCode.Equals(Keys.Right)))
            {
                SendKeys.Send("{TAB}");
            }
        }    
    }
}
