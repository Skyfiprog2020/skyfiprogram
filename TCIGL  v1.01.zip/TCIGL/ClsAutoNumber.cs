﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;

namespace TCIGL
{
    class ClsAutoNumber
    {
        SqlConnection myconnection;
        SqlCommand mycommand;
        SqlDataReader dr;
        public string plsnumber;
        ClsDefaultBranch ClsDefaultBranch1 = new ClsDefaultBranch();
        ClsGetConnection ClsGetConnection1 = new ClsGetConnection(); 

        public void CustomerNameAdd()
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                if (new Clsexist().RecordExists(ref myconnection, "SELECT CustCode FROM tblCustomer WHERE CNCode='" + (ClsDefaultBranch1.plsvardb) + "' AND NType='C'"))
                {
                    mycommand = new SqlCommand("SELECT Top 1 CustCode FROM tblCustomer WHERE CNCode='" + (ClsDefaultBranch1.plsvardb) + "' AND NType='C' ORDER BY CustCode DESC", myconnection);
                    dr = mycommand.ExecuteReader();
                    while (dr.Read())
                    {
                        string no1;
                        int no2;
                        no1 = dr[0].ToString();
                        no2 = (int.Parse(no1)) + 1;
                        plsnumber = Convert.ToString(no2).PadLeft(5, '0');
                    }
                }
                else
                {
                    plsnumber = "00001";
                }
                if (plsnumber == "00001")
                {
                    myconnection.Close();
                }
                else
                {
                    dr.Close();
                    myconnection.Close();
                }
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                //dr.Close();
                myconnection.Close();
            }
        }
        public void InvClassAdd()
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                if (new Clsexist().RecordExists(ref myconnection, "SELECT InvClassCode FROM tblInvClass"))
                {
                    mycommand = new SqlCommand("SELECT TOP 1 InvClassCode FROM tblInvClass ORDER BY InvClassCode DESC", myconnection);
                    dr = mycommand.ExecuteReader();
                    while (dr.Read())
                    {
                        string no1;
                        int no2;
                        no1 = dr[0].ToString();
                        no2 = (int.Parse(no1)) + 1;
                        plsnumber = Convert.ToString(no2).PadLeft(2, '0');
                    }
                }
                else
                {
                    plsnumber = "01";
                }
                if (plsnumber == "01")
                {
                    myconnection.Close();
                }
                else
                {
                    dr.Close();
                    myconnection.Close();
                }
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                //dr.Close();
                myconnection.Close();
            }
        }
        public void SupplierAdd()
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                if (new Clsexist().RecordExists(ref myconnection, "SELECT Top 1 CustCode FROM tblCustomer WHERE CNCode='" + (ClsDefaultBranch1.plsvardb) + "' AND NType='S'"))
                {
                    mycommand = new SqlCommand("SELECT Top 1 CustCode FROM tblCustomer WHERE CNCode='" + (ClsDefaultBranch1.plsvardb) + "' AND NType = 'S' ORDER BY CustCode DESC", myconnection);
                    dr = mycommand.ExecuteReader();
                    while (dr.Read())
                    {
                        string no1;
                        int no2;
                        no1 = dr[0].ToString();
                        no2 = (int.Parse(no1)) + 1;
                        plsnumber = Convert.ToString(no2).PadLeft(5, '0');
                    }
                }
                else
                {
                    plsnumber = "00001";
                }
                if (plsnumber == "00001")
                {
                    myconnection.Close();
                }
                else
                {
                    dr.Close();
                    myconnection.Close();
                }
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                //dr.Close();
                myconnection.Close();
            }
        }

        public void OtherNameAdd()
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                if (new Clsexist().RecordExists(ref myconnection, "SELECT Top 1 CustCode FROM tblCustomer WHERE CNCode='" + (ClsDefaultBranch1.plsvardb) + "' AND NType='O'"))
                {
                    mycommand = new SqlCommand("SELECT Top 1 CustCode FROM tblCustomer WHERE CNCode='" + (ClsDefaultBranch1.plsvardb) + "' AND NType='O' ORDER BY CustCode DESC", myconnection);
                    dr = mycommand.ExecuteReader();
                    while (dr.Read())
                    {
                        string no1;
                        int no2;
                        no1 = dr[0].ToString();
                        no2 = (int.Parse(no1)) + 1;
                        plsnumber = Convert.ToString(no2).PadLeft(5, '0');
                    }
                }
                else
                {
                    plsnumber = "00001";
                }
                if (plsnumber == "00001")
                {
                    myconnection.Close();
                }
                else
                {
                    dr.Close();
                    myconnection.Close();
                }
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                //dr.Close();
                myconnection.Close();
            }
        }


        public void VoucherAutoNum(string argvoucher)
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                if (new Clsexist().RecordExists(ref myconnection, "SELECT Top 1 DocNum FROM tblMain1 WHERE CNCode='" + (ClsDefaultBranch1.plsvardb) + "' AND Voucher ='" + argvoucher + "' AND (ISNUMERIC(DocNum) = 1)"))
                {
                    mycommand = new SqlCommand("SELECT Top 1 DocNum FROM tblMain1 WHERE CNCode='" + (ClsDefaultBranch1.plsvardb) + "' AND Voucher = '" + argvoucher + "' AND (ISNUMERIC(DocNum) = 1) ORDER BY DocNum DESC", myconnection);
                    dr = mycommand.ExecuteReader();
                    while (dr.Read())
                    {
                        string no1 = null;
                        int no2;
                        no1 = dr["DocNum"].ToString();
                        no2 = (int.Parse(no1)) + 1;
                        plsnumber = Convert.ToString(no2).PadLeft(7, '0');
                    }
                }
                else
                {
                    plsnumber = "0000001";
                }
                if (plsnumber == "0000001")
                {
                    myconnection.Close();
                }
                else
                {
                    dr.Close();
                    myconnection.Close();
                }
            }

            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                //dr.Close();
                myconnection.Close();
            }
        }

        public void VoucherAutoNumPO(string argvoucher)
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                if (new Clsexist().RecordExists(ref myconnection, "SELECT Top 1 DocNum FROM tblPO1 WHERE CNCode='" + (ClsDefaultBranch1.plsvardb) + "' AND Voucher ='" + argvoucher + "' AND (ISNUMERIC(DocNum) = 1)"))
                {
                    mycommand = new SqlCommand("SELECT Top 1 DocNum FROM tblPO1 WHERE CNCode='" + (ClsDefaultBranch1.plsvardb) + "' AND Voucher = '" + argvoucher + "' AND (ISNUMERIC(DocNum) = 1) ORDER BY DocNum DESC", myconnection);
                    dr = mycommand.ExecuteReader();
                    while (dr.Read())
                    {
                        string no1 = null;
                        int no2;
                        no1 = dr["DocNum"].ToString();
                        no2 = (int.Parse(no1)) + 1;
                        plsnumber = Convert.ToString(no2).PadLeft(7, '0');
                    }
                }
                else
                {
                    plsnumber = "0000001";
                }
                if (plsnumber == "0000001")
                {
                    myconnection.Close();
                }
                else
                {
                    dr.Close();
                    myconnection.Close();
                }
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                //dr.Close();
                myconnection.Close();
            }
        }
        public void VoucherAutoNumPI(string argvoucher)
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                if (new Clsexist().RecordExists(ref myconnection, "SELECT Top 1 DocNum FROM tblPI1 WHERE CNCode='" + (ClsDefaultBranch1.plsvardb) + "' AND Voucher ='" + argvoucher + "' AND (ISNUMERIC(DocNum) = 1)"))
                {
                    mycommand = new SqlCommand("SELECT Top 1 DocNum FROM tblPI1 WHERE CNCode='" + (ClsDefaultBranch1.plsvardb) + "' AND Voucher = '" + argvoucher + "' AND (ISNUMERIC(DocNum) = 1) ORDER BY DocNum DESC", myconnection);
                    dr = mycommand.ExecuteReader();
                    while (dr.Read())
                    {
                        string no1 = null;
                        int no2;
                        no1 = dr["DocNum"].ToString();
                        no2 = (int.Parse(no1)) + 1;
                        plsnumber = Convert.ToString(no2).PadLeft(7, '0');
                    }
                }
                else
                {
                    plsnumber = "0000001";
                }
                if (plsnumber == "0000001")
                {
                    myconnection.Close();
                }
                else
                {
                    dr.Close();
                    myconnection.Close();
                }
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                //dr.Close();
                myconnection.Close();
            }
        }

        public void VoucherAutoNumAI(string argvoucher)
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                if (new Clsexist().RecordExists(ref myconnection, "SELECT Top 1 DocNum FROM tblMain4 WHERE CNCode='" + (ClsDefaultBranch1.plsvardb) + "' AND Voucher ='" + argvoucher + "' AND (ISNUMERIC(DocNum) = 1)"))
                {
                    mycommand = new SqlCommand("SELECT Top 1 DocNum FROM tblMain4 WHERE CNCode='" + (ClsDefaultBranch1.plsvardb) + "' AND Voucher = '" + argvoucher + "' AND (ISNUMERIC(DocNum) = 1) ORDER BY DocNum DESC", myconnection);
                    dr = mycommand.ExecuteReader();
                    while (dr.Read())
                    {
                        string no1 = null;
                        int no2;
                        no1 = dr["DocNum"].ToString();
                        no2 = (int.Parse(no1)) + 1;
                        plsnumber = Convert.ToString(no2).PadLeft(7, '0');
                    }
                }
                else
                {
                    plsnumber = "0000001";
                }
                if (plsnumber == "0000001")
                {
                    myconnection.Close();
                }
                else
                {
                    dr.Close();
                    myconnection.Close();
                }
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                //dr.Close();
                myconnection.Close();
            }
        }

         public void VoucherLatestNum(string argvoucher, string varCNCode)
         {
             try
             {
                 ClsGetConnection1.ClsGetConMSSQL();
                 myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                 myconnection.Open();
                 mycommand = new SqlCommand("SELECT Top 1 DocNum FROM tblMain1 WHERE  Voucher = '" + argvoucher + "' AND CNCode='"+varCNCode+"' ORDER BY DocNum DESC", myconnection);
                 dr = mycommand.ExecuteReader();
                 while (dr.Read())
                 {
                     plsnumber = dr["DocNum"].ToString();
                 }

                 dr.Close();
                 myconnection.Close();
             }

             catch (Exception ex)
             {
                 System.Windows.Forms.MessageBox.Show(ex.Message);
             }
             finally
             {
                 //dr.Close();
                 myconnection.Close();
             }
         }

         public void VoucherLatestNumPO(string argvoucher, string varCNCode)
         {
             try
             {
                 ClsGetConnection1.ClsGetConMSSQL();
                 myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                 myconnection.Open();
                 mycommand = new SqlCommand("SELECT Top 1 DocNum FROM tblPO1 WHERE  Voucher = '" + argvoucher + "' AND CNCode='" + varCNCode + "' ORDER BY DocNum DESC", myconnection);
                 dr = mycommand.ExecuteReader();
                 while (dr.Read())
                 {
                     plsnumber = dr["DocNum"].ToString();
                 }
                 dr.Close();
                 myconnection.Close();
             }
             catch (Exception ex)
             {
                 System.Windows.Forms.MessageBox.Show(ex.Message);
             }
             finally
             {
                 myconnection.Close();
             }
         }
         public void VoucherLatestNumPI()
         {
             try
             {
                 ClsGetConnection1.ClsGetConMSSQL();
                 myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                 myconnection.Open();
                 mycommand = new SqlCommand("SELECT Top 1 DocNum FROM tblPI1  ORDER BY DocNum DESC", myconnection);
                 dr = mycommand.ExecuteReader();
                 while (dr.Read())
                 {
                     plsnumber = dr["DocNum"].ToString();
                 }
                 dr.Close();
                 myconnection.Close();
             }
             catch (Exception ex)
             {
                 System.Windows.Forms.MessageBox.Show(ex.Message);
             }
             finally
             {
                 myconnection.Close();
             }
         }

         public void VoucherLatestNumAI(string argvoucher, string varCNCode)
         {
             try
             {
                 ClsGetConnection1.ClsGetConMSSQL();
                 myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                 myconnection.Open();
                 mycommand = new SqlCommand("SELECT Top 1 DocNum FROM tblMain4 WHERE  Voucher = '" + argvoucher + "' AND CNCode='" + varCNCode + "' ORDER BY DocNum DESC", myconnection);
                 dr = mycommand.ExecuteReader();
                 while (dr.Read())
                 {
                     plsnumber = dr["DocNum"].ToString();
                 }
                 dr.Close();
                 myconnection.Close();
             }
             catch (Exception ex)
             {
                 System.Windows.Forms.MessageBox.Show(ex.Message);
             }
             finally
             {
                 myconnection.Close();
             }
         }



         public void GAAutoNum()
         {
             try
             {
                 ClsGetConnection1.ClsGetConMSSQL();
                 myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                 myconnection.Open();
                 if (new Clsexist().RecordExists(ref myconnection, "SELECT GACode FROM tblGeogArea"))
                 {
                     mycommand = new SqlCommand("SELECT Top 1 GACode FROM tblGeogArea ORDER BY GACode DESC", myconnection);
                     dr = mycommand.ExecuteReader();
                     while (dr.Read())
                     {
                         string no1 = null;
                         int no2;
                         no1 = dr["GACode"].ToString();
                         no2 = (int.Parse(no1)) + 1;
                         plsnumber = Convert.ToString(no2).PadLeft(3, '0');
                     }
                 }
                 else
                 {
                     plsnumber = "001";
                 }
                 if (plsnumber == "001")
                 {
                     myconnection.Close();
                 }
                 else
                 {
                     dr.Close();
                     myconnection.Close();
                 }
             }

             catch (Exception ex)
             {
                 System.Windows.Forms.MessageBox.Show(ex.Message);
             }
             finally
             {
                 //dr.Close();
                 myconnection.Close();
             }
         }

         public void TerritoryAutoNum()
         {
             try
             {
                 ClsGetConnection1.ClsGetConMSSQL();
                 myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                 myconnection.Open();
                 if (new Clsexist().RecordExists(ref myconnection, "SELECT TCode FROM tblTerritory"))
                 {
                     mycommand = new SqlCommand("SELECT Top 1 TCode FROM tblTerritory ORDER BY TCode DESC", myconnection);
                     dr = mycommand.ExecuteReader();
                     while (dr.Read())
                     {
                         string no1 = null;
                         int no2;
                         no1 = dr["TCode"].ToString();
                         no2 = (int.Parse(no1)) + 1;
                         plsnumber = Convert.ToString(no2).PadLeft(3, '0');
                     }
                 }
                 else
                 {
                     plsnumber = "001";
                 }
                 if (plsnumber == "001")
                 {
                     myconnection.Close();
                 }
                 else
                 {
                     dr.Close();
                     myconnection.Close();
                 }
             }

             catch (Exception ex)
             {
                 System.Windows.Forms.MessageBox.Show(ex.Message);
             }
             finally
             {
                 //dr.Close();
                 myconnection.Close();
             }
         }

         public void CategoryAutoNum()
         {
             try
             {
                 ClsGetConnection1.ClsGetConMSSQL();
                 myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                 myconnection.Open();
                 if (new Clsexist().RecordExists(ref myconnection, "SELECT CatCode FROM tblCategory"))
                 {
                     mycommand = new SqlCommand("SELECT Top 1 CatCode FROM tblCategory ORDER BY CatCode DESC", myconnection);
                     dr = mycommand.ExecuteReader();
                     while (dr.Read())
                     {
                         string no1 = null;
                         int no2;
                         no1 = dr["CatCode"].ToString();
                         no2 = (int.Parse(no1)) + 1;
                         plsnumber = Convert.ToString(no2).PadLeft(3, '0');
                     }
                 }
                 else
                 {
                     plsnumber = "001";
                 }
                 if (plsnumber == "001")
                 {
                     myconnection.Close();
                 }
                 else
                 {
                     dr.Close();
                     myconnection.Close();
                 }
             }

             catch (Exception ex)
             {
                 System.Windows.Forms.MessageBox.Show(ex.Message);
             }
             finally
             {
                 //dr.Close();
                 myconnection.Close();
             }
         }

         public void ChannelAutoNum()
         {
             try
             {
                 ClsGetConnection1.ClsGetConMSSQL();
                 myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                 myconnection.Open();
                 if (new Clsexist().RecordExists(ref myconnection, "SELECT ChannelCode FROM tblChannel"))
                 {
                     mycommand = new SqlCommand("SELECT Top 1 ChannelCode FROM tblChannel ORDER BY ChannelCode DESC", myconnection);
                     dr = mycommand.ExecuteReader();
                     while (dr.Read())
                     {
                         string no1 = null;
                         int no2;
                         no1 = dr["ChannelCode"].ToString();
                         no2 = (int.Parse(no1)) + 1;
                         plsnumber = Convert.ToString(no2).PadLeft(3, '0');
                     }
                 }
                 else
                 {
                     plsnumber = "001";
                 }
                 if (plsnumber == "001")
                 {
                     myconnection.Close();
                 }
                 else
                 {
                     dr.Close();
                     myconnection.Close();
                 }
             }

             catch (Exception ex)
             {
                 System.Windows.Forms.MessageBox.Show(ex.Message);
             }
             finally
             {
                 //dr.Close();
                 myconnection.Close();
             }
         }
        public void WarehouseAutoNum()
         {
             try
             {
                 ClsGetConnection1.ClsGetConMSSQL();
                 myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                 myconnection.Open();
                 if (new Clsexist().RecordExists(ref myconnection, "SELECT WHCode FROM tblWarehouse"))
                 {
                     mycommand = new SqlCommand("SELECT Top 1 WHCode FROM tblWarehouse ORDER BY WHCode DESC", myconnection);
                     dr = mycommand.ExecuteReader();
                     while (dr.Read())
                     {
                         string no1 = null;
                         int no2;
                         no1 = dr["WHCode"].ToString();
                         no2 = (int.Parse(no1)) + 1;
                         plsnumber = Convert.ToString(no2).PadLeft(3, '0');
                     }
                 }
                 else
                 {
                     plsnumber = "001";
                 }
                 if (plsnumber == "001")
                 {
                     myconnection.Close();
                 }
                 else
                 {
                     dr.Close();
                     myconnection.Close();
                 }
             }

             catch (Exception ex)
             {
                 System.Windows.Forms.MessageBox.Show(ex.Message);
             }
             finally
             {
                 //dr.Close();
                 myconnection.Close();
             }
         }

        public void SalesmanAutoNum()
         {
             try
             {
                 ClsGetConnection1.ClsGetConMSSQL();
                 myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                 myconnection.Open();
                 if (new Clsexist().RecordExists(ref myconnection, "SELECT Top 1 SMCode FROM tblSalesman"))
                 {
                     mycommand = new SqlCommand("SELECT Top 1 SMCode FROM tblSalesman ORDER BY SMCode DESC", myconnection);
                     dr = mycommand.ExecuteReader();
                     while (dr.Read())
                     {
                         string no1 = null;
                         int no2;
                         no1 = dr["SMCode"].ToString();
                         no2 = (int.Parse(no1)) + 1;
                         plsnumber = Convert.ToString(no2).PadLeft(3, '0');

                     }
                 }
                 else
                 {
                     plsnumber = "001";
                 }
                 if (plsnumber == "001")
                 {
                     myconnection.Close();
                 }
                 else
                 {
                     dr.Close();
                     myconnection.Close();
                 }
             }

             catch (Exception ex)
             {
                 System.Windows.Forms.MessageBox.Show(ex.Message);
             }
             finally
             {
                 //dr.Close();
                 myconnection.Close();
             }
         }

         public void Dept1AutoNum()
         {
             try
             {
                 ClsGetConnection1.ClsGetConMSSQL();
                 myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                 myconnection.Open();
                 if (new Clsexist().RecordExists(ref myconnection, "SELECT D1Code FROM tblDept1"))
                 {
                     mycommand = new SqlCommand("SELECT Top 1 D1Code FROM tblDept1 ORDER BY D1Code DESC", myconnection);
                     dr = mycommand.ExecuteReader();
                     while (dr.Read())
                     {
                         string no1 = null;
                         int no2;
                         no1 = dr["D1Code"].ToString();
                         no2 = (int.Parse(no1)) + 1;
                         plsnumber = Convert.ToString(no2).PadLeft(4, '0');

                     }
                 }
                 else
                 {
                     plsnumber = "0001";
                 }
                 if (plsnumber == "0001")
                 {
                     myconnection.Close();
                 }
                 else
                 {
                     dr.Close();
                     myconnection.Close();
                 }

             }

             catch (Exception ex)
             {
                 System.Windows.Forms.MessageBox.Show(ex.Message);
             }
             finally
             {
                 //dr.Close();
                 myconnection.Close();
             }
         }
         public void Dept2AutoNum()
         {
             try
             {
                 ClsGetConnection1.ClsGetConMSSQL();
                 myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                 myconnection.Open();
                 if (new Clsexist().RecordExists(ref myconnection, "SELECT D2Code FROM tblDept2"))
                 {
                     mycommand = new SqlCommand("SELECT Top 1 D2Code FROM tblDept2 ORDER BY D2Code DESC", myconnection);
                     dr = mycommand.ExecuteReader();
                     while (dr.Read())
                     {
                         string no1 = null;
                         int no2;
                         no1 = dr["D2Code"].ToString();
                         no2 = (int.Parse(no1)) + 1;
                         plsnumber = Convert.ToString(no2).PadLeft(4, '0');
                     }
                 }
                 else
                 {
                     plsnumber = "0001";
                 }
                 if (plsnumber == "0001")
                 {
                     myconnection.Close();
                 }
                 else
                 {
                     dr.Close();
                     myconnection.Close();
                 }
             }

             catch (Exception ex)
             {
                 System.Windows.Forms.MessageBox.Show(ex.Message);
             }
             finally
             {
                 //dr.Close();
                 myconnection.Close();
             }
         }

         public void ProductAddAutNum()
         {
             try
             {

                 ClsGetConnection1.ClsGetConMSSQL();
                 myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                 myconnection.Open();

                 if (new Clsexist().RecordExists(ref myconnection, "SELECT StockNumber FROM tblStocks "))
                 {
                     mycommand = new SqlCommand("SELECT Top 1 StockNumber FROM tblStocks ORDER BY StockNumber DESC", myconnection);
                     dr = mycommand.ExecuteReader();
                     while (dr.Read())
                     {
                         string no1;
                         int no2;
                         //no1 = dr["EmployeeCode"].ToString();
                         no1 = dr[0].ToString();
                         no2 = (int.Parse(no1)) + 1;
                         plsnumber = Convert.ToString(no2).PadLeft(5, '0');
                     }
                 }
                 else
                 {
                     plsnumber = "00001";
                 }
                 if (plsnumber == "00001")
                 {
                     myconnection.Close();
                 }
                 else
                 {
                     dr.Close();
                     myconnection.Close();
                 }
             }

             catch (Exception ex)
             {
                 System.Windows.Forms.MessageBox.Show(ex.Message);
             }
             finally
             {
                 //dr.Close();
                 myconnection.Close();
             }
         }

         public void CollectorAutoNum()
         {
             try
             {
                 ClsGetConnection1.ClsGetConMSSQL();
                 myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                 myconnection.Open();

                 if (new Clsexist().RecordExists(ref myconnection, "SELECT CollectCode FROM tblCollector "))
                 {
                     mycommand = new SqlCommand("SELECT Top 1 CollectCode FROM tblCollector ORDER BY CollectCode DESC", myconnection);
                     dr = mycommand.ExecuteReader();
                     while (dr.Read())
                     {
                         string no1;
                         int no2;
                         no1 = dr[0].ToString();
                         no2 = (int.Parse(no1)) + 1;
                         plsnumber = Convert.ToString(no2).PadLeft(3, '0');
                     }
                 }
                 else
                 {
                     plsnumber = "001";
                 }
                 if (plsnumber == "001")
                 {
                     myconnection.Close();
                 }
                 else
                 {
                     dr.Close();
                     myconnection.Close();
                 }
             }

             catch (Exception ex)
             {
                 System.Windows.Forms.MessageBox.Show(ex.Message);
             }
             finally
             {
                 myconnection.Close();
             }
         }

         public void BankDetailAutoNum()
         {
             try
             {
                 ClsGetConnection1.ClsGetConMSSQL();
                 myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                 myconnection.Open();
                 if (new Clsexist().RecordExists(ref myconnection, "SELECT BankCode FROM tblBankDetail"))
                 {
                     mycommand = new SqlCommand("SELECT Top 1 BankCode FROM tblBankDetail ORDER BY BankCode DESC", myconnection);
                     dr = mycommand.ExecuteReader();
                     while (dr.Read())
                     {
                         string no1 = null;
                         int no2;
                         no1 = dr["BankCode"].ToString();
                         no2 = (int.Parse(no1)) + 1;
                         plsnumber = Convert.ToString(no2).PadLeft(2, '0');
                     }
                 }
                 else
                 {
                     plsnumber = "01";
                 }
                 if (plsnumber == "01")
                 {
                     myconnection.Close();
                 }
                 else
                 {
                     dr.Close();
                     myconnection.Close();
                 }
             }

             catch (Exception ex)
             {
                 System.Windows.Forms.MessageBox.Show(ex.Message);
             }
             finally
             {
                 //dr.Close();
                 myconnection.Close();
             }
         }


    }
}
