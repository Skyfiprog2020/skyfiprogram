﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace TCIGL
{
    static class Program
    {
        //public static string mycon;
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
           // string varservername = Form1.glblservername.Text;
  //          mycon = "Server = 112.207.212.37; Database = TCIGL_BE; User ID = server2008; Password = Mssqlone1; Trusted_Connection = False;";
  //          mycon = "Server = +Form1.glblservername.Text+; Database = TCIGL_BE; User ID = server2008; Password = Mssqlone1; Trusted_Connection = False;";
 //           mycon = "Server = WINSERVER\\SERVEROTHER; Database = TCIGL_BE; User ID = server2008; Password = Mssqlone1; Trusted_Connection = False;";
 //             mycon = "Server = GL_SERVER; Database = TCIGL_BE; User ID = server2008; Password = Mssqlone1; Trusted_Connection = False;";
  //          mycon = "Server = iexterminate.ddns.net; Database = TCIGL_BE; User ID = server2008; Password = Mssqlone1; Trusted_Connection = False;";
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
