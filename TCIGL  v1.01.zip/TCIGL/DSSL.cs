﻿namespace TCIGL
{
    
    
    public partial class DSSL {
    }
}
