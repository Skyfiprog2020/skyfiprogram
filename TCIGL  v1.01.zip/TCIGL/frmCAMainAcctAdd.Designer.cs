﻿namespace TCIGL
{
    partial class frmCAMainAcctAdd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnsave = new System.Windows.Forms.Button();
            this.btnclose = new System.Windows.Forms.Button();
            this.txtAcctNo = new System.Windows.Forms.TextBox();
            this.txtTitleAcct = new System.Windows.Forms.TextBox();
            this.cboFCCode = new System.Windows.Forms.ComboBox();
            this.cboFSClass = new System.Windows.Forms.ComboBox();
            this.cboNormalBal = new System.Windows.Forms.ComboBox();
            this.cboSCCode = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.cboUsageCode = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(21, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(126, 19);
            this.label1.TabIndex = 3;
            this.label1.Text = "Account Number:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(21, 85);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(103, 19);
            this.label2.TabIndex = 4;
            this.label2.Text = "Account Title:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(21, 148);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(126, 19);
            this.label3.TabIndex = 5;
            this.label3.Text = "FS Classification:";
            // 
            // btnsave
            // 
            this.btnsave.Location = new System.Drawing.Point(290, 478);
            this.btnsave.Name = "btnsave";
            this.btnsave.Size = new System.Drawing.Size(75, 23);
            this.btnsave.TabIndex = 7;
            this.btnsave.Text = "&Save";
            this.btnsave.UseVisualStyleBackColor = true;
            this.btnsave.Click += new System.EventHandler(this.btnsave_Click);
            // 
            // btnclose
            // 
            this.btnclose.Location = new System.Drawing.Point(371, 478);
            this.btnclose.Name = "btnclose";
            this.btnclose.Size = new System.Drawing.Size(75, 23);
            this.btnclose.TabIndex = 8;
            this.btnclose.Text = "&Close";
            this.btnclose.UseVisualStyleBackColor = true;
            this.btnclose.Click += new System.EventHandler(this.btnclose_Click);
            // 
            // txtAcctNo
            // 
            this.txtAcctNo.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAcctNo.Location = new System.Drawing.Point(25, 44);
            this.txtAcctNo.Name = "txtAcctNo";
            this.txtAcctNo.Size = new System.Drawing.Size(421, 26);
            this.txtAcctNo.TabIndex = 0;
            this.txtAcctNo.KeyDown += new System.Windows.Forms.KeyEventHandler(this.nextfieldenter1);
            // 
            // txtTitleAcct
            // 
            this.txtTitleAcct.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTitleAcct.Location = new System.Drawing.Point(25, 107);
            this.txtTitleAcct.Name = "txtTitleAcct";
            this.txtTitleAcct.Size = new System.Drawing.Size(418, 26);
            this.txtTitleAcct.TabIndex = 1;
            this.txtTitleAcct.KeyDown += new System.Windows.Forms.KeyEventHandler(this.nextfieldenter1);
            // 
            // cboFCCode
            // 
            this.cboFCCode.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cboFCCode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cboFCCode.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboFCCode.FormattingEnabled = true;
            this.cboFCCode.Location = new System.Drawing.Point(25, 234);
            this.cboFCCode.Name = "cboFCCode";
            this.cboFCCode.Size = new System.Drawing.Size(421, 27);
            this.cboFCCode.TabIndex = 3;
            this.cboFCCode.KeyDown += new System.Windows.Forms.KeyEventHandler(this.nextfieldenter2);
            this.cboFCCode.Validating += new System.ComponentModel.CancelEventHandler(this.cboFCCode_Validating);
            // 
            // cboFSClass
            // 
            this.cboFSClass.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cboFSClass.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cboFSClass.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboFSClass.FormattingEnabled = true;
            this.cboFSClass.Location = new System.Drawing.Point(25, 170);
            this.cboFSClass.Name = "cboFSClass";
            this.cboFSClass.Size = new System.Drawing.Size(421, 27);
            this.cboFSClass.TabIndex = 2;
            this.cboFSClass.KeyDown += new System.Windows.Forms.KeyEventHandler(this.nextfieldenter2);
            this.cboFSClass.Validating += new System.ComponentModel.CancelEventHandler(this.cboFSClass_Validating);
            // 
            // cboNormalBal
            // 
            this.cboNormalBal.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cboNormalBal.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cboNormalBal.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboNormalBal.FormattingEnabled = true;
            this.cboNormalBal.Location = new System.Drawing.Point(25, 362);
            this.cboNormalBal.Name = "cboNormalBal";
            this.cboNormalBal.Size = new System.Drawing.Size(421, 27);
            this.cboNormalBal.TabIndex = 5;
            this.cboNormalBal.KeyDown += new System.Windows.Forms.KeyEventHandler(this.nextfieldenter2);
            this.cboNormalBal.Validating += new System.ComponentModel.CancelEventHandler(this.cboNormalBal_Validating);
            // 
            // cboSCCode
            // 
            this.cboSCCode.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cboSCCode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cboSCCode.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboSCCode.FormattingEnabled = true;
            this.cboSCCode.Location = new System.Drawing.Point(25, 298);
            this.cboSCCode.Name = "cboSCCode";
            this.cboSCCode.Size = new System.Drawing.Size(421, 27);
            this.cboSCCode.TabIndex = 4;
            this.cboSCCode.KeyDown += new System.Windows.Forms.KeyEventHandler(this.nextfieldenter2);
            this.cboSCCode.Validating += new System.ComponentModel.CancelEventHandler(this.cboSCCode_Validating);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(21, 276);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(118, 19);
            this.label4.TabIndex = 17;
            this.label4.Text = "Second Caption:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(21, 213);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(101, 19);
            this.label5.TabIndex = 16;
            this.label5.Text = "First Caption:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(18, 341);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(122, 19);
            this.label7.TabIndex = 18;
            this.label7.Text = "Normal Balance:";
            // 
            // cboUsageCode
            // 
            this.cboUsageCode.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cboUsageCode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cboUsageCode.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboUsageCode.FormattingEnabled = true;
            this.cboUsageCode.Location = new System.Drawing.Point(25, 426);
            this.cboUsageCode.Name = "cboUsageCode";
            this.cboUsageCode.Size = new System.Drawing.Size(421, 27);
            this.cboUsageCode.TabIndex = 6;
            this.cboUsageCode.KeyDown += new System.Windows.Forms.KeyEventHandler(this.nextfieldenter2);
            this.cboUsageCode.Validating += new System.ComponentModel.CancelEventHandler(this.cboUsageCode_Validating);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(21, 405);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(56, 19);
            this.label8.TabIndex = 20;
            this.label8.Text = "Usage:";
            // 
            // frmCAMainAcctAdd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(472, 522);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.cboUsageCode);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.cboNormalBal);
            this.Controls.Add(this.cboSCCode);
            this.Controls.Add(this.cboFCCode);
            this.Controls.Add(this.cboFSClass);
            this.Controls.Add(this.txtTitleAcct);
            this.Controls.Add(this.txtAcctNo);
            this.Controls.Add(this.btnclose);
            this.Controls.Add(this.btnsave);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "frmCAMainAcctAdd";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Main Account - Add";
            this.Load += new System.EventHandler(this.frmCAPAAdd_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnsave;
        private System.Windows.Forms.Button btnclose;
        private System.Windows.Forms.TextBox txtAcctNo;
        private System.Windows.Forms.TextBox txtTitleAcct;
        private System.Windows.Forms.ComboBox cboFCCode;
        private System.Windows.Forms.ComboBox cboFSClass;
        private System.Windows.Forms.ComboBox cboNormalBal;
        private System.Windows.Forms.ComboBox cboSCCode;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cboUsageCode;
        private System.Windows.Forms.Label label8;
    }
}