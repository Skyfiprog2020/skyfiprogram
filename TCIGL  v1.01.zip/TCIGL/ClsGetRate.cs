﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;

namespace TCIGL
{
    class ClsGetRate
    {
        public string plsServiceCharge, plsProcessFee, plsNotarialFee;
        public string plsReferralFee, plsInsurance, plsATM, plsCI;
        public string plsAveCostCase;
        SqlConnection myconnection;
        SqlDataReader dr;
        SqlCommand mycommand;
        ClsGetConnection ClsGetConnection1 = new ClsGetConnection(); 

        public void ClsGetRatedata()
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = new SqlCommand("SELECT ServiceCharge, ProcessFee, NotarialFee, ReferralFee, Insurance, ATM, CI FROM tblRate", myconnection);
                    dr = mycommand.ExecuteReader();
                    while (dr.Read())
                    {
                        plsServiceCharge = Convert.ToDouble(dr["ServiceCharge"]).ToString("N2");
                        plsProcessFee = Convert.ToDouble(dr["ProcessFee"]).ToString("N2");
                        plsNotarialFee = Convert.ToDouble(dr["NotarialFee"]).ToString("N2");
                        plsReferralFee = Convert.ToDouble(dr["ReferralFee"]).ToString("N2");
                        plsInsurance = Convert.ToDouble(dr["Insurance"]).ToString("N2");
                        plsATM = Convert.ToDouble(dr["ATM"]).ToString("N2");
                        plsCI= Convert.ToDouble(dr["CI"]).ToString("N2");

                    }
                    dr.Close();
                    myconnection.Close();


            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                //dr.Close();
                myconnection.Close();
            }
        }

        public void ClsGetAveCost(string strStockNumber)
        {
            try
            {
                if (new ClsValidation().DataExist("ViewAveCost2", "StockNumber", strStockNumber))
                {
                    ClsGetConnection1.ClsGetConMSSQL();
                    myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                    myconnection.Open();
                    mycommand = new SqlCommand("SELECT AveCostCase FROM ViewAveCost2 WHERE StockNumber='" + strStockNumber + "'", myconnection);
                    dr = mycommand.ExecuteReader();
                    while (dr.Read())
                    {
                        plsAveCostCase = dr["AveCostCase"].ToString(); ;
                    }
                    dr.Close();
                    myconnection.Close();
                }
                else
                {
                    plsAveCostCase = "0";
                }
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                //dr.Close();
                //myconnection.Close();
            }
        }
    }
}
