﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TCIGL
{
    public partial class frmEntryCustomerEditOthers : Form
    {
        private SqlDataAdapter da;
        private DataTable dataTable = null;
        private SqlConnection myconnection;
        private BindingSource bindingSource = null;
        BindingSource bsource = new BindingSource();
        ClsDefaultBranch ClsDefaultBranch1 = new ClsDefaultBranch();
        //   DataSet ds = null;
        string sql;
        ClsGetConnection ClsGetConnection1 = new ClsGetConnection();
        ClsPermission ClsPermission1 = new ClsPermission(); 
        public frmEntryCustomerEditOthers()
        {
            InitializeComponent();
        }

        private void frmEntryCustomerEditOthers_Load(object sender, EventArgs e)
        {
            ClsPermission1.ClsObjects(this.Text);
            if (new ClsValidation().emptytxt(ClsPermission1.plstxtObject))
            {
                MessageBox.Show("You do not have necessary permission to open this file", "GL");
                this.Close();
            }
            else
            {

                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                sql = "SELECT ControlNo, CustCode, CustName, ContactNo, Address FROM tblCustomer WHERE NType ='O'";

                da = new SqlDataAdapter(sql, myconnection);
                SqlCommandBuilder commandBuilder = new SqlCommandBuilder(da);
                da.SelectCommand.CommandTimeout = 600;
                dataTable = new DataTable();
                da.Fill(dataTable);
                bindingSource = new BindingSource();
                bindingSource.DataSource = dataTable;

                //Adding  ControlNo TextBox
                DataGridViewTextBoxColumn ColumnControlNo = new DataGridViewTextBoxColumn();
                ColumnControlNo.HeaderText = "Code";
                //ColumnControlNo.Width = 80;
                ColumnControlNo.DataPropertyName = "ControlNo";
                ColumnControlNo.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
                ColumnControlNo.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
                ColumnControlNo.Visible = false;
                dgv1.Columns.Add(ColumnControlNo);

                //Adding  CustCode TextBox
                DataGridViewTextBoxColumn ColumnCustCode = new DataGridViewTextBoxColumn();
                ColumnCustCode.HeaderText = "Code";
                //ColumnItem.Width = 80;
                ColumnCustCode.DataPropertyName = "CustCode";
                ColumnCustCode.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
                ColumnCustCode.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
                ColumnCustCode.ReadOnly = true;
                dgv1.Columns.Add(ColumnCustCode);

                //Adding  CustName TextBox
                DataGridViewTextBoxColumn ColumnCustName = new DataGridViewTextBoxColumn();
                ColumnCustName.HeaderText = "Name";
                ColumnCustName.Width = 210;
                ColumnCustName.DataPropertyName = "CustName";
               // ColumnCustName.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                ColumnCustName.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
                ColumnCustName.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
                dgv1.Columns.Add(ColumnCustName);

                //Adding  ContactNo TextBox
                DataGridViewTextBoxColumn ColumnContactNo = new DataGridViewTextBoxColumn();
                ColumnContactNo.HeaderText = "Contact Number";
                //ColumnItem.Width = 80;
                ColumnContactNo.DataPropertyName = "ContactNo";
                ColumnContactNo.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
                ColumnContactNo.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
                dgv1.Columns.Add(ColumnContactNo);

                //Adding  Address TextBox
                DataGridViewTextBoxColumn ColumnAddress = new DataGridViewTextBoxColumn();
                ColumnAddress.HeaderText = "Address";
                //ColumnItem.Width = 80;
                ColumnAddress.DataPropertyName = "Address";
                ColumnAddress.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
                ColumnAddress.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
                dgv1.Columns.Add(ColumnAddress);

                //Setting Data Source for DataGridView
                dgv1.DataSource = bindingSource;
               // dgv1.AutoResizeColumns();
                //dgv1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
                myconnection.Close();
               this.WindowState = FormWindowState.Maximized;
                dgv1.AllowUserToAddRows = false;
            }
        }

        private void btnclose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                da.Update(dataTable);
                MessageBox.Show("Saved", "GL");
                this.Close();

            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }
    }
}
