﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using CrystalDecisions.CrystalReports.Engine;
using System.Data.SqlClient;

namespace TCIGL
{
    public partial class frmrptBooksWarehouse : Form
    {
        SqlConnection myconnection;
        BindingSource dbind = new BindingSource();
        ClsCompName ClsCompName1 = new ClsCompName();
        ClsBuildEntryComboBox ClsBuildEntryComboBox1 = new ClsBuildEntryComboBox();
        ClsBuildComboBox ClsBuildComboBox1 = new ClsBuildComboBox();
        ClsDefaultBranch ClsDefaultBranch1 = new ClsDefaultBranch();
        ClsGetSomething ClsGetSomething1 = new ClsGetSomething();
        ClsGetConnection ClsGetConnection1 = new ClsGetConnection();
        ClsPermission ClsPermission1 = new ClsPermission();
        SqlCommand mycommand;
        SqlDataReader SqlDataReader1;
        string sqlstatement;
        public frmrptBooksWarehouse()
        {
            InitializeComponent();
            cbortprint.DisplayMember = "Text";
            cbortprint.ValueMember = "Value";
            cbortprint.Text = "Accounts Payable Voucher";
            var items = new[]
            { 
             new { Text = "Purchase Delivery", Value = "01" },
             new { Text = "Return To Supplier", Value = "02" },
             new { Text = "Charge Invoice", Value = "03" },
             new { Text = "Cash Sales", Value = "04" },
             new { Text = "Return Slip", Value = "05" },
             new { Text = "Transfer Slip", Value = "06" },
             new { Text = "Adjustment Slip", Value = "07" },
             new { Text = "Withdrawal Slip", Value = "08" },
             new { Text = "Production Slip", Value = "09" },
            };
            cbortprint.DataSource = items;
        }

        private void buildcboWHCode()
        {
            cboWHCode.DataSource = null;
            ClsBuildEntryComboBox1.ARWHCode.Clear();
            ClsBuildEntryComboBox1.ClsBuildWHCode();
            this.cboWHCode.DataSource = (ClsBuildEntryComboBox1.ARWHCode);
            this.cboWHCode.DisplayMember = "Display";
            this.cboWHCode.ValueMember = "Value";
            //this.cboWHCode.DropDownWidth = 450;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtBeginDate_Leave(object sender, EventArgs e)
        {
            if (new ClsValidation().errordate(txtBeginDate.Text) == true)
            {
                MessageBox.Show("Invalid Date", "GL");
                txtBeginDate.Focus();
            }
        }

        private void txtEndDate_Leave(object sender, EventArgs e)
        {
            if (new ClsValidation().errordate(txtEndDate.Text) == true)
            {
                MessageBox.Show("Invalid Date", "GL");
                txtEndDate.Focus();
            }
        }

        private void btnPreview_Click(object sender, EventArgs e)
        {
            if (new ClsValidation().emptytxt(cbortprint.Text))
            {
                MessageBox.Show("Please complete your entry", "GL");
                cbortprint.Focus();
            }
            else if (new ClsValidation().emptytxt(cboCNCode.Text))
            {
                MessageBox.Show("Please complete your entry", "GL");
                cboCNCode.Focus();
            }
            else if (new ClsValidation().emptytxt(cboWHCode.Text))
            {
                MessageBox.Show("Please complete your entry", "GL");
                cboWHCode.Focus();
            }
            else if (txtBeginDate.Text == "  /  /")
            {
                MessageBox.Show("Please complete your entry", "GL");
                txtBeginDate.Focus();
            }
            else if (txtEndDate.Text == "  /  /")
            {
                MessageBox.Show("Please complete your entry", "GL");
                txtEndDate.Focus();
            }
            else if (Convert.ToDateTime(txtBeginDate.Text) > Convert.ToDateTime(txtEndDate.Text))
            {
                MessageBox.Show("Beginning date is greater than ending date");
                txtBeginDate.Focus();
            }
            else
            {
                if (cbortprint.SelectedValue.ToString() == "01")//Purchase Delivery
                {
                    BookPD();
                }
                else if (cbortprint.SelectedValue.ToString() == "02")//Return To Supplier
                {
                    BookRTS();
                }
                else if (cbortprint.SelectedValue.ToString() == "03")//Charge Invoice
                {
                    BookCI();
                }
                else if (cbortprint.SelectedValue.ToString() == "04")//Cash Sales
                {
                    BookCS();
                }

                else if (cbortprint.SelectedValue.ToString() == "05")//Return Slip
                {
                    BookRS();
                }

                else if (cbortprint.SelectedValue.ToString() == "06")//Transfer Slip
                {
                    BookTS();
                }
                else if (cbortprint.SelectedValue.ToString() == "07")//Adjustment Slip
                {
                    BookAS();
                }
                else if (cbortprint.SelectedValue.ToString() == "08")//Withdrawal Slip
                {
                    BookWS();
                }
                else if (cbortprint.SelectedValue.ToString() == "09")//Production Slip
                {
                    BookPS();
                }
            }
        }

        private void BookPD()
        {
            sqlstatement = "SELECT * FROM ViewDetailsBookPD WHERE TDate BETWEEN '" + txtBeginDate.Text + "' And  '" + txtEndDate.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "' AND WHCode='"+cboWHCode.SelectedValue.ToString()+"'";
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();
            mycommand = myconnection.CreateCommand();
            mycommand.CommandText = sqlstatement;
            mycommand.CommandTimeout = 900;
            SqlDataReader1 = mycommand.ExecuteReader();
            DataTable DataTable1 = new DataTable();
            DataTable1.Load(SqlDataReader1);
            myconnection.Close();

            if (DataTable1.Rows.Count == 0)
            {
                MessageBox.Show("No data found", "GL");
                return;
            }


            CRBookPD objRpt = new CRBookPD();
            TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            ClsCompName1.ClsCompNameMain();
            vartxtcompany.Text = ClsCompName1.varcn;

            ClsCompName1.ClsCompNamebranchAddress(cboCNCode.SelectedValue.ToString());
            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            vartxtaddress.Text = ClsCompName1.plsCRaddress;

            TextObject varTextDateRange = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["TextDateRange"];
            varTextDateRange.Text = "From " + txtBeginDate.Text + " To " + txtEndDate.Text;

            objRpt.SetDataSource(DataTable1);
            crystalReportViewer1.ReportSource = objRpt;
            crystalReportViewer1.Refresh();
        }

        private void BookRTS()
        {
            sqlstatement = "SELECT * FROM ViewDetailsBookRTS WHERE TDate BETWEEN '" + txtBeginDate.Text + "' And  '" + txtEndDate.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "' AND WHCode='" + cboWHCode.SelectedValue.ToString() + "'";

            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();
            mycommand = myconnection.CreateCommand();
            mycommand.CommandText = sqlstatement;
            mycommand.CommandTimeout = 900;
            SqlDataReader1 = mycommand.ExecuteReader();
            DataTable DataTable1 = new DataTable();
            DataTable1.Load(SqlDataReader1);
            myconnection.Close();

            if (DataTable1.Rows.Count == 0)
            {
                MessageBox.Show("No data found", "GL");
                return;
            }

            CRBookRTS objRpt = new CRBookRTS();
            TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            ClsCompName1.ClsCompNameMain();
            vartxtcompany.Text = ClsCompName1.varcn;

            ClsCompName1.ClsCompNamebranchAddress(cboCNCode.SelectedValue.ToString());
            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            vartxtaddress.Text = ClsCompName1.plsCRaddress;

            TextObject varTextDateRange = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["TextDateRange"];
            varTextDateRange.Text = "From " + txtBeginDate.Text + " To " + txtEndDate.Text;

            objRpt.SetDataSource(DataTable1);
            crystalReportViewer1.ReportSource = objRpt;
            crystalReportViewer1.Refresh();
        }

        private void BookCS()
        {
            sqlstatement = "SELECT * FROM ViewDetailsBookCS WHERE TDate BETWEEN '" + txtBeginDate.Text + "' And  '" + txtEndDate.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "' AND WHCode='" + cboWHCode.SelectedValue.ToString() + "'";

            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();
            mycommand = myconnection.CreateCommand();
            mycommand.CommandText = sqlstatement;
            mycommand.CommandTimeout = 900;
            SqlDataReader1 = mycommand.ExecuteReader();
            DataTable DataTable1 = new DataTable();
            DataTable1.Load(SqlDataReader1);
            myconnection.Close();

            if (DataTable1.Rows.Count == 0)
            {
                MessageBox.Show("No data found", "GL");
                return;
            }

            CRBookCS objRpt = new CRBookCS();
            TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            ClsCompName1.ClsCompNameMain();
            vartxtcompany.Text = ClsCompName1.varcn;

            ClsCompName1.ClsCompNamebranchAddress(cboCNCode.SelectedValue.ToString());
            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            vartxtaddress.Text = ClsCompName1.plsCRaddress;

            TextObject varTextDateRange = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["TextDateRange"];
            varTextDateRange.Text = "From " + txtBeginDate.Text + " To " + txtEndDate.Text;

            objRpt.SetDataSource(DataTable1);
            crystalReportViewer1.ReportSource = objRpt;
            crystalReportViewer1.Refresh();
        }

        private void BookCI()
        {
            sqlstatement = "SELECT * FROM ViewDetailsBookCI WHERE TDate BETWEEN '" + txtBeginDate.Text + "' And  '" + txtEndDate.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "' AND WHCode='" + cboWHCode.SelectedValue.ToString() + "'";

            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();
            mycommand = myconnection.CreateCommand();
            mycommand.CommandText = sqlstatement;
            mycommand.CommandTimeout = 900;
            SqlDataReader1 = mycommand.ExecuteReader();
            DataTable DataTable1 = new DataTable();
            DataTable1.Load(SqlDataReader1);
            myconnection.Close();

            if (DataTable1.Rows.Count == 0)
            {
                MessageBox.Show("No data found", "GL");
                return;
            }

            CRBookCI objRpt = new CRBookCI();
            TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            ClsCompName1.ClsCompNameMain();
            vartxtcompany.Text = ClsCompName1.varcn;

            ClsCompName1.ClsCompNamebranchAddress(cboCNCode.SelectedValue.ToString());
            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            vartxtaddress.Text = ClsCompName1.plsCRaddress;

            TextObject varTextDateRange = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["TextDateRange"];
            varTextDateRange.Text = "From " + txtBeginDate.Text + " To " + txtEndDate.Text;

            objRpt.SetDataSource(DataTable1);
            crystalReportViewer1.ReportSource = objRpt;
            crystalReportViewer1.Refresh();
        }
        private void BookAS()
        {
            sqlstatement = "SELECT * FROM ViewDetailsBookAS WHERE TDate BETWEEN '" + txtBeginDate.Text + "' And  '" + txtEndDate.Text + "'AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "' AND WHCode='" + cboWHCode.SelectedValue.ToString() + "'";

            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();
            mycommand = myconnection.CreateCommand();
            mycommand.CommandText = sqlstatement;
            mycommand.CommandTimeout = 900;
            SqlDataReader1 = mycommand.ExecuteReader();
            DataTable DataTable1 = new DataTable();
            DataTable1.Load(SqlDataReader1);
            myconnection.Close();

            if (DataTable1.Rows.Count == 0)
            {
                MessageBox.Show("No data found", "GL");
                return;
            }

            CRBookAS objRpt = new CRBookAS();
            TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            ClsCompName1.ClsCompNameMain();
            vartxtcompany.Text = ClsCompName1.varcn;

            ClsCompName1.ClsCompNamebranchAddress(cboCNCode.SelectedValue.ToString());
            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            vartxtaddress.Text = ClsCompName1.plsCRaddress;

            TextObject varTextDateRange = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["TextDateRange"];
            varTextDateRange.Text = "From " + txtBeginDate.Text + " To " + txtEndDate.Text;

            objRpt.SetDataSource(DataTable1);
            crystalReportViewer1.ReportSource = objRpt;
            crystalReportViewer1.Refresh();
        }

        private void BookRS()
        {
            sqlstatement = "SELECT * FROM ViewDetailsBookRS WHERE TDate BETWEEN '" + txtBeginDate.Text + "' And  '" + txtEndDate.Text + "'AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "' AND WHCode='" + cboWHCode.SelectedValue.ToString() + "'";

            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();
            mycommand = myconnection.CreateCommand();
            mycommand.CommandText = sqlstatement;
            mycommand.CommandTimeout = 900;
            SqlDataReader1 = mycommand.ExecuteReader();
            DataTable DataTable1 = new DataTable();
            DataTable1.Load(SqlDataReader1);
            myconnection.Close();

            if (DataTable1.Rows.Count == 0)
            {
                MessageBox.Show("No data found", "GL");
                return;
            }

            CRBookRS objRpt = new CRBookRS();
            TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            ClsCompName1.ClsCompNameMain();
            vartxtcompany.Text = ClsCompName1.varcn;

            ClsCompName1.ClsCompNamebranchAddress(cboCNCode.SelectedValue.ToString());
            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            vartxtaddress.Text = ClsCompName1.plsCRaddress;

            TextObject varTextDateRange = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["TextDateRange"];
            varTextDateRange.Text = "From " + txtBeginDate.Text + " To " + txtEndDate.Text;

            objRpt.SetDataSource(DataTable1);
            crystalReportViewer1.ReportSource = objRpt;
            crystalReportViewer1.Refresh();
        }

        private void BookTS()
        {
            sqlstatement = "SELECT * FROM ViewDetailsBookTS WHERE TDate BETWEEN '" + txtBeginDate.Text + "' And  '" + txtEndDate.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "' AND WHCode='" + cboWHCode.SelectedValue.ToString() + "'";

            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();
            mycommand = myconnection.CreateCommand();
            mycommand.CommandText = sqlstatement;
            mycommand.CommandTimeout = 900;
            SqlDataReader1 = mycommand.ExecuteReader();
            DataTable DataTable1 = new DataTable();
            DataTable1.Load(SqlDataReader1);
            myconnection.Close();

            if (DataTable1.Rows.Count == 0)
            {
                MessageBox.Show("No data found", "GL");
                return;
            }

            CRBookTS objRpt = new CRBookTS();
            TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            ClsCompName1.ClsCompNameMain();
            vartxtcompany.Text = ClsCompName1.varcn;

            ClsCompName1.ClsCompNamebranchAddress(cboCNCode.SelectedValue.ToString());
            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            vartxtaddress.Text = ClsCompName1.plsCRaddress;

            TextObject varTextDateRange = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["TextDateRange"];
            varTextDateRange.Text = "From " + txtBeginDate.Text + " To " + txtEndDate.Text;

            objRpt.SetDataSource(DataTable1);
            crystalReportViewer1.ReportSource = objRpt;
            crystalReportViewer1.Refresh();
        }


        private void BookWS()
        {
            sqlstatement = "SELECT * FROM ViewDetailsBookWS WHERE TDate BETWEEN '" + txtBeginDate.Text + "' And  '" + txtEndDate.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "' AND WHCode='" + cboWHCode.SelectedValue.ToString() + "'";

            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();
            mycommand = myconnection.CreateCommand();
            mycommand.CommandText = sqlstatement;
            mycommand.CommandTimeout = 900;
            SqlDataReader1 = mycommand.ExecuteReader();
            DataTable DataTable1 = new DataTable();
            DataTable1.Load(SqlDataReader1);
            myconnection.Close();

            if (DataTable1.Rows.Count == 0)
            {
                MessageBox.Show("No data found", "GL");
                return;
            }

            CRBookWS objRpt = new CRBookWS();
            TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            ClsCompName1.ClsCompNameMain();
            vartxtcompany.Text = ClsCompName1.varcn;

            ClsCompName1.ClsCompNamebranchAddress(cboCNCode.SelectedValue.ToString());
            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            vartxtaddress.Text = ClsCompName1.plsCRaddress;

            TextObject varTextDateRange = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["TextDateRange"];
            varTextDateRange.Text = "From " + txtBeginDate.Text + " To " + txtEndDate.Text;

            objRpt.SetDataSource(DataTable1);
            crystalReportViewer1.ReportSource = objRpt;
            crystalReportViewer1.Refresh();
        }

        private void BookPS()
        {
            sqlstatement = "SELECT * FROM ViewDetailsBookPS WHERE TDate BETWEEN '" + txtBeginDate.Text + "' And  '" + txtEndDate.Text + "' AND CNCode = '" + cboCNCode.SelectedValue.ToString() + "' AND WHCode='" + cboWHCode.SelectedValue.ToString() + "'";

            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();
            mycommand = myconnection.CreateCommand();
            mycommand.CommandText = sqlstatement;
            mycommand.CommandTimeout = 900;
            SqlDataReader1 = mycommand.ExecuteReader();
            DataTable DataTable1 = new DataTable();
            DataTable1.Load(SqlDataReader1);
            myconnection.Close();

            if (DataTable1.Rows.Count == 0)
            {
                MessageBox.Show("No data found", "GL");
                return;
            }

            CRBookPS objRpt = new CRBookPS();
            TextObject vartxtcompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtcompany"];
            ClsCompName1.ClsCompNameMain();
            vartxtcompany.Text = ClsCompName1.varcn;

            ClsCompName1.ClsCompNamebranchAddress(cboCNCode.SelectedValue.ToString());
            TextObject vartxtaddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["rpttxtaddress"];
            vartxtaddress.Text = ClsCompName1.plsCRaddress;

            TextObject varTextDateRange = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["TextDateRange"];
            varTextDateRange.Text = "From " + txtBeginDate.Text + " To " + txtEndDate.Text;

            objRpt.SetDataSource(DataTable1);
            crystalReportViewer1.ReportSource = objRpt;
            crystalReportViewer1.Refresh();
        }

        private void frmrptBooksWarehouse_Load(object sender, EventArgs e)
        {
            ClsPermission1.ClsObjects(this.Text);
            if (new ClsValidation().emptytxt(ClsPermission1.plstxtObject))
            {
                MessageBox.Show("You do not have necessary permission to open this file", "GL");
                this.Close();
            }
            else
            {
                ClsGetSomething1.ClsGetDefaultDate();
                txtBeginDate.Text = ClsGetSomething1.plsdefdate;
                txtEndDate.Text = ClsGetSomething1.plsdefdate;
                buildcboCNCode();
                buildcboWHCode();
                cboCNCode.SelectedValue = (ClsDefaultBranch1.plsvardb);
                this.WindowState = FormWindowState.Maximized;
            }
        }

        private void buildcboCNCode()
        {
            cboCNCode.DataSource = null;
            ClsBuildComboBox1.ARBranch.Clear();
            ClsBuildComboBox1.ClsBuildBranch();
            this.cboCNCode.DataSource = (ClsBuildComboBox1.ARBranch);
            this.cboCNCode.DisplayMember = "Display";
            this.cboCNCode.ValueMember = "Value";
        }

      

        private void cboCNCode_Validating(object sender, CancelEventArgs e)
        {
            if (new ClsValidation().emptytxt(cboCNCode.Text))
            {
            }
            else if (cboCNCode.Text != null && cboCNCode.SelectedValue == null)
            {
                MessageBox.Show("Not found", "GL");
                cboCNCode.Focus();
            }
        }

        private void txtBeginDate_Leave_1(object sender, EventArgs e)
        {
            if (new ClsValidation().errordate(txtBeginDate.Text) == true)
            {
                MessageBox.Show("Invalid Date", "GL");
                txtBeginDate.Focus();
            }
        }

        private void txtEndDate_Leave_1(object sender, EventArgs e)
        {
            if (new ClsValidation().errordate(txtEndDate.Text) == true)
            {
                MessageBox.Show("Invalid Date", "GL");
                txtEndDate.Focus();
            }
        }

        private void nextfieldenter1(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.Equals(Keys.Enter))
            {
                SendKeys.Send("{TAB}");
            }
            else if ((e.KeyCode.Equals(Keys.Up)) || (e.KeyCode.Equals(Keys.Left)))
            {
                SendKeys.Send("+{TAB}");
            }
            else if ((e.KeyCode.Equals(Keys.Down)) || (e.KeyCode.Equals(Keys.Right)))
            {
                SendKeys.Send("{TAB}");
            }

        }

        private void nextfieldenter2(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.Equals(Keys.Enter))
            {
                SendKeys.Send("{TAB}");
            }

        }
      

    }
}
