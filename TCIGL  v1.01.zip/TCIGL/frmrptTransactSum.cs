﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using CrystalDecisions.CrystalReports.Engine;
using System.Data.SqlClient;

namespace TCIGL
{
    public partial class frmrptTransactSum : Form
    {
        SqlConnection myconnection;
        BindingSource dbind = new BindingSource();
        SqlCommand mycommand;
        SqlDataReader SqlDataReader1;
        ClsCompName ClsCompName1 = new ClsCompName();
        ClsBuildComboBox ClsBuildComboBox1 = new ClsBuildComboBox();
        ClsDefaultBranch ClsDefaultBranch1 = new ClsDefaultBranch();
        ClsGetSomething ClsGetSomething1 = new ClsGetSomething();
        ClsPermission ClsPermission1 = new ClsPermission();
        ClsGetConnection ClsGetConnection1 = new ClsGetConnection();
        ClsBuildEntryComboBox ClsBuildEntryComboBox1 = new ClsBuildEntryComboBox();
 
        public frmrptTransactSum()
        {
            InitializeComponent();
            cbortprint.DisplayMember = "Text";
            cbortprint.ValueMember = "Value";
            cbortprint.SelectedValue="01";
            var items = new[]
            { 
             new { Text = "Transaction Summary - All", Value = "01" },
             new { Text = "Transaction Summary - Category", Value = "02" },
            };
            cbortprint.DataSource = items;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtBeginDate_Leave(object sender, EventArgs e)
        {
            if (new ClsValidation().errordate(txtBeginDate.Text) == true)
            {
                MessageBox.Show("Invalid Date", "GL");
                txtBeginDate.Focus();
            }
        }

        private void txtEndDate_Leave(object sender, EventArgs e)
        {
            if (new ClsValidation().errordate(txtEndDate.Text) == true)
            {
                MessageBox.Show("Invalid Date", "GL");
                txtEndDate.Focus();
            }
        }

        private void btnPreview_Click(object sender, EventArgs e)
        {
            if (new ClsValidation().emptytxt(cbortprint.Text))
            {
                MessageBox.Show("Please complete your entry", "GL");
                cbortprint.Focus();
            }
            else if (new ClsValidation().emptytxt(cboCNCode.Text))
            {
                MessageBox.Show("Please complete your entry", "GL");
                cboCNCode.Focus();
            }
            else if (txtBeginDate.Text == "  /  /")
            {
                MessageBox.Show("Please complete your entry", "GL");
                txtBeginDate.Focus();
            }
            else if (txtEndDate.Text == "  /  /")
            {
                MessageBox.Show("Please complete your entry", "GL");
                txtEndDate.Focus();
            }
            else if (Convert.ToDateTime(txtBeginDate.Text) > Convert.ToDateTime(txtEndDate.Text))
            {
                MessageBox.Show("Beginning date is greater than ending date");
                txtBeginDate.Focus();
            }
            else
            {
                if (cbortprint.SelectedValue.ToString() == "01")//Transaction Summary - All
                {
                    TransactSum();
                }
                else if (cbortprint.SelectedValue.ToString()=="02")//Transaction Summary - Category
                {
                    TransactSumCat();
                }
            }
        }

        private void frmrptTransactSum_Load(object sender, EventArgs e)
        {
            ClsPermission1.ClsObjects(this.Text);
            if (new ClsValidation().emptytxt(ClsPermission1.plstxtObject))
            {
                MessageBox.Show("You do not have necessary permission to open this file", "GL");
                this.Close();
            }
            else
            {
                ClsGetSomething1.ClsGetDefaultDate();
                txtBeginDate.Text = ClsGetSomething1.plsdefdate;
                txtEndDate.Text = ClsGetSomething1.plsdefdate;

                buildcboCNCode();
                buildcboWHCode();
                buildcboCatCode();
                cboWHCode.SelectedValue = "";
                cboCNCode.SelectedValue = (ClsDefaultBranch1.plsvardb);
                this.WindowState = FormWindowState.Maximized;
            }
        }
        private void buildcboCNCode()
        {
            cboCNCode.DataSource = null;
            ClsBuildComboBox1.ARBranch.Clear();
            ClsBuildComboBox1.ClsBuildBranch();
            this.cboCNCode.DataSource = (ClsBuildComboBox1.ARBranch);
            this.cboCNCode.DisplayMember = "Display";
            this.cboCNCode.ValueMember = "Value";
        }
        private void buildcboWHCode()
        {
            cboWHCode.DataSource = null;
            ClsBuildEntryComboBox1.ARWHCode.Clear();
            ClsBuildEntryComboBox1.ClsBuildWHCode();
            this.cboWHCode.DataSource = (ClsBuildEntryComboBox1.ARWHCode);
            this.cboWHCode.DisplayMember = "Display";
            this.cboWHCode.ValueMember = "Value";
            //this.cboWHCode.DropDownWidth = 450;
        }

        private void buildcboCatCode()
        {
            cboCatCode.DataSource = null;
            ClsBuildEntryComboBox1.ARCatCode.Clear();
            ClsBuildEntryComboBox1.ClsBuildCatCode();
            this.cboCatCode.DataSource = (ClsBuildEntryComboBox1.ARCatCode);
            this.cboCatCode.DisplayMember = "Display";
            this.cboCatCode.ValueMember = "Value";
        }
      
        private void TransactSum()
        {
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();
            mycommand = new SqlCommand("usp_TransactSum2", myconnection);
            mycommand.CommandType = CommandType.StoredProcedure;
            mycommand.Parameters.Add("@ParamCNCode2", SqlDbType.VarChar).Value = cboCNCode.SelectedValue.ToString();
            mycommand.Parameters.Add("@ParamBeginDate2", SqlDbType.DateTime).Value = txtBeginDate.Text;
            mycommand.Parameters.Add("@ParamEndDate2", SqlDbType.DateTime).Value = txtEndDate.Text;
            mycommand.Parameters.Add("@ParamWHCode2", SqlDbType.VarChar).Value = cboWHCode.SelectedValue.ToString();

            mycommand.CommandTimeout = 900;
            SqlDataReader1 = mycommand.ExecuteReader();
            DataTable DataTable1 = new DataTable();
            DataTable1.Load(SqlDataReader1);
            myconnection.Close();

            if (DataTable1.Rows.Count == 0)
            {
                MessageBox.Show("No data found", "GL");
                return;
            }
            CRTransactSum objRpt = new CRTransactSum();
            TextObject varTextCompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["TextCompany"];
            varTextCompany.Text = cboCNCode.Text;

            ClsGetSomething1.ClsGetBranchAddress(cboCNCode.SelectedValue.ToString());
            TextObject varTextAddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["TextAddress"];
            varTextAddress.Text = ClsGetSomething1.plsvarCAdress;

            TextObject varTextDateRange = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["TextDateRange"];
            varTextDateRange.Text = "From " + txtBeginDate.Text + " To " + txtEndDate.Text;

            TextObject varTextWarehouse = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["txtWHCode"];
            varTextWarehouse.Text = cboWHCode.Text;

            objRpt.SetDataSource(DataTable1);
            crystalReportViewer1.ReportSource = objRpt;
            crystalReportViewer1.Refresh();
        }

        private void TransactSumCat()
        {
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();
            mycommand = new SqlCommand("usp_TransactSumCat2", myconnection);
            mycommand.CommandType = CommandType.StoredProcedure;
            mycommand.Parameters.Add("@ParamCNCode2", SqlDbType.VarChar).Value = cboCNCode.SelectedValue.ToString();
            mycommand.Parameters.Add("@ParamBeginDate2", SqlDbType.DateTime).Value = txtBeginDate.Text;
            mycommand.Parameters.Add("@ParamEndDate2", SqlDbType.DateTime).Value = txtEndDate.Text;
            mycommand.Parameters.Add("@ParamWHCode2", SqlDbType.VarChar).Value = cboWHCode.SelectedValue.ToString();
            mycommand.Parameters.Add("@ParamCatCode2", SqlDbType.VarChar).Value = cboCatCode.SelectedValue.ToString();

            mycommand.CommandTimeout = 900;
            SqlDataReader1 = mycommand.ExecuteReader();
            DataTable DataTable1 = new DataTable();
            DataTable1.Load(SqlDataReader1);
            myconnection.Close();

            if (DataTable1.Rows.Count == 0)
            {
                MessageBox.Show("No data found", "GL");
                return;
            }
            CRTransactSum objRpt = new CRTransactSum();
            TextObject varTextCompany = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["TextCompany"];
            varTextCompany.Text = cboCNCode.Text;

            ClsGetSomething1.ClsGetBranchAddress(cboCNCode.SelectedValue.ToString());
            TextObject varTextAddress = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["TextAddress"];
            varTextAddress.Text = ClsGetSomething1.plsvarCAdress;

            TextObject varTextDateRange = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["TextDateRange"];
            varTextDateRange.Text = "From " + txtBeginDate.Text + " To " + txtEndDate.Text;

            TextObject varTextWarehouse = (TextObject)objRpt.ReportDefinition.Sections["Section1"].ReportObjects["txtWHCode"];
            varTextWarehouse.Text = cboWHCode.Text;

            objRpt.SetDataSource(DataTable1);
            crystalReportViewer1.ReportSource = objRpt;
            crystalReportViewer1.Refresh();
        }

        private void nextfieldenter1(object sender, KeyEventArgs e)
        {

        }

        private void nextfieldenter2(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.Equals(Keys.Enter))
            {
                SendKeys.Send("{TAB}");
            }
        }

        private void cbortprint_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbortprint.SelectedValue.ToString()=="01")
            {
                cboCatCode.Enabled = false;
            }
            else if (cbortprint.SelectedValue.ToString()=="02")
            {
                cboCatCode.Enabled = true;
            }
        }
    }
}
