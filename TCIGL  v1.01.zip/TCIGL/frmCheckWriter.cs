﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using CrystalDecisions.CrystalReports.Engine;
using System.Data.SqlClient;
using System.Drawing.Printing;

namespace TCIGL
{
    public partial class frmCheckWriter : Form
    {

        private SqlConnection myconnection; ClsGetConnection ClsGetConnection1 = new ClsGetConnection();
        //SqlDataReader dr;
        //SqlCommand mycommand;
        private SqlDataAdapter da;
        private DataTable dataTable = null;
        private BindingSource bindingSource = null;
        string pristrDocNum, pristrVoucher, pristrCheckNo, pristrTDate;

        //ClsCompName ClsCompName1 = new ClsCompName();
        ClsBuildComboBox ClsBuildComboBox1 = new ClsBuildComboBox();
        ClsDefaultBranch ClsDefaultBranch1 = new ClsDefaultBranch();
        ClsPermission ClsPermission1 = new ClsPermission();
        ClsGetSomething ClsGetSomething1 = new ClsGetSomething();
 
        int xstrDate = 0;// |
        int ystrDate = 0;// _
        int xstrtxtCustName = 0;// |
        int ystrtxtCustName = 0;// _
        int xstrtxtcamount = 0;// |
        int ystrtxtcamount = 0;// _
        int xstramtinword = 0;// |
        int ystramtinword = 0;// _
        int intsizefont = 0;
        int xstrComputerDoc = 0;//|
        int ystrComputerDoc = 0;//_

        public frmCheckWriter()
        {
            InitializeComponent();
        }

        private void buildcboCName()
        {
            ClsBuildComboBox1.ClsBuildBranch();
            this.cboCNCode.DataSource = (ClsBuildComboBox1.ARBranch);
            this.cboCNCode.DisplayMember = "Display";
            this.cboCNCode.ValueMember = "Value";
        }
     

        private void refreshlist()
        {
            if (txtBeginDate.Text == "  /  /")
            {
                MessageBox.Show("Please complete your entry", "GL");
                txtBeginDate.Focus();
            }
            else if (txtEndDate.Text == "  /  /")
            {
                MessageBox.Show("Please complete your entry", "GL");
                txtEndDate.Focus();
            }
            else if (Convert.ToDateTime(txtBeginDate.Text) > Convert.ToDateTime(txtEndDate.Text))
            {
                MessageBox.Show("Beginning date is greater than ending date");
                txtBeginDate.Focus();
            }
            else
            {
                showsearchdata();
            }
        }
        private void btnrefresh_Click(object sender, EventArgs e)
        {
            refreshlist();           
            
        }

        private void frmCheckWriter_Load(object sender, EventArgs e)
        {
            ClsPermission1.ClsObjects(this.Text);
            if (new ClsValidation().emptytxt(ClsPermission1.plstxtObject))
            {
                MessageBox.Show("You do not have necessary permission to open this file", "GL");
                this.Close();
            }
            else
            {
                String varDate1 = DateTime.Today.ToShortDateString();
                DateTime varDate2 = Convert.ToDateTime(varDate1);
                txtBeginDate.Text = String.Format("{0:MM/dd/yyyy}", varDate2);
                txtEndDate.Text = String.Format("{0:MM/dd/yyyy}", varDate2);
                buildcboCName();
                buildcboBankcode();
                cboCNCode.SelectedValue = (ClsDefaultBranch1.plsvardb);
                showsearchdata();
            }
        }

        private void buildcboBankcode()
        {
            cboBankCode.DataSource = null;
            ClsBuildComboBox1.ARLBankCode.Clear();
            ClsBuildComboBox1.ClsBuildBankCode();
            this.cboBankCode.DataSource = (ClsBuildComboBox1.ARLBankCode);
            this.cboBankCode.DisplayMember = "Display";
            this.cboBankCode.ValueMember = "Value";
        }

      
        private void txtBeginDate_Leave(object sender, EventArgs e)
        {
            if (new ClsValidation().errordate(txtBeginDate.Text) == true)
            {
                MessageBox.Show("Invalid Date", "GL");
                txtBeginDate.Focus();
            }
        }

        private void txtEndDate_Leave(object sender, EventArgs e)
        {
            if (new ClsValidation().errordate(txtEndDate.Text) == true)
            {
                MessageBox.Show("Invalid Date", "GL");
                txtEndDate.Focus();
            }
        }

       
      

        private void cboCName_Validated(object sender, EventArgs e)
        {
            refreshlist();
        }
        private void showsearchdata()
        {
            dgv1.DataSource = null;
            dgv1.Columns.Clear();

            string sql;
            sql = "SELECT DocNum, Voucher, CustName, BankActEntry, CheckNo, TDate, Credit  FROM viewcheckwriter WHERE TDate BETWEEN '" + txtBeginDate.Text + "' And  '" + txtEndDate.Text + "'";
            ClsGetConnection1.ClsGetConMSSQL(); myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);


            da = new SqlDataAdapter(sql, myconnection);
            SqlCommandBuilder commandBuilder = new SqlCommandBuilder(da);

            dataTable = new DataTable();
            da.Fill(dataTable);
            bindingSource = new BindingSource();
            bindingSource.DataSource = dataTable;

            // Adding  DocNum TextBox
            DataGridViewTextBoxColumn ColumnNumber = new DataGridViewTextBoxColumn();
            ColumnNumber.HeaderText = "Number";
            ColumnNumber.Width = 65;
            ColumnNumber.DataPropertyName = "DocNum";
            //ColumnNumber.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnNumber.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnNumber.Visible = true;
            dgv1.Columns.Add(ColumnNumber);

            //Adding  Voucher TextBox
            DataGridViewTextBoxColumn ColumnVoucher = new DataGridViewTextBoxColumn();
            ColumnVoucher.HeaderText = "Voucher";
            ColumnVoucher.Width = 60;
            ColumnVoucher.DataPropertyName = "Voucher";
            //ColumnVoucher.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnVoucher.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            //ColumnVoucher.Visible = false;
            ColumnVoucher.ReadOnly = true;
            dgv1.Columns.Add(ColumnVoucher);

            // Adding  CustName TextBox
            DataGridViewTextBoxColumn ColumnCustName = new DataGridViewTextBoxColumn();
            ColumnCustName.HeaderText = "Name";
            ColumnCustName.Width = 225;
            ColumnCustName.DataPropertyName = "CustName";
            //ColumnCustName.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnCustName.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnCustName.Visible = true;
            dgv1.Columns.Add(ColumnCustName);

            // Adding  BankActEntry TextBox
            DataGridViewTextBoxColumn ColumnBankActEntry = new DataGridViewTextBoxColumn();
            ColumnBankActEntry.HeaderText = "Bank";
            ColumnBankActEntry.Width = 150;
            ColumnBankActEntry.DataPropertyName = "BankActEntry";
            //ColumnBankActEntry.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnBankActEntry.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnBankActEntry.Visible = true;
            dgv1.Columns.Add(ColumnBankActEntry);

            // Adding  CheckNo TextBox
            DataGridViewTextBoxColumn ColumnCheckNo = new DataGridViewTextBoxColumn();
            ColumnCheckNo.HeaderText = "Check No.";
            ColumnCheckNo.Width = 126;
            ColumnCheckNo.DataPropertyName = "CheckNo";
            //ColumnCheckNo.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnCheckNo.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnCheckNo.Visible = true;
            dgv1.Columns.Add(ColumnCheckNo);

            //Adding  Date TextBox
            DataGridViewTextBoxColumn ColumnTDate = new DataGridViewTextBoxColumn();
            ColumnTDate.HeaderText = "Date";
            ColumnTDate.Width = 75;
            ColumnTDate.DataPropertyName = "TDate";
            //ColumnTDate.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnTDate.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            //ColumnTDate.Visible = false;
            ColumnTDate.ReadOnly = true;
            dgv1.Columns.Add(ColumnTDate);

            //Adding  Credit TextBox
            DataGridViewTextBoxColumn ColumnCredit = new DataGridViewTextBoxColumn();
            ColumnCredit.HeaderText = "Amount";
            ColumnCredit.Width = 100;
            ColumnCredit.DataPropertyName = "Credit";
            //ColumnCredit.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnCredit.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            ColumnCredit.ReadOnly = true;
            dgv1.Columns.Add(ColumnCredit);



            //dgv1.Columns[0].Name = "ColumnNum";
            //dgv1.Columns[1].Name = "ColumnControlNoSub";
            //dgv1.Columns[2].Name = "ColumnTDate";
            //dgv1.Columns[3].Name = "ColumnCSeries";
            //dgv1.Columns[4].Name = "ColumnDebit";
            //dgv1.Columns[5].Name = "ColumnCredit";


            // dgv1.Columns[6].Name = "ColumnRTotal";

            //Setting Data Source for DataGridView
            dgv1.DataSource = bindingSource;
            //            dgv1.AutoResizeColumns();
            //            dgv1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            myconnection.Close();
            //            this.WindowState = FormWindowState.Maximized;
            dgv1.AllowUserToAddRows = false;
            dgv1.Columns[6].DefaultCellStyle.Format = "N2";
            dgv1.Columns[5].DefaultCellStyle.Format = "MM/dd/yyyy";

        }

        private void dgv1_CellEnter(object sender, DataGridViewCellEventArgs e)
        {

            DataGridViewRow row = dgv1.Rows[e.RowIndex];
            double varCAmt = double.Parse(row.Cells[6].FormattedValue.ToString());
            pristrDocNum = row.Cells[0].FormattedValue.ToString();
            pristrVoucher = row.Cells[1].FormattedValue.ToString();
            txtCustName.Text = row.Cells[2].FormattedValue.ToString();
            pristrCheckNo = row.Cells[4].FormattedValue.ToString();
            pristrTDate = row.Cells[5].FormattedValue.ToString();
            txtcamount.Text = varCAmt.ToString("N2");

            double waa = double.Parse(txtcamount.Text);
            int wab = (int)waa;

            string wac = (decamout.Calculateamount(waa, wab)).ToString();
            string damtcent = Convert.ToDouble(wac).ToString("N2");
            convertcents cvcnts = new convertcents();
            string dwordcent = cvcnts.getconvertcents(damtcent);

            double a = double.Parse(txtcamount.Text);
            int b = (int)a;
            NumberToWordsConvertor ntwc = new NumberToWordsConvertor();
            string trimdamt = ntwc.NumberToWords(b);
            txtamtinwords.Text = trimdamt.Trim() + " Pesos And " + dwordcent;

        }

  
        
      
        void printDocumentBank(object sender, PrintPageEventArgs e)
        {
            // 0pristrDocNum, 1pristrVoucher, 2pristrCustName,  4pristrCheckNo, 5pristrTDate, 6pristrCredit;

            Graphics graphic = e.Graphics;
            string strDate = pristrTDate;
            string strtxtCustName = txtCustName.Text;
            string strtxtcamount = txtcamount.Text;
            string stramtinword = txtamtinwords.Text;
            string strComputerDoc = pristrVoucher + pristrDocNum;
         
            ClsGetSomething1.ClsGetCheckWriterCheckUp(cboBankCode.SelectedValue.ToString());
            intsizefont = int.Parse(ClsGetSomething1.plssizefont);
            Font font = new Font(ClsGetSomething1.plsFontName, intsizefont);
            
            xstrDate = int.Parse(ClsGetSomething1.plsxstrDate); //|
            ystrDate = int.Parse(ClsGetSomething1.plsystrDate); // _

            xstrtxtCustName = int.Parse(ClsGetSomething1.plsxstrtxtCustName);
            ystrtxtCustName = int.Parse(ClsGetSomething1.plsystrtxtCustName);

            xstrtxtcamount = int.Parse(ClsGetSomething1.plsxstrtxtcamount);
            ystrtxtcamount = int.Parse(ClsGetSomething1.plsystrtxtcamount);

            xstramtinword = int.Parse(ClsGetSomething1.plsxstramtinword);
            ystramtinword = int.Parse(ClsGetSomething1.plsystramtinword);

            xstrComputerDoc = int.Parse(ClsGetSomething1.plsXCompDoc);
            ystrComputerDoc = int.Parse(ClsGetSomething1.plsYCompDoc);

            graphic.DrawString(strDate, font, new SolidBrush(Color.Black), xstrDate, ystrDate);
            graphic.DrawString(strtxtCustName, font, new SolidBrush(Color.Black), xstrtxtCustName, ystrtxtCustName);
            graphic.DrawString(strtxtcamount, font, new SolidBrush(Color.Black), xstrtxtcamount, ystrtxtcamount);
            graphic.DrawString(stramtinword, font, new SolidBrush(Color.Black), xstramtinword, ystramtinword);
            //graphic.DrawString(strComputerDoc, font, new SolidBrush(Color.Black), xstrComputerDoc, ystrComputerDoc);
            //          offset = offset + 20;
        }

       
    

        private void btnPrint_Click(object sender, EventArgs e)
        {
            if (new ClsValidation().emptytxt(txtcamount.Text))
            {
                MessageBox.Show("Please select transaction number", "GL");
                dgv1.Focus();
            }
            else
            {
                PrintDialog printDialog = new PrintDialog();
                PrintDocument printDocument = new PrintDocument();
                printDialog.Document = printDocument;
                printDocument.PrintPage += new PrintPageEventHandler(printDocumentBank);
                printDocument.Print();
            }
        }

        private void nextfieldenter1(object sender, KeyEventArgs e)
        {
            if (e.KeyCode.Equals(Keys.Enter))
            {
                SendKeys.Send("{TAB}");
            }
            else if ((e.KeyCode.Equals(Keys.Up)) || (e.KeyCode.Equals(Keys.Left)))
            {
                SendKeys.Send("+{TAB}");
            }
            else if ((e.KeyCode.Equals(Keys.Down)) || (e.KeyCode.Equals(Keys.Right)))
            {
                SendKeys.Send("{TAB}");
            }

        }

 
        private void btnSettings_Click(object sender, EventArgs e)
        {
            frmCheckSetting frmCheckSetting1 = new frmCheckSetting();
            frmCheckSetting1.Show();
 
        }

   
     
    }
}
