﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TCIGL
{
    public partial class frmListOfPendingJO : Form
    {
        SqlCommand mycommand;
        SqlDataReader dr;
        private SqlDataAdapter da;
        private DataTable dataTable = null;
        private SqlConnection myconnection;
        private BindingSource bindingSource = null;
        BindingSource bsource = new BindingSource();
        string sql;
        ClsPermission ClsPermission1 = new ClsPermission();
        ClsGetConnection ClsGetConnection1 = new ClsGetConnection();
        ClsDefaultBranch ClsDefaultBranch1 = new ClsDefaultBranch();
        string pristrDocNum, pristrIC, pristrRowNum;
        bool pristrCancelItem;
        double ActRemain=0;
        public frmListOfPendingJO()
        {
            InitializeComponent();
        }
        private void LoadData()
        {
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            sql = "SELECT DocNum, TDate, CustName FROM ViewListOfPendingJO WHERE ControlNo = '" + frmVoucherWS.glblcboControlNo.SelectedValue.ToString() + "' AND CNCode='" + ClsDefaultBranch1.plsvardb + "' ORDER BY DocNum ASC";

            da = new SqlDataAdapter(sql, myconnection);
            SqlCommandBuilder commandBuilder = new SqlCommandBuilder(da);

            dataTable = new DataTable();
            da.Fill(dataTable);
            bindingSource = new BindingSource();
            bindingSource.DataSource = dataTable;

            //Adding  DocNum TextBox
            DataGridViewTextBoxColumn ColumnDocNum = new DataGridViewTextBoxColumn();
            ColumnDocNum.HeaderText = "Number";
            ColumnDocNum.Width = 80;
            ColumnDocNum.DataPropertyName = "DocNum";
            ColumnDocNum.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            ColumnDocNum.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            //ColumnCatCode.Visible = false;
            ColumnDocNum.ReadOnly = true;
            dgv1.Columns.Add(ColumnDocNum);

            //Adding  Date TextBox
            DataGridViewTextBoxColumn ColumnTDate = new DataGridViewTextBoxColumn();
            ColumnTDate.HeaderText = "Date";
            ColumnTDate.Width = 80;
            ColumnTDate.DataPropertyName = "TDate";
            ColumnTDate.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            ColumnTDate.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnTDate.ReadOnly = true;
            dgv1.Columns.Add(ColumnTDate);

            //Column Customer
            DataGridViewTextBoxColumn ColumnCustName = new DataGridViewTextBoxColumn();
            ColumnCustName.HeaderText = "Name";
            //ColumnItem.Width = 80;
            ColumnCustName.DataPropertyName = "CustName";
            ColumnCustName.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            ColumnCustName.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            ColumnCustName.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            ColumnCustName.ReadOnly = true;
            dgv1.Columns.Add(ColumnCustName);

            //Setting Data Source for DataGridView
            dgv1.DataSource = bindingSource;
            //dgv1.AutoResizeColumns();
            //dgv1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            myconnection.Close();
            //this.WindowState = FormWindowState.Maximized;
            dgv1.AllowUserToAddRows = false;
        }
        private void btnclose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    

        private void dgv1_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            pristrDocNum = dgv1.CurrentRow.Cells[0].Value.ToString();
        }

        private void dgv1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            //transferheadingdata();
            DisplayDetailsJO();
        }

        private void PosttoPD()
        {
           // frmVoucherPD.glbltxtPONumber.Text = dgv1.CurrentRow.Cells[0].Value.ToString();
            
            //DataGridViewRow row1 = null;
            for (int x = 0; x < dgv2.Rows.Count; x++)
            {
               // string strPPDPDisct, strPPDActDisct, strPPDVAT, strPPDTotal, strPPDCost;
                //string strOrigQty= dgv2.Rows[x].Cells[2].FormattedValue.ToString();
               // string strD1 = dgv2.Rows[x].Cells[0].FormattedValue.ToString();
                string strStockNumber = dgv2.Rows[x].Cells[0].FormattedValue.ToString();
                string strDescription = dgv2.Rows[x].Cells[1].FormattedValue.ToString();
                string strQty = dgv2.Rows[x].Cells[3].FormattedValue.ToString();
                //string strUM = dgv2.Rows[x].Cells[4].FormattedValue.ToString();
                string strUP = dgv2.Rows[x].Cells[4].FormattedValue.ToString();
                //string strTotal=dgv2.Rows[x].Cells[6].FormattedValue.ToString();
                double Total = (Convert.ToDouble(dgv2.Rows[x].Cells[3].Value) * Convert.ToDouble(dgv2.Rows[x].Cells[4].Value));
                //string strPDisct = dgv2.Rows[x].Cells[6].FormattedValue.ToString();
               
                //string strD2 = "0";
                //string strD3 = "0";
                //string strBatchNo = "NA";
               // string strExpDate = "NA";
               // string strRemainQty = dgv2.Rows[x].Cells[13].FormattedValue.ToString();
               // string strIC = dgv2.Rows[x].Cells[15].FormattedValue.ToString();
               // string strRowNum = dgv2.Rows[x].Cells[16].FormattedValue.ToString();
               
                //if (double.Parse(strPDisct)==0)
                //{
                //    strPPDPDisct = "0.00";
                //}
                //else
                //{
                //    strPPDPDisct = ((double.Parse(strPDisct) / double.Parse(strOrigQty)) * double.Parse(strQty)).ToString("N2");
                //}

                //string strActDisct = dgv2.Rows[x].Cells[7].FormattedValue.ToString();
                //if (double.Parse(strActDisct) == 0)
                //{
                //    strPPDActDisct = "0.00";
                //}
                //else
                //{
                //    strPPDActDisct = ((double.Parse(strActDisct) / double.Parse(strOrigQty)) * double.Parse(strQty)).ToString("N2");
                //}

                //string strVAT = dgv2.Rows[x].Cells[8].FormattedValue.ToString();
                //if (double.Parse(strVAT) == 0)
                //{
                //    strPPDVAT = "0.00";
                //}
                //else
                //{
                //    strPPDVAT = ((double.Parse(strVAT) / double.Parse(strOrigQty)) * double.Parse(strQty)).ToString("N2");
                //}

                //string strTotal = dgv2.Rows[x].Cells[9].FormattedValue.ToString();
                //if (double.Parse(strTotal) == 0)
                //{
                //    strPPDTotal = "0.00";
                //}
                //else
                //{
                //    strPPDTotal = ((double.Parse(strTotal) / double.Parse(strOrigQty)) * double.Parse(strQty)).ToString("N2");
                //}

                //string strCost = dgv2.Rows[x].Cells[10].FormattedValue.ToString();
                //if (double.Parse(strCost) == 0)
                //{
                //    strPPDCost = "0.00";
                //}
                //else
                //{
                //    strPPDCost = ((double.Parse(strCost) / double.Parse(strOrigQty)) * double.Parse(strQty)).ToString("N2");
                //}
                //row1 = dgv2.Rows[x];
                //frmVoucherPD.glbldgv2.Rows.Add(strD1, strStockNumber, strDescription, strQty, strUP, strPPDPDisct, strPPDActDisct, strPPDVAT, strPPDTotal, strPPDCost);
                frmVoucherWS.glbldgv2.Rows.Add(strStockNumber, strDescription, 0, strQty, strUP, Total);

            }
            dgv2total();
            this.Close();
        }
        private void transferheadingdata()
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();
                mycommand = new SqlCommand("SELECT * FROM ViewDetailsBookPOUnserved WHERE DocNum = '" + pristrDocNum + "' AND CNCode='" + ClsDefaultBranch1.plsvardb + "'", myconnection);
                dr = mycommand.ExecuteReader();
                while (dr.Read())
                {
                    //frmVoucherPD.glbltxtTDate.Text = DateTime.Parse(dr["TDate"].ToString()).ToString();
                    //frmVoucherPD.glbltxtreference.Text = dr["Reference"].ToString();
                    frmVoucherPD.glblcboControlNo.SelectedValue = dr["Controlno"].ToString();
                    frmVoucherPD.glbltxtTerm.Text = dr["Term"].ToString();
                    frmVoucherPD.glbltxtRemarks.Text = dr["Remarks"].ToString();
                    frmVoucherPD.glbltxtPONumber.Text = dr["DocNum"].ToString();

                }
                dr.Close();
                myconnection.Close();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                dr.Close();
                myconnection.Close();
            }
        }

        private void DisplayDetailsJO()
        {
            dgv2.DataSource = null;
            dgv2.Columns.Clear();

            string sql;
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            //sql = "SELECT D1, StockNumber, StockDesc, PIn, UM, UP, PDisct, ActDisct, VAT, (UP*PIn) As Total, Cost, RQty, AQty, TRQty, CancelItem, IC, RowNum FROM ViewDetailsBookPOUnserved WHERE DocNum = '" + pristrDocNum + "' AND CNCode='" + ClsDefaultBranch1.plsvardb + "'";
            sql = "SELECT StockNumber, StockDesc, POut, UP, (UP*POut) As Total, IC, RowNum FROM ViewDetailsBookPIUnserved WHERE DocNum = '" + pristrDocNum + "' AND CNCode='" + ClsDefaultBranch1.plsvardb + "'";
            da = new SqlDataAdapter(sql, myconnection);
            SqlCommandBuilder commandBuilder = new SqlCommandBuilder(da);

            dataTable = new DataTable();
            da.Fill(dataTable);
            bindingSource = new BindingSource();
            bindingSource.DataSource = dataTable;

            //Adding  dgv2StockNumber TextBox
            DataGridViewTextBoxColumn Columndgv2StockNumber = new DataGridViewTextBoxColumn();
            Columndgv2StockNumber.HeaderText = "Code";
            Columndgv2StockNumber.Width = 85;
            Columndgv2StockNumber.DataPropertyName = "StockNumber";
            Columndgv2StockNumber.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            Columndgv2StockNumber.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            Columndgv2StockNumber.ReadOnly = true;
            dgv2.Columns.Add(Columndgv2StockNumber);

            //Adding  dgv2StockDesc TextBox
            DataGridViewTextBoxColumn Columndgv2StockDesc = new DataGridViewTextBoxColumn();
            Columndgv2StockDesc.HeaderText = "Description";
            Columndgv2StockDesc.Width = 250;
            Columndgv2StockDesc.DataPropertyName = "StockDesc";
            Columndgv2StockDesc.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            Columndgv2StockDesc.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            Columndgv2StockDesc.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            Columndgv2StockDesc.ReadOnly = true;
            dgv2.Columns.Add(Columndgv2StockDesc);

            //Adding  dgv2PIn TextBoxPIn
            DataGridViewTextBoxColumn Columndgv2POut = new DataGridViewTextBoxColumn();
            Columndgv2POut.HeaderText = "Qty";
            Columndgv2POut.Width = 45;
            Columndgv2POut.DataPropertyName = "POut";
            Columndgv2POut.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            Columndgv2POut.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            Columndgv2POut.ReadOnly = true;
            dgv2.Columns.Add(Columndgv2POut);

            //Adding  dgv2UP TextBox
            DataGridViewTextBoxColumn Columndgv2UP = new DataGridViewTextBoxColumn();
            Columndgv2UP.HeaderText = "U. Price";
            Columndgv2UP.Width = 75;
            Columndgv2UP.DataPropertyName = "UP";
            Columndgv2UP.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            Columndgv2UP.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            Columndgv2UP.ReadOnly = true;
            dgv2.Columns.Add(Columndgv2UP);

       
            DataGridViewTextBoxColumn Columndgv2Total = new DataGridViewTextBoxColumn();
            Columndgv2Total.HeaderText = "Total";
            Columndgv2Total.Width = 80;
            Columndgv2Total.DataPropertyName = "Total";
            Columndgv2Total.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            Columndgv2Total.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            Columndgv2Total.ReadOnly = true;
            dgv2.Columns.Add(Columndgv2Total);

            //Adding  dgv2IC TextBox
            DataGridViewTextBoxColumn Columndgv2IC = new DataGridViewTextBoxColumn();
            Columndgv2IC.HeaderText = "IC";
            Columndgv2IC.Width = 35;
            Columndgv2IC.DataPropertyName = "IC";
            Columndgv2IC.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            Columndgv2IC.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            Columndgv2IC.Visible = false;
            dgv2.Columns.Add(Columndgv2IC);

            //Adding  dgv2RowNum TextBox
            DataGridViewTextBoxColumn Columndgv2RowNum = new DataGridViewTextBoxColumn();
            Columndgv2RowNum.HeaderText = "RowNum";
            Columndgv2RowNum.Width = 35;
            Columndgv2RowNum.DataPropertyName = "RowNum";
            Columndgv2RowNum.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            Columndgv2RowNum.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            Columndgv2RowNum.Visible = false;
            dgv2.Columns.Add(Columndgv2RowNum);



            //Setting Data Source for DataGridView
            dgv2.DataSource = bindingSource;
            //            dgv1.AutoResizeColumns();
            //            dgv1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            myconnection.Close();
            //            this.WindowState = FormWindowState.Maximized;
            //            dgv1.AllowUserToAddRows = true;

            //dgv2.Columns[3].DefaultCellStyle.Format = "N2";
            //dgv2.Columns[5].DefaultCellStyle.Format = "N2";
            //dgv2.Columns[6].DefaultCellStyle.Format = "N2";
            //dgv2.Columns[7].DefaultCellStyle.Format = "N2";
            //dgv2.Columns[8].DefaultCellStyle.Format = "N2";
            //dgv2.Columns[9].DefaultCellStyle.Format = "N2";
            //dgv2.Columns[10].DefaultCellStyle.Format = "N2";
            //dgv2.Columns[11].DefaultCellStyle.Format = "N2";
            //dgv2.Columns[12].DefaultCellStyle.Format = "N2";
            //dgv2.Columns[13].DefaultCellStyle.Format = "N2";
           
            //DataGridViewRow row = null;
            //for (int x = 0; x < dgv2.Rows.Count; x++)
            //{
            //    row = dgv2.Rows[x];
            //    ActRemain = Convert.ToDouble(row.Cells[11].FormattedValue.ToString());
            //    row.Cells[13].Value = ActRemain;
            //}
        }

        //row.Cells[13].Value=row.Cells[11].FormattedValue.ToString();
        //row.Cells[13].Value = row.Cells[11].Value.ToString();
        //row.Cells[13].Value = dgv2.CurrentRow.Cells[11].Value;
        //double ActRemain = Convert.ToDouble(dgv2.CurrentRow.Cells[11].Value);
        //dgv2.CurrentRow.Cells[13].Value = ActRemain - ActDelivered;
        //string strCost = dgv2.Rows[x].Cells[10].FormattedValue.ToString();
        //double varin = double.Parse(dgv2.Rows[x].Cells[3].Value.ToString());
        //double varTCost = double.Parse(dgv2.Rows[x].Cells[9].Value.ToString());
        //double varTVAT = double.Parse(dgv2.Rows[x].Cells[7].Value.ToString());
        //ClsGetSomething1.ClsGetAT(row.Cells[0].Value.ToString());
        //row.Cells[1].Value = ClsGetSomething1.plsAT;
        //dgv1.CurrentRow.Cells[2].Value = "NA";
        //dgv1.CurrentRow.Cells[3].Value = txtreference.Text;

        private void DeliveredAll()
        {
            DataGridViewRow row = null;
            for (int x = 0; x < dgv2.Rows.Count; x++)
            {
                row = dgv2.Rows[x];
                ActRemain = Convert.ToDouble(row.Cells[11].FormattedValue.ToString());

                row.Cells[12].Value = ActRemain;
                row.Cells[13].Value = 0.00;
            }
        }
        private void dgv2total()
        {
            //double dbltxtTotDisct = 0;
            //double dbltxtTotalVAT = 0;
            //double dbltxtTotCost = 0;
            {
                //for (int x = 0; x < frmVoucherPD.glbldgv2.Rows.Count - 1; x++)
                //{
                //    //string vartxtD1 = frmVoucherPD.glbldgv2.Rows[x].Cells[5].FormattedValue.ToString();
                //    //string vartxtD2 = frmVoucherPD.glbldgv2.Rows[x].Cells[6].FormattedValue.ToString();
                //    //dbltxtTotDisct += double.Parse(vartxtD1) + double.Parse(vartxtD2);
                //}
                //for (int x = 0; x < frmVoucherPD.glbldgv2.Rows.Count - 1; x++)
                //{
                //    dbltxtTotalVAT += double.Parse(frmVoucherPD.glbldgv2.Rows[x].Cells[7].FormattedValue.ToString());
                //}

                //for (int x = 0; x < frmVoucherPD.glbldgv2.Rows.Count - 1; x++)
                //{
                //    dbltxtTotCost += double.Parse(frmVoucherPD.glbldgv2.Rows[x].Cells[9].FormattedValue.ToString());
                //}

                //frmVoucherPD.glbltxtTotDisct.Text = dbltxtTotDisct.ToString("N2");
                //frmVoucherPD.glbltxtTotalVAT.Text = dbltxtTotalVAT.ToString("N2");
                //frmVoucherPD.glbltxtTotCost.Text = dbltxtTotCost.ToString("N2");
            }
        }

        private void btnPost_Click(object sender, EventArgs e)
        {
           //try
           // {
                //ClsGetConnection1.ClsGetConMSSQL();
                //myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                //myconnection.Open();

                //DataGridViewRow row = null;
                //for (int x = 0; x < dgv2.Rows.Count; x++)
                //{
                //    row = dgv2.Rows[x];
                //    string strRemainQty = row.Cells[13].Value.ToString();
                //    pristrIC = row.Cells[15].FormattedValue.ToString();
                //    pristrRowNum = row.Cells[16].FormattedValue.ToString();
                //    string sqlstatement = "UPDATE tblPO2 SET Rqty=@_Rqty WHERE IC ='" + pristrIC + "' AND RowNum = '" + pristrRowNum + "'";
                //    mycommand = new SqlCommand(sqlstatement, myconnection);
                //    mycommand.Parameters.Add("_Rqty", SqlDbType.Int).Value = strRemainQty;
                //    int n1 = mycommand.ExecuteNonQuery();
                //}
                //myconnection.Close();
                PosttoPD();
            //}
           //catch (Exception exceptionObj)
           //{
           //    MessageBox.Show(exceptionObj.Message.ToString());
           //}
        }

        private void btnDeliveredAll_Click(object sender, EventArgs e)
        {
          //  DeliveredAll();
        }

        private void dgv2_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            double ActRemain = Convert.ToDouble(dgv2.CurrentRow.Cells[11].Value); 
            double ActDelivered = Convert.ToDouble(dgv2.CurrentRow.Cells[12].Value); 
            
            dgv2.CurrentRow.Cells[13].Value = ActRemain-ActDelivered;
        }

        private void btnCancelItem_Click(object sender, EventArgs e)
        {
            try
            {
                ClsGetConnection1.ClsGetConMSSQL();
                myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
                myconnection.Open();

                DataGridViewRow row = null;
                for (int x = 0; x < dgv2.Rows.Count; x++)
                {
                    row = dgv2.Rows[x];
                    pristrCancelItem = Convert.ToBoolean(row.Cells[14].Value.ToString());
                    pristrIC = row.Cells[15].FormattedValue.ToString();
                    pristrRowNum = row.Cells[16].FormattedValue.ToString();
                    string sqlstatement = "UPDATE tblPO2 SET CancelItem=@_CancelItem WHERE IC ='" + pristrIC + "' AND RowNum = '" + pristrRowNum + "'";
                    mycommand = new SqlCommand(sqlstatement, myconnection);
                    mycommand.Parameters.Add("_CancelItem", SqlDbType.Bit).Value = pristrCancelItem;
                    int n1 = mycommand.ExecuteNonQuery();
                }
                myconnection.Close();
                MessageBox.Show("Saved", "GL");
                DisplayDetailsJO();

            }
            catch (Exception exceptionObj)
            {
                MessageBox.Show(exceptionObj.Message.ToString());
            }
        }

        private void frmListOfPendingJO_Load_1(object sender, EventArgs e)
        {
            ClsPermission1.ClsObjects(this.Text);
            if (new ClsValidation().emptytxt(ClsPermission1.plstxtObject))
            {
                MessageBox.Show("You do not have necessary permission to open this file", "GL");
                this.Close();
            }
            else
            {
                LoadData();
            }
        }
    }
}
