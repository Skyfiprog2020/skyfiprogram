﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TCIGL
{
    public partial class frmEntrySupplierAdd : Form
    {
        SqlConnection myconnection;
        SqlCommand mycommand;
        //BindingSource dbind = new BindingSource();
        ClsDefaultBranch ClsDefaultBranch1  = new ClsDefaultBranch();
        ClsAutoNumber ClsAutoNumber1 = new ClsAutoNumber();
        ClsValidation ClsValidation1 = new ClsValidation();
        ClsBuildComboBox ClsBuildComboBox1 = new ClsBuildComboBox();
        ClsBuildEntryComboBox ClsBuildEntryComboBox1 = new ClsBuildEntryComboBox(); 
        ClsGetConnection ClsGetConnection1 = new ClsGetConnection();
        ClsPermission ClsPermission1 = new ClsPermission(); 
        public frmEntrySupplierAdd()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmNameAdd_Load(object sender, EventArgs e)
        {
            ClsPermission1.ClsObjects(this.Text);
            if (new ClsValidation().emptytxt(ClsPermission1.plstxtObject))
            {
                MessageBox.Show("You do not have necessary permission to open this file", "GL");
                this.Close();
            }
            else
            {
                ClsAutoNumber1.SupplierAdd();
                txtCustCode.Text = (ClsAutoNumber1.plsnumber);
                buildcboChannelCode();
                buildcboGACode();
                buildcboSMCode();
                buildcboSPCode();
            }

        }

        private void buildcboChannelCode()
        {
            cboChannelCode.DataSource = null;
            ClsBuildEntryComboBox1.ARChannelCode.Clear();
            ClsBuildEntryComboBox1.ClsBuildChannelCode();
            this.cboChannelCode.DataSource = (ClsBuildEntryComboBox1.ARChannelCode);
            this.cboChannelCode.DisplayMember = "Display";
            this.cboChannelCode.ValueMember = "Value";
        }

        private void buildcboGACode()
        {
            cboGACode.DataSource = null;
            ClsBuildEntryComboBox1.ARGACode.Clear();
            ClsBuildEntryComboBox1.ClsBuildGACode();
            this.cboGACode.DataSource = (ClsBuildEntryComboBox1.ARGACode);
            this.cboGACode.DisplayMember = "Display";
            this.cboGACode.ValueMember = "Value";
        }
        private void buildcboSMCode()
        {
            cboSMCode.DataSource = null;
            ClsBuildEntryComboBox1.ARSMCode.Clear();
            ClsBuildEntryComboBox1.ClsBuildSalesman();
            this.cboSMCode.DataSource = (ClsBuildEntryComboBox1.ARSMCode);
            this.cboSMCode.DisplayMember = "Display";
            this.cboSMCode.ValueMember = "Value";
        }

        private void buildcboSPCode()
        {
            cboSPCode.DataSource = null;
            ClsBuildEntryComboBox1.ARSPCode.Clear();
            ClsBuildEntryComboBox1.ClsBuildSPCode();
            this.cboSPCode.DataSource = (ClsBuildEntryComboBox1.ARSPCode);
            this.cboSPCode.DisplayMember = "Display";
            this.cboSPCode.ValueMember = "Value";
        }
        private void savedata()
        {
            try
            {
            ClsGetConnection1.ClsGetConMSSQL();
            myconnection = new SqlConnection(ClsGetConnection1.plsMyConMSSQL);
            myconnection.Open();
            
                if (new Clsexist().RecordExists(ref myconnection, "SELECT CustName FROM tblCustomer WHERE CustName = '" + txtCustName.Text + "'"))
                {
                    myconnection.Close();
                    MessageBox.Show("Duplicate customer name", "GL");
                    txtCustName.Focus();
                }
     
                else if (new ClsValidation().emptytxt(txtCustName.Text))
                {
                    myconnection.Close();
                    MessageBox.Show("Please complete your entry", "GL");
                    txtCustName.Focus();
                }
                else if (new ClsValidation().emptytxt(txtContactNo.Text))
                {
                    myconnection.Close();
                    MessageBox.Show("Please complete your entry", "GL");
                    txtContactNo.Focus();
                }
                else if (new ClsValidation().emptytxt(txtAddress.Text))
                {
                    myconnection.Close();
                    MessageBox.Show("Please complete your entry", "GL");
                    txtAddress.Focus();
                }
                else if (new ClsValidation().emptytxt(cboChannelCode.Text))
                {
                    myconnection.Close();
                    MessageBox.Show("Please complete your entry", "GL");
                    cboChannelCode.Focus();
                }
                else if (new ClsValidation().emptytxt(cboGACode.Text))
                {
                    myconnection.Close();
                    MessageBox.Show("Please complete your entry", "GL");
                    cboGACode.Focus();
                }
                else if (new ClsValidation().emptytxt(cboSMCode.Text))
                {
                    myconnection.Close();
                    MessageBox.Show("Please complete your entry", "GL");
                    cboSMCode.Focus();
                }
                else if (new ClsValidation().emptytxt(txtContactPerson.Text))
                {
                    myconnection.Close();
                    MessageBox.Show("Please complete your entry", "GL");
                    txtContactPerson.Focus();
                }
                else if (new ClsValidation().emptytxt(txtTIN.Text))
                {
                    myconnection.Close();
                    MessageBox.Show("Please complete your entry", "GL");
                    txtTIN.Focus();
                }
                else if (new ClsValidation().emptytxt(cboSPCode.Text))
                {
                    myconnection.Close();
                    MessageBox.Show("Please complete your entry", "GL");
                    cboSPCode.Focus();
                }
                else
                {
                    ClsAutoNumber1.SupplierAdd();
                    txtCustCode.Text = (ClsAutoNumber1.plsnumber);
   
                    string sqlstatement;
                    sqlstatement = "INSERT INTO tblCustomer (ControlNo, CustCode, CustName, ContactNo, Address, ChannelCode, GACode, SMCode, Term, CreditLimit, NType, ContactPerson, TIN, SPCode, CNCode, CollectCode) ";
                    sqlstatement += "Values (@_ControlNo, @_CustCode, @_CustName, @_ContactNo, @_Address, @_ChannelCode, @_GACode, @_SMCode, @_Term, @_CreditLimit, @_NType, @_ContactPerson, @_TIN, @_SPCode, @_CNCode, @_CollectCode) ";

                    mycommand = new SqlCommand(sqlstatement, myconnection);
                    mycommand.Parameters.Add("_ControlNo", SqlDbType.VarChar).Value = txtCustCode.Text + (ClsDefaultBranch1.plsvardb) + "S";
                    mycommand.Parameters.Add("_CustCode", SqlDbType.VarChar).Value = txtCustCode.Text;
                    mycommand.Parameters.Add("_CustName", SqlDbType.VarChar).Value = txtCustName.Text;
                    mycommand.Parameters.Add("_ContactNo", SqlDbType.VarChar).Value = txtContactNo.Text;
                    mycommand.Parameters.Add("_Address", SqlDbType.VarChar).Value = txtAddress.Text;
                    mycommand.Parameters.Add("_ChannelCode", SqlDbType.VarChar).Value = cboChannelCode.SelectedValue.ToString();
                    mycommand.Parameters.Add("_GACode", SqlDbType.VarChar).Value = cboGACode.SelectedValue.ToString();
                    mycommand.Parameters.Add("_SMCode", SqlDbType.VarChar).Value = cboSMCode.SelectedValue.ToString();
                    mycommand.Parameters.Add("_Term", SqlDbType.Int).Value = txtTerm.Text;
                    mycommand.Parameters.Add("_CreditLimit", SqlDbType.Money).Value = txtCreditLimit.Text;
                    mycommand.Parameters.Add("_NType", SqlDbType.VarChar).Value = "S";
                    mycommand.Parameters.Add("_ContactPerson", SqlDbType.VarChar).Value = txtContactPerson.Text;
                    mycommand.Parameters.Add("_TIN", SqlDbType.VarChar).Value = txtTIN.Text;
                    mycommand.Parameters.Add("_SPCode", SqlDbType.VarChar).Value = cboSPCode.SelectedValue.ToString();
                    mycommand.Parameters.Add("_CNCode", SqlDbType.VarChar).Value = (ClsDefaultBranch1.plsvardb);
                    mycommand.Parameters.Add("_CollectCode", SqlDbType.VarChar).Value = "001";
                    int n1 = mycommand.ExecuteNonQuery();

                    ClsAutoNumber1.SupplierAdd();
                    txtCustCode.Text = (ClsAutoNumber1.plsnumber);
                    myconnection.Close();
                    ClearScreen();
                    }
                }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                //  dr.Close();
                myconnection.Close();
            }
        }

        private void ClearScreen()
        {
            txtCustName.Clear();
            txtCustName.Focus();
            txtContactNo.Clear();
            txtAddress.Clear();
            txtTerm.Text = "0";
            txtCreditLimit.Text = "0.00";
            txtContactPerson.Text = "";
            txtTIN.Text = "";
        }
         private void btnSave_Click(object sender, EventArgs e)
        {
            savedata();
        }

     

     

         private void txtTerm_Validating(object sender, CancelEventArgs e)
         {
             if (new ClsValidation().isInt(txtTerm.Text) == true)
             {
                 MessageBox.Show("Invalid Number", "GL");
                 txtTerm.Focus();
             }

         }

         private void txtCreditLimit_Validating(object sender, CancelEventArgs e)
         {
             if (new ClsValidation().isDouble(txtCreditLimit.Text) == true)
             {
                 MessageBox.Show("Invalid Number", "GL");
                 txtCreditLimit.Focus();
             }
             else
             {
                 txtCreditLimit.Text = Convert.ToDouble(txtCreditLimit.Text).ToString("N2");
             }
         }

         private void nextfieldenter2(object sender, KeyEventArgs e)
         {
             if (e.KeyCode.Equals(Keys.Enter))
             {
                 SendKeys.Send("{TAB}");
             }

         }

         private void nextfieldenter1(object sender, KeyEventArgs e)
         {
             if (e.KeyCode.Equals(Keys.Enter))
             {
                 SendKeys.Send("{TAB}");
             }
             else if ((e.KeyCode.Equals(Keys.Up)) || (e.KeyCode.Equals(Keys.Left)))
             {
                 SendKeys.Send("+{TAB}");
             }
             else if ((e.KeyCode.Equals(Keys.Down)) || (e.KeyCode.Equals(Keys.Right)))
             {
                 SendKeys.Send("{TAB}");
             }
         }
      
    }
}
